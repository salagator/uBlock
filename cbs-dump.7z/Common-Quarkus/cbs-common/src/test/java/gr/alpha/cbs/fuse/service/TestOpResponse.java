package gr.alpha.cbs.fuse.service;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "barfoo"
})
@XmlRootElement(name = "TestOpResponse")
public class TestOpResponse {
    @XmlElement(name = "barfoo", required = true)
    protected String barfoo;

    public String getBarfoo() {
        return barfoo;
    }

    public void setBarfoo(String barfoo) {
        this.barfoo = barfoo;
    }
}
