package gr.alpha.cbs.fuse.service;

import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import io.quarkus.test.junit.QuarkusTest;
import net.sf.saxon.dom.DocumentBuilderImpl;
import net.sf.saxon.xpath.XPathFactoryImpl;
import org.apache.camel.CamelContext;
import org.apache.camel.impl.DefaultCamelContext;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import static org.junit.jupiter.api.Assertions.assertEquals;

// This test is here because not all converters are loaded in the cbs-common-lib library
// where FormatUtils belongs. This is probably because of missing dependencies in the
// cbs-common-lib library.

@QuarkusTest
public class FormatUtilsTest {

    @Test
    public void testPartialNoNamespaceXPath() throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        DocumentBuilder documentBuilder = dbf.newDocumentBuilder();
        Document doc = documentBuilder.parse(this.getClass().getResourceAsStream("/FormatUtilsNSTest.xml"));
        int counter = Integer.parseInt(FormatUtils.getValue(doc, "/*:GetSeizuresByAccountOrTaxIDPayload/confiscationGetResponse/counter"));
        assertEquals(1, counter);
    }

    @Test
    public void testPartialNoNamespaceXPathCamel() throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (InputStream is = this.getClass().getResourceAsStream("/FormatUtilsNSTest.xml")) {
            int readCount;
            byte[] buffer = new byte[1024];
            while ((readCount = is.read(buffer)) != -1) {
                baos.write(buffer, 0, readCount);
            }
            try (CamelContext ctx = new DefaultCamelContext()) {
                ctx.start();
                Document doc = ctx.getTypeConverter().convertTo(Document.class, baos.toString());
                int counter = Integer.parseInt(FormatUtils.getValue(doc, "/*:GetSeizuresByAccountOrTaxIDPayload/confiscationGetResponse/counter"));
                assertEquals(1, counter);
            }
        }
    }

    @Test
    public void testPartialNoNamespaceXPathSaxon() throws Exception {
        XPathFactoryImpl xPathFactory = (XPathFactoryImpl) FormatUtils.getXPathFactory();
        DocumentBuilderImpl documentBuilder = new DocumentBuilderImpl();
        documentBuilder.setConfiguration(xPathFactory.getConfiguration());
        Document doc = documentBuilder.parse(this.getClass().getResourceAsStream("/FormatUtilsNSTest.xml"));
        int counter = Integer.parseInt(FormatUtils.getValue(doc, "/*:GetSeizuresByAccountOrTaxIDPayload/confiscationGetResponse/counter"));
        assertEquals(1, counter);
    }

}
