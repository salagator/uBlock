package gr.alpha.cbs.fuse.service;

/*
 * This should normally implement AbstractCamelRouteDrivingJSONServlet, BUT this throws the
 * most interesting: Absent Code attribute in method that is not native or abstract in class file javax/servlet/http/HttpServlet
 * so, bypassing the HttpServlet (which is not needed for testing anyway) by
 * extracting the serialization and deserialization methods in a default interface
 * implementation and using this here.
 */
public class TestingCamelRouteDrivingJSONServlet implements SerializationHelper {

    @Override
    public String getPackageName() {
        return "gr.alpha.cbs.fuse.service";
    }

}
