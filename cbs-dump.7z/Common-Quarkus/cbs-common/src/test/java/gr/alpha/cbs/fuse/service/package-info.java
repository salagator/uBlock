@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://www.example.org/testop", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package gr.alpha.cbs.fuse.service;