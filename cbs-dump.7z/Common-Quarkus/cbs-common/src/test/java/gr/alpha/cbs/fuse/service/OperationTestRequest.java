package gr.alpha.cbs.fuse.service;

public class OperationTestRequest {
    private OperationTestRequestPayload payload;

    public void setPayload(OperationTestRequestPayload payload) {
        this.payload = payload;
    }

    public OperationTestRequestPayload getPayload() {
        return payload;
    }
}
