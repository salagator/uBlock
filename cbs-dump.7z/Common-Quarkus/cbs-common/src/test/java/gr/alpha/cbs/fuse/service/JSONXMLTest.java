package gr.alpha.cbs.fuse.service;

import static org.junit.jupiter.api.Assertions.assertTrue;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.ObjectWriter;
import io.quarkus.test.junit.QuarkusTest;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@QuarkusTest
public class JSONXMLTest {

    @Test
    public void testJSONSerialization() throws JAXBException, IOException, ParserConfigurationException, ClassNotFoundException, TransformerException {
        TestingCamelRouteDrivingJSONServlet testObject = new TestingCamelRouteDrivingJSONServlet();

        ObjectMapper mapper = new ObjectMapper();
        Map<String, JAXBContext> jaxbContextMap = new HashMap<>();
        Map<String, ObjectReader> objectReaderMap = new HashMap<>();
        InputStream inputStream = IOUtils.toInputStream("{\"foobar\":\"this is a test\"}", StandardCharsets.UTF_8);
        Document inputDocument = testObject.getInputDocument(inputStream, "TestOp", mapper, jaxbContextMap, objectReaderMap);

        DOMSource domSource = new DOMSource(inputDocument);
        StringWriter writer = new StringWriter();
        StreamResult result = new StreamResult(writer);
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        transformer.transform(domSource, result);

        System.out.println("Result is: " + writer);

        assertTrue("<?xml version=\"1.0\" encoding=\"UTF-8\"?><TestOp xmlns=\"http://www.example.org/testop\"><foobar>this is a test</foobar></TestOp>".equals(writer.toString()), "The result does not match");
    }

    @Test
    public void testJSONDeserialization() throws ParserConfigurationException, JAXBException, IOException, ClassNotFoundException {
        TestingCamelRouteDrivingJSONServlet testObject = new TestingCamelRouteDrivingJSONServlet();

        String namespace = "http://www.example.org/testop";
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document responseDocument = db.newDocument();
        Element rootElement = responseDocument.createElementNS(namespace, "TestOpResponse");
        responseDocument.appendChild(rootElement);
        Element barfooElement = responseDocument.createElementNS(namespace, "barfoo");
        rootElement.appendChild(barfooElement);
        barfooElement.setTextContent("This is a test");

        ObjectMapper mapper = new ObjectMapper();
        Map<String, JAXBContext> jaxbContextMap = new HashMap<>();
        Map<String, ObjectWriter> objectWriterMap = new HashMap<>();
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        testObject.writeOutputDocument(outputStream, "TestOp", responseDocument, mapper, jaxbContextMap, objectWriterMap);

        String result = outputStream.toString("UTF-8");
        System.out.println("Result is: " + result);

        assertTrue("{\"barfoo\":\"This is a test\"}".equals(result), "The result does not match");
    }

}
