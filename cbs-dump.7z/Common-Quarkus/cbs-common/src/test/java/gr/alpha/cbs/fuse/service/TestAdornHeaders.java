package gr.alpha.cbs.fuse.service;

import static org.junit.jupiter.api.Assertions.assertTrue;

import gr.alpha.cbs.domain.Container;
import gr.alpha.cbs.domain.EnvParamsType;
import gr.alpha.cbs.domain.LoggingInfoType;
import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

import java.util.UUID;

@QuarkusTest
public class TestAdornHeaders {

    @Test
    public void testAdornHeaders() {
        OperationTestRequest request = new OperationTestRequest();
        request.setPayload(new OperationTestRequestPayload());
        request.getPayload().setSomeRandomTestClass(new SomeRandomTestClass());
        request.getPayload().getSomeRandomTestClass().setName("foo");

        String requestId = UUID.randomUUID().toString();
        String dateAsString = "2023-01-01";

        HarnessRESTAPI restapi = new HarnessRESTAPI();
        restapi.optionallyCallAdornHeaders(request, requestId, "Some User", null, null, "",
                container -> {
                    Container returnContainer = new Container();
                    returnContainer.setLoggingInfo(new LoggingInfoType());
                    returnContainer.getLoggingInfo().setRequestId(container.getLoggingInfo().getRequestId());
                    returnContainer.getLoggingInfo().setSessionId(UUID.randomUUID().toString());
                    returnContainer.getLoggingInfo().setBusinessCaseId(UUID.randomUUID().toString());
                    returnContainer.getLoggingInfo().setSequenceId("1");
                    returnContainer.getLoggingInfo().setUserId(container.getLoggingInfo().getUserId());
                    returnContainer.getLoggingInfo().setCBSUnId(UUID.randomUUID().toString());
                    returnContainer.setEnvParams(new EnvParamsType());
                    returnContainer.getEnvParams().setWorkingDate(dateAsString);
                    returnContainer.getEnvParams().setPreviousWorkingDate(dateAsString);
                    returnContainer.getEnvParams().setNextWorkingDate(dateAsString);
                    returnContainer.getEnvParams().setValeurDate(dateAsString);
                    returnContainer.getEnvParams().setMachineDate(dateAsString);
                    returnContainer.getEnvParams().setResourceID("ResourceID");
                    returnContainer.getEnvParams().setResourceName("ResourceName");
                    returnContainer.getEnvParams().setUnitCodeLevel1("UnitCodeLevel1");
                    returnContainer.getEnvParams().setUnitTypeCodeLevel1("UnitTypeCodeLevel1");
                    returnContainer.getEnvParams().setUnitCodeLevel2("UnitCodeLevel2");
                    returnContainer.getEnvParams().setUnitTypeCodeLevel2("UnitTypeCodeLevel2");
                    returnContainer.getEnvParams().setUnitCodeLevel3("UnitCodeLevel3");
                    returnContainer.getEnvParams().setUnitTypeCodeLevel3("UnitTypeCodeLevel3");
                    returnContainer.getEnvParams().setUnitCodeLevel4("UnitCodeLevel4");
                    returnContainer.getEnvParams().setUnitTypeCodeLevel4("UnitTypeCodeLevel4");
                    returnContainer.getEnvParams().setAliasList(new String[]{"1", "2"});
                    returnContainer.getEnvParams().setChannelTypeCode("ChannelTypeCode");
                    returnContainer.getEnvParams().setResourceTypeCode("ResourceTypeCode");
                    returnContainer.getEnvParams().setReleaseType("ReleaseType");
                    returnContainer.getEnvParams().setPageSize(1);
                    returnContainer.getEnvParams().setPageKey("PageKey");
                    returnContainer.getEnvParams().setLanguage("Language");
                    returnContainer.getEnvParams().setUserLanguage("UserLanguage");
                    returnContainer.getEnvParams().setCardReaderPresent(true);
                    returnContainer.getEnvParams().setApprovalID("ApprovalID");
                    returnContainer.getEnvParams().setApprovalType("ApprovalType");
                    returnContainer.getEnvParams().setBusinessFlowName("BusinessFlowName");
                    returnContainer.getEnvParams().setUserRoleList(new String[]{"3", "4"});
                    returnContainer.getEnvParams().setRelationValue1("RelationValue1");
                    returnContainer.getEnvParams().setRelationType1("RelationType1");
                    returnContainer.getEnvParams().setRelationValue2("RelationValue2");
                    returnContainer.getEnvParams().setRelationType2("RelationType2");
                    returnContainer.getEnvParams().setRelationValue3("RelationValue3");
                    returnContainer.getEnvParams().setRelationType3("RelationType3");
                    returnContainer.getEnvParams().setRelationValue4("RelationValue4");
                    returnContainer.getEnvParams().setRelationType4("RelationType4");
                    returnContainer.getEnvParams().setApprovalTypePoint("ApprovalTypePoint");
                    returnContainer.getEnvParams().setApprovalTypeRole("ApprovalTypeRole");
                    returnContainer.getEnvParams().setBaseCurrency("BaseCurrency");
                    returnContainer.getEnvParams().setRunAsUser("RunAsUser");
                    returnContainer.getEnvParams().setRunAsUnit("RunAsUnit");

                    return returnContainer;
                });

        assertTrue(requestId.equals(request.getPayload().getLoggingInfo().getRequestId()));
        assertTrue(request.getPayload().getEnvParams().getWorkingDate().getYear() == 2023);
        assertTrue(request.getPayload().getEnvParams().getWorkingDate().getMonth() == 1);
        assertTrue(request.getPayload().getEnvParams().getWorkingDate().getDay() == 1);
        assertTrue(request.getPayload().getEnvParams().getAliasList().getAlias().size() == 2);
        assertTrue(request.getPayload().getEnvParams().getUserRoleList().getUserRole().size() == 2);
    }

    public static class HarnessRESTAPI extends AbstractCamelRouteDrivingRESTAPI {

    }
}
