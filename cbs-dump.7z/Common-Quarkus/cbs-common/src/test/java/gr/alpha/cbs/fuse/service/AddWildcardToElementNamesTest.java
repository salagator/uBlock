package gr.alpha.cbs.fuse.service;

import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import io.quarkus.test.junit.QuarkusTest;
import net.sf.saxon.dom.DocumentBuilderImpl;
import net.sf.saxon.xpath.XPathFactoryImpl;
import org.apache.camel.CamelContext;
import org.apache.camel.impl.DefaultCamelContext;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import static gr.alpha.cbs.fuse.bean.HorizontalProcessor.addWildcardToElementNames;
import static org.junit.jupiter.api.Assertions.assertEquals;

// This test is here because not all converters are loaded in the cbs-common-lib library
// where FormatUtils belongs. This is probably because of missing dependencies in the
// cbs-common-lib library.

@QuarkusTest
public class AddWildcardToElementNamesTest {


    @Test
    public void testSimpleXpath() throws Exception {
        String xpathString = "/*:GetSeizureReturnsInfoForPrintPayload/confiscationGetResponse[1]/afm_1/text()";
        String formattedXpath = addWildcardToElementNames(xpathString);
        String correctXPath = "/*:GetSeizureReturnsInfoForPrintPayload/*:confiscationGetResponse[1]/*:afm_1/text()";
        assertEquals(correctXPath, formattedXpath);
    }
    @Test
    public void testSubstringXpath() throws Exception {
        String xpathString = "substring(/*:GetSeizureReturnsInfoForPrintPayload/confiscationGetResponse[1]/afm_1/text(),12)";
        String formattedXpath = addWildcardToElementNames(xpathString);
        String correctXPath = "substring(/*:GetSeizureReturnsInfoForPrintPayload/*:confiscationGetResponse[1]/*:afm_1/text(),12)";
        assertEquals(correctXPath, formattedXpath);
    }

    @Test
    public void testConcatXpath() throws Exception {
        String xpathString = "concat(/*:GetSeizureInfoByRefKeyPayload/confiscationGetResponse/comment/text(),'||',/*:GetSeizureInfoByRefKeyPayload/confiscationGetResponse/commentB/text())";
        String formattedXpath = addWildcardToElementNames(xpathString);
        String correctXPath = "concat(/*:GetSeizureInfoByRefKeyPayload/*:confiscationGetResponse/*:comment/text(),'||',/*:GetSeizureInfoByRefKeyPayload/*:confiscationGetResponse/*:commentB/text())";
        assertEquals(correctXPath, formattedXpath);
    }

    @Test
    public void testNoChangeRequiredXpath() throws Exception {
        String xpathString = "substring(/*:GetSeizureReturnsInfoForPrintPayload/*:confiscationGetResponse[1]/*:afm_1/text(),12)";
        String formattedXpath = addWildcardToElementNames(xpathString);
        String correctXPath = "substring(/*:GetSeizureReturnsInfoForPrintPayload/*:confiscationGetResponse[1]/*:afm_1/text(),12)";
        assertEquals(correctXPath, formattedXpath);
    }

}