package gr.alpha.cbs.fuse.service;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "foobar"
})
@XmlRootElement(name = "TestOp")
public class TestOp {
    @XmlElement(name = "foobar", required = true)
    protected String foobar;

    public String getFoobar() {
        return foobar;
    }

    public void setFoobar(String foobar) {
        this.foobar = foobar;
    }
}
