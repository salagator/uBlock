package gr.alpha.cbs.fuse.service;

public class OperationTestRequestPayload {
    private SomeRandomTestClass someRandomTestClass;
    private LoggingInfoType loggingInfo;
    private EnvParamsType envParams;

    public SomeRandomTestClass getSomeRandomTestClass() {
        return someRandomTestClass;
    }

    public void setSomeRandomTestClass(SomeRandomTestClass someRandomTestClass) {
        this.someRandomTestClass = someRandomTestClass;
    }

    public LoggingInfoType getLoggingInfo() {
        return loggingInfo;
    }

    public void setLoggingInfo(LoggingInfoType loggingInfo) {
        this.loggingInfo = loggingInfo;
    }

    public EnvParamsType getEnvParams() {
        return envParams;
    }

    public void setEnvParams(EnvParamsType envParams) {
        this.envParams = envParams;
    }
}
