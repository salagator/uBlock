package gr.alpha.cbs.fuse.ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;

import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangeProperties;
import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;

import gr.alpha.cbs.fuse.common.support.TransactionConfig;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;

@Named("getJournalRecord")

@Dependent

@RegisterForReflection
public class GetJournalRecord {

	private static final Logger LOGGER = Logger.getLogger(GetJournalRecord.class);
	
	@Inject
	@io.quarkus.agroal.DataSource("cbsun")
	DataSource sqlDsCBSUN;
	
	@Inject
	private MetaDataEjb metaDataEjb;
	
	private static final String JOURNAL_COLUMN_SERVICE_NAME = "serviceName";
	private static final String JOURNAL_COLUMN_OPERATION = "Operation";
	

	/**
	 * Retrieves a journal record given a specific BUN number and sets two properties 
	 * 
	 * Sets two variables as output
	 * com.journal.payload --> String Object (XML document)
	 * com.journal.record  --> ResultSet Object 
	 * 
	 * @param exchange
	 * @param rBun
	 * @throws SQLException
	 * @throws CBSException
	 */
	public void GetRecordFromBUN(Exchange exchange, String rBun) throws SQLException, CBSException {
		
		
		ResultSet res = null;		
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("Reverse BUN is: " + rBun);			
		}
		String sql = "select * FROM JOU_Reversal_Data WHERE BUN = ?";
		
		try (Connection conn = this.sqlDsCBSUN.getConnection();PreparedStatement pstm = conn.prepareStatement(sql)) {			
			
			pstm.setString(1, rBun);
			res = pstm.executeQuery();			

			if (!res.next()) {
				ErrorUtils.throwCBSException(null, 
						String.valueOf(ConstantError_Types._Functional), 
						String.valueOf(ConstantError_System_IDs._FUSE), 
						this.getClass().getCanonicalName(), 
						"300817", 
						String.valueOf(ConstantError_Levels._Error), 
						"BUN not found in database even though transaction is reversal!", 
						"", 
						"");
			}
			
			exchange.setProperty("com.journal.payload", res.getString("JournalReversePayload"));
			exchange.setProperty("com.journal.record", res);

		} catch (Exception ex) {
			if (!(ex instanceof CBSException)){
				ErrorUtils.throwCBSException(ex, 
						String.valueOf(ConstantError_Types._Functional), 
						String.valueOf(ConstantError_System_IDs._FUSE), 
						this.getClass().getCanonicalName(), 
						String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob), 
						String.valueOf(ConstantError_Levels._Error), 
						ex.getMessage(), 
						"", 
						"");
			}else
				throw ex;
		} finally {
			if (res != null) {
				res.close();
			}
		}

	}
	
	/**
	 * Given a bun as input, this method checks if exist record in the JOU_DATA table with the given bun as RBUN,
	 * If exists return true, otherwise false
	 * 
	 * @param rBun
	 * @return
	 * @throws Exception
	 */
	public boolean isJournalRecordByRBUNReturned(String rBun) throws Exception{
		
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Start checking if operation with bun "+rBun+" has already been reversed.");
		}

		String sqlStatement = "select BUN FROM JOU_Data WHERE RBUN = ?";
		
		try(Connection conn = this.sqlDsCBSUN.getConnection();
			PreparedStatement preparedStatement = conn.prepareStatement(sqlStatement)){
			
			preparedStatement.setString(1, rBun);
			
			try(ResultSet resultSet = preparedStatement.executeQuery()){
				
				//in case that no record returned from the query method returns false
				if(!resultSet.next()){
					
					if (LOGGER.isDebugEnabled()){
						LOGGER.debug("No record found in the journal table with rbun = "+rBun);
					}
					return false;
				}
			}
			
		}catch (Exception ex) {
			if (!(ex instanceof CBSException)){
				ErrorUtils.throwCBSException(ex, 
						String.valueOf(ConstantError_Types._Functional), 
						String.valueOf(ConstantError_System_IDs._FUSE), 
						this.getClass().getCanonicalName(), 
						String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob), 
						String.valueOf(ConstantError_Levels._Error), 
						ex.getMessage(), 
						"", 
						"");
			}else
				throw ex;
		}
		
		return true;
	}
	
	/**
	 * Given a specific bun and a List<String> , this method returns in a Map the journal values of the columns that 
	 * correspond in the strings of the List<String>.
	 * 
	 * @param columnsToBeRetrieved
	 * @param bun
	 * @return
	 * @throws Exception
	 */
	public Map<String,String> retrieveJournalInformationAsMap(List<String> columnsToBeRetrieved, String bun) throws Exception{
		
		String selectedColumns = String.join(",", columnsToBeRetrieved);
		String sqlStatement = "select "+selectedColumns+" FROM JOU_Data WHERE BUN = ?";
		
		Map<String,String> journalRecordsMap = new LinkedHashMap<>();
		if (LOGGER.isDebugEnabled()){			
			LOGGER.debug("Sql statement to be executed :"+sqlStatement);
		}
		
		try(Connection conn = this.sqlDsCBSUN.getConnection();
			PreparedStatement preparedStatement = conn.prepareStatement(sqlStatement)){
			
			preparedStatement.setString(1, bun);
			
			try(ResultSet resultSet = preparedStatement.executeQuery()){
				
				if(resultSet.next()){
					
					for(int index = 0; index < columnsToBeRetrieved.size() ; index++){
						
						if (LOGGER.isDebugEnabled()){
							LOGGER.debug("Adding in journalRecordsMap map key : "+columnsToBeRetrieved.get(index)+" with value : "+resultSet.getString(columnsToBeRetrieved.get(index)));
						}
						journalRecordsMap.put(columnsToBeRetrieved.get(index), resultSet.getString(columnsToBeRetrieved.get(index)));

					}
				}
			}
			
		}catch (Exception ex) {
			if (!(ex instanceof CBSException)){
				ErrorUtils.throwCBSException(ex, 
						String.valueOf(ConstantError_Types._Functional), 
						String.valueOf(ConstantError_System_IDs._FUSE), 
						this.getClass().getCanonicalName(), 
						String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob), 
						String.valueOf(ConstantError_Levels._Error), 
						ex.getMessage(), 
						"", 
						"");
			}else
				throw ex;
		}
		
		if (LOGGER.isDebugEnabled()){			
			LOGGER.debug("Retrieved journal info :"+journalRecordsMap);
		}
		
		return journalRecordsMap;
	}

	/**
	 * Searches in the EventRegistry configuration to identify if the
	 * operation that corresponds to the given confKey can be reversed,
	 * using the canReverse attribute (AttrCode = 112)
	 * 
	 * @param serviceName
	 * @param operationName
	 * @return true if operation can be reversed, false otherwise
	 * @throws Exception
	 */
	public boolean isOperationEligibleForReversal(String serviceName, String operationName) throws Exception {
		String confKey = serviceName + operationName;
		LOGGER.debug("Trying to search in the EventRegistry configuration with key :" + confKey);

		TransactionConfig configuration = metaDataEjb.getEventRegistryConfiguration(serviceName, operationName);
		if (configuration == null) {
			LOGGER.warn("There is not Configuration for " + confKey + " In Event Registry");
			ErrorUtils.throwCBSException(null,
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					this.getClass().getCanonicalName(),
					ConstantErrorMessages._ServiceNotParameterizedEventsRegistry,
					"3", "", "", "");
		}

		return configuration.isCanReverse();
	}

	/**
	 * Wrapper method that calls methods
	 *- isOperationEligibleForReversal
	 *- isJournalRecordByRBUNReturned
	 * to identify if a Reverse operation can be processed.
	 * 
	 * @param rBun
	 * @param exchangeProperties
	 * @throws Exception
	 */
	
	public void checkValidityOfReverseOperation(String rBun , @ExchangeProperties Map<String,Object> exchangeProperties) throws Exception{
		
		List<String> columnsToBeRetrieved = Arrays.asList(JOURNAL_COLUMN_SERVICE_NAME,JOURNAL_COLUMN_OPERATION);
		
		Map<String,String> journalInformationAsMap = retrieveJournalInformationAsMap(columnsToBeRetrieved , rBun);
		
		//check if the given rbun is valid
		if(journalInformationAsMap.isEmpty()){
			ErrorUtils.throwCBSException(null ,  
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, 
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, 
					this.getClass().getCanonicalName(), 
					String.valueOf(ConstantErrorMessages._ANYPARKTO_BUN_MW),
					String.valueOf(ConstantError_Levels._Error),
					"Operation can not be reversed.The provided RBUN could not been retrieved from the database.", 
					"", "");
		}
		
		String serviceName = journalInformationAsMap.get(JOURNAL_COLUMN_SERVICE_NAME);
		String operationName = journalInformationAsMap.get(JOURNAL_COLUMN_OPERATION);
		String confKey = serviceName + operationName;
		
		if (LOGGER.isDebugEnabled()){			
			LOGGER.debug("Trying to search in the EventRegistry configuration with key :"+confKey);
		}
		
		//retrieve the event registry configuration for the current operation (aka the reverse operation)
		TransactionConfig currentOperationConfig = (TransactionConfig) exchangeProperties.get("configuration");
		
		//if the reversalServiceOperation for the current operation has not been set throw error
		if(StringUtils.isEmpty(currentOperationConfig.getReversalServiceOperation())){
			ErrorUtils.throwCBSException(null ,  
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, 
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, 
					this.getClass().getCanonicalName(), 
					"301149",
					String.valueOf(ConstantError_Levels._Error),
					"Reversal Service Operation has not been parameterized in Event Registry", 
					"", "");
		}
		
		//check if rbun belongs to the corresponding direct operation
		if(!confKey.equals(currentOperationConfig.getReversalServiceOperation())){
			ErrorUtils.throwCBSException(null ,  
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, 
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, 
					this.getClass().getCanonicalName(), 
					String.valueOf(ConstantErrorMessages._Den_Epitrepetai_Antilogismos),
					String.valueOf(ConstantError_Levels._Error),
					"Operation can not be reversed.The provided RBUN do not belong to the corresponding direct operation.", 
					"", "");
		}
		
		
		//check - using the EventRegistry - if operation that corresponds in the rbun can be reversed
		if(!isOperationEligibleForReversal(serviceName, operationName)){
			ErrorUtils.throwCBSException(null ,  
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, 
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, 
					this.getClass().getCanonicalName(), 
					String.valueOf(ConstantErrorMessages._Den_Epitrepetai_Antilogismos),
					String.valueOf(ConstantError_Levels._Error),
					"Operation can not be reversed.", 
					"", "");
		}
		
		
		//check if operation has already been reversed
		if(isJournalRecordByRBUNReturned(rBun)){
			ErrorUtils.throwCBSException(null ,  
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, 
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, 
					this.getClass().getCanonicalName(), 
					String.valueOf(ConstantErrorMessages._I_Kinisi_Exei_Idi_Antilogistei),
					String.valueOf(ConstantError_Levels._Error),
					"Operation has already been reversed.", 
					"", "");
		}
	}	

	/**
	 * Retrieves Reversal Service Operation Name given a specific BUN number 
	 * 
	 * Sets one variable as output
	 * com.journal.record.reversalServiceOperation
	 * 
	 * @param exchange
	 * @param Bun
	 * @throws Exception
	 */	
	public void getReversalServiceOperation(Exchange exchange, String bun) throws Exception {
		String reversalServiceOperationExchangeProperty = "com.journal.record.reversalServiceOperation";

		LOGGER.debug("START getReversalServiceOperation");

		List<String> columnsToBeRetrieved = Arrays.asList(JOURNAL_COLUMN_SERVICE_NAME, JOURNAL_COLUMN_OPERATION);
		Map<String, String> journalInformationAsMap = retrieveJournalInformationAsMap(columnsToBeRetrieved, bun);

		String serviceName = journalInformationAsMap.get(JOURNAL_COLUMN_SERVICE_NAME);
		String operationName = journalInformationAsMap.get(JOURNAL_COLUMN_OPERATION);
		String lookupOperation = serviceName + operationName;

		Map<String, TransactionConfig> eventRegistry = metaDataEjb.getEventRegistryConfiguration();
		for (Map.Entry<String, TransactionConfig> eventRegistryEntry: eventRegistry.entrySet()) {
			TransactionConfig eventRegistryConfig = eventRegistryEntry.getValue();
			String reverseReversalServiceOperation = eventRegistryConfig.getReversalServiceOperation();
			if (lookupOperation.equals(reverseReversalServiceOperation)) {
				String reverseOperationName = eventRegistryConfig.getOperation();
				String reverseServiceName = eventRegistryConfig.getService();
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("Reverse ServiceName: " + reverseServiceName);
					LOGGER.debug("Reverse OperationName: " + reverseOperationName);
					LOGGER.debug("Reverse ReversalServiceOperation: " + reverseReversalServiceOperation);
				}
				exchange.setProperty(reversalServiceOperationExchangeProperty, reverseOperationName);
				break;
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(String.format("%s: %s", reversalServiceOperationExchangeProperty, exchange.getProperty(reversalServiceOperationExchangeProperty)));
			LOGGER.debug("END getReversalServiceOperation");
		}
	}
	
}
