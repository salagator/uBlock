//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ServiceLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class KieServicesClientImpl extends AbstractKieServicesClientImpl implements KieServicesClient {
    private static Logger logger = LoggerFactory.getLogger(KieServicesClientImpl.class);
    private static final ServiceLoader<KieServicesClientBuilder> clientBuilders = ServiceLoader.load(KieServicesClientBuilder.class, KieServicesClientImpl.class.getClassLoader());
    private static List<KieServicesClientBuilder> loadedClientBuilders = loadClientBuilders();
    private String conversationId;
    private KieServerInfo kieServerInfo;
    private Map<Class<?>, Object> servicesClients = new HashMap();

    public KieServicesClientImpl(KieServicesConfiguration config) {
        super(config);
        this.init();
    }

    public KieServicesClientImpl(KieServicesConfiguration config, ClassLoader classLoader) {
        super(config, classLoader);
        this.init();
    }

    private void init() {
        this.setOwner(this);
        List<String> serverCapabilities = this.config.getCapabilities();

        try {
            if (serverCapabilities == null) {
                serverCapabilities = this.getCapabilitiesFromServer();
            }

            if (serverCapabilities != null && !serverCapabilities.isEmpty()) {
                Map<String, KieServicesClientBuilder> clientBuildersByCapability = new HashMap();

                for(KieServicesClientBuilder builder : loadedClientBuilders) {
                    clientBuildersByCapability.put(builder.getImplementedCapability(), builder);
                }

                for(String capability : serverCapabilities) {
                    logger.debug("Building services client for server capability {}", capability);
                    KieServicesClientBuilder builder = (KieServicesClientBuilder)clientBuildersByCapability.get(capability);
                    if (builder != null) {
                        try {
                            logger.debug("Builder '{}' for capability '{}'", builder, capability);
                            Map<Class<?>, Object> clients = builder.build(this.config, this.classLoader);

                            for(Object serviceClient : clients.values()) {
                                if (serviceClient instanceof AbstractKieServicesClientImpl) {
                                    ((AbstractKieServicesClientImpl)serviceClient).setOwner(this);
                                }
                            }

                            logger.debug("Capability implemented by {}", clients);
                            this.servicesClients.putAll(clients);
                        } catch (Exception var9) {
                            logger.warn("Builder {} throw exception while setting up clients, no {} capabilities will be available", builder, capability);
                        }
                    } else {
                        logger.debug("No builder found for '{}' capability", capability);
                    }
                }
            }

        } catch (Exception e) {
            this.close();
            throw new RuntimeException(e);
        }
    }

    private List<String> getCapabilitiesFromServer() {
        this.kieServerInfo = (KieServerInfo)this.getServerInfo().getResult();

        logger.debug("KieServicesClient connected to: {} version {}", this.kieServerInfo.getServerId(), this.kieServerInfo.getVersion());
        List<String> capabilities = this.kieServerInfo.getCapabilities();
        logger.debug("Supported capabilities by the server: {}", capabilities);
        return capabilities;
    }

    private KieServerInfo getServerInfoInTransaction() {
        throw new IllegalStateException("Cannot get capabilities from server in a transaction");
    }

    public <T> T getServicesClient(Class<T> serviceClient) {
        if (this.servicesClients.containsKey(serviceClient)) {
            return (T)this.servicesClients.get(serviceClient);
        } else {
            throw new KieServicesException("Server that this client is connected to has no capabilities to handle " + serviceClient.getSimpleName());
        }
    }

    public ServiceResponse<KieServerInfo> getServerInfo() {
        return this.makeHttpGetRequestAndCreateServiceResponse(this.loadBalancer.getUrl(), KieServerInfo.class);
    }

    /*
    public ServiceResponse<KieContainerResourceList> listContainers() {
        return this.listContainers(KieContainerResourceFilter.ACCEPT_ALL);
    }

    public ServiceResponse<KieContainerResourceList> listContainers(KieContainerResourceFilter containerFilter) {
        if (this.config.isRest()) {
            String queryParams = containerFilter.toURLQueryString();
            String uri = this.loadBalancer.getUrl() + "/containers" + (queryParams.isEmpty() ? "" : "?" + queryParams);
            return this.makeHttpGetRequestAndCreateServiceResponse(uri, KieContainerResourceList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new ListContainersCommand(containerFilter)));
            ServiceResponse<KieContainerResourceList> response = (ServiceResponse)this.executeJmsCommand(script).getResponses().get(0);
            return this.<KieContainerResourceList>getResponseOrNullIfNoResponse(response);
        }
    }

    public ServiceResponse<KieContainerResource> createContainer(String id, KieContainerResource resource) {
        if (this.config.isRest()) {
            return this.makeHttpPutRequestAndCreateServiceResponse(this.loadBalancer.getUrl() + "/containers/" + id, resource, KieContainerResource.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new CreateContainerCommand(resource)));
            ServiceResponse<KieContainerResource> response = (ServiceResponse)this.executeJmsCommand(script, (String)null, (String)null, id).getResponses().get(0);
            return this.<KieContainerResource>getResponseOrNullIfNoResponse(response);
        }
    }

    public ServiceResponse<KieContainerResource> activateContainer(String id) {
        if (this.config.isRest()) {
            return this.makeHttpPutRequestAndCreateServiceResponse(this.loadBalancer.getUrl() + "/containers/" + id + "/status/activated", (String)null, KieContainerResource.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new ActivateContainerCommand(id)));
            ServiceResponse<KieContainerResource> response = (ServiceResponse)this.executeJmsCommand(script, (String)null, (String)null, id).getResponses().get(0);
            return this.<KieContainerResource>getResponseOrNullIfNoResponse(response);
        }
    }

    public ServiceResponse<KieContainerResource> deactivateContainer(String id) {
        if (this.config.isRest()) {
            return this.makeHttpPutRequestAndCreateServiceResponse(this.loadBalancer.getUrl() + "/containers/" + id + "/status/deactivated", (String)null, KieContainerResource.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DeactivateContainerCommand(id)));
            ServiceResponse<KieContainerResource> response = (ServiceResponse)this.executeJmsCommand(script, (String)null, (String)null, id).getResponses().get(0);
            return this.<KieContainerResource>getResponseOrNullIfNoResponse(response);
        }
    }

    public ServiceResponse<KieContainerResource> getContainerInfo(String id) {
        if (this.config.isRest()) {
            return this.makeHttpGetRequestAndCreateServiceResponse(this.loadBalancer.getUrl() + "/containers/" + id, KieContainerResource.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new GetContainerInfoCommand(id)));
            ServiceResponse<KieContainerResource> response = (ServiceResponse)this.executeJmsCommand(script, (String)null, (String)null, id).getResponses().get(0);
            return this.<KieContainerResource>getResponseOrNullIfNoResponse(response);
        }
    }

    public ServiceResponse<Void> disposeContainer(String id) {
        if (this.config.isRest()) {
            return this.makeHttpDeleteRequestAndCreateServiceResponse(this.loadBalancer.getUrl() + "/containers/" + id, Void.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DisposeContainerCommand(id)));
            ServiceResponse<Void> response = (ServiceResponse)this.executeJmsCommand(script, (String)null, (String)null, id).getResponses().get(0);
            return this.<Void>getResponseOrNullIfNoResponse(response);
        }
    }

    public ServiceResponsesList executeScript(CommandScript script) {
        if (this.config.isRest()) {
            return (ServiceResponsesList)this.makeHttpPostRequestAndCreateCustomResponse(this.loadBalancer.getUrl() + "/config", script, ServiceResponsesList.class);
        } else {
            ServiceResponsesList responsesList = this.executeJmsCommand(script);
            return !responsesList.getResponses().isEmpty() && this.shouldReturnWithNullResponse((ServiceResponse)responsesList.getResponses().get(0)) ? null : responsesList;
        }
    }

    public ServiceResponse<KieScannerResource> getScannerInfo(String id) {
        if (this.config.isRest()) {
            return this.makeHttpGetRequestAndCreateServiceResponse(this.loadBalancer.getUrl() + "/containers/" + id + "/scanner", KieScannerResource.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new GetScannerInfoCommand(id)));
            ServiceResponse<KieScannerResource> response = (ServiceResponse)this.executeJmsCommand(script, (String)null, (String)null, id).getResponses().get(0);
            return this.<KieScannerResource>getResponseOrNullIfNoResponse(response);
        }
    }

    public ServiceResponse<KieScannerResource> updateScanner(String id, KieScannerResource resource) {
        if (this.config.isRest()) {
            return this.makeHttpPostRequestAndCreateServiceResponse(this.loadBalancer.getUrl() + "/containers/" + id + "/scanner", resource, KieScannerResource.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new UpdateScannerCommand(id, resource)));
            ServiceResponse<KieScannerResource> response = (ServiceResponse)this.executeJmsCommand(script, (String)null, (String)null, id).getResponses().get(0);
            return this.<KieScannerResource>getResponseOrNullIfNoResponse(response);
        }
    }

    public ServiceResponse<ReleaseId> getReleaseId(String containerId) {
        if (this.config.isRest()) {
            return this.makeHttpGetRequestAndCreateServiceResponse(this.loadBalancer.getUrl() + "/containers/" + containerId + "/release-id", ReleaseId.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new GetReleaseIdCommand(containerId)));
            ServiceResponse<ReleaseId> response = (ServiceResponse)this.executeJmsCommand(script).getResponses().get(0);
            return this.<ReleaseId>getResponseOrNullIfNoResponse(response);
        }
    }

    public ServiceResponse<ReleaseId> updateReleaseId(String id, ReleaseId releaseId) {
        return this.updateReleaseId(id, releaseId, false);
    }

    public ServiceResponse<ReleaseId> updateReleaseId(String id, ReleaseId releaseId, boolean resetBeforeUpdate) {
        if (this.config.isRest()) {
            return this.makeHttpPostRequestAndCreateServiceResponse(this.loadBalancer.getUrl() + "/containers/" + id + "/release-id?" + "resetBeforeUpdate" + "=" + resetBeforeUpdate, releaseId, ReleaseId.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new UpdateReleaseIdCommand(id, releaseId, resetBeforeUpdate)));
            ServiceResponse<ReleaseId> response = (ServiceResponse)this.executeJmsCommand(script, (String)null, (String)null, id).getResponses().get(0);
            return this.<ReleaseId>getResponseOrNullIfNoResponse(response);
        }
    }

    public ServiceResponse<KieServerStateInfo> getServerState() {
        if (this.config.isRest()) {
            return this.makeHttpGetRequestAndCreateServiceResponse(this.loadBalancer.getUrl() + "/state", KieServerStateInfo.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new GetServerStateCommand()));
            ServiceResponse<KieServerStateInfo> response = (ServiceResponse)this.executeJmsCommand(script).getResponses().get(0);
            return this.<KieServerStateInfo>getResponseOrNullIfNoResponse(response);
        }
    }
    */

    public void close() {
        super.close();

        for(Object serviceClient : this.servicesClients.values()) {
            if (serviceClient instanceof AbstractKieServicesClientImpl) {
                ((AbstractKieServicesClientImpl)serviceClient).close();
            }
        }

    }

    /** @deprecated */
    /*
    @Deprecated
    public ServiceResponse<String> executeCommands(String id, String payload) {
        if (this.config.isRest()) {
            return this.makeBackwardCompatibleHttpPostRequestAndCreateServiceResponse(this.loadBalancer.getUrl() + "/containers/instances/" + id, payload, String.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new CallContainerCommand(id, payload)));
            ServiceResponse<String> response = (ServiceResponse)this.executeJmsCommand(script, (String)null, (String)null, id).getResponses().get(0);
            return this.<String>getResponseOrNullIfNoResponse(response);
        }
    }
     */

    /** @deprecated */
    /*
    @Deprecated
    public ServiceResponse<String> executeCommands(String id, Command<?> cmd, Response.Status status) {
        if (this.config.isRest()) {
            return this.makeBackwardCompatibleHttpPostRequestAndCreateServiceResponse(this.loadBalancer.getUrl() + "/containers/instances/" + id, cmd, String.class, this.getHeaders(cmd), status);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new CallContainerCommand(id, this.serialize(cmd))));
            ServiceResponse<String> response = (ServiceResponse)this.executeJmsCommand(script, cmd.getClass().getName(), (String)null, id).getResponses().get(0);
            return this.<String>getResponseOrNullIfNoResponse(response);
        }
    }
     */

    public String toString() {
        return "KieServicesClient{kieServer=" + this.kieServerInfo + ", available clients=" + this.servicesClients + '}';
    }

    public void setClassLoader(ClassLoader classLoader) {
        this.marshaller.setClassLoader(classLoader);
    }

    public ClassLoader getClassLoader() {
        return this.marshaller.getClassLoader();
    }

    public String getConversationId() {
        return this.conversationId;
    }

    public void completeConversation() {
        this.conversationId = null;
    }

    public void setConversationId(String conversationId) {
        if (conversationId != null) {
            this.conversationId = conversationId;
        }

    }

    private static synchronized List<KieServicesClientBuilder> loadClientBuilders() {
        List<KieServicesClientBuilder> builders = new ArrayList();

        for(KieServicesClientBuilder builder : clientBuilders) {
            builders.add(builder);
        }

        return builders;
    }

    private <T> ServiceResponse<T> getResponseOrNullIfNoResponse(ServiceResponse<T> response) {
        return this.shouldReturnWithNullResponse(response) ? null : response;
    }
}
