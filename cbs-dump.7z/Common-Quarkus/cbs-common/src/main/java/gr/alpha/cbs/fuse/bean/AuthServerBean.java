package gr.alpha.cbs.fuse.bean;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpHeaderValues;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.inject.Singleton;
import org.infinispan.protostream.SerializationContextInitializer;
import org.jboss.logging.Logger;
import org.json.JSONObject;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.inject.Named;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Base64;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

@Named("authServerBean")
@Singleton
@RegisterForReflection
public class AuthServerBean {
    private static final Logger LOGGER = Logger.getLogger(AuthServerBean.class);
    private static final String CONTAINER_NAME = "AuthTokens";
    private SerializationContextInitializer contextInitializer;

    RemoteDatagridClientHelper<String,Object> datagridHelper;

    @PostConstruct
    void postConstruct() {
        datagridHelper = new RemoteDatagridClientHelper<>();
        datagridHelper.initCacheManagerWithMarshaller(contextInitializer);
        datagridHelper.setCache(CONTAINER_NAME);
        LOGGER.debug("postConstruct called");
    }

    @PreDestroy
    void preDestroy() {
        datagridHelper.stopCacheManager();
        LOGGER.debug("preDestroy called");
    }

    public String getToken(String authServerUrl, String grant_type, String client_id, String client_secret, String scope, boolean enforceIssueNew, boolean enforceTokenWithLifespan) throws Exception {
        String token = null;
        String key = authServerUrl + "_" + client_id + "_" + scope + "_" + grant_type;
        if (!enforceIssueNew) {
            /* Get from Datagrid */
            token = getEntry(key);
            /* If the token exists in datagrid return it */
            if (token != null && !token.equals("")){
                LOGGER.info("Token found in Datagrid: " + token);
                return token;
            }
        }
        /* Prepare request for auth server call */
        HttpClient client = HttpClient.newHttpClient();
        String body = "grant_type=" + grant_type + "&client_id=" + client_id + "&client_secret=" + client_secret + "&scope=" + scope;
        LOGGER.debug("Body sent to AUTH server is: " + body);
        HttpRequest request = HttpRequest.newBuilder()
                .header(HttpHeaderNames.CONTENT_TYPE.toString(), HttpHeaderValues.APPLICATION_X_WWW_FORM_URLENCODED.toString())
                .header(HttpHeaderNames.ACCEPT.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .uri(new URI(authServerUrl))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() == HttpResponseStatus.OK.code()) {
            String responseEntity = response.body();
            LOGGER.debug("Response is: " + responseEntity);
            LOGGER.debug("Response status is: " + response.statusCode());
            JSONObject result = new JSONObject(responseEntity);
            token = result.getString("access_token");
            LOGGER.info("access_token: " + token);
            /* Save token to datagrid if token is not null */
            if(token != null) {
                putEntry(key, token, enforceTokenWithLifespan);
            }
        }

        return token;
    }

    public String getTokenWithCredentials(String authServerUrl, String grant_type, String client_id, String client_secret,
            String scope, String username, String password, boolean enforceIssueNew, boolean enforceTokenWithLifespan)
            throws Exception {
        String token = null;
        String key = authServerUrl + "_" + client_id + "_" + scope + "_" + grant_type;
        if (!enforceIssueNew) {
            /* Get from Datagrid */
            token = getEntry(key);
            /* If the token exists in datagrid return it */
            if (token != null && !token.equals("")) {
                LOGGER.info("Token found in Datagrid: " + token);
                return token;
            }
        }
        /* Prepare request for auth server call */
        HttpClient client = HttpClient.newHttpClient();
        String body = "grant_type=" + grant_type + "&client_id=" + client_id + "&client_secret=" + client_secret
                + "&scope=" + scope + "&username=" + username + "&password=" + password;
        LOGGER.debug("Body sent to AUTH server is: " + body);
        HttpRequest request = HttpRequest.newBuilder()
                .header(HttpHeaderNames.CONTENT_TYPE.toString(),
                        HttpHeaderValues.APPLICATION_X_WWW_FORM_URLENCODED.toString())
                .header(HttpHeaderNames.ACCEPT.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .uri(new URI(authServerUrl))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() == HttpResponseStatus.OK.code()) {
            String responseEntity = response.body();
            LOGGER.debug("Response is: " + responseEntity);
            LOGGER.debug("Response status is: " + response.statusCode());
            JSONObject result = new JSONObject(responseEntity);
            token = result.getString("access_token");
            LOGGER.info("access_token: " + token);
        }
        /* Save token to datagrid */
        putEntry(key, token, enforceTokenWithLifespan);
        return token;
    }

    private String getEntry(String key) {
        String cacheEntry = null;
        if (datagridHelper.getCache() != null) {
            LOGGER.info("DataGridEJB: Will now try to retrieve from " + CONTAINER_NAME + " DataGrid for key:" + key);
            Object value = datagridHelper.get(key);
            if (value != null) {
                cacheEntry = (String) value;
            }
        }
        return cacheEntry;
    }

    private void putEntry(String key, String token, boolean enforceTokenWithLifespan) throws JsonProcessingException {
        if (datagridHelper.getCache() != null) {
            if (enforceTokenWithLifespan) {
                // token based lifespan
                // lifespan minus some time
                datagridHelper.put(key, token, getTokenLifespan(token), TimeUnit.SECONDS);
            } else {
                // default cache lifespan
                datagridHelper.put(key, token);
            }
            LOGGER.info("DataGridEJB: Entry saved to " + CONTAINER_NAME + " DataGrid with key:" + key);
        }
        else {
            LOGGER.info("DataGridEJB: Entry not saved to " + CONTAINER_NAME + " DataGrid with key:" + key);
        }
    }

    @SuppressWarnings("unchecked")
    private long getTokenLifespan(String token) throws JsonProcessingException {
        HashMap<String, Object> tokenMap;
        long lifespan = -1;
        if (token != null) {
            String tokenSubContent = token.split("\\.")[1];
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.USE_LONG_FOR_INTS, true);
            tokenMap = mapper.readValue(
                    new String(Base64.getDecoder().decode(tokenSubContent)), HashMap.class);
            long expirationTime = (Long) tokenMap.get("exp");
            long issuanceTime = (Long) tokenMap.get("nbf");
            lifespan = expirationTime - issuanceTime;
            LOGGER.info("token lifespan is: " + lifespan);
        }
        return lifespan;
    }
}
