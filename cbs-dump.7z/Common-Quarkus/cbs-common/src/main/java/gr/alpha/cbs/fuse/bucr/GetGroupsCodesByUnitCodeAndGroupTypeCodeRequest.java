package gr.alpha.cbs.fuse.bucr;

public class GetGroupsCodesByUnitCodeAndGroupTypeCodeRequest {
	
	private String unitCode;
	
	private String groupTypeCode;
	
	public GetGroupsCodesByUnitCodeAndGroupTypeCodeRequest(){
		
	}

	public String getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(String unitCode) {
		this.unitCode = unitCode;
	}

	public String getGroupTypeCode() {
		return groupTypeCode;
	}

	public void setGroupTypeCode(String groupTypeCode) {
		this.groupTypeCode = groupTypeCode;
	}

	@Override
	public String toString() {
		return "GetGroupsCodesByUnitCodeAndGroupTypeCodeRequest{" +
				"unitCode='" + unitCode + '\'' +
				", groupTypeCode='" + groupTypeCode + '\'' +
				'}';
	}
}