package gr.alpha.cbs.fuse.support;

import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;

@Named("hostDateFormatter")
@ApplicationScoped
@RegisterForReflection

public class HostDateFormatterXsltExtension extends ExtensionFunctionDefinition {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2060328806415784962L;

	@Override
	public StructuredQName getFunctionQName() {
		return new StructuredQName("hdf", "http://fuse.cbs.alpha.gr/hostDateFormatter/", "hostDateFormatter");
	}

	@Override
	public SequenceType[] getArgumentTypes() {
		return new SequenceType[] { SequenceType.SINGLE_STRING };
	}

	@Override
	public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
		return SequenceType.SINGLE_STRING;
	}

	@Override
	public ExtensionFunctionCall makeCallExpression() {
		return new ExtensionFunctionCall() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -2058456802203838019L;

			@Override
			public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
				try {

					String date = null;
					// Check date - Required field
					if (arguments[0] instanceof LazySequence) {
						date = ((LazySequence) arguments[0]).head().getStringValue();
					} else if (arguments[0] instanceof StringValue) {
						date = ((StringValue) arguments[0]).getStringValue();
					} else {
						throw new Exception("Unrecognized argument type for fromIntPart parameter: "
								+ arguments[0].getClass().getCanonicalName());
					}

					/**
					 * If date is empty string or zeroes, throw exception
					 */
					checkUnprasableDate(date);

					return StringValue.makeStringValue(FormatUtils.getDateFromHostFormatted(date));

				} catch (Exception e) {
					throw new XPathException("Unable to format date", e);
				}
			}

			private void checkUnprasableDate(String date) throws Exception {
				if (date.isEmpty() || date.matches("^[0]+$")) {
					throw new Exception("Unable to format date: " + date);
				}
			}

		};
	}

}
