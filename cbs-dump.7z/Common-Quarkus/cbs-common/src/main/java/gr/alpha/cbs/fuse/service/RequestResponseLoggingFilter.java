package gr.alpha.cbs.fuse.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import io.quarkus.arc.properties.IfBuildProperty;
import jakarta.annotation.Priority;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.container.ContainerResponseFilter;
import jakarta.ws.rs.ext.Provider;

import org.apache.commons.io.IOUtils;
import org.jboss.logging.Logger;

@Provider
@Priority(Priorities.USER)
@IfBuildProperty(name="logging.request-response.enabled", stringValue="true")
public class RequestResponseLoggingFilter implements ContainerRequestFilter, ContainerResponseFilter {
    private static final Logger log = Logger.getLogger(RequestResponseLoggingFilter.class);
    private static final int MAX_BODY_LOG = 1024;

    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {
        log.infof("Incoming request: %s %s headers=%s",
                requestContext.getMethod(),
                requestContext.getUriInfo().getRequestUri(),
                requestContext.getHeaders());

        if (requestContext.hasEntity()) {
            InputStream in = requestContext.getEntityStream();
            byte[] entityBytes = IOUtils.toByteArray(in);
            String body = new String(entityBytes, StandardCharsets.UTF_8);
            log.infof("Request body: %s", truncate(body));
            requestContext.setEntityStream(new ByteArrayInputStream(entityBytes));
        }
    }

    @Override
    public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext) throws IOException {
        log.infof("Outgoing response: status=%d headers=%s",
                responseContext.getStatus(),
                responseContext.getHeaders());

        Object entity = responseContext.getEntity();
        if (entity != null) {
            if (entity instanceof String) {
                log.infof("Response body: %s", truncate((String) entity));
            } else {
                log.infof("Response entity type: %s", entity.getClass().getName());
            }
        }
    }

    private String truncate(String s) {
        if (s == null) return null;
        return (s.length() > MAX_BODY_LOG) ? s.substring(0, MAX_BODY_LOG) + "...[truncated]" : s;
    }
}
