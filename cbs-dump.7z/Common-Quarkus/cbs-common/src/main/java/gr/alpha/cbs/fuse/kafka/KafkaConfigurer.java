package gr.alpha.cbs.fuse.kafka;

import io.quarkus.arc.Unremovable;
import io.quarkus.arc.properties.IfBuildProperty;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.CamelContext;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.event.CamelContextStartedEvent;
import org.apache.camel.model.ModelCamelContext;
import org.apache.camel.model.RouteDefinition;
import org.apache.camel.spi.CamelEvent;
import org.apache.camel.support.EventNotifierSupport;
import org.eclipse.microprofile.config.ConfigProvider;

import jakarta.enterprise.context.ApplicationScoped;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

@ApplicationScoped
@RegisterForReflection
@Unremovable
@IfBuildProperty(name = "kafka.facility.enabled", stringValue = "true")
public class KafkaConfigurer extends EventNotifierSupport {
	private static final String CONSUMER_ROUTE_ID = "%s-%s-%s-consumer";
	private static final String DEFAULT_EXCEPTION_MSG = "${exception.message}";
	private Map<String, List<KafkaConfig>> kafkaConfigsRepository;

	@Override
	public void notify(CamelEvent event) throws Exception {
		if (kafkaConfigsRepository == null) {
			kafkaConfigsRepository = createKafkaConfigsRespository();
		}

		if (kafkaConfigsRepository.isEmpty()) {
			return;
		}

		CamelContextStartedEvent startedEvent = (CamelContextStartedEvent) event;
		CamelContext context = startedEvent.getContext();

		// In the brave new world of Quarkus, there is only one CamelContext.
		// Therefore, the context name lookup that was used in the Fuse world is not needed anymore.
		// List<KafkaConfig> contextKafkaConfigs = kafkaConfigsRepository.get(context.getName());
		List<KafkaConfig> contextKafkaConfigs = kafkaConfigsRepository.values().iterator().next();
		if (!contextKafkaConfigs.isEmpty()) {
			Iterator<KafkaConfig> kafkaConfigs = contextKafkaConfigs.iterator();
			while (kafkaConfigs.hasNext()) {
				KafkaConfig kafkaConfig = kafkaConfigs.next();
				createKafkaRoutes(context, kafkaConfig);
			}
		}
	}

	@Override
	public boolean isEnabled(CamelEvent event) {
		return (event instanceof CamelContextStartedEvent);
	}

	private Map<String, List<KafkaConfig>> createKafkaConfigsRespository() throws IOException {
		Map<String, String> properties = KafkaHelper.loadPropertiesFile();
		if (properties.isEmpty()) {
			// Without kafka.properties in artifact then no kafka endpoints can be created
			return new HashMap<>();
		}

		Set<String> propertyNames = properties.keySet();

		// Step 1. Remove dataSourceRef property from the parsing process
		propertyNames.remove(KafkaConstants.DATA_SOURCE_REF);

		/*
		 * Step 2. Parse remaining properties into kafka configs
		 * 
		 * Properties format is:
		 *   <processName>.<context-property> = <value>
		 *   <processName>.consumer.<consumer-property> = <value>
		 *   <processName>.producer.<producer-property> = <value>
		 */ 
		Map<String, KafkaConfig.Builder> kafkaConfigsDirectory = new HashMap<>();
		Map<String, KafkaConfigContext.Builder> kafkaContextConfigsDirectory = new HashMap<>();
		Map<String, KafkaConfigConsumer.Builder> kafkaConsumerConfigsDirectory = new HashMap<>();
		Map<String, KafkaConfigProducer.Builder> kafkaProducerConfigsDirectory = new HashMap<>();

		Iterator<String> propertyNamesList = propertyNames.iterator();
		while (propertyNamesList.hasNext()) {
			String propertyName = propertyNamesList.next();
			String propertyValue = properties.get(propertyName);

			String processName = propertyName.substring(0, propertyName.indexOf('.'));
			// Initiate new config with default values if we don't have the processName in the dictionary
			if (!kafkaConfigsDirectory.containsKey(processName)) {
				kafkaConfigsDirectory.put(
						processName,
						new KafkaConfig.Builder().processName(processName)
				);

				kafkaContextConfigsDirectory.put(
						processName,
						new KafkaConfigContext.Builder()
				);

				kafkaConsumerConfigsDirectory.put(
						processName,
						new KafkaConfigConsumer.Builder().enabled(false).persistMessage(false).transactedPersistMessage(false)
				);

				kafkaProducerConfigsDirectory.put(
						processName,
						new KafkaConfigProducer.Builder().enabled(false)
				);
			}

			propertyName = propertyName.substring(processName.length() + 1);
			int propertyTypeCharIndex = propertyName.indexOf('.');
			// Parse property according to it's type (context, consumer, producer)
			if (propertyTypeCharIndex != -1) {
				String propertyType = propertyName.substring(0, propertyTypeCharIndex);
				propertyName = propertyName.substring(propertyTypeCharIndex + 1);
				if ("consumer".equals(propertyType)) {
					parseConsumerProperty(kafkaConsumerConfigsDirectory.get(processName), propertyName, propertyValue);
				} else if ("producer".equals(propertyType)) {
					parseProducerProperty(kafkaProducerConfigsDirectory.get(processName), propertyName, propertyValue);
				}
			} else {
				parseContextProperty(kafkaContextConfigsDirectory.get(processName), propertyName, propertyValue);
			}
		}

		Map<String, List<KafkaConfig>> kafkaConfigsPerContextId = new HashMap<>();
		Iterator<String> processNames = kafkaConfigsDirectory.keySet().iterator();
		while (processNames.hasNext()) {
			String processName = processNames.next();

			KafkaConfigContext kafkaConfigContext = kafkaContextConfigsDirectory.get(processName).build();
			KafkaConfigConsumer kafkaConfigConsumer = kafkaConsumerConfigsDirectory.get(processName).build();
			KafkaConfigProducer kafkaConfigProducer = kafkaProducerConfigsDirectory.get(processName).build();

			KafkaConfig kafkaConfig = kafkaConfigsDirectory.get(processName)
				.contextConfig(kafkaConfigContext)
				.consumerConfig(kafkaConfigConsumer)
				.producerConfig(kafkaConfigProducer)
				.build();

			String contextId = kafkaConfig.getContextConfig().getContextId();
			kafkaConfigsPerContextId.computeIfAbsent(contextId, k -> new ArrayList<>());
			kafkaConfigsPerContextId.get(contextId).add(kafkaConfig);
		}
		return kafkaConfigsPerContextId;
	}

	private void parseConsumerProperty(KafkaConfigConsumer.Builder consumerConfigBuilder, String propertyName, String propertyValue) {
		switch (propertyName) {
			case "enabled":
				consumerConfigBuilder.enabled(Boolean.valueOf(propertyValue));
				break;
			case "groupId":
				consumerConfigBuilder.groupId(propertyValue);
				break;
			case "persistMessage":
				consumerConfigBuilder.persistMessage(Boolean.valueOf(propertyValue));
				break;
			case "transactedPersistMessage":
				consumerConfigBuilder.transactedPersistMessage(Boolean.valueOf(propertyValue));
				break;
			case "messageIdPath":
				consumerConfigBuilder.messageIdPath(propertyValue);
				break;
			case "messageIdPathType":
				consumerConfigBuilder.messageIdPathType(propertyValue);
				break;
			case "routeForValidation":
				consumerConfigBuilder.routeForValidation(propertyValue);
				break;
			case "routeToExecute":
				consumerConfigBuilder.routeToExecute(propertyValue);
				break;
			default:
				// Unknown property - ignore
				break;
		}
	}

	private void parseProducerProperty(KafkaConfigProducer.Builder producerConfigBuilder, String propertyName, String propertyValue) {
		switch (propertyName) {
			case "enabled":
				producerConfigBuilder.enabled(Boolean.valueOf(propertyValue));
				break;
			case "receiveMessageFromRouteId":
				producerConfigBuilder.receiveMessageFromRouteId(propertyValue);
				break;
			default:
				// Unknown property - ignore
				break;
		}
	}

	private void parseContextProperty(KafkaConfigContext.Builder contextConfigBuilder, String propertyName, String propertyValue) {
		switch (propertyName) {
			case "brokerSystemProperty":
				contextConfigBuilder.brokerSystemProperty(propertyValue);
				break;
			case "topicSystemProperty":
				contextConfigBuilder.topicSystemProperty(propertyValue);
				break;
			case "saslKerberosServiceName":
				contextConfigBuilder.saslKerberosServiceName(propertyValue);
				break;
			case "securityProtocol":
				contextConfigBuilder.securityProtocol(propertyValue);
				break;
			case "contextId":
				contextConfigBuilder.contextId(propertyValue);
				break;
			case "saslJaasConfigSystemProperty":
				contextConfigBuilder.saslJaasConfigSystemProperty(propertyValue);
				break;
			default:
				// Unknown property - ignore
				break;
		}
	}

	private void createKafkaRoutes(CamelContext context, KafkaConfig kafkaConfig) {
		String processName = kafkaConfig.getProcessName();
		String topic = ConfigProvider.getConfig().getValue(kafkaConfig.getContextConfig().getTopicSystemProperty(), String.class);
		String kafkaBaseEndpoint = getKafkaBaseEndpoint(kafkaConfig);

		KafkaConfigConsumer kafkaConsumerConfig = kafkaConfig.getConsumerConfig();
		boolean createConsumerEndpoint = kafkaConsumerConfig.isEnabled();

		if (createConsumerEndpoint) {
			createConsumer(context, processName, topic, kafkaBaseEndpoint, kafkaConsumerConfig);
		}

		KafkaConfigProducer kafkaProducerConfig = kafkaConfig.getProducerConfig();
		boolean createProducerEndpoint = kafkaProducerConfig.isEnabled();
		if (createProducerEndpoint) {
			createProducer(context, processName, kafkaBaseEndpoint, kafkaProducerConfig);
		}
	}

	private void createProducer(CamelContext context, String processName, String kafkaBaseEndpoint, KafkaConfigProducer kafkaProducerConfig) {
		String receiveMessageFromRouteId = kafkaProducerConfig.getReceiveMessageFromRouteId();

		ModelCamelContext mcc = context.getCamelContextExtension().getContextPlugin(ModelCamelContext.class);
		RouteDefinition receiveMessageFromRoute = mcc.getRouteDefinition(receiveMessageFromRouteId);
		if (receiveMessageFromRoute == null)
			throw new KafkaException(String.format("Cannot create Kafka Producer for %s. Route with id %s not found.", processName, receiveMessageFromRouteId));

		try {
			AdviceWith.adviceWith(receiveMessageFromRoute, context, new AdviceWithRouteBuilder() {
				@Override
				public void configure() throws Exception {
					weaveAddFirst().removeHeaders("*");
					weaveAddLast().toD(kafkaBaseEndpoint);
				}
			});
		} catch (Exception e) {
			throw new KafkaException(e);
		}
	}

	private void createConsumer(CamelContext context,
			String processName,
			String topic,
			String kafkaBaseEndpoint,
			KafkaConfigConsumer kafkaConsumerConfig) {
		String groupId = kafkaConsumerConfig.getGroupId();
		Boolean persistMessage = kafkaConsumerConfig.isPeristMessage();
		Boolean transactedPersistMessage = kafkaConsumerConfig.isTransactedPersistMessage();
		String messageIdPath = kafkaConsumerConfig.getMessageIdPath();
		String messageIdPathType = kafkaConsumerConfig.getMessageIdPathType();
		String routeForValidation = kafkaConsumerConfig.getRouteForValidation();
		String routeToExecute = kafkaConsumerConfig.getRouteToExecute();
		String consumerEndpoint = String.format("%s&groupId=%s", kafkaBaseEndpoint, groupId);

		boolean validateMessageBeforeCallingRouteToExecute = routeForValidation != null && !"".equals(routeForValidation);

		String setupKafkaConsumerExchangeProperties = String.format(KafkaConstants.DIRECT_ROUTE_FORMAT, KafkaConstants.DIRECT_SETUP_KAFKA_CONSUMER_EXCHANGE_PROPERTIES, topic, groupId);
		String setupKafkaConsumerMessageIdExchangeProperty = String.format(KafkaConstants.DIRECT_ROUTE_FORMAT, KafkaConstants.DIRECT_SETUP_KAFKA_CONSUMER_MESSAGE_ID_EXCHANGE_PROPERTY, topic, groupId);
		String persistKafkaConsumer = String.format(KafkaConstants.DIRECT_ROUTE_FORMAT, KafkaConstants.DIRECT_PERSIST_KAFKA_CONSUMER_MESSAGE, topic, groupId);
		String validateKafkaConsumerMessage = String.format(KafkaConstants.DIRECT_ROUTE_FORMAT, KafkaConstants.DIRECT_VALIDATE_KAFKA_CONSUMER_MESSAGE, topic, groupId);
		String kafakaConsumerMessageRoute = String.format(KafkaConstants.DIRECT_ROUTE_FORMAT, KafkaConstants.DIRECT_KAFKA_CONSUMER_MESSAGE_ROUTE, topic, groupId);

		try {
			context.addRoutes(new RouteBuilder() {
				@Override
				public void configure() throws Exception {
					from(setupKafkaConsumerExchangeProperties)
						.routeId(setupKafkaConsumerExchangeProperties)

						.setProperty(KafkaConstants.PROCESS_NAME, constant(String.format("%s-%s-%s", processName, topic, groupId)))
						.setProperty(KafkaConstants.PERSIST_MESSAGE, constant(Boolean.toString(persistMessage)))
						.setProperty(KafkaConstants.TRANSACTED_PERSIST_MESSAGE, constant(Boolean.toString(transactedPersistMessage)))
						.setProperty(KafkaConstants.PERSIST_MESSAGE_ID_PATH, constant(messageIdPath))
						.setProperty(KafkaConstants.PERSIST_MESSAGE_TYPE, constant(messageIdPathType))
						.setProperty(KafkaConstants.VALIDATE_MESSAGE, constant(Boolean.toString(validateMessageBeforeCallingRouteToExecute)))

						.log(LoggingLevel.DEBUG, "Consumer for '${exchangeProperty.processName}' received message")
						.log(LoggingLevel.DEBUG, "Will persist message: ${exchangeProperty.persistMessage}")
						.log(LoggingLevel.DEBUG, "Will use transaction for persist message: ${exchangeProperty.transactedPersistMessage}")
						.log(LoggingLevel.DEBUG, "Message id info (type): ${exchangeProperty.persistMessageType}")
						.log(LoggingLevel.DEBUG, "Message id info (path): ${exchangeProperty.persistMessageIdPath}")
						.log(LoggingLevel.DEBUG, "Will validate message: ${exchangeProperty.validateMessage}");
				}
			});

			context.addRoutes(new RouteBuilder() {
				@Override
				public void configure() throws Exception {
					if (persistMessage && "xpath".equals(messageIdPathType)) {
						from(setupKafkaConsumerMessageIdExchangeProperty)
							.routeId(setupKafkaConsumerMessageIdExchangeProperty)
							.setProperty(KafkaConstants.MESSAGE_ID)
								.xpath(messageIdPath, String.class);
					}
					else if (persistMessage && "json".equals(messageIdPathType)) {
						from(setupKafkaConsumerMessageIdExchangeProperty)
							.routeId(setupKafkaConsumerMessageIdExchangeProperty)
							.setProperty(KafkaConstants.MESSAGE_ID)
								.jsonpath(messageIdPath);
					}
					else if (persistMessage) {
						throw new KafkaException(String.format("Unknown message id path type %s", messageIdPath));
					}
				}
			});

			context.addRoutes(new RouteBuilder() {
				@Override
				public void configure() throws Exception {
					from(persistKafkaConsumer)
						.routeId(persistKafkaConsumer)

						// Check if we have a valid message id before persisting it
						.choice()
							.when()
								.simple("${exchangeProperty.messageId} != ''")

								// Persist message
								.log(LoggingLevel.INFO, "Persisting message with id '${exchangeProperty.messageId}' for '${exchangeProperty.processName}'")
								.doTry()
									.setProperty("bodyBeforePersistingMessageId", simple("${body}"))
									.setBody(simple("INSERT INTO [KafkaPersistence] ([ProcessName], [MessageId]) VALUES ('${exchangeProperty.processName}', '${exchangeProperty.messageId}')"))

									.to("jdbc:kafkaDatasource?resetAutoCommit=false")
		
									.setBody(simple("${exchangeProperty.bodyBeforePersistingMessageId}"))
		
									.doCatch(SQLException.class)
										.onWhen(simple("${exception.errorCode} == 2627"))
											.log(LoggingLevel.ERROR, "Duplicated message with id '${exchangeProperty.messageId}' for '${exchangeProperty.processName}'!")
											.to("bean:kafkaDynatraceEvent")
											.throwException(KafkaException.class, DEFAULT_EXCEPTION_MSG)
		
									.doCatch(Exception.class)
										.log(LoggingLevel.ERROR, "Exception while trying to persist message '${exchangeProperty.messageId}' for '${exchangeProperty.processName}': ${exception.message}")
										.throwException(KafkaException.class, DEFAULT_EXCEPTION_MSG)
								.endDoTry()
							.endChoice()

							.when()
								.simple("${exchangeProperty.persistMessage} == 'true'")
									.throwException(KafkaException.class, "Cannot persist message without id")
							.endChoice()
						.end();
				}
			});

			context.addRoutes(new RouteBuilder() {
				@Override
				public void configure() throws Exception {
					from(validateKafkaConsumerMessage)
						.routeId(validateKafkaConsumerMessage)

						.choice()
							.when()
								.simple("${exchangeProperty.validateMessage} == 'true'")

								.log(LoggingLevel.INFO, "Validating consumer message for '${exchangeProperty.processName}'")
								.doTry()
									.toD(routeForValidation + "?failIfNoConsumers=false")
									.log(LoggingLevel.DEBUG, "Validation for '${exchangeProperty.processName}' completed. Proceeding to route execution.")
								.doCatch(Exception.class)
									.log(LoggingLevel.ERROR, "Validation route for consumer '${exchangeProperty.processName}' error.")
									.throwException(KafkaException.class, DEFAULT_EXCEPTION_MSG)
								.endDoTry()
							.endChoice() // when validate message true

							.otherwise()
								.log(LoggingLevel.DEBUG, "No validation route for '${exchangeProperty.processName}' has been configured. Proceeding to route execution.")
							.endChoice() // when validate message false
						.end();
				}
			});

			context.addRoutes(new RouteBuilder() {
				@Override
				public void configure() throws Exception {
					from(kafakaConsumerMessageRoute)
						.routeId(kafakaConsumerMessageRoute)

						.log(LoggingLevel.INFO, String.format("Executing route '%s' for consumer message for '${exchangeProperty.processName}'", routeToExecute))
						.doTry()
							.toD(routeToExecute)
							.log("Finished processing consumer message '${exchangeProperty.messageId}' for '${exchangeProperty.processName}'")
						.doCatch(Exception.class)
							.log(LoggingLevel.ERROR, String.format("Route '%s' for consumer '${exchangeProperty.processName}' error.", routeToExecute))
							.throwException(KafkaException.class, DEFAULT_EXCEPTION_MSG)
						.endDoTry();
				}
			});

			context.addRoutes(new RouteBuilder() {
				@Override
				public void configure() throws Exception {
					if (persistMessage) {
						Object datasourceBean = context.getRegistry().lookupByName(KafkaConstants.DATASOURCE_BEAN_NAME);
						Object transactionBean = null;
						if (transactedPersistMessage) {
							transactionBean = context.getRegistry().lookupByName(KafkaConstants.TRX_POLICY_BEAN_NAME);
						}

						if (datasourceBean == null || (transactedPersistMessage && transactionBean == null)) {
							throw new KafkaException("Required beans not found in registry. Perhaps '<context:component-scan base-package=\"gr.alpha.cbs.fuse.kafka\"/>' has not been defined in camel context?");
						}

						if (transactedPersistMessage) {
							from(consumerEndpoint)
								.routeId(String.format(CONSUMER_ROUTE_ID, processName, topic, groupId))
								// Start transaction
								.transacted(KafkaConstants.TRX_POLICY_BEAN_NAME)
								.convertBodyTo(String.class)
								// Setup route properties
								.to(setupKafkaConsumerExchangeProperties)
								// Setup message id property
								.to(setupKafkaConsumerMessageIdExchangeProperty)
								// Persist message
								.to(persistKafkaConsumer)
								// Validate message
								.to(validateKafkaConsumerMessage)
								// Execute consumer route
								.to(kafakaConsumerMessageRoute);
						} else {
							from(consumerEndpoint)
								.routeId(String.format(CONSUMER_ROUTE_ID, processName, topic, groupId))
								.convertBodyTo(String.class)
								// Setup route properties
								.to(setupKafkaConsumerExchangeProperties)
								// Setup message id property
								.to(setupKafkaConsumerMessageIdExchangeProperty)
								// Persist message
								.to(persistKafkaConsumer)
								// Validate message
								.to(validateKafkaConsumerMessage)
								// Execute consumer route
								.to(kafakaConsumerMessageRoute);
						}
					} else {
						from(consumerEndpoint)
							.routeId(String.format(CONSUMER_ROUTE_ID, processName, topic, groupId))
							.convertBodyTo(String.class)
							// Setup route properties
							.to(setupKafkaConsumerExchangeProperties)
							// Validate message
							.to(validateKafkaConsumerMessage)
							// Execute consumer route
							.to(kafakaConsumerMessageRoute);
					}
					
				}
			});
		} catch (Exception e) {
			throw new KafkaException(e);
		}
	}

	private String getKafkaBaseEndpoint(KafkaConfig kafkaConfig) {
		KafkaConfigContext kafkaConfigContext = kafkaConfig.getContextConfig();
		String broker = ConfigProvider.getConfig().getValue(kafkaConfigContext.getBrokerSystemProperty(), String.class);
		String topic = ConfigProvider.getConfig().getValue(kafkaConfigContext.getTopicSystemProperty(), String.class);
		String saslKerberosServiceName = kafkaConfigContext.getSaslKerberosServiceName();
		String securityProtocol = kafkaConfigContext.getSecurityProtocol();
		String saslJaasConfig = ConfigProvider.getConfig().getValue(kafkaConfigContext.getSaslJaasConfigSystemProperty(), String.class);
		return String.format("kafka:%s?brokers=%s&saslKerberosServiceName=%s&securityProtocol=%s&saslJaasConfig=%s", topic, broker, saslKerberosServiceName, securityProtocol, saslJaasConfig);
	}
}
