package gr.alpha.cbs.fuse.kie;

public enum KieServerMode {
    PRODUCTION, DEVELOPMENT
}
