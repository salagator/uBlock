package gr.alpha.cbs.fuse.service;

import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.common.logging.LoadLoggingHelper;
import gr.alpha.cbs.fuse.common.tools.AlternativePathsFlagHolder;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import gr.alpha.cbs.fuse.logging.LoggingMDCInterceptor;
import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import gr.alpha.cbs.fuse.tools.AppMonitoringHelper;
import io.smallrye.faulttolerance.api.RateLimitException;
import io.smallrye.faulttolerance.api.RateLimitType;
import io.smallrye.faulttolerance.api.TypedGuard;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.inject.Inject;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.xml.ws.Provider;
import jakarta.xml.ws.WebServiceContext;
import jakarta.xml.ws.handler.MessageContext;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.support.DefaultExchange;
import org.eclipse.microprofile.config.ConfigProvider;
import org.eclipse.microprofile.faulttolerance.exceptions.BulkheadException;
import org.eclipse.microprofile.faulttolerance.exceptions.CircuitBreakerOpenException;
import org.eclipse.microprofile.faulttolerance.exceptions.TimeoutException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.CompletionStage;

public abstract class AbstractCamelRouteDrivingProvider implements Provider<DOMSource> {
    private static final Logger logger = LoggerFactory.getLogger(AbstractCamelRouteDrivingProvider.class);

    private static final List<String> EXCLUDED_OPERATIONS = List.of(
            "getListReferenceDataItem",
            "ImportNaceCprsMappingFile",
            "ImportNacePhysicalRisksMappingFile",
            "ImportPostalCodePhysicalRisksMappingFile",
            "ImportBusinessActivityCodeExclusions",
            "ExportNaceCprsMappingFile",
            "ExportNacePhysicalRisksMappingFile",
            "ExportPostalCodePhysicalRisksMappingFile",
            "ExportBusinessActivityCodeExclusions");

    private static final int MAX_RESPONSE_SIZE = 5000;
    private static final boolean TRIMMING_RESPONSE = Boolean.parseBoolean(ConfigProvider.getConfig().getOptionalValue("do.not.trim.camel.responses", String.class).orElse("true"));
    private static final String FAULT_TOLERANCE_GUARD_CACHE_NAME = "FaultToleranceGuardCache";

    @Inject
    CamelContext camelContext;

    @Inject
    WebServiceContext webServiceContext;

    private RemoteDatagridClientHelper<String, String> datagridHelper;

    private final Map<String, TypedGuard<DOMSource>> typedGuardMap = Collections.synchronizedMap(new HashMap<>());

    private final Map<String, TypedGuard<CompletionStage<DOMSource>>> asynchronousTypedGuardMap = Collections.synchronizedMap(new HashMap<>());

    /**
     * Override this to set up fault tolerance for various operations.
     * If overridden, make sure to initialize the map only once by setting an
     * instance variable to the return value of this method in the constructor.
     * Otherwise, the fault tolerance logic will not work correctly.
     * Also make sure that the map is synchronized. See the example in this class on how to do this.
     * @return the map from operation name to FaultTolerance instance.
     */
    protected Map<String, TypedGuard<DOMSource>> getTypedGuardMap() {
        return typedGuardMap;
    }

    /**
     * Re-initialize the typed guard map. Called from the clearFaultToleranceGuards()
     * method that is used to re-read the fault tolerance settings from the datagrid.
     */
    protected void reinitializeTypedGuardMap() {
    }

    /**
     * Override this to set up fault tolerance for various operations.
     * If overridden, make sure to initialize the map only once by setting an
     * instance variable to the return value of this method in the constructor.
     * Otherwise, the fault tolerance logic will not work correctly.
     * Also make sure that the map is synchronized. See the example in this class on how to do this.
     * @return the map from operation name to FaultTolerance instance.
     */
    protected Map<String, TypedGuard<CompletionStage<DOMSource>>> getAsynchronousTypedGuardMap() {
        return asynchronousTypedGuardMap;
    }

    /**
     * Re-initialize the typed guard map. Called from the clearFaultToleranceGuards()
     * method that is used to re-read the fault tolerance settings from the datagrid.
     */
    protected void reinitializeAsynchronousTypedGuardMap() {
    }

    protected boolean faultToleranceEnabled() {
        return false;
    }

    protected boolean useStandardFaultToleranceSettings() {
        return false;
    }

    /**
     * Override in case where there are operations that should be handled asynchronously.
     * This would be so that @Bulkhead for the operation.
     *
     * @return a set of operation names
     */
    protected Set<String> asynchronousOperations() {
        return Collections.emptySet();
    }

    protected LoggingMDCInterceptor loggingMDCInterceptor = new LoggingMDCInterceptor();

    protected abstract Map<String, Object> getHeaders(String operation, Element requestRootElement);

    // It should be Implemented to Set 3 Important Headers
    // 1 Operation Name map.put(CBSConstants.HEADER_TRANSACTION_NAME,operation)
    // 2 Flow Name hardCoded from EventRegistry map.put(CBSConstants.HEADER_TRANSACTION_FLOW, flow-name )
    // 3 Service Name "hard coded for each service"
    protected abstract void setServiceOperationInfo(String flowName, String operation, Map<String, Object> property);

    @PostConstruct
    public void init() {
        if (faultToleranceEnabled()) {
            // datagridHelper is only used for get the lookup of fault tolerance settings
            // so that we can dynamically adjust them at runtime
            datagridHelper = new RemoteDatagridClientHelper<>();
            datagridHelper.initCacheManagerWithMarshaller(null);
            datagridHelper.setCache(FAULT_TOLERANCE_GUARD_CACHE_NAME);
        }
        logger.debug("postConstruct called");
    }

    @PreDestroy
    public void cleanup() {
        if (datagridHelper != null) {
            datagridHelper.stopCacheManager();
        }
        logger.debug("preDestroy called");
    }

    @Override
    public DOMSource invoke(DOMSource request) {
        String operation;
        if (request.getNode() instanceof Document requestDocument) {
            operation = requestDocument.getDocumentElement().getLocalName();
        } else if (request.getNode() instanceof Element requestElem) {
            operation = requestElem.getLocalName();
        } else {
            throw new UnsupportedOperationException(
                    "Unsupported element encountered: '" + request.getNode().getClass().getCanonicalName() + "'.");
        }

        MessageContext messageContext = webServiceContext.getMessageContext();
        HttpServletRequest servletRequest = (HttpServletRequest) messageContext.get(MessageContext.SERVLET_REQUEST);
        String remoteServer = servletRequest.getRemoteAddr();
        logger.info("Request for {} received from remote server: {}.", operation,  remoteServer);
        servletRequest.getHeaderNames().asIterator()
                .forEachRemaining(headerName -> logger.info("Header: {} = {}", headerName, servletRequest.getHeader(headerName)));

        if (useFaultTolerance(operation)) {
            return invokeWithFaultToleranceErrorHandling(operation, request);
        } else {
            return invokeActual(request);
        }
    }

    public void clearFaultToleranceGuards() {
        if (useStandardFaultToleranceSettings()) {
            getTypedGuardMap().clear();
            logger.info("Cleared all standard fault tolerance guards.");
        }
        reinitializeTypedGuardMap();
        reinitializeAsynchronousTypedGuardMap();
    }

    protected DOMSource invokeWithFaultToleranceErrorHandling(String operation, DOMSource request) {
        try {
            if (asynchronousOperations().contains(operation)) {
                TypedGuard<CompletionStage<DOMSource>> guard = getAsynchronousTypedGuardMap().get(operation);
                if (guard == null) {
                    logger.info("Although we use fault tolerance, no asynchronous guard is defined for operation {}. Invoking without fault tolerance.", operation);
                    return invokeActual(request);
                } else {
                    CompletionStage<DOMSource> completionStage = guard.get(() -> CompletableFuture.supplyAsync(() -> {
                        try {
                            loggingMDCInterceptor.processMessageIn(request);
                            return invokeActual(request);
                        } finally {
                            loggingMDCInterceptor.processMessageOut();
                        }
                    }));
                    return completionStage.toCompletableFuture().join();
                }
            } else {
                TypedGuard<DOMSource> guard = getTypedGuardMap().get(operation);
                if (guard == null) {
                    logger.info("Although we use fault tolerance, no guard is defined for operation {}. Invoking without fault tolerance.", operation);
                    return invokeActual(request);
                } else {
                    return guard.get(() -> invokeActual(request));
                }
            }
        } catch (CompletionException completionException) {
            logger.error("Completion exception while processing request.", completionException);
            throw completionException;
        } catch (ErrorEncounteredException technicalErrorEncounteredException) {
            logger.error("Technical error encountered while processing request: " + technicalErrorEncounteredException.getMessage());
            return technicalErrorEncounteredException.getDomSource();
        } catch (CircuitBreakerOpenException circuitBreakerOpenException) {
            logger.error("Circuit breaker is open, cannot process request: " + circuitBreakerOpenException.getMessage());
            return handleCircuitBreakerOpenException(operation, request, circuitBreakerOpenException);
        } catch (BulkheadException bulkheadException) {
            logger.error("Bulkhead limit reached, cannot process request: " + bulkheadException.getMessage());
            return handleBulkheadException(operation, request, bulkheadException);
        } catch (TimeoutException timeoutException) {
            logger.error("Request timed out: " + timeoutException.getMessage());
            return handleTimeoutException(operation, request, timeoutException);
        } catch (RateLimitException rateLimitException) {
            logger.error("Rate limit exceeded, cannot process request: " + rateLimitException.getMessage());
            return handleRateLimitException(operation, request, rateLimitException);
        }
    }

    protected DOMSource handleCircuitBreakerOpenException(String operation, DOMSource request, CircuitBreakerOpenException exception) {
        logger.error("Handling Circuit Breaker Open Exception: " + exception.getMessage() + ". " +
                "This method should not be called. Implementors that use circuit breaker functionality " +
                "should override AbstractCamelRouteDrivingProvider.handleCircuitBreakerOpenException() " +
                "to provide a custom implementation.");
        return null;
    }

    protected DOMSource handleBulkheadException(String operation, DOMSource request, BulkheadException exception) {
        logger.error("Handling Bulkhead Exception: " + exception.getMessage() + ". " +
                "This method should not be called. Implementors that use bulkhead functionality " +
                "should override AbstractCamelRouteDrivingProvider.handleBulkheadException() " +
                "to provide a custom implementation.");
        return null;
    }

    protected DOMSource handleTimeoutException(String operation, DOMSource request, TimeoutException exception) {
        logger.error("Handling Timeout Exception: " + exception.getMessage() + ". " +
                "This method should not be called. Implementors that use timeout functionality " +
                "should override AbstractCamelRouteDrivingProvider.handleTimeoutException() " +
                "to provide a custom implementation.");
        return null;
    }

    protected DOMSource handleRateLimitException(String operation, DOMSource request, RateLimitException exception) {
        logger.error("Handling Rate Limit Exception: " + exception.getMessage() + ". " +
                "This method should not be called. Implementors that use rate limiting functionality " +
                "should override AbstractCamelRouteDrivingProvider.handleRateLimitException() " +
                "to provide a custom implementation.");
        return null;
    }

    protected DOMSource invokeActual(DOMSource request) {
        DOMSource response = new DOMSource();
        long startTime = System.currentTimeMillis();

        try {
            AppMonitoringHelper.initialize();
        } catch (Exception e) {
            logger.debug("Application Monitoring Info initialization failed!");
        }

        try {
            // Get the operation from the root element of the payload. This is a
            // Document in the case
            // of a "naked" exposed JAX-WS web service. When the
            // LogicalLoggingHandler is interposed
            // in the web service, then we get an Element instead.
            String operation = null;
            String flowName = null;
            Element requestRootElement = null;

            if (request.getNode() instanceof Document requestDocument) {
                requestRootElement = requestDocument.getDocumentElement();
                operation = requestRootElement.getLocalName();
            } else if (request.getNode() instanceof Element requestElem) {
                requestRootElement = requestElem;
                operation = requestElem.getLocalName();
            } else {
                throw new UnsupportedOperationException(
                        "Unsupported element encountered: '" + request.getNode().getClass().getCanonicalName() + "'.");
            }
            if (logger.isDebugEnabled()) {
                logger.debug("Operation called: '" + operation + "'.");
            }

            AlternativePathsFlagHolder.setAlternativePathsFlag(
                    ConfigProvider.getConfig().getOptionalValue("cbs.common.tools.formatutils.alternativepaths", Boolean.class).orElse(false)
            );
            Boolean operationSpecificSetting =
                    ConfigProvider.getConfig().getOptionalValue("cbs.common.tools.formatutils." + operation + ".alternativepaths", Boolean.class).orElse(null);
            if (operationSpecificSetting != null) {
                AlternativePathsFlagHolder.setAlternativePathsFlag(operationSpecificSetting);
            }

            ProducerTemplate producerTemplate = camelContext.createProducerTemplate();

            //flowName = getFlowName(requestRootElement);
            Element payload = getXMLRootElement(requestRootElement);
            flowName = payload.getLocalName();

            logger.info("Call web service " + flowName + "." + operation + " RequestBody:\n" + formatNodeToString(operation, requestRootElement));


            // Get the headers from the concrete class
            Map<String, Object> headers = getHeaders(operation, requestRootElement);
            setServiceOperationInfo(flowName, operation, headers);

            // Perform the call to the camel route (to the template first, which
            // will call the proper route passed in the header above).
            Exchange exchange = new DefaultExchange(camelContext);
            headers.forEach(exchange::setProperty);
            //exchange.setIn(new Message(payload));
            exchange.getIn().setBody(payload);
            Object r = producerTemplate.send(getConsumer(operation), exchange).getIn().getBody();

            // Abnormal condition all exception should be handled by camel routes
            if (exchange.getException() != null) {
                throw new RuntimeException(exchange.getException());
            }

            // Capture point of errorCode for Dynatrace monitoring purposes
            AppMonitoringHelper.captureErrorCode(exchange);

            Document s = camelContext.getTypeConverter().convertTo(Document.class, r);

            Document responseDocument = createResponse(s, operation);

            long duration = System.currentTimeMillis() - startTime;

            logger.info("Call web service " + flowName + "." + operation + " Took " + duration + "ms. " + "ResponseBody:\n"
                    + formatNodeToString(operation, responseDocument));

            response.setNode(responseDocument);

            LoadLoggingHelper.createMessage("FUSE", operation, duration);

            if (useFaultTolerance(operation) && errorEncountered(responseDocument)) {
                // This will be short-circuited in invokeWithFaultToleranceErrorHandling()
                throw new ErrorEncounteredException("Technical error encountered while processing the request.", response);
            }
        } catch (TransformerFactoryConfigurationError | TransformerException | ParserConfigurationException e) {
            logger.error("Unable to process web service call", e);
        }
        return response;
    }

    protected boolean useFaultTolerance(String operation) {
        if (faultToleranceEnabled()) {
            // Either the guard is already in the map
            if (getTypedGuardMap().containsKey(operation)) {
                return true;
            }
            // or we use the standard settings
            int standardRateLimitLimit = getIntegerConfigValue(operation, "RateLimitLimit", 100);
            int standardCircuitBreakerRequestVolumeThreshold = getIntegerConfigValue(operation, "CircuitBreakerRequestVolumeThreshold", 5);
            ChronoUnit standardRateLimitWindowUnit = getChronoUnitConfigValue(operation, "RateLimitWindowUnit", ChronoUnit.MINUTES);
            int standardRateLimitWindow = getIntegerConfigValue(operation, "RateLimitWindow", 1);
            int standardRateLimitMinSpacing = getIntegerConfigValue(operation, "RateLimitMinSpacing", 0);
            ChronoUnit standardRateLimitMinSpacingUnit = getChronoUnitConfigValue(operation, "RateLimitMinSpacingUnit", ChronoUnit.SECONDS);
            RateLimitType standardRateLimitType = getRateLimitTypeConfigValue(operation, "RateLimitType", RateLimitType.ROLLING);
            long standardCircuitBreakerDelay = getIntegerConfigValue(operation, "CircuitBreakerDelay", 1);
            ChronoUnit standardCircuitBreakerDelayUnit = getChronoUnitConfigValue(operation, "CircuitBreakerDelayUnit", ChronoUnit.MINUTES);
            double standardCircuitBreakerFailureRatio = getDoubleConfigValue(operation, "CircuitBreakerFailureRatio", 1.0);
            int standardCircuitBreakerSuccessThreshold = getIntegerConfigValue(operation, "CircuitBreakerSuccessThreshold", 3);
            if (useStandardFaultToleranceSettings() &&
                    standardRateLimitLimit > 0 &&
                    standardCircuitBreakerRequestVolumeThreshold > 0)  {
                // Lazily create the standard fault tolerance settings if needed
                FaultToleranceStrategyHelper.Builder<DOMSource> builder =
                        FaultToleranceStrategyHelper.Builder.createSynchronous(DOMSource.class);
                if (standardRateLimitLimit > 0) {
                    builder = builder.addRateLimitStrategy(
                            standardRateLimitLimit,
                            standardRateLimitWindow,
                            standardRateLimitWindowUnit,
                            standardRateLimitMinSpacing,
                            standardRateLimitMinSpacingUnit,
                            standardRateLimitType,
                            null,
                            null
                    );
                }
                if (standardCircuitBreakerRequestVolumeThreshold > 0) {
                    builder = builder.addCircuitBreakerStrategy(
                            standardCircuitBreakerDelay,
                            standardCircuitBreakerDelayUnit,
                            standardCircuitBreakerRequestVolumeThreshold,
                            standardCircuitBreakerFailureRatio,
                            standardCircuitBreakerSuccessThreshold,
                            null,
                            Collections.singletonList(RateLimitException.class),
                            null,
                            null,
                            null,
                            null,
                            null
                    );
                }
                TypedGuard<DOMSource> standardTypedGuard = builder.build();
                // Add the standard guard to the map, so that it is used for this operation
                getTypedGuardMap().put(operation, standardTypedGuard);
                return true;
            }
        }
        // if we reach this point, no fault tolerance is to be used
        return false;
    }

    protected int getIntegerConfigValue(String operation, String configSuffix, int defaultValue) {
        if (datagridHelper != null) {
            String configKey = this.getClass().getSimpleName() + operation + configSuffix;
            logger.info("Looking up config key {} in datagrid.", configKey);
            String cachedValue = datagridHelper.get(configKey);
            if (cachedValue == null) {
                return defaultValue;
            }
            return Integer.parseInt(cachedValue);
        }
        return defaultValue;
    }

    protected double getDoubleConfigValue(String operation, String configSuffix, double defaultValue) {
        if (datagridHelper != null) {
            String configKey = this.getClass().getSimpleName() + operation + configSuffix;
            logger.info("Looking up config key {} in datagrid.", configKey);
            String cachedValue = datagridHelper.get(configKey);
            if (cachedValue == null) {
                return defaultValue;
            }
            return Double.parseDouble(cachedValue);
        }
        return defaultValue;
    }

    protected ChronoUnit getChronoUnitConfigValue(String operation, String configSuffix, ChronoUnit defaultValue) {
        if (datagridHelper != null) {
            String configKey = this.getClass().getSimpleName() + operation + configSuffix;
            logger.info("Looking up config key {} in datagrid.", configKey);
            String cachedValue = datagridHelper.get(configKey);
            if (cachedValue == null) {
                return defaultValue;
            }
            return ChronoUnit.valueOf(cachedValue);
        }
        return defaultValue;
    }

    protected RateLimitType getRateLimitTypeConfigValue(String operation, String configSuffix, RateLimitType defaultValue) {
        if (datagridHelper != null) {
            String configKey = this.getClass().getSimpleName() + operation + configSuffix;
            logger.info("Looking up config key {} in datagrid.", configKey);
            String cachedValue = datagridHelper.get(configKey);
            if (cachedValue == null) {
                return defaultValue;
            }
            return RateLimitType.valueOf(cachedValue);
        }
        return defaultValue;
    }

    protected RemoteDatagridClientHelper<String, String> getDatagridHelper() {
        return datagridHelper;
    }

    protected boolean errorEncountered(Document responseDocument) {
        return !Objects.isNull(FormatUtils.getValue(responseDocument, "//*:ErrorMessage/*:ErrorType")) &&
                !Objects.equals(FormatUtils.getValue(responseDocument, "//*:ErrorMessage/*:SeverityLevel"), ErrorTypeModel.SEVERITY_WARNING);
    }

    public String getConsumer(String operation) {
        return "direct:start";
    }

    public String formatNodeToString(String operation, Node node) throws TransformerFactoryConfigurationError, TransformerException {
        String returnValue = FormatUtils.nodeToString(node, FormatUtils.OMIT_XML_DECLARATION_YES, FormatUtils.INDENT_NO);
        if (TRIMMING_RESPONSE &&
                EXCLUDED_OPERATIONS.contains(operation) &&
                returnValue.length() > MAX_RESPONSE_SIZE) {
            return returnValue.substring(0, MAX_RESPONSE_SIZE) + "... (trimmed)";
        }
        return returnValue;
    }

    /**
     * Method to get the root element of the request XML.<br>
     * Default behavior is to get the first element child from the root.<br>
     * <p>
     * Override this method for other behavior
     *
     * @param rootElement Initial SOAP request XML
     * @return Root element
     */
    protected Element getXMLRootElement(Element rootElement) {
        Element newRoot = null;

        if (requestWithPayloadOnly()) {
            Node childNode = rootElement.getFirstChild();
            while (childNode != null && childNode.getNodeType() != Node.ELEMENT_NODE) {
                childNode = childNode.getNextSibling();
            }
            newRoot = (Element) childNode;
        } else {
            newRoot = rootElement;
        }

        return newRoot;
    }

    private Document createResponse(Document response, String operation) throws ParserConfigurationException {

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.newDocument();

        // root element
        Element rootElement = doc.createElementNS(response.getDocumentElement().getNamespaceURI(), operation + "Response");

        doc.appendChild(rootElement);

        Node nNode = null;
        if (keepRootElement() == ResponseLayout.WRAP) {
            nNode = doc.importNode(response.getDocumentElement(), true);
        } else if (keepRootElement() == ResponseLayout.WRAP_UNWRAP) {
            nNode = doc.importNode(getXMLRootElement(response.getDocumentElement()), true);
        } else {
            return response;
        }
        rootElement.appendChild(nNode);

        return doc;
    }

    /**
     * Override in case where the response payload should be wrapped.
     *
     * @return true/false
     */
    protected ResponseLayout keepRootElement() {
        return ResponseLayout.WRAP;
    }

    /**
     * Override in case the initial request will be handled as is.
     *
     * @return true if the request payload is expected to be the only content of the request,
     */
    protected boolean requestWithPayloadOnly() {
        return true;
    }

}