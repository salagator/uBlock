package gr.alpha.cbs.fuse.bean;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.ifaces.MasterDataInterface;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;
import org.jboss.logging.Logger;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.util.Map;

@Named("applicationContextHelper")
@Dependent
@RegisterForReflection
public class ApplicationContextHelper {

    private static final Logger LOGGER = Logger.getLogger(ApplicationContextHelper.class);
    private static final String CBSApplicationContext = "CBSApplicationContext";

    @Inject
    MasterDataInterface masterDataInterface;

    public void callMasterDataCBSApplicationContext(Exchange ex) throws Exception {
        Map<String,String> m = masterDataInterface.getMasterDetailsByItemNameLists(CBSApplicationContext, ex.getProperty(CBSConstants.HEADER_BANK_CODE, String.class));

        ex.setProperty(CBSConstants.HEADER_APP_CONTEXT_UNIT_CODE, m.get("UnitCode"));
        ex.setProperty(CBSConstants.HEADER_APP_CONTEXT_UNIT_COUNTRY, m.get("UnitCountry"));
        ex.setProperty(CBSConstants.HEADER_APP_CONTEXT_UNIT_INSTITUTION_CODE, m.get("UnitInstitutionCode"));
        ex.setProperty(CBSConstants.HEADER_APP_CONTEXT_UNIT_LANG, m.get("UnitLanguage"));
        ex.setProperty(CBSConstants.HEADER_APP_CONTEXT_UNIT_FTS_ID, m.get("UnitFTSId"));
        ex.setProperty(CBSConstants.HEADER_APP_CONTEXT_UNIT_IBAN_CALC_METHOD, m.get("UnitIBANCalculationMethod"));

        if(LOGGER.isDebugEnabled()){
            LOGGER.debug(ex.getProperty(CBSConstants.HEADER_APP_CONTEXT_UNIT_CODE));
            LOGGER.debug(ex.getProperty(CBSConstants.HEADER_APP_CONTEXT_UNIT_COUNTRY));
            LOGGER.debug(ex.getProperty(CBSConstants.HEADER_APP_CONTEXT_UNIT_INSTITUTION_CODE));
            LOGGER.debug(ex.getProperty(CBSConstants.HEADER_APP_CONTEXT_UNIT_LANG));
            LOGGER.debug(ex.getProperty(CBSConstants.HEADER_APP_CONTEXT_UNIT_FTS_ID));
            LOGGER.debug(ex.getProperty(CBSConstants.HEADER_APP_CONTEXT_UNIT_IBAN_CALC_METHOD));
        }

    }

}

