package gr.alpha.cbs.fuse.ejb;

import java.util.HashMap;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.inject.Named;

import jakarta.inject.Singleton;
import jakarta.transaction.Transactional;

import io.quarkus.runtime.annotations.RegisterForReflection;
import org.infinispan.commons.marshall.UTF8StringMarshaller;
import org.jboss.logging.Logger;

import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import gr.alpha.cbs.fuse.ifaces.CorporateDividendsInterface;

@Named("corporateDividendsEjb")
@Singleton
@RegisterForReflection
@Transactional(Transactional.TxType.NOT_SUPPORTED)
public class CorporateDividendsEjb implements CorporateDividendsInterface{
	
	private static final Logger LOGGER = Logger.getLogger(CorporateDividendsEjb.class);
	private static final String NO_CACHE_FOUND_WARNING = "Will not use datagrid. There is no cached data to retrieve.";
	private static final String NO_CACHE_VALUE_FOUND_WARNING = "Will not use datagrid. No such key found for cache: corporateDividends-datalookup";

	private RemoteDatagridClientHelper<String, String> datagridHelper;

	@PostConstruct
	private void postConstruct() {
		datagridHelper = new RemoteDatagridClientHelper<>();
		datagridHelper.initCacheManager(new UTF8StringMarshaller());
		datagridHelper.setCache("corporateDividends-datalookup");
		LOGGER.info("postConstruct called!");
	}

	@PreDestroy
	private void preDestroy() {
		datagridHelper.stopCacheManager();
		LOGGER.debug("preDestroy called");
	}
	
	public HashMap<String,String> getAllCorporateDividends() throws Exception{
		
		HashMap<String,String> result = new HashMap<>(); 
		
		if (datagridHelper.getCache() != null){
			datagridHelper.getCache().keySet().stream().forEach(key-> result.put(key,datagridHelper.get(key)));
		}else{
			LOGGER.warn(NO_CACHE_FOUND_WARNING);
		}
		
		return result;
	}
	
	public HashMap<String,String> getDividend(String cacheKey) throws Exception{
		
		HashMap<String,String> result = new HashMap<>();
		String cachedValue = null;
		
		if (datagridHelper.getCache() != null){
			cachedValue = datagridHelper.get(cacheKey);
		}else{
			LOGGER.warn(NO_CACHE_FOUND_WARNING);
		}
		
		if (cachedValue != null) {
			result.put(cacheKey, cachedValue);
		}else{
			LOGGER.warn(NO_CACHE_VALUE_FOUND_WARNING);
		}
		
		return result;
	}
}