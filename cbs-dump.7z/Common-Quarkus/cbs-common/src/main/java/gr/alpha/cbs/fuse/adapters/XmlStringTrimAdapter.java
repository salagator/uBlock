package gr.alpha.cbs.fuse.adapters;

import jakarta.xml.bind.annotation.adapters.XmlAdapter;

import org.apache.commons.lang3.StringUtils;

public class XmlStringTrimAdapter extends XmlAdapter<String, String> {
    @Override
    public String unmarshal(String v) throws Exception {
        if (v == null){
            return null;
        }
        return StringUtils.stripEnd(v, " ");
    }

    @Override
    public String marshal(String v) throws Exception {
        if (v == null){
            return null;
        }
        return StringUtils.stripEnd(v, " ");
    }
}
