package gr.alpha.cbs.fuse.tools;

import java.io.IOException;

import javax.xml.datatype.XMLGregorianCalendar;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

public class XMLGregorianCalendarSerializer extends StdSerializer<XMLGregorianCalendar>{
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public XMLGregorianCalendarSerializer() {
	        this(null);
	    }
	  
	 public XMLGregorianCalendarSerializer(Class<XMLGregorianCalendar> t) {
	        super(t);
	    }

	  @Override
	  public void serialize(
		XMLGregorianCalendar value, JsonGenerator jgen, SerializerProvider provider) 
	      throws IOException, JsonProcessingException {
		  jgen.writeString(value.toXMLFormat());
	    }


}
