package gr.alpha.cbs.fuse.helpers;

import gr.alpha.cbs.fuse.ifaces.ChannelRestCallerInterface;
import io.quarkus.runtime.annotations.RegisterForReflection;

import org.jboss.logging.Logger;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.util.HashMap;
import java.util.List;

@Named("channelBucrCallerHelper")
@ApplicationScoped
@RegisterForReflection

public class ChannelBucrCallerHelper {

    private static final Logger LOGGER = Logger.getLogger(ChannelBucrCallerHelper.class);

    @Inject
    ChannelRestCallerInterface channelRestCaller;

    public  List<String> getGroupsCodesByUnitCode(String unitCode) throws Exception {
        try {
            return channelRestCaller.getGroupsCodesByUnitCode(unitCode);
        } catch (Exception e) {
            LOGGER.error("ERROR wile invoking GetGroupsCodesByUnitCode with unitCode = " + unitCode);
            throw e;
        }
    }

    public  List<String> getGroupsCodesByMasterUnitCodeAndGroupTypeCode(String masterUnitCode, String groupTypeCode) throws Exception {
        try {
            return channelRestCaller.getGroupsCodesByMasterUnitCodeAndGroupTypeCode(masterUnitCode, groupTypeCode);
        } catch (Exception e) {
            LOGGER.error("ERROR wile invoking GetGroupsCodesByMasterUnitCodeAndGroupTypeCode with masterUnitCode = " + masterUnitCode + " and groupTypeCode =" + groupTypeCode);
            throw e;
        }
    }

    public  HashMap<Integer, String> getUnitsByGroupCode(String groupCode) throws Exception {
        try {
            return channelRestCaller.getUnitsByGroupCode(groupCode);
        } catch (Exception e) {
            LOGGER.error("ERROR wile invoking GetUnitsByGroupCode with groupCode = " + groupCode);
            throw e;
        }
    }

    public  HashMap<Integer, String> getTeamsByUnitCodeAndGroupCode(String unitCode, String groupCode) throws Exception {
        try {
            return channelRestCaller.getTeamsByUnitCodeAndGroupCode(unitCode, groupCode);
        } catch (Exception e) {
            LOGGER.error("ERROR wile invoking GetTeamsByUnitCodeAndGroupCode with unitCode =" + unitCode + " and groupCode = " + groupCode);
            throw e;
        }
    }

    public  List<String> getGroupsCodesByUnitCodeAndGroupTypeCode(String unitCode, String groupTypeCode) throws Exception {
        try {
            return channelRestCaller.getGroupsCodesByUnitCodeAndGroupTypeCode(unitCode, groupTypeCode);
        } catch (Exception e) {
            LOGGER.error("ERROR wile invoking GetGroupsCodesByUnitCodeAndGroupTypeCode with unitCode = " + unitCode + " and groupTypeCode = " + groupTypeCode);
            throw e;
        }
    }
}