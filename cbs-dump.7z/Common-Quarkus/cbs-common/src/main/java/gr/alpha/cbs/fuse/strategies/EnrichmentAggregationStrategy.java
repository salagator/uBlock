package gr.alpha.cbs.fuse.strategies;

import gr.alpha.cbs.fuse.support.ThreadLocalXPathExpression;
import gr.alpha.cbs.fuse.tools.XPathHelpers;
import org.apache.camel.AggregationStrategy;
import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import jakarta.annotation.PostConstruct;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import java.util.ArrayList;
import java.util.List;

public class EnrichmentAggregationStrategy implements AggregationStrategy {
    private static final String MUST_REPEAT = "mustRepeat";

    private static final Logger logger = LoggerFactory.getLogger(EnrichmentAggregationStrategy.class);

    private String namespaceInfo;
    private String namespace;
    private String namespacePrefix;
    private String sourceListXPath;
    private String targetElementXPath;
    private String repeatXPath;
    private String nodeEmptyXPath;
    private String concatTargetElementXPath;
    private String concatSourceElementXPath;
    private String removeTargetElementXPath;
    private List<String> additionalSourceListXPaths;
    private List<String> replaceSourceXPaths;
    private List<String> replaceTargetXPaths;
    private int pagingWindowSize;
    private int itemsPerServiceCall;

    private ThreadLocalXPathExpression sourceListExpression;
    private ThreadLocalXPathExpression targetElementExpression;
    private ThreadLocalXPathExpression repeatExpression;
    private ThreadLocalXPathExpression nodeEmptyExpression;
    private ThreadLocalXPathExpression concatTargetElementExpression;
    private ThreadLocalXPathExpression concatSourceElementExpression;
    private ThreadLocalXPathExpression removeTargetElementExpression;
    private List<ThreadLocalXPathExpression> additionalSourceListExpressions;
    private List<ThreadLocalXPathExpression> replaceSourceListExpressions;
    private List<ThreadLocalXPathExpression> replaceTargetListExpressions;

    private boolean aggregateHeaders = true;
    @Override
    public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
        // guard against unlikely NPE
        if (newExchange == null) {
            return oldExchange;
        }

        try {
            Document srcDocument = (Document) newExchange.getIn().getBody();

            // in the first call to this aggregation, do not call the XSLT but instead store the
            // incoming exchange
            if (oldExchange == null) {
                NodeList sourceNodes = (NodeList) sourceListExpression.get().evaluate(srcDocument, XPathConstants.NODESET);
                for (int j = sourceNodes.getLength() - 1; j >= 0; j--) {
                    Node childNode = sourceNodes.item(j);
                    boolean isEmpty = (Boolean) nodeEmptyExpression.get().evaluate(childNode, XPathConstants.BOOLEAN);
                    if (isEmpty) {
                        childNode.getParentNode().removeChild(childNode);
                    }
                }
                return newExchange;
            }


            Document targetDocument = (Document) oldExchange.getIn().getBody();
            Node targetNode = (Node) targetElementExpression.get().evaluate(targetDocument, XPathConstants.NODE);

            int actualWindowSize = pagingWindowSize;
            int numberOfChildren = targetNode.getChildNodes().getLength();
            boolean mustRepeatCase2 = true;
            NodeList sourceNodes = (NodeList) sourceListExpression.get().evaluate(srcDocument, XPathConstants.NODESET);
            List<NodeList> additionalNodeLists = new ArrayList<>();
            for (ThreadLocalXPathExpression expr : additionalSourceListExpressions) {
                additionalNodeLists.add((NodeList) expr.get().evaluate(srcDocument, XPathConstants.NODESET));
            }
            for (int j = 0; j < sourceNodes.getLength(); j++) {
                int index = sourceNodes.getLength();
                Node childNode = sourceNodes.item(j);
                boolean isEmpty = (Boolean) nodeEmptyExpression.get().evaluate(childNode, XPathConstants.BOOLEAN);
                if (isEmpty) {
                    continue;
                }

                /**
                 * The task was the service to return the EXACT size of  actualWindowSize records
                 * For the case where the module of actualWindowSize/records_per_request = 1
                 * we try not to read in the extra nodes
                 * in this case we use the property cutOffRecordsFromLastCall in witch we define the records per request the service returns
                 */
                if ( ((numberOfChildren + itemsPerServiceCall) > actualWindowSize) &&  itemsPerServiceCall > 0 ){
                    int lastRecord =  index - (numberOfChildren + itemsPerServiceCall) - actualWindowSize;

                    if (j < lastRecord ) {
                        Node adoptedChild = targetDocument.importNode(childNode, true);
                        for (NodeList additionalNodes : additionalNodeLists) {
                            adoptedChild.appendChild(targetDocument.importNode(additionalNodes.item(j),true));
                        }
                        targetNode.appendChild(adoptedChild);
                        mustRepeatCase2 = false;
                    }
                } else {
                    Node adoptedChild = targetDocument.importNode(childNode,true);
                    for (NodeList additionalNodes : additionalNodeLists) {
                        adoptedChild.appendChild(targetDocument.importNode(additionalNodes.item(j),true));
                    }
                    targetNode.appendChild(adoptedChild);
                }
            }

            if (concatTargetElementExpression != null && concatSourceElementExpression != null) {
                Node concatTargetNode = (Node) concatTargetElementExpression.get().evaluate(targetDocument, XPathConstants.NODE);
                Node concatSourceNode = (Node) concatSourceElementExpression.get().evaluate(srcDocument, XPathConstants.NODE);
                concatTargetNode.appendChild(targetDocument.importNode(concatSourceNode, true));
            }

            if (removeTargetElementExpression != null) {
                NodeList removeNodes = (NodeList) removeTargetElementExpression.get().evaluate(targetDocument, XPathConstants.NODESET);
                for (int j = removeNodes.getLength() - 1; j >= 0; j--) {
                    Node nodeToRemove = removeNodes.item(j);
                    nodeToRemove.getParentNode().removeChild(nodeToRemove);
                }
            }

            for (int i = 0; i < replaceSourceXPaths.size(); i++) {
                Node currentSourceNode = (Node) replaceSourceListExpressions.get(i).get().evaluate(srcDocument, XPathConstants.NODE);
                Node currentTargetNode = (Node) replaceTargetListExpressions.get(i).get().evaluate(targetDocument, XPathConstants.NODE);
                Node newChild = targetDocument.importNode(currentSourceNode,true);
                currentTargetNode.getParentNode().replaceChild(newChild, currentTargetNode);
            }

            /**
             * The header aggregation should be here before we decide whether we will repeat the loop.
             * Otherwise, any incoming mustRepeat header will overwrite the one we calculate here.
             */
            if (aggregateHeaders) {
                newExchange.getIn().getHeaders().forEach((k, v) -> oldExchange.getIn().setHeader(k, v) );
            }

            boolean repeatValue = (Boolean) repeatExpression.get().evaluate(srcDocument, XPathConstants.BOOLEAN);

            if (oldExchange.getIn().getHeader("cbs.aggregation.paging.window.size.override") != null) {
                actualWindowSize = Integer.parseInt(oldExchange.getIn().getHeader("cbs.aggregation.paging.window.size.override").toString());
                if (actualWindowSize < 0) {
                    actualWindowSize = Integer.MAX_VALUE;
                }
            }
            boolean pagingWindowIsFull = actualWindowSize == 0 ? false : targetNode.getChildNodes().getLength() >= actualWindowSize;

            if (itemsPerServiceCall > 0) {
                if (repeatValue && mustRepeatCase2) {
                    logger.info("We must repeat the process");
                    oldExchange.getIn().setHeader(MUST_REPEAT, true);
                } else {
                    oldExchange.getIn().setHeader(MUST_REPEAT, false);
                }
            }else if(repeatValue && !pagingWindowIsFull) {
                logger.info("We must repeat the process");
                oldExchange.getIn().setHeader(MUST_REPEAT, true);
            } else {
                oldExchange.getIn().setHeader(MUST_REPEAT, false);
            }

            return oldExchange;
        } catch (Exception e) {
            logger.error("Unable to aggregate exchanges.", e);
            throw new RuntimeException("Unable to aggregate exchanges.");
        }
    }

    @PostConstruct
    public void afterPropertiesSet() throws Exception {
        if (sourceListXPath == null ||
                targetElementXPath == null ||
                repeatXPath == null ||
                nodeEmptyXPath == null ||
                namespaceInfo == null) {
            throw new Exception("You must supply values for the following aggregation strategy parameters: "
                    + "sourceListXPath, targetElementXPath, repeatXPath, nodeEmptyXPath, namespaceInfo.");
        }

        int colonIndex = namespaceInfo.indexOf(':');
        if (colonIndex == -1) {
            throw new Exception("Malformed namespaceInfo. It must have a namespace prefix part and a namespace URL part seperated by ':'.");
        }

        namespacePrefix = namespaceInfo.substring(0, colonIndex);
        namespace = namespaceInfo.substring(colonIndex + 1);

        XPath xpath = XPathHelpers.getXPath(namespace, namespacePrefix);


        sourceListExpression = new ThreadLocalXPathExpression(xpath, sourceListXPath);
        targetElementExpression = new ThreadLocalXPathExpression(xpath, targetElementXPath);
        repeatExpression = new ThreadLocalXPathExpression(xpath, repeatXPath);
        nodeEmptyExpression = new ThreadLocalXPathExpression(xpath, nodeEmptyXPath);
        if (concatTargetElementXPath != null && concatSourceElementXPath != null) {
            concatTargetElementExpression = new ThreadLocalXPathExpression(xpath, concatTargetElementXPath);
            concatSourceElementExpression = new ThreadLocalXPathExpression(xpath, concatSourceElementXPath);
        }
        if (removeTargetElementXPath != null) {
            removeTargetElementExpression = new ThreadLocalXPathExpression(xpath, removeTargetElementXPath);
        }

        if(additionalSourceListXPaths == null) {
            additionalSourceListXPaths = new ArrayList<>();
        }

        additionalSourceListExpressions = new ArrayList<>();
        for (String sourceXPath : additionalSourceListXPaths) {
            ThreadLocalXPathExpression expr = new ThreadLocalXPathExpression(xpath, sourceXPath);
            additionalSourceListExpressions.add(expr);
        }

        if (replaceSourceXPaths == null) {
            replaceSourceXPaths = new ArrayList<>();
        }
        if (replaceTargetXPaths == null) {
            replaceTargetXPaths = new ArrayList<>();
        }
        if (replaceSourceXPaths.size() != replaceTargetXPaths.size()) {
            throw new Exception("Size of source and target replace XPath lists do not match (" +
                    replaceSourceXPaths.size() + ", " + replaceTargetXPaths.size() + ").");
        }
        replaceSourceListExpressions = new ArrayList<>();
        for (String replaceSourceXPath : replaceSourceXPaths) {
            ThreadLocalXPathExpression expr = new ThreadLocalXPathExpression(xpath, replaceSourceXPath);
            replaceSourceListExpressions.add(expr);
        }
        replaceTargetListExpressions = new ArrayList<>();
        for (String replaceTargetXPath : replaceTargetXPaths) {
            ThreadLocalXPathExpression expr = new ThreadLocalXPathExpression(xpath, replaceTargetXPath);
            replaceTargetListExpressions.add(expr);
        }
    }

    public void setNamespaceInfo(String namespaceInfo) {
        this.namespaceInfo = namespaceInfo;
    }

    public void setSourceListXPath(String sourceListXPath) {
        this.sourceListXPath = sourceListXPath;
    }

    public void setTargetElementXPath(String targetElementXPath) {
        this.targetElementXPath = targetElementXPath;
    }

    public void setRepeatXPath(String repeatXPath) {
        this.repeatXPath = repeatXPath;
    }

    public void setNodeEmptyXPath(String nodeEmptyXPath) {
        this.nodeEmptyXPath = nodeEmptyXPath;
    }

    public void setConcatTargetElementXPath(String concatTargetElementXPath) {
        this.concatTargetElementXPath = concatTargetElementXPath;
    }

    public void setConcatSourceElementXPath(String concatSourceElementXPath) {
        this.concatSourceElementXPath = concatSourceElementXPath;
    }

    public void setRemoveTargetElementXPath(String removeTargetElementXPath) {
        this.removeTargetElementXPath = removeTargetElementXPath;
    }

    public void setAggregateHeaders(boolean aggregateHeaders) {
        this.aggregateHeaders = aggregateHeaders;
    }

    public void setAdditionalSourceListXPaths(List<String> additionalSourceListXPaths) {
        this.additionalSourceListXPaths = additionalSourceListXPaths;
    }

    public void setPagingWindowSize(int pagingWindowSize) {
        this.pagingWindowSize = pagingWindowSize;
    }

    public void setReplaceSourceXPaths(List<String> replaceSourceXPaths) {
        this.replaceSourceXPaths = replaceSourceXPaths;
    }

    public void setReplaceTargetXPaths(List<String> replaceTargetXPaths) {
        this.replaceTargetXPaths = replaceTargetXPaths;
    }

    public int getItemsPerServiceCall() {
        return itemsPerServiceCall;
    }

    public void setItemsPerServiceCall(int itemsPerServiceCall) {
        this.itemsPerServiceCall = itemsPerServiceCall;
    }
}
