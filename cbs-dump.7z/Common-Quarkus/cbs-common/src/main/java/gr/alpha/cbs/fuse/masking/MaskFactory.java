package gr.alpha.cbs.fuse.masking;

public class MaskFactory {
	
	public static IMask getMask(String className){
		try{

			IMask mask = (IMask)Class.forName("gr.alpha.cbs.fuse.masking."+className).getDeclaredConstructor().newInstance();
			return mask;
		}catch (Exception e) {
			return new GenericMask();
		}	
	}
	
}