package gr.alpha.cbs.fuse.bean;

import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

@Named("warningExistenceBean")
@ApplicationScoped
@RegisterForReflection
public class WarningExistenceBean {
    public static boolean isWarningFree(Exchange exchange) {
        return exchange.getIn().getHeader("cbs.siglo.warning") == null;
    }
}
