package gr.alpha.cbs.fuse.service;

import org.jboss.resteasy.reactive.RestResponse;

import javax.xml.transform.dom.DOMSource;

public class ErrorEncounteredException extends RuntimeException {
    private DOMSource domSource;
    private RestResponse<String> restResponse;

    public ErrorEncounteredException(String message, DOMSource domSource) {
        super(message);
        this.domSource = domSource;
    }

    public ErrorEncounteredException(String message, RestResponse<String> restResponse) {
        super(message);
        this.restResponse = restResponse;
    }

    public DOMSource getDomSource() {
        return domSource;
    }

    public RestResponse<String> getRestResponse() {
        return restResponse;
    }
}
