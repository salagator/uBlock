package gr.alpha.cbs.fuse.helpers;

import java.util.HashMap;


import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.jboss.logging.Logger;

import gr.alpha.cbs.fuse.ifaces.MasterDataInterface;
import gr.alpha.cbs.fuse.enums.ConstantCurrencies;
/* 
 * Class that make a call to MasterData 
 * Given a currency value
 * Returns if is valid based on certain constraints 
 */
// TODO implement static methods - remove map from member variable make it local
@Named("CurrenciesHelper")
@ApplicationScoped
@RegisterForReflection
public class CurrenciesHelper{
	private static final Logger LOGGER = Logger.getLogger(CurrenciesHelper.class);
	private HashMap<String,String> map;
	private static final String currencies = "Currencies";
	@Inject
	MasterDataInterface masterData;

	/* Default call to MasterData to retrieve response */
	public HashMap<String,String> callToMasterData(String currencyValue) throws Exception{
		return masterData.getMasterDetailsByItemNameLists(currencies, currencyValue);
	}
	
	/* if current is valid for exchange*/
	public Boolean isValidCurrencyForExchange(String value) throws Exception{
		map = callToMasterData(value);
		Boolean isValid = false;
		if (map!=null && !map.isEmpty() && map.containsKey("CURRENCY_EXCHANGE")){
			String currExchange = map.get("CURRENCY_EXCHANGE");
			if("1".equals(currExchange)){
				isValid = true;
			}
		}
		return isValid;
	}
	
	/* if current is valid for exchange or current is Euro*/
	public Boolean isValidCurrencyForExchangeIncludingEUR(String value) throws Exception{
		Boolean isValid = false;
		int euroValue = Integer.parseInt(value);
		
		if(isValidCurrencyForExchange(value) || euroValue == ConstantCurrencies._EURO){
			isValid = true;
		}		
		return isValid;
	}
	
	/* if current is valid for bank note */
	public Boolean isValidCurrencyForBanknote(String value) throws Exception{
		map = callToMasterData(value);
		Boolean isValid = false;
		if (map!=null && !map.isEmpty() && map.containsKey("CURRENCY_BANK_NOTE")){
			String currExchange = map.get("CURRENCY_BANK_NOTE");
			if("1".equals(currExchange)){
				isValid = true;
			}
		}
		return isValid;
	}
	
	/* if current is valid for bank note or current is Euro*/
	public Boolean isValidCurrencyForBanknoteIncludingEUR(String value) throws Exception{
		Boolean isValid = false;
		int euroValue = Integer.parseInt(value);
		
		if(isValidCurrencyForBanknote(value) || euroValue == ConstantCurrencies._EURO){
			isValid = true;
		}	
		return isValid;
	}
	
	/* if current has previously changed to Euro  */
	public Boolean isValidCurrencyMigratedToEUR(String value) throws Exception{
		map = callToMasterData(value);
		Boolean isValid = false;
		if (map!=null && !map.isEmpty() && map.containsKey("CURRENCY_IN_OUT")){
			String currExchange = map.get("CURRENCY_IN_OUT");
			if("1".equals(currExchange)){
				isValid = true;
			}
		}
		return isValid;
	}
	
	/* if current is valid for account opening */
	public Boolean isValidCurrencyForAccountOpening(String value) throws Exception{
		map = callToMasterData(value);
		Boolean isValid = false;
		int euroValue = Integer.parseInt(value);
		
		if (map!=null && !map.isEmpty() && map.containsKey("CURRENCY_ACCNO_ALLOWED")){
			String currExchange = map.get("CURRENCY_ACCNO_ALLOWED");
			if("1".equals(currExchange) || euroValue == ConstantCurrencies._EURO){
				isValid = true;
			}
		}
		return isValid;
	}
	
	/* if currency is valid for exchange or bank note*/
	public Boolean isValidCurrencyForExchangeOrBanknote(String currency) throws Exception{
		return (isValidCurrencyForExchange(currency) || isValidCurrencyForBanknote(currency));
	}
	/* if currency is valid for exchange or bank note or currency is Euro*/
	public Boolean isValidCurrencyForExchangeOrBanknoteIncludingEUR(String currency) throws Exception{
		return (isValidCurrencyForExchangeOrBanknote(currency) || Integer.parseInt(currency) == ConstantCurrencies._EURO);
	}
	
	/**
	 * 
	 * MW function IsEoxCurrency as described on ESB.CreateFundTransferOfflinePayByAccount V0.5.docx file
	 * 
	 * @param currencyISO
	 * @return
	 * @throws Exception
	 */
	public boolean isEuropeanUnionCurrency(String currencyISO) throws Exception{
		
		map = callToMasterData(currencyISO);
		
		if (map!=null && !map.isEmpty() && map.containsKey("IsEOX")){
			if (LOGGER.isDebugEnabled()){
				LOGGER.debug("in isEuropeanUnionCurrency isEOX value: " + map.get("IsEOX"));
			}
			if ("1".equals(map.get("IsEOX"))){
				return true;
			}
		}
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("in isEuropeanUnionCurrency isEOX value not found or is not equal to 0");
		}
		return false;
	}
	
}
