package gr.alpha.cbs.fuse.support;

import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;

@Named("functionSubstitutor")
@ApplicationScoped
@RegisterForReflection
public class CharacterSubstitutorXsltExtension extends ExtensionFunctionDefinition {

    /**
     *
     */
    private static final long serialVersionUID = -3901296852162188027L;


    @Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("sb", "http://fuse.cbs.alpha.gr/substitutor/", "substitutor");
    }

    @Override
    public SequenceType[] getArgumentTypes() {
        return new SequenceType[]{SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING};

    }

    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
        return SequenceType.SINGLE_STRING;
    }

    @Override
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {
            private static final long serialVersionUID = 5090616615262067008L;

            @Override
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
                try {
                    String toLng = null;
                    if (arguments[0] instanceof LazySequence) {
                        toLng = ((LazySequence)arguments[0]).head().getStringValue();
                    } else if (arguments[0] instanceof StringValue) {
                        toLng = ((StringValue)arguments[0]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type: " + arguments[1].getClass().getCanonicalName());
                    }

                    String value = null;
                    if (arguments[1] instanceof LazySequence) {
                        value = ((LazySequence)arguments[1]).head().getStringValue();
                    } else if (arguments[1] instanceof StringValue) {
                        value = ((StringValue)arguments[1]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type: " + arguments[1].getClass().getCanonicalName());
                    }



                    if(toLng!=null && "GR".equals(toLng.trim()))
                        return StringValue.makeStringValue(FormatUtils.translateEnglish(value));
                    else if(toLng!=null && "EN".equals(toLng.trim()))
                        return StringValue.makeStringValue(FormatUtils.translateGreek(value));
                    else
                        return StringValue.makeStringValue(value) ;

                } catch (Exception e) {
                    throw new XPathException("Unable to translate value", e);
                }
            }
        };
    }

}

