package gr.alpha.cbs.fuse.support;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import gr.alpha.cbs.fuse.common.CBSConstants;
import org.apache.camel.Exchange;

/**
 * Default implementation of the Abstract printing rules processor that does no special case custom processing.
 */
public class DefaultPrintingRulesProcessor extends AbstractPrintingRulesProcessor {
	
	public DefaultPrintingRulesProcessor() {
		super();
	}
	
	public DefaultPrintingRulesProcessor(String kjarGroupId, String kjarArtifactId, String kjarVersion,
			String kieProcessName, boolean useOperationAgenda) {
		super(kjarGroupId, kjarArtifactId, kjarVersion, kieProcessName, useOperationAgenda);
	}
	
	@Override
	public void process(Exchange exchange) throws Exception {
		// Short circuit the BRMS call and perform the minimal processing here.
		Map<String, Object> properties = exchange.getProperties();
		
		PrintingInfoFromRoute printingInfoFromRoute = initPrintingInfoFromRoute(exchange);
		
		for (@SuppressWarnings("unused") String templateName : printingInfoFromRoute.templateList) {
			printingInfoFromRoute.statusList.add("P");
			printingInfoFromRoute.modeList.add("6");
		}

		properties.put(CBSConstants.HEADER_PRINTING_STATUS, printingInfoFromRoute.statusList);
		properties.put(CBSConstants.HEADER_PRINTING_MODE, printingInfoFromRoute.modeList);
		properties.put(CBSConstants.HEADER_PRINTING_SLIP_TYPE, printingInfoFromRoute.slipTypeList);
		properties.put(CBSConstants.HEADER_PRINTING_TEMPLATE_CODE, printingInfoFromRoute.templateList);

		List<PrintingResponse> responseList = new ArrayList<>();
		@SuppressWarnings("unchecked")
		Map<String, Object> printingMap = (Map<String, Object>) properties.get("printingMap");
		String operationName = (String) properties.get(CBSConstants.HEADER_TRANSACTION_NAME);
		performCustomProcessing(exchange, printingMap, operationName,
				printingInfoFromRoute.templateList,
				printingInfoFromRoute.slipTypeList,
				printingInfoFromRoute.modeList,
				printingInfoFromRoute.statusList,
				responseList);
	}

	@Override
	public void performCustomProcessing(Exchange exchange, Map<String, Object> printingMap, String operationName,
			List<String> templateList, List<String> slipTypeList, List<String> modeList, List<String> statusList,
			List<PrintingResponse> responseList) {
		// Intentionally do nothing
		return;
	}

}
