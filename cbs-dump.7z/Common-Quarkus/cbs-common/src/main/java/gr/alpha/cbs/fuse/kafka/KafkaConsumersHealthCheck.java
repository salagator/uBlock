package gr.alpha.cbs.fuse.kafka;

import io.quarkus.arc.properties.IfBuildProperty;
import io.smallrye.common.annotation.Blocking;
import jakarta.enterprise.context.ApplicationScoped;
import org.apache.camel.CamelContext;
import org.apache.camel.component.kafka.KafkaConsumer;
import org.apache.camel.component.kafka.TaskHealthState;
import org.apache.camel.spi.Registry;
import org.eclipse.microprofile.health.HealthCheck;
import org.eclipse.microprofile.health.HealthCheckResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@ApplicationScoped
@Blocking
@IfBuildProperty(name="cbs.fuse.health.kafka.consumers.enabled", stringValue="true")
public class KafkaConsumersHealthCheck implements HealthCheck {
    private static final Logger logger = LoggerFactory.getLogger(KafkaConsumersHealthCheck.class);

    private final CamelContext camelContext;

    public KafkaConsumersHealthCheck(CamelContext camelContext) {
        this.camelContext = camelContext;
    }

    @Override
    public HealthCheckResponse call() {
        boolean up = true;
        // Iterate over Kafka consumers registered in the Camel context registry
        Registry registry = camelContext.getRegistry();
        for (KafkaConsumer kc : registry.findByType(KafkaConsumer.class)) {
            try {
                List<TaskHealthState> healthStates = kc.healthStates();
                for (TaskHealthState healthState : healthStates) {
                    if (!healthState.isReady()) {
                        up = false;
                        final String msg = healthState.buildStateMessage();
                        final Exception lastError = healthState.getLastError();
                        logger.warn("Kafka consumer '{}' is not ready. State message: {}. Last error: {}",
                                kc.getEndpoint().getConfiguration().getTopic(), msg,
                                lastError != null ? lastError.getMessage() : "N/A");
                        // Stop at the first failure.
                        break;
                    }
                }
                if (!up) {
                    // Stop at the first failure.
                    break;
                }
            } catch (Exception e) {
                // If any exception occurs, consider the consumer as not connected
                logger.error("Unable to test Kafka consumer status.", e);
                up = false;
            }
        }
        return HealthCheckResponse.builder()
                .name("kafka-consumers-health-check")
                .status(up)
                .build();
    }
}
