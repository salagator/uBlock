package gr.alpha.cbs.fuse.masking;

public class LeftMask implements IMask {

	@Override
	public String mask(String value, int length) {
		StringBuilder builder = new StringBuilder();
		for(int i=0;i<length;i++){
			builder.append("*");
		}
		builder.append(value.substring(length));
		return builder.toString();
	}
}
