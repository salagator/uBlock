package gr.alpha.cbs.fuse.ejb;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;

import jakarta.jms.MapMessage;
import jakarta.transaction.Transactional;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.ExchangeProperty;
import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;


@Named("extraitHandlerBean")
@Dependent
@RegisterForReflection
public class ExtraitHandlerBean {
	
	private Map<String, MapMessage> allMessages;
	private Map<String, Map<String,String>> allDBMaps;

	private static final Logger LOGGER = Logger.getLogger(ExtraitHandlerBean.class);

	@Inject
	@io.quarkus.agroal.DataSource("psdxa")
	DataSource sqlDS;

	@Transactional(Transactional.TxType.MANDATORY)
	public void createExtraitRecord(@ExchangeProperty("extraitMap") Map<String, Object> extraitMap) throws Exception {

		if (extraitMap != null){
			writeToDB(extraitMap);
		}

	}

	/*	==================================================================================================*/

	private void writeToDB(Map<String, Object> extraitDBMap) throws Exception {
		LOGGER.info("Will write directly to DB");
		allDBMaps = new HashMap<String, Map<String,String>>();

		// There could be up to N different extrait records for one operation
		// Use Map 0 to keep the common fields of the operation

		// Iterate extraitMap and store the values to the appropriate numbered Maps

		for (Entry<String, Object> entry : extraitDBMap.entrySet()) {
			String fullKey = entry.getKey();
			// The key will be available in the fomat "Number~Keyvalue"
			String[] splitedValues = fullKey.split("~");

			String targetMapKey = splitedValues[0];
			LOGGER.debug("targetMapKey " + targetMapKey);
			String key = splitedValues[1];
			LOGGER.debug("key " + key);
			String value = "";
			if(entry.getValue() != null){
				value = entry.getValue().toString();
			}

			LOGGER.debug("value " + value);
			//
			addToAppropriateDBMap(targetMapKey, key, value);
		}

		// Keep common map to a specific Map, remove it from the pool
		Map<String, String> commonMap = allDBMaps.get("0");
		allDBMaps.remove("0");

		// iterate through all maps for
		for (Entry<String, Map<String, String>> entry : allDBMaps.entrySet()) {
			Map<String, String> mapToBeWritten = entry.getValue();
			int completedMandatoryFields = validateDBMap(mapToBeWritten);
			LOGGER.debug("completedMandatoryFields = " + completedMandatoryFields);
			// None of the mandatory fields are filled - Empty record will be skipped
			if (completedMandatoryFields == 0){
				LOGGER.debug("A record will be skipped, no mandatory fields are present");
			}
			// If all Mandatory fields are filled from the operation, write this record to the DB
			else if (completedMandatoryFields == 6){
				if (commonMap!=null)
					writeEntryToDBUsingSP(mapToBeWritten, commonMap, extraitDBMap);
			}
			// Not all mandatory fields are filled, throw an exception
			else if (completedMandatoryFields < 6){
				ErrorUtils.throwCBSException(null ,
						String.valueOf(ConstantError_Types._Technical),
						String.valueOf(ConstantError_System_IDs._FUSE),
						ExtraitHandlerBean.class.getCanonicalName(),
						ConstantErrorMessages._Wrong_Parameters_MW,
						String.valueOf(ConstantError_Levels._Error),
						"",
						"", "", "");
			}
		}

	}

	private void writeEntryToDBUsingSP(Map<String, String> mapToDB, Map<String, String> commonMap, Map<String, Object> extraitMap) throws Exception{

		String sql = "exec InsertAccountEntryFromCBS ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?";

		try(java.sql.Connection conn = this.sqlDS.getConnection();PreparedStatement statement = conn.prepareStatement(sql);) {

			statement.setLong		(1, Long.parseLong(mapToDB.get("AccountNumber")));

			java.util.Date date = new java.util.Date();
			java.sql.Date myDate = new java.sql.Date(date.getTime());
			String dateString = myDate.toString().replace("-", "");
			statement.setInt		(2, Integer.parseInt(dateString));

			statement.setTimestamp	(3, Timestamp.valueOf(mapToDB.get("UTCPostingTimestamp")));
			statement.setInt		(4, !StringUtils.isEmpty(mapToDB.get("RealBranchNumber"))		? Integer.parseInt(mapToDB.get("RealBranchNumber")) : 0);
			statement.setInt		(5, !StringUtils.isEmpty(mapToDB.get("CbsProductCode"))			? Integer.parseInt(mapToDB.get("CbsProductCode")) : 0);
			statement.setShort		(6, !StringUtils.isEmpty(mapToDB.get("TransType")) 				? Short.parseShort(mapToDB.get("TransType")) :0 );
			statement.setShort		(7, !StringUtils.isEmpty(mapToDB.get("Sign"))					? Short.parseShort(mapToDB.get("Sign")) : 2);
			statement.setBigDecimal	(8, !StringUtils.isEmpty(mapToDB.get("Amount"))					? new BigDecimal(mapToDB.get("Amount")) : new BigDecimal(0));
			//Construct Amount Signed
			if ( Short.parseShort(mapToDB.get("Sign")) == 2)
				statement.setBigDecimal	(9,(new BigDecimal(mapToDB.get("Amount"))).negate());
			else
				statement.setBigDecimal	(9,new BigDecimal(mapToDB.get("Amount")));
			statement.setInt		(10,!StringUtils.isEmpty(commonMap.get("WorkingDate"))			? Integer.parseInt(commonMap.get("WorkingDate").replace("-", "").replace("Z", "")) : 0);
			statement.setInt		(11,!StringUtils.isEmpty(mapToDB.get("ValeurDate"))				? Integer.parseInt(mapToDB.get("ValeurDate")) : 0);
			statement.setInt		(12,!StringUtils.isEmpty(mapToDB.get("AitCode"))				? Integer.parseInt(mapToDB.get("AitCode")) : 0);
			statement.setInt		(13,!StringUtils.isEmpty(mapToDB.get("AitSapCode")) 			? Integer.parseInt(mapToDB.get("AitSapCode")) : 0 );
			statement.setString		(14,!StringUtils.isEmpty(mapToDB.get("AitOnlineExtrait"))		? mapToDB.get("AitOnlineExtrait") : " ");
			statement.setString		(15,!StringUtils.isEmpty(mapToDB.get("AitSapExtrait")) 			? mapToDB.get("AitSapExtrait") : " ");
			statement.setString		(16,!StringUtils.isEmpty(mapToDB.get("CustomerID")) 			? mapToDB.get("CustomerID") : " ");
			statement.setString		(17,!StringUtils.isEmpty(mapToDB.get("CustomerName")) 			? mapToDB.get("CustomerName") : " ");
			statement.setBigDecimal (18,!StringUtils.isEmpty(mapToDB.get("GrossBalance"))			? new BigDecimal(mapToDB.get("GrossBalance")) : new BigDecimal(0));
			statement.setBigDecimal (19,!StringUtils.isEmpty(mapToDB.get("AvailableBalance"))		? new BigDecimal(mapToDB.get("AvailableBalance")) : new BigDecimal(0));
			statement.setString		(20,!StringUtils.isEmpty(mapToDB.get("Tun"))					? mapToDB.get("Tun") : " ");
			statement.setString		(21,!StringUtils.isEmpty(commonMap.get("Bun"))					? commonMap.get("Bun") : " ");
			statement.setString		(22,!StringUtils.isEmpty(mapToDB.get("RTun"))					? mapToDB.get("RTun") : " ");
			statement.setString		(23,!StringUtils.isEmpty(mapToDB.get("RBun"))					? mapToDB.get("RBun") : " ");
			statement.setString		(24,!StringUtils.isEmpty(mapToDB.get("EventCategory"))			? mapToDB.get("EventCategory") : " ");
			statement.setString		(25,!StringUtils.isEmpty(mapToDB.get("EventSubCategory"))		? mapToDB.get("EventSubCategory") : " ");
			statement.setString		(26,!StringUtils.isEmpty(mapToDB.get("ProductKind"))			? mapToDB.get("ProductKind") : " ");
			statement.setString		(27,!StringUtils.isEmpty(mapToDB.get("Product"))				? mapToDB.get("Product") : " ");
			statement.setString		(28,!StringUtils.isEmpty(mapToDB.get("ProductDescription"))		? mapToDB.get("ProductDescription") : " ");
			statement.setString		(29,!StringUtils.isEmpty(mapToDB.get("TransDetails"))			? mapToDB.get("TransDetails") : " ");
			statement.setString		(30,!StringUtils.isEmpty(mapToDB.get("TransDetailsJson"))		? mapToDB.get("TransDetailsJson") : " ");
			statement.setString 	(31,!StringUtils.isEmpty(mapToDB.get("OrginSys"))				? mapToDB.get("OrginSys") : " ");
			statement.setString 	(32,!StringUtils.isEmpty(mapToDB.get("OrginUN"))				? mapToDB.get("OrginUN") : " ");
			statement.setString 	(33,!StringUtils.isEmpty(mapToDB.get("OrginTransID"))			? mapToDB.get("OrginTransID") : " ");
			statement.setLong		(34,!StringUtils.isEmpty(mapToDB.get("ContraAccountNumber"))	? Long.parseLong(mapToDB.get("ContraAccountNumber")) : 0);
			statement.setString		(35,!StringUtils.isEmpty(mapToDB.get("Remarks"))				? mapToDB.get("Remarks") : " ");
			statement.setShort		(36,!StringUtils.isEmpty(mapToDB.get("FlagReversal"))			? Short.parseShort(mapToDB.get("FlagReversal")) : 0);
			statement.setShort		(37,!StringUtils.isEmpty(mapToDB.get("FlagCash")) 				? Short.parseShort(mapToDB.get("FlagCash")) : 0);
			statement.setShort		(38,!StringUtils.isEmpty(mapToDB.get("FlagClearHold"))			? Short.parseShort(mapToDB.get("FlagClearHold")) : 0);
			statement.setShort		(39,!StringUtils.isEmpty(mapToDB.get("FlagPad"))				? Short.parseShort(mapToDB.get("FlagPad")) : 0);
			statement.setShort		(40,!StringUtils.isEmpty(mapToDB.get("FlagTax"))				? Short.parseShort(mapToDB.get("FlagTax")) : 0);
			statement.setString 	(41,!StringUtils.isEmpty(commonMap.get("ChannelFunctionCode"))	? commonMap.get("ChannelFunctionCode") : " ");
			statement.setString		(42,!StringUtils.isEmpty(commonMap.get("ChannelRFunctionCode"))	? commonMap.get("ChannelRFunctionCode") : " ");
			statement.setString 	(43,!StringUtils.isEmpty(commonMap.get("ChannelExecBranch")) 	? commonMap.get("ChannelExecBranch") : " ");
			statement.setString 	(44,!StringUtils.isEmpty(commonMap.get("ChannelTerminalID"))	? commonMap.get("ChannelTerminalID") : " ");
			statement.setString 	(45,!StringUtils.isEmpty(mapToDB.get("ChannelTransNetwork"))	? mapToDB.get("ChannelTransNetwork") : " ");
			statement.setString 	(46,!StringUtils.isEmpty(mapToDB.get("Psd")) 					? mapToDB.get("Psd") : " ");
			statement.setString 	(47,!StringUtils.isEmpty(mapToDB.get("PsdJson")) 				? mapToDB.get("PsdJson") : " ");
			statement.setString 	(48,!StringUtils.isEmpty(mapToDB.get("Pad"))					? mapToDB.get("Pad") : " ");
			statement.setString 	(49,!StringUtils.isEmpty(mapToDB.get("PadJson"))				? mapToDB.get("PadJson") : " ");
			statement.setString		(50,!StringUtils.isEmpty(mapToDB.get("CurrentTimestamp"))		? mapToDB.get("CurrentTimestamp") : " ");
			statement.execute();
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Exception on Writting EntryAccounts", e);
			throw e;
		}

	}

	private void addToAppropriateDBMap(String targetMapKey, String key, String value){
		Map<String, String>  targetMap = checkIfExistsOrReturnNewMapDB(targetMapKey);

		targetMap.put(key, value);
		allDBMaps.put(targetMapKey, targetMap);
	}

	private Map<String, String> checkIfExistsOrReturnNewMapDB(String targetMapKey){

		Map<String, String> targetMap = allDBMaps.get(targetMapKey);

		if (targetMap == null){
			targetMap = new HashMap<String, String>();
		}
		return targetMap;
	}

	private int validateDBMap(Map<String, String> mapForValidation) throws Exception{
		int completedMandatoryFields = 0;


		if (!StringUtils.isEmpty(mapForValidation.get("AccountNumber"))) completedMandatoryFields++;
		if (!StringUtils.isEmpty(mapForValidation.get("UTCPostingTimestamp"))) completedMandatoryFields++;
		if (!StringUtils.isEmpty(mapForValidation.get("Amount"))) completedMandatoryFields++;
		if (!StringUtils.isEmpty(mapForValidation.get("GrossBalance"))) completedMandatoryFields++;
		if (!StringUtils.isEmpty(mapForValidation.get("AvailableBalance"))) completedMandatoryFields++;
		if (!StringUtils.isEmpty(mapForValidation.get("CurrentTimestamp"))) completedMandatoryFields++;

		return completedMandatoryFields;
	}
}	