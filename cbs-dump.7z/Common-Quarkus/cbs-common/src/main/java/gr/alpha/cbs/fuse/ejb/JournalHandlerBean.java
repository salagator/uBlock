package gr.alpha.cbs.fuse.ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLXML;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;

import jakarta.transaction.TransactionScoped;
import jakarta.transaction.Transactional;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.ExchangeProperty;
import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;

@Named("journalHandlerBean")
@TransactionScoped
@RegisterForReflection
public class JournalHandlerBean extends AbstractJournalHandlerBean {

	@Inject
	@io.quarkus.agroal.DataSource("cbsxa")
	DataSource sqlDS;

	@Override
	protected DataSource getDataSource() {
		return sqlDS;
	}

	private static final Logger LOGGER = Logger.getLogger(JournalHandlerBean.class);
	private static final int BMR_TRANSACTION = 18;

	@Transactional(Transactional.TxType.REQUIRED)
	public void createJournalRecord(@ExchangeProperty("journalMap") Map<String, Object> journalMap) throws Exception {
		// TODO take null protection away when journal horizontal is fully
		// implemented

		LOGGER.debug("createJournalRecord");
		if (journalMap != null)
			writeToDatabase(journalMap, true);
	}

	@Transactional(Transactional.TxType.REQUIRED)
	public void createJournalReverseRecord(@ExchangeProperty("journalReverseMap") Map<String, Object> journalReverseMap) throws Exception {

		LOGGER.debug("createJournalReverseRecord");
		if (journalReverseMap != null)
			writeReverseJournalToDatabase(journalReverseMap);
	}

	private void writeReverseJournalToDatabase(Map<String, Object> journalReverseMap) throws Exception {
		String tableName ="JOU_Reversal_Data";
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("Full Map For Reverse Journal: "+journalReverseMap);
		}

		List<Map<String, Object>> listForInsertionMaps = divideJournalDataInLists(journalReverseMap);

		Map<String, Object> journalForTable = listForInsertionMaps.get(0);
		Map<String, Object> journalForXml = listForInsertionMaps.get(2);

		List<String> sqlKeys = Arrays.asList("BUN", "JournalReversePayload");

		StringJoiner sqlJoiner = new StringJoiner(",", "insert into " + tableName + " (", ")");
		sqlKeys.forEach(s -> sqlJoiner.add(s));

		String sql = null;
		sql = sqlJoiner.toString() + " values(?,?)";

		try(Connection conn = this.sqlDS.getConnection();PreparedStatement statement = conn.prepareStatement(sql);) {

			String bun = (String) journalForTable.get("BUN");
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("BUN: "+ bun);
			}

			/* BUN */
			statement.setString(1, StringUtils.left(bun, 18));
			/* JournalPayload */
			SQLXML sqlxml = conn.createSQLXML();
			sqlxml.setString(createJournalPayloadXml(sqlKeys, journalForXml));
			statement.setSQLXML(2, sqlxml);

			statement.execute();



		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Exception on Writting Journal", e);
			throw e;

		}
	}
}