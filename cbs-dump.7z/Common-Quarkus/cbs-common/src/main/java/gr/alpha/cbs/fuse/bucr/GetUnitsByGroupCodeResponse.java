package gr.alpha.cbs.fuse.bucr;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class GetUnitsByGroupCodeResponse {
	
	private Units responseData;

	public Units getResponseData() {
		return responseData;
	}

	public void setResponseData(Units responseData) {
		this.responseData = responseData;
	}

}
