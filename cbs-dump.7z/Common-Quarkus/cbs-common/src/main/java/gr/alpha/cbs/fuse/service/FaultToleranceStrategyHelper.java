package gr.alpha.cbs.fuse.service;

import io.smallrye.faulttolerance.api.CircuitBreakerState;
import io.smallrye.faulttolerance.api.RateLimitType;
import io.smallrye.faulttolerance.api.TypedGuard;

import java.time.temporal.ChronoUnit;
import java.util.Collection;
import java.util.concurrent.CompletionStage;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class FaultToleranceStrategyHelper {

    public static class Builder<T> {
        private TypedGuard.Builder<T> parent;
        private final Class<T> resultType;

        private Builder(TypedGuard.Builder<T> parent, Class<T> resultType) {
            this.parent = parent;
            this.resultType = resultType;
        }

        public static <T> Builder<CompletionStage<T>> createAsynchronous() {
            @SuppressWarnings("unchecked")
            TypedGuard.Builder<CompletionStage<T>> builder =
                    (TypedGuard.Builder<CompletionStage<T>>) (TypedGuard.Builder<?>) TypedGuard.create(CompletionStage.class);
            @SuppressWarnings("unchecked")
            Class<CompletionStage<T>> resultType =
                    (Class<CompletionStage<T>>) (Class<?>) CompletionStage.class;
            return new Builder<>(builder, resultType);
        }

        public static <T> Builder<T> createSynchronous(Class<T> resultType) {
            TypedGuard.Builder<T> builder = TypedGuard.create(resultType);
            return new Builder<>(builder, resultType);
        }

        public boolean isAsynchronous() {
            return CompletionStage.class.equals(resultType);
        }

        public Builder<T> addFallbackStrategy(
                Function<Throwable, T> handler,
                Predicate<Throwable> whenValue,
                Collection<Class<? extends Throwable>> applyOn,
                Collection<Class<? extends Throwable>> skipOn
        ) {
            TypedGuard.Builder.FallbackBuilder<T> fallbackBuilder = parent.
                    withFallback().
                    handler(handler);
            if (whenValue != null) {
                fallbackBuilder.when(whenValue);
            }
            if (applyOn != null && !applyOn.isEmpty()) {
                fallbackBuilder.applyOn(applyOn);
            }
            if (skipOn != null && !skipOn.isEmpty()) {
                fallbackBuilder.skipOn(skipOn);
            }
            parent = fallbackBuilder.done();
            return this;
        }

        public Builder<T> addBulkheadStrategy(
                int limit,
                int queueSize,
                Runnable acceptableRunnable,
                Runnable rejectedRunnable,
                Runnable finishedRunnable
        ) {
            TypedGuard.Builder.BulkheadBuilder<T> bulkheadBuilder = parent.
                    withBulkhead().
                    limit(limit);
            if (queueSize > 0) {
                bulkheadBuilder.queueSize(queueSize);
            }
            if (acceptableRunnable != null) {
                bulkheadBuilder.onAccepted(acceptableRunnable);
            }
            if (rejectedRunnable != null) {
                bulkheadBuilder.onRejected(rejectedRunnable);
            }
            if (finishedRunnable != null) {
                bulkheadBuilder.onFinished(finishedRunnable);
            }
            parent = bulkheadBuilder.done();
            return this;
        }

        public Builder<T> addRetryStrategy(
                int maxRetries,
                long delay,
                ChronoUnit delayUnit,
                long maxDuration,
                ChronoUnit maxDurationUnit,
                long jitter,
                ChronoUnit jitterUnit,
                Predicate<Object> whenResult,
                Predicate<Throwable> whenException,
                Collection<Class<? extends Throwable>> retryOn,
                Collection<Class<? extends Throwable>> abortOn,
                boolean useExponentialBackoff,
                boolean useFibonacciBackoff,
                Runnable beforeRetry,
                Runnable onRetry,
                Runnable onSuccess,
                Runnable onFailure
        ) {
            TypedGuard.Builder.RetryBuilder<T> retryBuilder = parent.
                    withRetry().
                    maxRetries(maxRetries);
            if (delay > 0) {
                retryBuilder.delay(delay, delayUnit);
            }
            if (maxDuration > 0) {
                retryBuilder.maxDuration(maxDuration, maxDurationUnit);
            }
            if (jitter > 0) {
                retryBuilder.jitter(jitter, jitterUnit);
            }
            if (whenResult != null) {
                retryBuilder.whenResult(whenResult);
            }
            if (whenException != null) {
                retryBuilder.whenException(whenException);
            }
            if (retryOn != null && !retryOn.isEmpty()) {
                retryBuilder.retryOn(retryOn);
            }
            if (abortOn != null && !abortOn.isEmpty()) {
                retryBuilder.abortOn(abortOn);
            }
            if (useExponentialBackoff) {
                retryBuilder.withExponentialBackoff();
            }
            if (useFibonacciBackoff) {
                retryBuilder.withFibonacciBackoff();
            }
            if (beforeRetry != null) {
                retryBuilder.beforeRetry(beforeRetry);
            }
            if (onRetry != null) {
                retryBuilder.onRetry(onRetry);
            }
            if (onSuccess != null) {
                retryBuilder.onSuccess(onSuccess);
            }
            if (onFailure != null) {
                retryBuilder.onFailure(onFailure);
            }
            parent = retryBuilder.done();
            return this;
        }

        public Builder<T> addCircuitBreakerStrategy(
                long delay,
                ChronoUnit delayUnit,
                int requestVolumeThreshold,
                double failureRatio,
                int successThreshold,
                Collection<Class<? extends Throwable>> failOn,
                Collection<Class<? extends Throwable>> skipOn,
                Predicate<Throwable> whenValue,
                Consumer<CircuitBreakerState> onStateChange,
                Runnable onSuccess,
                Runnable onPrevented,
                Runnable onFailure
        ) {
            TypedGuard.Builder.CircuitBreakerBuilder<T> circuitBreakerBuilder = parent.
                    withCircuitBreaker();
            if (delay > 0) {
                circuitBreakerBuilder.delay(delay, delayUnit);
            }
            if (failOn != null && !failOn.isEmpty()) {
                circuitBreakerBuilder.failOn(failOn);
            }
            if (skipOn != null && !skipOn.isEmpty()) {
                circuitBreakerBuilder.skipOn(skipOn);
            }
            if (requestVolumeThreshold > 0) {
                circuitBreakerBuilder.requestVolumeThreshold(requestVolumeThreshold);
            }
            if (failureRatio >= 0) {
                circuitBreakerBuilder.failureRatio(failureRatio);
            }
            if (successThreshold > 0) {
                circuitBreakerBuilder.successThreshold(successThreshold);
            }
            if (whenValue != null) {
                circuitBreakerBuilder.when(whenValue);
            }
            if (onStateChange != null) {
                circuitBreakerBuilder.onStateChange(onStateChange);
            }
            if (onSuccess != null) {
                circuitBreakerBuilder.onSuccess(onSuccess);
            }
            if (onPrevented != null) {
                circuitBreakerBuilder.onPrevented(onPrevented);
            }
            if (onFailure != null) {
                circuitBreakerBuilder.onFailure(onFailure);
            }
            parent = circuitBreakerBuilder.done();
            return this;
        }

        public Builder<T> addRateLimitStrategy(
                int limit,
                long window,
                ChronoUnit windowUnit,
                long minSpacing,
                ChronoUnit minSpacingUnit,
                RateLimitType rateLimitType,
                Runnable onPermitted,
                Runnable onRejected
        ) {
            TypedGuard.Builder.RateLimitBuilder<T> rateLimitBuilder = parent.
                    withRateLimit().
                    type(rateLimitType);
            if (limit != 0) {
                rateLimitBuilder.limit(limit);
            }
            if (window != 0) {
                rateLimitBuilder.window(window, windowUnit);
            }
            if (minSpacing >= 0) {
                rateLimitBuilder.minSpacing(minSpacing, minSpacingUnit);
            }
            if (onPermitted != null) {
                rateLimitBuilder.onPermitted(onPermitted);
            }
            if (onRejected != null) {
                rateLimitBuilder.onRejected(onRejected);
            }
            parent = rateLimitBuilder.done();
            return this;
        }

        public Builder<T> addTimeoutStrategy(
                long duration,
                ChronoUnit durationUnit,
                Runnable onTimeout,
                Runnable onFinished
        ) {
            TypedGuard.Builder.TimeoutBuilder<T> timeoutBuilder = parent.
                    withTimeout().
                    duration(duration, durationUnit);
            if (onTimeout != null) {
                timeoutBuilder.onTimeout(onTimeout);
            }
            if (onFinished != null) {
                timeoutBuilder.onFinished(onFinished);
            }
            parent = timeoutBuilder.done();
            return this;
        }

        TypedGuard<T> build() {
            return parent.build();
        }

    }

}
