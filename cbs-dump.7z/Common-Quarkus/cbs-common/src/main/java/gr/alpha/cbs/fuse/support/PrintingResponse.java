package gr.alpha.cbs.fuse.support;

import java.util.ArrayList;
import java.util.List;

public class PrintingResponse {
	private List<String> templateIDList;
	private List<String> eSlipTypeList;

	private String operationName;
	private String slipType;
	private boolean cardReaderPresentFlag;
	private boolean sendByEmail;
	private boolean removeTemplate;
	private String mode;
	private String status;
	private String templateName;
	private boolean decisionMade;

	public String getSlipType() {
		return slipType;
	}

	public void setSlipType(String slipType) {
		this.slipType = slipType;
	}

	public boolean isCardReaderPresentFlag() {
		return cardReaderPresentFlag;
	}

	public void setCardReaderPresentFlag(boolean cardReaderPresentFlag) {
		this.cardReaderPresentFlag = cardReaderPresentFlag;
	}

	public boolean isSendByEmail() {
		return sendByEmail;
	}

	public void setSendByEmail(boolean sendByEmail) {
		this.sendByEmail = sendByEmail;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public List<String> getTemplateIDList() {
		if (templateIDList == null)
			templateIDList = new ArrayList<>();
		return templateIDList;
	}

	public void setTemplateIDList(List<String> templateIDList) {
		this.templateIDList = templateIDList;
	}

	public List<String> geteSlipTypeList() {
		if (eSlipTypeList == null)
			eSlipTypeList = new ArrayList<>();
		return eSlipTypeList;
	}

	public void seteSlipTypeList(List<String> eSlipTypeList) {
		this.eSlipTypeList = eSlipTypeList;
	}

	public void addPrintInfo(String templateID, String eSlipType) {
		templateIDList = getTemplateIDList();
		templateIDList.add(templateID);

		eSlipTypeList = geteSlipTypeList();
		eSlipTypeList.add(eSlipType);
	}

	public boolean isRemoveTemplate() {
		return removeTemplate;
	}

	public void setRemoveTemplate(boolean removeTemplate) {
		this.removeTemplate = removeTemplate;
	}
	
	public boolean isDecisionMade() {
		return decisionMade;
	}
	
	public void setDecisionMade(boolean decisionMade) {
		this.decisionMade = decisionMade;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}
}
