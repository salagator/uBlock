package gr.alpha.cbs.fuse.processors;

import gr.alpha.cbs.fuse.legacy.ObjectFactory;
import gr.alpha.cbs.fuse.legacy.ServeResponse;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;

import gr.alpha.cbs.fuse.common.tools.FormatUtils;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

@Named("serveResponseHandler")
@ApplicationScoped
@RegisterForReflection
public class ServeResponseHandler implements Processor {

	private static final Logger LOGGER = Logger.getLogger(ServeResponseHandler.class);
	
	public void process(Exchange exchange){
			
		ObjectFactory factory = new ObjectFactory();
		Document doc = exchange.getIn().getBody(Document.class);
		
		ServeResponse response = factory.createServeResponse();
		
		String cdata = FormatUtils.getValue(doc, "/*[1]");
		response.setServeResult(cdata);
		
		response.setReply(cdata);
		response.setCommitStatus((short) 0);
		
		
		exchange.getIn().setBody(response);
	}	
	
}
