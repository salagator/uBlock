package gr.alpha.cbs.fuse.ifaces;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface ICreateAccountingEntriesHelper extends Serializable {

    public Map<String, String> getAccountingPlanRecord(String accountingCode) throws Exception;
    public List<Map<String, String>> getExceptionsList(String accountMask) throws Exception;
    public List<Map<String, String>> getPairAccountsList(String accountMask) throws Exception;
    public String getSAPAccountsData(int accountType, int currency1, String accountNumber) throws Exception;
    public List<Map<String, String>> getSpecificAccountingTemplateFC(String operationCode,String acgfcIncomeKind,String acgfcOutcomeKind) throws Exception;
    public String getAccountingModelFC(String operationCode, String incomeKind, String outcomeKind, Boolean calcSameInAndOut, String exchangeTypePosition, String specialCase) throws Exception;
}
