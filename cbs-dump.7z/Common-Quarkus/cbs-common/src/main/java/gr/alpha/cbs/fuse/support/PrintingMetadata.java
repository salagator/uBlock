package gr.alpha.cbs.fuse.support;

public class PrintingMetadata {
	
	private String operationName;
	
	private String slipType;
	
	private String templateName;
	
	private boolean cardReaderPresentFlag;
	
	private boolean sendByEmail;
	
	private String customerType;
	
	private String customerStatus;
	
	private String mode;
	
	private String status;
	
	private String loanFlagGeneric6;
	
	private String loanFinancialYear;


	public String getSlipType() {
		return slipType;
	}

	public void setSlipType(String slipType) {
		this.slipType = slipType;
	}

	public boolean isCardReaderPresentFlag() {
		return cardReaderPresentFlag;
	}

	public void setCardReaderPresentFlag(boolean cardReaderPresentFlag) {
		this.cardReaderPresentFlag = cardReaderPresentFlag;
	}

	public boolean isSendByEmail() {
		return sendByEmail;
	}

	public void setSendByEmail(boolean sendByEmail) {
		this.sendByEmail = sendByEmail;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getCustomerStatus() {
		return customerStatus;
	}

	public void setCustomerStatus(String customerStatus) {
		this.customerStatus = customerStatus;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getLoanFlagGeneric6() {
		return loanFlagGeneric6;
	}

	public void setLoanFlagGeneric6(String loanFlagGeneric6) {
		this.loanFlagGeneric6 = loanFlagGeneric6;
	}

	public String getLoanFinancialYear() {
		return loanFinancialYear;
	}

	public void setLoanFinancialYear(String loanFinancialYear) {
		this.loanFinancialYear = loanFinancialYear;
	}
}
