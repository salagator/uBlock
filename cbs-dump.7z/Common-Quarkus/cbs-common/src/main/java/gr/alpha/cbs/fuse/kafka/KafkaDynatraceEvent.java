package gr.alpha.cbs.fuse.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import gr.alpha.cbs.fuse.bean.DynatraceEvent;
import gr.alpha.cbs.fuse.bean.DynatraceEventAttachRules;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpHeaderValues;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.quarkus.runtime.annotations.RegisterForReflection;

import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.config.ConfigProvider;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;

@ApplicationScoped
@Named("kafkaDynatraceEvent")
@RegisterForReflection
public class KafkaDynatraceEvent {
	public void createEvent(Exchange exchange) throws Exception {
		boolean dynatraceEnabled = Boolean.parseBoolean(ConfigProvider.getConfig().getOptionalValue("cbs.camel.dynatrace.enabled", String.class).orElse("false"));
		if (dynatraceEnabled) {
			String protocol = ConfigProvider.getConfig().getValue("cbs.camel.dynatrace.server.protocol", String.class);
			String host = ConfigProvider.getConfig().getValue("cbs.camel.dynatrace.server.address", String.class);
			String instance = ConfigProvider.getConfig().getValue("cbs.camel.dynatrace.server.instance", String.class);
			String token = ConfigProvider.getConfig().getValue("cbs.camel.dynatrace.token", String.class);
			String kafkaEntityId = ConfigProvider.getConfig().getValue("cbs.camel.dynatrace.kafkaEntityId", String.class);

			if (StringUtils.isBlank(protocol) || StringUtils.isBlank(host) || StringUtils.isBlank(instance) || StringUtils.isBlank(token) || StringUtils.isBlank(kafkaEntityId)) {
				throw new IllegalArgumentException("There are required system properties missing for Dynatrace events [cbs.camel.dynatrace.server.protocol, cbs.camel.dynatrace.server.address, cbs.camel.dynatrace.server.instance, cbs.camel.dynatrace.token, cbs.camel.dynatrace.kafkaEntityId]");
			}

			String dynatraceEndpoint = String.format("%s://%s/e/%s/api/v1/events", protocol, host, instance);

			DynatraceEventAttachRules attachRules = new DynatraceEventAttachRules(Arrays.asList(kafkaEntityId));
			DynatraceEvent event = new DynatraceEvent("ERROR_EVENT", "Duplicate message id detected", String.format("Message ID: %s", exchange.getProperty(KafkaConstants.MESSAGE_ID)), String.format("Kafka Connector %s", exchange.getProperty(KafkaConstants.PROCESS_NAME)), attachRules);
			ObjectMapper mapper = new ObjectMapper();
			String eventAsString = mapper.writeValueAsString(event);

			HttpClient client = HttpClient.newHttpClient();
			HttpRequest request = HttpRequest.newBuilder()
					.header(HttpHeaderNames.CONTENT_TYPE.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
					.header(HttpHeaderNames.ACCEPT.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
					.POST(HttpRequest.BodyPublishers.ofString(eventAsString))
					.uri(new URI(dynatraceEndpoint))
					.build();
			HttpResponse<Void> clientResponse = client.send(request, HttpResponse.BodyHandlers.discarding());
			final int statusCode = clientResponse.statusCode();
			if (clientResponse.statusCode() != HttpResponseStatus.OK.code()) {
				ErrorUtils.throwCBSException(null,
						String.valueOf(ConstantError_Types._Technical),
						String.valueOf(ConstantError_System_IDs._FUSE),
						this.getClass().getCanonicalName(),
						String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob),
						String.valueOf(ConstantError_Levels._Error),
						String.format("Dynatrace Events API response error: %d", statusCode),
						"",
						"");
			}
		}
	}
}
