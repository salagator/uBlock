package gr.alpha.cbs.fuse.ejb;

import gr.alpha.cbs.fuse.common.CBSConstants;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangeProperties;
import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;

import jakarta.annotation.Resource;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;
import jakarta.transaction.Transactional;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Map;

@Named("documentRequirementBean")
@Dependent
@RegisterForReflection
public class DocumentRequirementBean {

	@Inject
	@io.quarkus.agroal.DataSource("cbsxa")
	DataSource sqlDS;

	private static final Logger LOGGER = Logger.getLogger(DocumentRequirementBean.class);

	private static final String insertDocumentRequirementToDB = "INSERT INTO DocumentUploadRequirements  "
			+ "(BUN, BMR, CreationDate, LastUpdateDate, BranchCode, Datacap, AlphanetID, Operation, documentUploadCategories, Status, IsRequiredFlag, DocumentId) " + "VALUES (?,?,GETDATE(),GETDATE(),?,?,?,?,?,?,?,?)";
	private static final String updateDocumentRequirementToOptional = "UPDATE DocumentUploadRequirements SET isRequiredFlag = ?, Status = ? WHERE BUN = ?";
	private static final String insertDocumentUploadSummaryToDB = "INSERT INTO DocumentUploadSummary  "
			+ "(BUN, LinkedDocumentStatus) " + "VALUES (?,?)";
	private static final String updateDocumentUploadSummary = "UPDATE DocumentUploadSummary SET LinkedDocumentStatus = ? WHERE BUN = ? ";
	private static final String selectCountUploadRequirementsWithDocumentId = "SELECT count(RequirementId) AS total FROM DocumentUploadRequirements WITH (NOLOCK) WHERE BUN = ? AND DocumentId <> NULL ";
	private static final String selectDocumentUploadCategoriesForOperation = "SELECT DocumentUploadCategories FROM DocumentUploadCategories WITH (NOLOCK) WHERE Operation = ?";
	private static final String COMPLETED_STATE="Completed";
	private static final String PENDING_STATE="Pending";


	@Transactional(Transactional.TxType.REQUIRED)
	public void createDocumentRequirement(Exchange exchange) throws Exception {
		//in createDocumentRequirement method
		LOGGER.info("in createDocumentRequirement method");
		insertDocumentRequirementToDatabase(exchange);
		insertDocumentUploadSummary(exchange.getProperties());
	}

	@Transactional(Transactional.TxType.REQUIRED)
	public void updateDocumentRequirement(Exchange exchange) throws Exception {
		LOGGER.info("updateDocumentRequirement");
		setDocumentRequirementToOptional(exchange);
		updateDocumentUploadCategory(exchange.getProperties());
	}

	private void insertDocumentRequirementToDatabase(Exchange exchange) throws Exception {
		LOGGER.info("in insertDocumentRequirementToDatabase");
		Map<String, Object> properties = exchange.getProperties();
		ArrayList<String> documentUploadCategoriesList = getDocumentUploadCategories(exchange);

		String bun = properties.get(CBSConstants.HEADER_BUN).toString();
		String bmrFlag = String.valueOf(properties.get("bmr.flag"));
		int bmr = bmrFlag.equals("true") ? 1 : 0;
		String branchCode = properties.get(CBSConstants.HEADER_BRANCH_CODE).toString();
		int datacap = 0;
		String alphanetID = properties.get("cbs.document.upload.alphanetId").toString() ;
		String operation = properties.get(CBSConstants.HEADER_TRANSACTION_NAME).toString();
		String status = PENDING_STATE;
		int isRequiredFlag = 1;
		String documentId = null;

		try (Connection conn = sqlDS.getConnection();
			PreparedStatement stmt = conn.prepareStatement(insertDocumentRequirementToDB);) {
			for (String documentUploadCategories: documentUploadCategoriesList) {
				stmt.setString(1, bun);
				stmt.setInt(2, bmr);
				stmt.setString(3, branchCode);
				stmt.setInt(4, datacap);
				stmt.setString(5, StringUtils.left((String) alphanetID, 10));
				stmt.setString(6, operation);
				stmt.setString(7, documentUploadCategories);
				stmt.setString(8, status);
				stmt.setInt(9, isRequiredFlag);
				stmt.setString(10, documentId);
				stmt.execute();
			}
		} catch (Exception e) {
			LOGGER.error("Exception on Writing Document Requirement", e);
			throw e;
		}
	}
	private void insertDocumentUploadSummary(@ExchangeProperties Map<String, Object> properties) throws Exception {
		LOGGER.info("in insertDocumentUploadSummary");
		String bun = properties.get(CBSConstants.HEADER_BUN).toString();
		int linkedDocumentStatus = 2 ;
		try (Connection conn = sqlDS.getConnection();
			 PreparedStatement stmt = conn.prepareStatement(insertDocumentUploadSummaryToDB);) {
			stmt.setString(1, bun);
			stmt.setInt(2, linkedDocumentStatus);
			stmt.execute();
		} catch (Exception e) {
			LOGGER.error("Exception on Document Upload Summary", e);
			throw e;
		}
	}

	private void setDocumentRequirementToOptional(Exchange exchange) throws Exception {
		LOGGER.info("in setDocumentRequirementToOptional");
		Map<String, Object> properties = exchange.getProperties();

		String bun = properties.get("cbs.common.reqBUN").toString();
		int isRequiredFlag = 0;
		String status = COMPLETED_STATE;

		try (Connection conn = sqlDS.getConnection();
			 PreparedStatement stmt = conn.prepareStatement(updateDocumentRequirementToOptional);) {
				stmt.setInt(1, isRequiredFlag);
				stmt.setString(2, status);
				stmt.setString(3, bun);
			int affectedRows = stmt.executeUpdate();
			if (affectedRows == 0) {
				LOGGER.info("Unable to update DocumentUploadSummary");
			}
		} catch (Exception e) {
			LOGGER.error("Exception on Writing Document Requirement", e);
			throw e;
		}
	}

	private void updateDocumentUploadCategory(@ExchangeProperties Map<String, Object> properties) throws Exception {
		LOGGER.info("in updateDocumentUploadCategory");

		ResultSet rs = null;
		String bun = properties.get("cbs.common.reqBUN").toString();
		LOGGER.info("cbs.common.reqBUN: " + bun);
		String status = COMPLETED_STATE;
		int linkedDocumentStatus = -1;
		int countCompleted = 0;

		try (Connection conn = sqlDS.getConnection();
			 PreparedStatement stmt_select = conn.prepareStatement(selectCountUploadRequirementsWithDocumentId);
			 PreparedStatement stmt_update = conn.prepareStatement(updateDocumentUploadSummary);) {

			/* count the completed requirements to update document upload summary properly */
			stmt_select.setString(1, bun);
			rs = stmt_select.executeQuery();

			while (rs.next()) {
				countCompleted = rs.getInt("total");
			}

			if (countCompleted > 0) {
				/* NAI => NAI, ΕΚΚΡΕΜΕΙ => ΝΑΙ */
				linkedDocumentStatus = 1;
			} else {
				/* ΕΚΚΡΕΜΕΙ => ΟΧΙ, ΟΧΙ => ΟΧΙ */
				linkedDocumentStatus = 0;
			}

			stmt_update.setInt(1, linkedDocumentStatus);
			stmt_update.setString(2, bun);
			int affectedRows = stmt_update.executeUpdate();
			if (affectedRows == 0) {
				LOGGER.info("Unable to update DocumentUploadSummary");
			}
		} catch (Exception e) {
			LOGGER.error("Exception on Writing Document Requirement", e);
			throw e;
		}
	}

	private ArrayList<String> getDocumentUploadCategories(Exchange exchange) throws Exception {
		LOGGER.info("in getDocumentUploadCategories");

		ArrayList<String> documentUploadCategoriesList = new ArrayList<>();
		ResultSet rs = null;
		String operation = exchange.getProperties().get(CBSConstants.HEADER_TRANSACTION_NAME).toString();
		String documentUploadCategories = null;

		try (Connection conn = sqlDS.getConnection();
			 PreparedStatement stmt = conn.prepareStatement(selectDocumentUploadCategoriesForOperation)) {

			stmt.setString(1, operation);
			rs = stmt.executeQuery();
			while (rs.next()) {
				documentUploadCategories = rs.getString("DocumentUploadCategories");
				documentUploadCategoriesList.add(documentUploadCategories);
			}
		} catch (Exception e) {
			LOGGER.error("Exception on Writing Document Requirement", e);
			throw e;
		}
		return documentUploadCategoriesList;
	}


}