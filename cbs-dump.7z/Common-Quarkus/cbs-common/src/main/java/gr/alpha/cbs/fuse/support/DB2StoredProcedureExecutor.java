package gr.alpha.cbs.fuse.support;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public abstract class DB2StoredProcedureExecutor {
	private String storedProcedure;
	
	public DB2StoredProcedureExecutor(String storedProcedure) {
		this.storedProcedure = storedProcedure;
	}
	
	public void executeAndStore(Connection connection, Object parameters, Element rootElement) throws SQLException {
		try (CallableStatement stmt = connection.prepareCall(storedProcedure)) {
			applyParametersToStatement(stmt, parameters);
			
			try (ResultSet resultSet = stmt.executeQuery()) {
				Element storedProcedureElement = rootElement.getOwnerDocument().createElement(extractStoredProcedureName(storedProcedure));
				rootElement.appendChild(storedProcedureElement);
				convertResultSetToXml(resultSet, storedProcedureElement);
			}
		}
	}
	
	
	/**
	 * Implement this in order to transfer the parameters that were extracted from the
	 * AbstractCrystalReportGeneratingProcessor::extractParameters() method to the callable
	 * statement that is the stored procedure.
	 * @param stmt the stored procedure compiled and ready to execute
	 * @param parameters the parameters to apply to the stored procedure
	 * @throws SQLException iff something goes wrong.
	 */
	public abstract void applyParametersToStatement(CallableStatement stmt, Object parameters) throws SQLException;
	
	private String extractStoredProcedureName(String storedProcedure) {
		int firstParenthesisIndex = storedProcedure.indexOf('(');
		if (firstParenthesisIndex == -1) {
			throw new IllegalStateException("Stored procedure '" + storedProcedure + "' is malformed for stored procedure name extraction.");
		}
		String remains = storedProcedure.substring(0, firstParenthesisIndex);
		int dotIndex = remains.indexOf('.');
		if (dotIndex == -1) {
			int spaceIndex = remains.indexOf(' ');
			if (spaceIndex == -1) {
				throw new IllegalStateException("Stored procedure '" + storedProcedure + "' is malformed for stored procedure name extraction.");
			}
			return remains.substring(spaceIndex + 1);
		}
		return remains.substring(dotIndex + 1);
	}
	
	private void convertResultSetToXml(ResultSet rs, Element element) throws SQLException {
		Document document = element.getOwnerDocument();
		ResultSetMetaData metaData = rs.getMetaData();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		while (rs.next()) {
			Element rowElement = document.createElement("row");
			element.appendChild(rowElement);
			// column meta data index is 1-based, not 0-based.
			for (int i = 1; i <= metaData.getColumnCount(); i++) {
				Element columnElement = document.createElement(metaData.getColumnLabel(i));
				if (metaData.getColumnType(i) == Types.DATE) {
					Date sqlDate = rs.getDate(i);
					columnElement.setTextContent(sdf.format(sqlDate));
				} else {
				columnElement.setTextContent(rs.getString(i));
				}
				rowElement.appendChild(columnElement);
			}
		}
	}

}
