//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

public class NoEndpointFoundException extends KieServerHttpRequestException {
    private static final long serialVersionUID = -6698944619491159189L;

    public NoEndpointFoundException(String msg, Throwable cause) {
        super(msg, cause);
    }

    public NoEndpointFoundException(String msg) {
        super(msg);
    }
}
