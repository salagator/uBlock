package gr.alpha.cbs.fuse.helpers;

import java.util.HashMap;
import java.util.List;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.ifaces.ProductStudioInterface;
import jakarta.inject.Named;
import org.apache.commons.lang3.math.NumberUtils;
import org.jboss.logging.Logger;

import gr.alpha.cbs.fuse.enums.ConstantTransactionLanguages;

@Named("productStudioHelper")
@ApplicationScoped
@RegisterForReflection
public class ProductStudioHelper {

    private static final Logger LOGGER = Logger.getLogger(ProductStudioHelper.class);

    @Inject
    ProductStudioInterface productStudio;

    /**
     * Get Product Attribute Value List
     * It exists only to help the call of getProductAttributeValuesLists inside camel Context without losing the body
     *
     * @param productId             Integer
     * @param productVersion        Integer
     * @param productAttributeCodes List<Integer>
     * @return HashMap <String,List<Integer>> ProductAttributeValuesLists
     * @throws Exception
     */
    public HashMap<String, List<Integer>> getProductAttributeValuesLists(Integer productId, Integer productVersion, List<Integer> productAttributeCodes) throws Exception {
        HashMap<String, List<Integer>> productStudioMap = productStudio.getProductAttributeValuesLists(productId, productVersion, productAttributeCodes);
        if (productStudioMap == null) {
            throw new CBSException(
                    getErrorTypeModel(" Μη Παραμετροποιημένος κωδικός προϊόντος PRODUCT: " + productId + " VERSION: " + productVersion)
            );
        }
        return productStudioMap;
    }

    /**
     * Overloaded Get Product Attribute Value List
     * It exists only to help the call of getProductAttributeValuesLists inside camel Context without loosing the body with String
     *
     * @param productIdStr          String
     * @param productVersion        Integer
     * @param productAttributeCodes List<Integer>
     * @return HashMap <String,List<Integer>> ProductAttributeValuesLists
     * @throws Exception
     */
    public HashMap<String, List<Integer>> getProductAttributeValuesLists(String productIdStr, Integer productVersion, List<Integer> productAttributeCodes) throws Exception {
        try {
            int productId = NumberUtils.toInt(productIdStr);
            HashMap<String, List<Integer>> productStudioMap = productStudio.getProductAttributeValuesLists(productId, productVersion, productAttributeCodes);

            if (productStudioMap == null) {
                throw new CBSException(
                        getErrorTypeModel(" Μη Παραμετροποιημένος κωδικός προϊόντος PRODUCT: " + productId + " VERSION: " + productVersion)
                );
            }
            return productStudioMap;
        } catch (Exception e) {
            LOGGER.error("ERROR wile invoking ProductStudioEjb with productId = " + productIdStr + " and productVersion " + productVersion);
            throw e;
        }
    }

    /**
     * Get Product Attribute Name List
     * It exists only to help the call of getProductAttributeNamesListsByDate inside camel Context without loosing the body
     *
     * @param productId             Integer
     * @param productDate           String
     * @param productAttributeCodes List<Integer>
     * @return HashMap <String,List<Integer>> ProductAttributeValuesLists
     * @throws Exception
     */
    public HashMap<String, String> getProductAttributeNamesListsByDate(Integer productId, String productDate, List<Integer> productAttributeCodes) throws Exception {
        HashMap<String, String> productStudioMap = productStudio.getProductAttributeNamesListsByDate(productId, productDate, productAttributeCodes);
        if (productStudioMap == null) {
            throw new CBSException(
                    getErrorTypeModel(" Μη Παραμετροποιημένος κωδικός προϊόντος PRODUCT: " + productId + " DATE: " + productDate)
            );
        }
        return productStudioMap;
    }

    public HashMap<String, List<Integer>> getProductAttributeValuesLists(String productIdStr, String productVersion) throws Exception {
        try {
            int productId = NumberUtils.toInt(productIdStr);
            int productVer = NumberUtils.toInt(productVersion);
            HashMap<String, List<Integer>> productStudioMap = productStudio.getProductAttributeValuesLists(productId, productVer, null);

            if (productStudioMap == null) {
                throw new CBSException(
                        getErrorTypeModel(" Μη Παραμετροποιημένος κωδικός προϊόντος PRODUCT: " + productId + " VERSION: " + productVersion)
                );
            }
            return productStudioMap;
        } catch (Exception e) {
            LOGGER.error("ERROR while invoking ProductStudioEjb with productId = " + productIdStr + " and productVersion " + productVersion);
            throw e;
        }
    }

    /**
     * It exists only to help the call of getProductAttributeRealValuesLists inside camel Context without loosing the body with String
     *
     * @param productId             String
     * @param productVersion        String
     * @param productAttributeCodes List<Integer>
     * @return HashMap <String,List<String>> ProductAttributeRealValuesLists
     * @throws Exception
     */
    public HashMap<String, List<String>> getProductAttributeRealValuesLists(String productId, String productVersion, List<Integer> productAttributeCodes) throws Exception {
        try {
            int product = NumberUtils.toInt(productId);
            int productVer = NumberUtils.toInt(productVersion);
            HashMap<String, List<String>> productStudioMap = productStudio.getProductAttributeRealValuesLists(product, productVer, productAttributeCodes);
            if (productStudioMap == null) {
                throw new CBSException(
                        getErrorTypeModel(" Μη Παραμετροποιημένος κωδικός προϊόντος PRODUCT: " + productId + " VERSION: " + productVersion)
                );
            }
            return productStudioMap;
        } catch (Exception e) {
            LOGGER.error("ERROR while invoking ProductStudioEjb with productId = " + productId + " and productVersion " + productVersion);
            throw e;
        }
    }

    public HashMap<String, List<Integer>> getProductAttributeValuesLists(Integer productId, Integer productVersion, List<Integer> productAttributeCodes, Object langCode) throws Exception {
        HashMap<String, List<Integer>> productStudioMap = productStudio.getProductAttributeValuesLists(productId, productVersion, productAttributeCodes, getPRDLanguageId(langCode));
        if (productStudioMap == null) {
            throw new CBSException(
                    getErrorTypeModel(" Μη Παραμετροποιημένος κωδικός προϊόντος PRODUCT: " + productId + " VERSION: " + productVersion)
            );
        }
        return productStudioMap;
    }

    public HashMap<String, String> getProductAttributeNamesListsByDate(Integer productId, String productDate, List<Integer> productAttributeCodes, Object langCode) throws Exception {
        HashMap<String, String> productStudioMap = productStudio.getProductAttributeNamesListsByDate(productId, productDate, productAttributeCodes, getPRDLanguageId(langCode));
        if (productStudioMap == null) {
            throw new CBSException(
                    getErrorTypeModel(" Μη Παραμετροποιημένος κωδικός προϊόντος PRODUCT: " + productId + " DATE: " + productDate)
            );
        }
        return productStudioMap;
    }

    public HashMap<String, List<Integer>> getProductAttributeValuesLists(String productIdStr, Integer productVersion, List<Integer> productAttributeCodes, Object langCode) throws Exception {
        try {
            int productId = NumberUtils.toInt(productIdStr);
            HashMap<String, List<Integer>> productStudioMap = productStudio.getProductAttributeValuesLists(productId, productVersion, productAttributeCodes, getPRDLanguageId(langCode));
            if (productStudioMap == null) {
                throw new CBSException(
                        getErrorTypeModel(" Μη Παραμετροποιημένος κωδικός προϊόντος PRODUCT: " + productId + " VERSION: " + productVersion)
                );
            }
            return productStudioMap;
        } catch (Exception e) {
            LOGGER.error("ERROR wile invoking ProductStudioEjb with productId = " + productIdStr + " and productVersion " + productVersion);
            throw e;
        }
    }

    public HashMap<String, List<String>> getProductAttributeRealValuesLists(String productId, String productVersion, List<Integer> productAttributeCodes, Object langCode) throws Exception {
        try {
            int product = NumberUtils.toInt(productId);
            int productVer = NumberUtils.toInt(productVersion);
            HashMap<String, List<String>> productStudioMap = productStudio.getProductAttributeRealValuesLists(product, productVer, productAttributeCodes, getPRDLanguageId(langCode));
            if (productStudioMap == null) {
                throw new CBSException(
                        getErrorTypeModel(" Μη Παραμετροποιημένος κωδικός προϊόντος PRODUCT: " + productId + " VERSION: " + productVersion)
                );
            }
            return productStudioMap;
        } catch (Exception e) {
            LOGGER.error("ERROR while invoking ProductStudioEjb with productId = " + productId + " and productVersion " + productVersion);
            throw e;
        }
    }

    private static ErrorTypeModel getErrorTypeModel(String productId) {
        ErrorTypeModel model = new ErrorTypeModel();
        model.setErrorType(ErrorTypeModel.ERROR_TYPE_FUNCTIONAL);
        model.setSourceSystem(ErrorTypeModel.ERROR_SYSTEM_ID_FUSE);
        model.setComponent(ProductStudioHelper.class.getCanonicalName());
        model.setErrorCode("300218");
        model.setSeverityLevel("2");
        model.setDescription(productId);
        model.setSuggestions("");
        model.setServerName("");
        return model;
    }

    /**
     * Used only for product studio queries to get product descriptions in greek/english language
     *
     * @param langCode (en/el)
     * @return languageId (en-> 0, el-> 1)
     */
    public static Integer getPRDLanguageId(Object langCode) {
        if (langCode instanceof Integer) {
            return (Integer) langCode;
        } else if (langCode instanceof String) {
            return ConstantTransactionLanguages._AGGLIKA.equals(langCode) ? 0 : 1; //en-> 0, el-> 1
        } else {
            LOGGER.debug("Language id cannot be resolved");
            return null;
        }
    }
}
