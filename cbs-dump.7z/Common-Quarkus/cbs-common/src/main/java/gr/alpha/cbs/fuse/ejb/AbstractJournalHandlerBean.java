package gr.alpha.cbs.fuse.ejb;

import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.config.ConfigProvider;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import javax.sql.DataSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;

public abstract class AbstractJournalHandlerBean {
    private static final Logger LOGGER = Logger.getLogger(JournalHandlerBeanNoTransaction.class);
    private static final int BMR_TRANSACTION = 18;

    protected abstract DataSource getDataSource();

    protected void writeToDatabase(Map<String, Object> fullJournalMap, boolean success) throws Exception {
        String tableName = success ? "JOU_Data" : "JOU_Data_NC";
        if (LOGGER.isDebugEnabled()){
            LOGGER.debug("Full Map For Journal: "+fullJournalMap);
        }

        List<Map<String, Object>> listForInsertionMaps = divideJournalDataInLists(fullJournalMap);
        Map<String, Object> journalForTable = listForInsertionMaps.get(0);
        Map<String, Object> journalForBoth = listForInsertionMaps.get(1);
        Map<String, Object> journalForXml = listForInsertionMaps.get(2);

        List<String> sqlKeys = Arrays.asList("BUN", "BDate", "BUNRef", "RBUN", "UserID", "UserRole",
                "SensitivityFlag", "RecourceIdentifier", "BCID", "BMR", "CustomerID", "CustomerID2", "Account", "Account2",
                "Currency", "Amount", "BUCR_Level1UnitCode",  "BUCR_Level1UnitType", "BUCR_Channel", "REQID",
                "TransactionCode", "TransactionAlias", "FlowName", "JournalPayload", "CreationDate", "Operation",
                "Quantity", "Approval_ID", "TransactionType", "ApprovalType", "Auxiliary1", "Auxiliary2", "CardReader","FunctionalTechnicalFlag",
                "BUCR_Level2UnitCode", "BUCR_Level2UnitType", "BUCR_Level3UnitCode", "BUCR_Level3UnitType", "BUCR_Level4UnitCode",
                "BUCR_Level4UnitType", "ResourceType",  "TransactionTag", "ApprovalTypePoint", "ApprovalTypeRole", "ServiceName","Notes","RunAsUser","RunAsUnit");

        if (!success) {
            sqlKeys = new ArrayList<>(sqlKeys);
            sqlKeys.add("Layer");
            sqlKeys.add("ErrorTrace");
            sqlKeys.add("ErrorCode");
            sqlKeys.add("ParameterValues");
        }

        StringJoiner sqlJoiner = new StringJoiner(",", "insert into " + tableName + " (", ")");
        sqlKeys.forEach(s -> sqlJoiner.add(s));

        String sql = null;
        if (success) {
            sql = sqlJoiner.toString() + " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        } else {
            sql = sqlJoiner.toString() + " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        }

        try(Connection conn = getDataSource().getConnection(); PreparedStatement statement = conn.prepareStatement(sql);) {

            LocalDate ldt = LocalDate.now(ZoneId.of(ConfigProvider.getConfig().getOptionalValue("cbs.time.zone", String.class).orElse("Europe/Athens")));
            Boolean bmr = (Boolean) journalForTable.get("BMR");
            Boolean bmrValue = "CreateTimeDeposit".equalsIgnoreCase((String)(journalForTable.get("Operation"))) ? (Boolean) fullJournalMap.get("TBMR") : bmr;

            if(bmrValue!=null && bmrValue) {
                String updatedTransactionTag = setTransactionTagBasedOnBMR(journalForTable);
                if(!updatedTransactionTag.isEmpty()) {
                    journalForTable.put("TransactionTag", updatedTransactionTag);
                }
            }
            String bun = (String) journalForTable.get("BUN");

            java.util.Date utilDate = null;
            String dateString = (String) journalForTable.get("BDate");

            if (dateString != null) {

                /** check if Date contains dot */
                if(dateString.contains(".")){
                    utilDate = new SimpleDateFormat("dd.MM.yyyy").parse(dateString);
                }
                else if(dateString.contains("-")){
                    utilDate = new SimpleDateFormat("yyyy-MM-dd").parse(dateString);
                }
                else{
                    utilDate = new SimpleDateFormat("yyyyMMdd").parse(dateString);
                }
            }

            /* BUN */ statement.setString(1, StringUtils.left(bun, 18));
            /* BDate */ statement.setDate(2, utilDate != null?new java.sql.Date(utilDate.getTime()):null);
            /* BUNRef */ statement.setNull(3, Types.BIGINT);
            /* RBUN */ statement.setString(4, StringUtils.left((String) journalForTable.get("RBUN"),18));
            /* UserID */ statement.setString(5, StringUtils.left((String) journalForTable.get("UserID"),50));
            /* UserRole */ statement.setString(6, StringUtils.left((String) journalForTable.get("UserRole"),50));
            /* SensitivityFlag */ statement.setBoolean(7, (journalForTable.get("SensitivityFlag") == null ? false : ((boolean)journalForTable.get("SensitivityFlag"))));
            /* RecourceId */ statement.setString(8, StringUtils.left((String) journalForTable.get("RecourceIdentifier"),18));
            /* BCID */ statement.setString(9, StringUtils.left((String) journalForTable.get("BCID"),50));
            /* BMR */ statement.setBoolean(10, "CreateTimeDeposit".equalsIgnoreCase((String)(journalForTable.get("Operation"))) ? (Boolean) fullJournalMap.get("TBMR") : bmr);
            /* CustomerID */ statement.setString(11, StringUtils.left((String) journalForTable.get("CustomerID"),10));
            if (((String)journalForTable.get("CustomerID2")==null) ||((String) journalForTable.get("CustomerID2")).trim().equals("")){
                /* CustomerID2 */ statement.setString(12, null);
            } else{
                /* CustomerID2 */ statement.setString(12, StringUtils.left((String) journalForTable.get("CustomerID2"),10));
            }
            /* Account */ statement.setString(13, StringUtils.left((String) journalForTable.get("Account"),15));
            /* Account2 */ statement.setString(14, StringUtils.left((String) journalForTable.get("Account2"),15));
            /* Currency */ statement.setString(15, StringUtils.left((String) journalForTable.get("Currency"),50));
            if (journalForTable.get("Amount") == null) {
                /* Amount */ statement.setNull(16, Types.DECIMAL);
            } else if (journalForTable.get("Amount").toString().length() == 0) {
                /* Amount */ statement.setNull(16, Types.DECIMAL);
            } else {
                /* Amount */ statement.setBigDecimal(16, new BigDecimal(StringUtils.left((String) journalForTable.get("Amount"),18)));
            }
            /* BUCR_Level1UnitCode */ statement.setString(17, StringUtils.left((String) journalForTable.get("BUCR_Level1UnitCode"),50));
            /* BUCR_Level1UnitType */ statement.setString(18, StringUtils.left((String) journalForTable.get("BUCR_Level1UnitType"),50));
            /* BUCR_Channel */ statement.setString(19, StringUtils.left((String) journalForTable.get("BUCR_Channel"),50));
            /* REQID */ statement.setString(20, StringUtils.left((String) journalForTable.get("REQID"),50));
            /* TransactionCode */ statement.setString(21, StringUtils.left((String) journalForTable.get("TransactionCode"),8));
            /* TransactionAli */ statement.setString(22, StringUtils.left((String) journalForTable.get("TransactionAlias"),50));
            /* FlowName */ statement.setString(23, StringUtils.left((String) journalForTable.get("FlowName"),150));
            /* CreationDate */ statement.setDate(25, java.sql.Date.valueOf(ldt));
            /* Operation */ statement.setString(26, StringUtils.left((String) journalForTable.get("Operation"),150));
            /* Quantity */ statement.setString(27, StringUtils.left((String) journalForTable.get("Quantity"),50));
            /* Approval_ID */ statement.setString(28, StringUtils.left((String) journalForTable.get("Approval_ID"),10));
            /* TransactionType */ statement.setString(29, StringUtils.left((String) journalForTable.get("TransactionType"),6));
            /* ApprovalType */ statement.setString(30, StringUtils.left((String) journalForTable.get("ApprovalType"),50));
            /* Auxiliary1	*/ statement.setString(31, StringUtils.left((String) journalForTable.get("Auxiliary1"),50));
            /* Auxiliary2	*/ statement.setString(32, StringUtils.left((String) journalForTable.get("Auxiliary2"),50));
            /* CardReader	*/ statement.setBoolean(33,  (("true".equals(journalForTable.get("CardReader")))||"1".equals(journalForTable.get("CardReader")))?true:false);
            /* FunctionalTechnicalFlag*/ statement.setString(34,StringUtils.left((String)journalForTable.get("FunctionalTechnicalFlag"),1));
            /* BUCR_Level2UnitCode */ statement.setString(35, StringUtils.left((String) journalForTable.get("BUCR_Level2UnitCode"),25));
            /* BUCR_Level2UnitType */ statement.setString(36, StringUtils.left((String) journalForTable.get("BUCR_Level2UnitType"),20));
            /* BUCR_Level3UnitCode */ statement.setString(37, StringUtils.left((String) journalForTable.get("BUCR_Level3UnitCode"),25));
            /* BUCR_Level3UnitType */ statement.setString(38, StringUtils.left((String) journalForTable.get("BUCR_Level3UnitType"),20));
            /* BUCR_Level4UnitCode */ statement.setString(39, StringUtils.left((String) journalForTable.get("BUCR_Level4UnitCode"),25));
            /* BUCR_Level4UnitType */ statement.setString(40, StringUtils.left((String) journalForTable.get("BUCR_Level4UnitType"),20));
            /* ResourceType */ statement.setString(41, StringUtils.left((String) journalForTable.get("ResourceType"),10));
            /* TransactionTag */ statement.setString(42, StringUtils.left((String) journalForTable.get("TransactionTag"),55));
            /* ApprovalTypePoint */ statement.setString(43, StringUtils.left((String) journalForTable.get("ApprovalTypePoint"),50));
            /* ApprovalTypeRole */ statement.setString(44, StringUtils.left((String) journalForTable.get("ApprovalTypeRole"),50));
            /* ServiceName */ statement.setString(45, StringUtils.left((String) journalForTable.get("Service"),150));
            /* Notes */ statement.setString(46, StringUtils.left((String) journalForTable.get("Notes"),50));
            /* RunAsUser */ statement.setString(47, StringUtils.left((String) journalForTable.get("RunAsUser"),50));
            /* RunAsUnit */ statement.setString(48, StringUtils.left((String) journalForTable.get("RunAsUnit"),25));
            if(success == false){
                statement.setString(49, StringUtils.left((String) journalForTable.get("Layer"),50));
                statement.setString(50, StringUtils.left((String) journalForTable.get("ErrorTrace"),50));
                statement.setString(51, StringUtils.left((String) journalForTable.get("ErrorCode"),50));
                statement.setString(52, StringUtils.left((String) journalForTable.get("ParameterValues"),150));
            }
            SQLXML sqlxml = conn.createSQLXML();
            sqlxml.setString(createJournalPayloadXml(sqlKeys, journalForXml, journalForBoth));
            /* JournalPayload */ statement.setSQLXML(24, sqlxml);

            if(LOGGER.isDebugEnabled()){
                LOGGER.debug("Numeric Values Check");
                LOGGER.debug("BUNRef:" + (Long) journalForTable.get("BUNRef"));
                LOGGER.debug("Account:" + StringUtils.left((String) journalForTable.get("Account"),15));
                LOGGER.debug("Account2:" + StringUtils.left((String) journalForTable.get("Account2"),15));
                LOGGER.debug("CustomerID:" + StringUtils.left((String) journalForTable.get("CustomerID"),10));
                LOGGER.debug("CustomerID2:" + StringUtils.left((String) journalForTable.get("CustomerID2"),10));
                LOGGER.debug("Amount:" + StringUtils.left((String) journalForTable.get("Amount"),18));
                LOGGER.debug("RecourceIdentifier:" + StringUtils.left((String) journalForTable.get("RecourceIdentifier"),18));
            }


            statement.execute();

        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error("Exception on Writting Journal", e);
            throw e;

        }
    }

    @SafeVarargs
    protected static String createJournalPayloadXml(List<String> sqlkeys, Map<String, Object>... maps)
            throws ParserConfigurationException, TransformerFactoryConfigurationError, TransformerException {

        DocumentBuilderFactory dFactory = DocumentBuilderFactory.newInstance();
        dFactory.setNamespaceAware(true);
        DocumentBuilder dbuilder = dFactory.newDocumentBuilder();
        Document doc = dbuilder.newDocument();
        Element journalPayload = doc.createElement("journalPayload");


        List<String> highlighted = null;

        if(maps[0].get("HIGLIGHTED")!= null )
            highlighted = Arrays.asList(((String) maps[0].get("HIGLIGHTED")).split(","));

        for (Map<String, Object> map : maps) {

            Integer i = 1;

            for (Map.Entry<String, Object> entry : map.entrySet()) {
                if (!(sqlkeys.contains(entry.getKey())) && !entry.getKey().equals("HIGLIGHTED")) {
                    Element elemEntry = doc.createElement("entry");

                    Element elemName = doc.createElement("name");
                    elemName.setTextContent(entry.getKey());
                    elemEntry.appendChild(elemName);

                    Element elemValue = doc.createElement("value");

                    if (entry.getValue() instanceof Node) {
                        Node node = doc.importNode((Node) entry.getValue(), true);
                        elemValue.appendChild(node);
                    } else {
                        elemValue.setTextContent((String) entry.getValue());
                    }

                    if(highlighted!=null && highlighted.contains(entry.getKey()))
                        elemEntry.setAttribute("highlighted", "true");

                    elemEntry.setAttribute("id", i.toString());
                    elemEntry.appendChild(elemValue);

                    i++;
                    journalPayload.appendChild(elemEntry);
                }
            }
        }

        doc.appendChild(journalPayload);
        if (LOGGER.isDebugEnabled()){
            LOGGER.debug("JournalPatyload Of Journal: "+ FormatUtils.nodeToString(journalPayload, FormatUtils.OMIT_XML_DECLARATION_YES, FormatUtils.INDENT_YES));
        }

        DOMSource domSource = new DOMSource(doc);
        TransformerFactory tf = new net.sf.saxon.TransformerFactoryImpl();
        Transformer transformer = tf.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        transformer.setOutputProperty(OutputKeys.METHOD, "xml");
        transformer.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");
        StringWriter sw = new StringWriter();
        StreamResult sr = new StreamResult(sw);
        transformer.transform(domSource, sr);

        return sw.toString();
    }

    protected static List<Map<String, Object>> divideJournalDataInLists(Map<String, Object> journalmap) {

        List<Map<String, Object>> listForInsert = new ArrayList<Map<String, Object>>();

        Map<String, Object> mapForTable = new LinkedHashMap<String, Object>();
        Map<String, Object> mapForXml = new LinkedHashMap<String, Object>();
        Map<String, Object> mapForBoth = new LinkedHashMap<String, Object>();

        for (Map.Entry<String, Object> entry : journalmap.entrySet()) {

            if (entry.getKey().startsWith("M")) {
                mapForXml.put(entry.getKey().substring(1), entry.getValue());
            } else if (entry.getKey().startsWith("B")) {
                mapForBoth.put(entry.getKey().substring(1), entry.getValue());
            } else {
                mapForTable.put(entry.getKey().substring(1), entry.getValue());
            }
        }
        listForInsert.add(mapForTable);
        listForInsert.add(mapForBoth);
        listForInsert.add(mapForXml);
        if (LOGGER.isDebugEnabled()){
            LOGGER.debug("mapForTable:" + Arrays.toString(mapForTable.entrySet().toArray()));
            LOGGER.debug("mapForBoth:" + Arrays.toString(mapForBoth.entrySet().toArray()));
            LOGGER.debug("mapForXml:" + Arrays.toString(mapForXml.entrySet().toArray()));
        }


        return listForInsert;

    }

    protected String setTransactionTagBasedOnBMR(Map<String, Object> valuesInJournalTable) {
        StringBuilder result = new StringBuilder();

        String transactionTag = StringUtils.left((String) valuesInJournalTable.get("TransactionTag"), 55);
        if(transactionTag !=null && !transactionTag.isEmpty()) {
            result.append(transactionTag);
            result.append(BMR_TRANSACTION);
            result.append("|");
        }
        else {
            result.append("|");
            result.append(BMR_TRANSACTION);
            result.append("|");
        }

        return result.toString();
    }


}
