//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.ws.rs.core.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractKieServicesClientImpl {
    private static Logger logger = LoggerFactory.getLogger(AbstractKieServicesClientImpl.class);
    protected static final Boolean BYPASS_AUTH_USER = Boolean.parseBoolean(System.getProperty("org.kie.server.bypass.auth.user", "false"));
    protected LoadBalancer loadBalancer;
    protected final KieServicesConfiguration config;
    protected final Marshaller marshaller;
    protected ClassLoader classLoader;
    protected KieServicesClientImpl owner;

    public AbstractKieServicesClientImpl(KieServicesConfiguration config) {
        this.config = config.clone();
        this.loadBalancer = config.getLoadBalancer() == null ? LoadBalancer.getDefault(config.getServerUrl()) : config.getLoadBalancer();
        this.classLoader = Thread.currentThread().getContextClassLoader() != null ? Thread.currentThread().getContextClassLoader() : CommandScript.class.getClassLoader();
        this.marshaller = MarshallerFactory.getMarshaller(config.getExtraClasses(), config.getMarshallingFormat(), this.classLoader);
    }

    public AbstractKieServicesClientImpl(KieServicesConfiguration config, ClassLoader classLoader) {
        this.config = config.clone();
        this.loadBalancer = config.getLoadBalancer() == null ? LoadBalancer.getDefault(config.getServerUrl()) : config.getLoadBalancer();
        this.classLoader = classLoader;
        this.marshaller = MarshallerFactory.getMarshaller(config.getExtraClasses(), config.getMarshallingFormat(), classLoader);
    }

    protected String initializeURI(URL url, String servicePrefix) {
        if (url == null) {
            throw new IllegalArgumentException("The url may not be empty or null.");
        } else {
            try {
                url.toURI();
            } catch (URISyntaxException urise) {
                throw new IllegalArgumentException("URL (" + url.toExternalForm() + ") is incorrectly formatted: " + urise.getMessage(), urise);
            }

            String urlString = url.toExternalForm();
            if (!urlString.endsWith("/")) {
                urlString = urlString + "/";
            }

            urlString = urlString + "services/" + servicePrefix + "/server";

            try {
                new URL(urlString);
                return urlString;
            } catch (MalformedURLException murle) {
                throw new IllegalArgumentException("URL (" + url.toExternalForm() + ") is incorrectly formatted: " + murle.getMessage(), murle);
            }
        }
    }

    public void setOwner(KieServicesClientImpl owner) {
        this.owner = owner;
    }

    public LoadBalancer getLoadBalancer() {
        return this.loadBalancer;
    }

    protected void throwExceptionOnFailure(ServiceResponse<?> serviceResponse) {
        if (serviceResponse != null && KieServiceResponse.ResponseType.FAILURE.equals(serviceResponse.getType())) {
            throw new KieServicesException(serviceResponse.getMsg());
        }
    }

    protected boolean shouldReturnWithNullResponse(ServiceResponse<?> serviceResponse) {
        if (serviceResponse != null && KieServiceResponse.ResponseType.NO_RESPONSE.equals(serviceResponse.getType())) {
            logger.debug("Returning null as the response type is NO_RESPONSE");
            return true;
        } else {
            return false;
        }
    }

    protected void sendTaskOperation(String containerId, Long taskId, String operation, String queryString) {
        this.sendTaskOperation(containerId, taskId, operation, queryString, (Object)null);
    }

    protected void sendTaskOperation(String containerId, Long taskId, String operation, String queryString, Object data) {
        Map<String, Object> valuesMap = new HashMap();
        valuesMap.put("containerId", containerId);
        valuesMap.put("taskInstanceId", taskId);
        this.makeHttpPutRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), operation, valuesMap) + queryString, data, String.class, this.getHeaders((Object)null));
    }

    protected <T> ServiceResponse<T> makeHttpGetRequestAndCreateServiceResponse(String uri, Class<T> resultType) {
        KieServerHttpRequest request = this.invoke(uri, new RemoteHttpOperation() {
            public KieServerHttpRequest doOperation(String url) {
                AbstractKieServicesClientImpl.logger.debug("About to send GET request to '{}'", url);
                return AbstractKieServicesClientImpl.this.newRequest(url).get();
            }
        });
        KieServerHttpResponse response = request.response();
        this.owner.setConversationId(response.header("X-KIE-ConversationId"));
        if (response.code() == Response.Status.OK.getStatusCode()) {
            ServiceResponse<T> serviceResponse = (ServiceResponse)this.deserialize(response.body(), ServiceResponse.class);
            this.checkResultType(serviceResponse, resultType);
            return serviceResponse;
        } else {
            throw this.createExceptionForUnexpectedResponseCode(request, response);
        }
    }

    protected <T> T makeHttpGetRequestAndCreateCustomResponse(String uri, Class<T> resultType) {
        KieServerHttpRequest request = this.invoke(uri, new RemoteHttpOperation() {
            public KieServerHttpRequest doOperation(String url) {
                AbstractKieServicesClientImpl.logger.debug("About to send GET request to '{}'", url);
                return AbstractKieServicesClientImpl.this.newRequest(url).get();
            }
        });
        KieServerHttpResponse response = request.response();
        this.owner.setConversationId(response.header("X-KIE-ConversationId"));
        if (response.code() == Response.Status.OK.getStatusCode()) {
            return (T)this.deserialize(response.body(), resultType);
        } else {
            throw this.createExceptionForUnexpectedResponseCode(request, response);
        }
    }

    protected <T> T makeHttpGetRequestAndCreateCustomResponseWithHandleNotFound(String uri, Class<T> resultType) {
        KieServerHttpRequest request = this.invoke(uri, new RemoteHttpOperation() {
            public KieServerHttpRequest doOperation(String url) {
                AbstractKieServicesClientImpl.logger.debug("About to send GET request to '{}'", url);
                return AbstractKieServicesClientImpl.this.newRequest(url).get();
            }
        });
        KieServerHttpResponse response = request.response();
        this.owner.setConversationId(response.header("X-KIE-ConversationId"));
        if (response.code() == Response.Status.NOT_FOUND.getStatusCode()) {
            return null;
        } else if (response.code() == Response.Status.OK.getStatusCode()) {
            return (T)this.deserialize(response.body(), resultType);
        } else {
            throw this.createExceptionForUnexpectedResponseCode(request, response);
        }
    }

    protected String makeHttpGetRequestAndCreateRawResponse(String uri) {
        KieServerHttpRequest request = this.invoke(uri, new RemoteHttpOperation() {
            public KieServerHttpRequest doOperation(String url) {
                AbstractKieServicesClientImpl.logger.debug("About to send GET request to '{}'", url);
                return AbstractKieServicesClientImpl.this.newRequest(url).get();
            }
        });
        KieServerHttpResponse response = request.response();
        this.owner.setConversationId(response.header("X-KIE-ConversationId"));
        if (response.code() == Response.Status.OK.getStatusCode()) {
            return response.body();
        } else {
            throw this.createExceptionForUnexpectedResponseCode(request, response);
        }
    }

    protected String makeHttpGetRequestAndCreateRawResponse(String uri, final Map<String, String> headers) {
        KieServerHttpRequest request = this.invoke(uri, new RemoteHttpOperation() {
            public KieServerHttpRequest doOperation(String url) {
                AbstractKieServicesClientImpl.logger.debug("About to send GET request to '{}'", url);
                return AbstractKieServicesClientImpl.this.newRequest(url).headers(headers).get();
            }
        });
        KieServerHttpResponse response = request.response();
        this.owner.setConversationId(response.header("X-KIE-ConversationId"));
        if (response.code() == Response.Status.OK.getStatusCode()) {
            return response.body();
        } else {
            throw this.createExceptionForUnexpectedResponseCode(request, response);
        }
    }

    protected <T> ServiceResponse<T> makeHttpPostRequestAndCreateServiceResponse(String uri, Object bodyObject, Class<T> resultType) {
        return this.makeHttpPostRequestAndCreateServiceResponse(uri, this.serialize(bodyObject), resultType);
    }

    protected <T> ServiceResponse<T> makeHttpPostRequestAndCreateServiceResponse(String uri, Object bodyObject, Class<T> resultType, Map<String, String> headers) {
        return this.makeHttpPostRequestAndCreateServiceResponse(uri, this.serialize(bodyObject), resultType, headers);
    }

    protected <T> ServiceResponse<T> makeHttpPostRequestAndCreateServiceResponse(String uri, Object bodyObject, Class<T> resultType, Map<String, String> headers, Response.Status status) {
        return this.makeHttpPostRequestAndCreateServiceResponse(uri, this.serialize(bodyObject), resultType, headers, status);
    }

    protected <T> ServiceResponse<T> makeHttpPostRequestAndCreateServiceResponse(String uri, String body, Class<T> resultType) {
        return this.makeHttpPostRequestAndCreateServiceResponse(uri, (String)body, resultType, new HashMap());
    }

    protected <T> ServiceResponse<T> makeHttpPostRequestAndCreateServiceResponse(String uri, String body, Class<T> resultType, Map<String, String> headers) {
        return this.makeHttpPostRequestAndCreateServiceResponse(uri, body, resultType, headers, Response.Status.OK);
    }

    protected <T> ServiceResponse<T> makeHttpPostRequestAndCreateServiceResponse(String uri, final String body, Class<T> resultType, final Map<String, String> headers, Response.Status status) {
        KieServerHttpRequest request = this.invoke(uri, new RemoteHttpOperation() {
            public KieServerHttpRequest doOperation(String url) {
                AbstractKieServicesClientImpl.logger.debug("About to send POST request to '{}' with payload '{}'", url, body);
                return AbstractKieServicesClientImpl.this.newRequest(url).headers(headers).body(body).post();
            }
        });
        KieServerHttpResponse response = request.response();
        this.owner.setConversationId(response.header("X-KIE-ConversationId"));
        if (response.code() == status.getStatusCode()) {
            ServiceResponse<T> serviceResponse = (ServiceResponse)this.deserialize(response.body(), ServiceResponse.class);
            this.checkResultType(serviceResponse, resultType);
            return serviceResponse;
        } else {
            throw this.createExceptionForUnexpectedResponseCode(request, response);
        }
    }

    protected <T> T makeHttpPostRequestAndCreateCustomResponse(String uri, Object bodyObject, Class<T> resultType, Map<String, String> headers) {
        return (T)this.makeHttpPostRequestAndCreateCustomResponse(uri, this.serialize(bodyObject), resultType, headers);
    }

    protected <T> T makeHttpPostRequestAndCreateCustomResponse(String uri, Object bodyObject, Class<T> resultType) {
        return (T)this.makeHttpPostRequestAndCreateCustomResponse(uri, (String)this.serialize(bodyObject), resultType, new HashMap());
    }

    protected <T> T makeHttpPostRequestAndCreateCustomResponse(String uri, final String body, Class<T> resultType, final Map<String, String> headers) {
        KieServerHttpRequest request = this.invoke(uri, new RemoteHttpOperation() {
            public KieServerHttpRequest doOperation(String url) {
                AbstractKieServicesClientImpl.logger.debug("About to send POST request to '{}' with payload '{}'", url, body);
                return AbstractKieServicesClientImpl.this.newRequest(url).headers(headers).body(body).post();
            }
        });
        KieServerHttpResponse response = request.response();
        this.owner.setConversationId(response.header("X-KIE-ConversationId"));
        if (response.code() != Response.Status.OK.getStatusCode() && response.code() != Response.Status.CREATED.getStatusCode()) {
            throw this.createExceptionForUnexpectedResponseCode(request, response);
        } else {
            return (T)this.deserialize(response.body(), resultType);
        }
    }

    protected <T> ServiceResponse<T> makeHttpPutRequestAndCreateServiceResponse(String uri, Object bodyObject, Class<T> resultType) {
        return this.makeHttpPutRequestAndCreateServiceResponse(uri, this.serialize(bodyObject), resultType);
    }

    protected <T> ServiceResponse<T> makeHttpPutRequestAndCreateServiceResponse(String uri, final String body, Class<T> resultType) {
        KieServerHttpRequest request = this.invoke(uri, new RemoteHttpOperation() {
            public KieServerHttpRequest doOperation(String url) {
                AbstractKieServicesClientImpl.logger.debug("About to send PUT request to '{}' with payload '{}'", url, body);
                return AbstractKieServicesClientImpl.this.newRequest(url).body(body).put();
            }
        });
        KieServerHttpResponse response = request.response();
        this.owner.setConversationId(response.header("X-KIE-ConversationId"));
        if (response.code() != Response.Status.CREATED.getStatusCode() && response.code() != Response.Status.BAD_REQUEST.getStatusCode()) {
            throw this.createExceptionForUnexpectedResponseCode(request, response);
        } else {
            ServiceResponse<T> serviceResponse = (ServiceResponse)this.deserialize(response.body(), ServiceResponse.class);
            this.checkResultType(serviceResponse, resultType);
            return serviceResponse;
        }
    }

    protected <T> T makeHttpPutRequestAndCreateCustomResponse(String uri, Object bodyObject, Class<T> resultType, Map<String, String> headers) {
        return (T)this.makeHttpPutRequestAndCreateCustomResponse(uri, this.serialize(bodyObject), resultType, headers);
    }

    protected <T> T makeHttpPutRequestAndCreateCustomResponse(String uri, final String body, Class<T> resultType, final Map<String, String> headers) {
        KieServerHttpRequest request = this.invoke(uri, new RemoteHttpOperation() {
            public KieServerHttpRequest doOperation(String url) {
                AbstractKieServicesClientImpl.logger.debug("About to send PUT request to '{}' with payload '{}'", url, body);
                return AbstractKieServicesClientImpl.this.newRequest(url).headers(headers).body(body).put();
            }
        });
        KieServerHttpResponse response = request.response();
        this.owner.setConversationId(response.header("X-KIE-ConversationId"));
        if (response.code() == Response.Status.CREATED.getStatusCode()) {
            T serviceResponse = (T)this.deserialize(response.body(), resultType);
            return serviceResponse;
        } else {
            throw this.createExceptionForUnexpectedResponseCode(request, response);
        }
    }

    protected <T> ServiceResponse<T> makeHttpDeleteRequestAndCreateServiceResponse(String uri, Class<T> resultType) {
        KieServerHttpRequest request = this.invoke(uri, new RemoteHttpOperation() {
            public KieServerHttpRequest doOperation(String url) {
                AbstractKieServicesClientImpl.logger.debug("About to send DELETE request to '{}' ", url);
                return AbstractKieServicesClientImpl.this.newRequest(url).delete();
            }
        });
        KieServerHttpResponse response = request.response();
        this.owner.setConversationId(response.header("X-KIE-ConversationId"));
        if (response.code() == Response.Status.OK.getStatusCode()) {
            ServiceResponse<T> serviceResponse = (ServiceResponse)this.deserialize(response.body(), ServiceResponse.class);
            this.checkResultType(serviceResponse, resultType);
            return serviceResponse;
        } else {
            throw this.createExceptionForUnexpectedResponseCode(request, response);
        }
    }

    protected <T> T makeHttpDeleteRequestAndCreateCustomResponse(String uri, Class<T> resultType) {
        KieServerHttpRequest request = this.invoke(uri, new RemoteHttpOperation() {
            public KieServerHttpRequest doOperation(String url) {
                AbstractKieServicesClientImpl.logger.debug("About to send DELETE request to '{}' ", url);
                return AbstractKieServicesClientImpl.this.newRequest(url).delete();
            }
        });
        KieServerHttpResponse response = request.response();
        this.owner.setConversationId(response.header("X-KIE-ConversationId"));
        if (response.code() != Response.Status.OK.getStatusCode() && response.code() != Response.Status.NO_CONTENT.getStatusCode()) {
            throw this.createExceptionForUnexpectedResponseCode(request, response);
        } else {
            return (T)(resultType == null ? null : this.deserialize(response.body(), resultType));
        }
    }

    protected KieServerHttpRequest newRequest(String uri) {
        KieServerHttpRequest httpRequest = KieServerHttpRequest.newRequest(uri).followRedirects(true).timeout(this.config.getTimeout());
        httpRequest.accept(this.getMediaType(this.config.getMarshallingFormat()));
        httpRequest.header("X-KIE-ContentType", this.config.getMarshallingFormat().toString());
        if (this.config.getHeaders() != null) {
            for(Map.Entry<String, String> header : this.config.getHeaders().entrySet()) {
                httpRequest.header((String)header.getKey(), header.getValue());
                logger.debug("Adding additional header {} value {}", header.getKey(), header.getValue());
            }
        }

        if (this.config.getCredentialsProvider() != null) {
            String authorization = this.config.getCredentialsProvider().getAuthorization();
            if (authorization != null && !authorization.isEmpty()) {
                httpRequest.header(this.config.getCredentialsProvider().getHeaderName(), authorization);
            }
        }

//        httpRequest.clientCertificate(this.config.getClientCertificate());
        if (this.owner.getConversationId() != null) {
            httpRequest.header("X-KIE-ConversationId", this.owner.getConversationId());
        }

        return httpRequest;
    }

    protected String getMediaType(MarshallingFormat format) {
        switch (format) {
            case JAXB:
                return "application/xml";
            case JSON:
                return "application/json";
            default:
                return "application/xml";
        }
    }

    protected String serialize(Object object) {
        if (object == null) {
            return "";
        } else {
            try {
                return this.marshaller.marshall(object);
            } catch (MarshallingException e) {
                throw new KieServicesException("Error while serializing request data!", e);
            }
        }
    }

    protected <T> T deserialize(String content, Class<T> type) {
        logger.debug("About to deserialize content: \n '{}' \n into type: '{}'", content, type);
        if (content != null && !content.isEmpty()) {
            try {
                return (T)this.marshaller.unmarshall(content, type);
            } catch (MarshallingException e) {
                throw new KieServicesException("Error while deserializing data received from server!", e);
            }
        } else {
            return null;
        }
    }

    protected void checkResultType(ServiceResponse<?> serviceResponse, Class<?> expectedResultType) {
        Object actualResult = serviceResponse.getResult();
        if (actualResult != null && !expectedResultType.isInstance(actualResult)) {
            throw new KieServicesException("Error while creating service response! The actual result type " + serviceResponse.getResult().getClass() + " does not match the expected type " + expectedResultType + "!");
        }
    }

    protected RuntimeException createExceptionForUnexpectedResponseCode(KieServerHttpRequest request, KieServerHttpResponse response) {
        String summaryMessage = "Unexpected HTTP response code when requesting URI '" + request.getUri() + "'! Error code: " + response.code() + ", message: " + response.body();
        logger.debug(summaryMessage + ", response body: " + this.getMessage(response));
        return new KieServicesHttpException(summaryMessage, response.code(), request.getUri().toString(), response.body());
    }

    protected String getMessage(KieServerHttpResponse response) {
        try {
            String body = response.body();
            if (body != null && !body.isEmpty()) {
                return body;
            }
        } catch (Exception e) {
            logger.debug("Error when getting both of the response {}", e.getMessage());
        }

        return response.message();
    }

    protected String buildQueryString(String paramName, List<?> items) {
        StringBuilder builder = new StringBuilder("?");

        for(Object o : items) {
            builder.append(paramName).append("=").append(o).append("&");
        }

        builder.deleteCharAt(builder.length() - 1);
        return builder.toString();
    }

    protected Map<String, String> getHeaders(Object object) {
        Map<String, String> headers = new HashMap();
        if (object != null) {
            headers.put("X-KIE-ClassType", object.getClass().getName());
        }

        return headers;
    }

    protected String getUserQueryStr(String userId, char prefix) {
        return BYPASS_AUTH_USER && userId != null ? prefix + "user=" + userId : "";
    }

    protected String getUserQueryStr(String userId) {
        return this.getUserQueryStr(userId, '?');
    }

    protected String getUserAndPagingQueryString(String userId, Integer page, Integer pageSize) {
        StringBuilder queryString = new StringBuilder(this.getUserQueryStr(userId));
        if (queryString.length() == 0) {
            queryString.append("?");
        } else {
            queryString.append("&");
        }

        queryString.append("page=" + page).append("&pageSize=" + pageSize);
        return queryString.toString();
    }

    protected String getUserAndAdditionalParam(String userId, String name, String value) {
        StringBuilder queryString = new StringBuilder(this.getUserQueryStr(userId));
        if (queryString.length() == 0) {
            queryString.append("?");
        } else {
            queryString.append("&");
        }

        queryString.append(name).append("=").append(value);
        return queryString.toString();
    }

    protected String getUserAndAdditionalParams(String userId, String name, List<?> values) {
        StringBuilder queryString = new StringBuilder(this.getUserQueryStr(userId));
        if (values != null) {
            if (queryString.length() == 0) {
                queryString.append("?");
            } else {
                queryString.append("&");
            }

            for(Object value : values) {
                queryString.append(name).append("=").append(value).append("&");
            }

            queryString.deleteCharAt(queryString.length() - 1);
        }

        return queryString.toString();
    }

    protected String getPagingQueryString(String inQueryString, Integer page, Integer pageSize) {
        StringBuilder queryString = new StringBuilder(inQueryString);
        if (queryString.length() == 0) {
            queryString.append("?");
        } else {
            queryString.append("&");
        }

        queryString.append("page=" + page).append("&pageSize=" + pageSize);
        return queryString.toString();
    }

    protected String getSortingQueryString(String inQueryString, String sort, boolean sortOrder) {
        StringBuilder queryString = new StringBuilder(inQueryString);
        if (queryString.length() == 0) {
            queryString.append("?");
        } else {
            queryString.append("&");
        }

        queryString.append("sort=" + sort).append("&sortOrder=" + sortOrder);
        return queryString.toString();
    }

    protected String getAdditionalParams(String inQueryString, String name, List<?> values) {
        StringBuilder queryString = new StringBuilder(inQueryString);
        if (values != null) {
            if (queryString.length() == 0) {
                queryString.append("?");
            } else {
                queryString.append("&");
            }

            for(Object value : values) {
                queryString.append(name).append("=").append(value).append("&");
            }

            queryString.deleteCharAt(queryString.length() - 1);
        }

        return queryString.toString();
    }

    protected Map<?, ?> safeMap(Map<?, ?> map) {
        return map == null ? new HashMap() : new HashMap(map);
    }

    protected List<?> safeList(List<?> list) {
        return list == null ? new ArrayList() : new ArrayList(list);
    }

    /*
    protected <T> ServiceResponse<T> makeBackwardCompatibleHttpPostRequestAndCreateServiceResponse(String uri, Object body, Class<T> resultType, Map<String, String> headers) {
        return this.<T>makeBackwardCompatibleHttpPostRequestAndCreateServiceResponse(uri, body, resultType, headers, Response.Status.OK);
    }

    protected <T> ServiceResponse<T> makeBackwardCompatibleHttpPostRequestAndCreateServiceResponse(String uri, Object body, Class<T> resultType, Map<String, String> headers, Response.Status expectedStatus) {
        logger.debug("About to send POST request to '{}' with payload '{}'", uri, body);
        KieServerHttpRequest request = this.newRequest(uri).headers(headers).body(this.serialize(body)).post();
        KieServerHttpResponse response = request.response();
        this.owner.setConversationId(response.header("X-KIE-ConversationId"));
        if (response.code() == expectedStatus.getStatusCode()) {
            ServiceResponse<T> serviceResponse = (ServiceResponse)this.deserialize(response.body(), ServiceResponse.class);
            serviceResponse.setResult(this.serialize(serviceResponse.getResult()));
            this.checkResultType(serviceResponse, resultType);
            return serviceResponse;
        } else {
            throw this.createExceptionForUnexpectedResponseCode(request, response);
        }
    }

    protected <T> ServiceResponse<T> makeBackwardCompatibleHttpPostRequestAndCreateServiceResponse(String uri, String body, Class<T> resultType) {
        logger.debug("About to send POST request to '{}' with payload '{}'", uri, body);
        KieServerHttpRequest request = this.newRequest(uri).body(body).post();
        KieServerHttpResponse response = request.response();
        this.owner.setConversationId(response.header("X-KIE-ConversationId"));
        if (response.code() == Response.Status.OK.getStatusCode()) {
            ServiceResponse<T> serviceResponse = (ServiceResponse)this.deserialize(response.body(), ServiceResponse.class);
            serviceResponse.setResult(this.serialize(serviceResponse.getResult()));
            this.checkResultType(serviceResponse, resultType);
            return serviceResponse;
        } else {
            throw this.createExceptionForUnexpectedResponseCode(request, response);
        }
    }
     */

    public String getConversationId() {
        return this.owner.getConversationId();
    }

    protected KieServerHttpRequest invoke(String url, RemoteHttpOperation operation) {
        String currentUrl = url;
        String nextHost = null;

        while(true) {
            try {
                return operation.doOperation(currentUrl);
            } catch (KieServerHttpRequestException e) {
                if (!(e.getCause() instanceof IOException)) {
                    throw e;
                }

                String failedBaseUrl = this.loadBalancer.markAsFailed(currentUrl);
                logger.warn("Marking endpoint '{}' as failed due to {}", failedBaseUrl, e.getCause().getMessage());

                try {
                    nextHost = this.loadBalancer.getUrl();
                    currentUrl = nextHost + url.substring(failedBaseUrl.length());
                    logger.debug("Selecting next endpoint from load balancer - '{}'", currentUrl);
                } catch (NoEndpointFoundException noEndpointFoundException) {
                    logger.warn("Cannot invoke request - '{}'", noEndpointFoundException.getMessage());
                    throw noEndpointFoundException;
                }

                if (nextHost == null) {
                    throw new KieServerHttpRequestException("Unable to invoke operation " + operation);
                }
            }
        }
    }

    protected String encode(String value) {
        try {
            return URLEncoder.encode(value, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new IllegalStateException("Unexpected error while encoding string '" + value + "'", e);
        }
    }

    protected void close() {
        this.loadBalancer.close();
    }

    abstract class RemoteHttpOperation {
        RemoteHttpOperation() {
        }

        public abstract KieServerHttpRequest doOperation(String url);
    }
}
