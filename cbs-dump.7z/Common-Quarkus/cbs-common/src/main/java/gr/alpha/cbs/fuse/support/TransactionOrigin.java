package gr.alpha.cbs.fuse.support;

public enum TransactionOrigin {
	Online(0),
	Offline(1),
	Batch(2);
	
	private int value;

	private TransactionOrigin(int value) {
		this.setValue(value);
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

}
