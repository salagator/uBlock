package gr.alpha.cbs.fuse.strategies;

import java.util.Map.Entry;

import org.apache.camel.CamelContext;
import org.apache.camel.CamelContextAware;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.component.xslt.saxon.XsltSaxonAggregationStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ThreadSafeXsltAggregationStrategy extends XsltSaxonAggregationStrategy implements CamelContextAware {
    private static final Logger logger = LoggerFactory.getLogger(ThreadSafeXsltAggregationStrategy.class);

    private CamelContext camelContext;
    private boolean concatHeaders;

    public ThreadSafeXsltAggregationStrategy(String xslFileLocation) {

        super(xslFileLocation);
        logger.debug("Initialized " + xslFileLocation);
    }

    @Override
    public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
        Exchange returnExchange = super.aggregate(oldExchange, newExchange);

        // Merge the headers if the relevant property is set.
        if (concatHeaders) {
            for (Entry<String, Object> entry : newExchange.getIn().getHeaders().entrySet()) {
                Message message = returnExchange.getIn();
                if (returnExchange.getOut() != null) {
                    message = returnExchange.getOut();
                }
                if (message.getHeader(entry.getKey()) == null) {
                    message.setHeader(entry.getKey(), entry.getValue());
                }
            }
        }

        return returnExchange;
    }

    @Override
    public void setCamelContext(CamelContext camelContext) {
        logger.debug("Camel context is being set");
        this.camelContext = camelContext;
        try {
            super.setCamelContext(camelContext);
        } catch (Exception e) {
            logger.error("Unable to initialize aggregator strategy" , e);
        }
    }

    @Override
    public CamelContext getCamelContext() {
        return camelContext;
    }

    public boolean isConcatHeaders() {
        return concatHeaders;
    }

    public void setConcatHeaders(boolean concatHeaders) {
        this.concatHeaders = concatHeaders;
    }

}
