package gr.alpha.cbs.fuse.tools;

import org.jboss.logging.Logger;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

@Named("pagingHelper")
@ApplicationScoped
@RegisterForReflection

public class PagingHelper {
	private static final Logger LOGGER = Logger.getLogger(PagingHelper.class);
	/**
	 * 
	 * @param offset - number of characters removed from the head of body 
	 * @param tail - number of characters removed from the tail of body
	 * @param size - the size of each body segment
	 * @param body - the initial body
	 * @param count - the maximum number of items-segments we return  
	 * @return the splitted message
	 */
	public String splitMessage(Integer offset, Integer tail, Integer size, String body, Integer count) {
		
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("offset:" +  offset + "|tail:" + tail + "|size:" + size + "|body:" + body + "|count:" + count);
		}
		int ubodyLength = body.length() - tail;		
		
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("INITIAL BODY LEN:" +body.length());
		}
						
		body = body.substring(offset, ubodyLength);
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("BODY substring:" +body);					
			LOGGER.debug("bodyLen:" + body.length());
		}

		StringBuilder b = new StringBuilder();
		int c = 0;
		for (int i = 0; i <= body.length() / size; i++) {
			if (c < count) {
				b.append(body.substring(i * size, Math.min((i + 1) * size, body.length())));
				b.append(System.lineSeparator());
				c++;
			}
		}
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("SPLT c:" + c);
			LOGGER.debug("SPLT RESULT:" + b.toString());
		}
		return b.toString();

	}
	
	public Integer maxLoopCalculator(String requestedSize, String OS2200Size){		
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Pagesize: " + requestedSize  + " OS2200Size: " + OS2200Size);
		}
		Double d = Double.parseDouble(requestedSize) / Double.parseDouble(OS2200Size);
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("After division " +d);
		}
		Double m = Math.ceil(d); 
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("After ceil " +m);
		}
		return m.intValue();
				
	}
	
	public boolean loopEvaluator(Integer loopMaxCount, Integer camelLoopIndex, String hasMore){
		if (camelLoopIndex ==null){
			camelLoopIndex = -1;
		}
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("loopEvaluator loopMaxCount:" + loopMaxCount + " camelLoopIndex:" + camelLoopIndex + " hasMore:" + hasMore);
		}
		if ("1".equals(hasMore) && (loopMaxCount -1) > (camelLoopIndex)){
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("loopEvaluator -> 1");
			}
			return true;
		} else {
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("loopEvaluator -> 0");
			}
			return false;
		}
	}
	
	public static String hasMoreEvaluator(Integer arraySize,String requestedPageSize, String OS2200HasMore){
		if (arraySize > Integer.parseInt(requestedPageSize) || "1".equals(OS2200HasMore)){
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("hasMoreEvaluator -> 1");
			}
			return "1";
		} else {
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("hasMoreEvaluator -> 0");
			}
			return "0";
		}		
	}
	
	@SuppressWarnings("rawtypes")
	public static void sizeTrimmer (java.util.ArrayList arrayList,String requestedPageSize){
		Integer ps = Integer.parseInt(requestedPageSize);
		if (ps<arrayList.size())		
			arrayList.subList(ps, arrayList.size()).clear();
		
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("sizeTrimmer -> 0");
		}
	}
	
	public Integer maxLoopCalculatorPlus(String requestedSize, String OS2200Size, String retries){		
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Pagesize: " + requestedSize  + " OS2200Size: " + OS2200Size);
		}
		
		Double d = (Double.parseDouble(requestedSize) / Double.parseDouble(OS2200Size)  ) + Double.parseDouble(retries);
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("After division " +d);
		}
		Double m = Math.ceil(d); 
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("After ceil " +m);
		}
		return m.intValue();
				
	}
	
	public boolean dynamicLoopEvaluator(Integer loopMaxCount, Integer camelLoopIndex, String hasMore, Integer totalCount, String pageSize) throws Exception{
		Integer ps = Integer.parseInt(pageSize);
		if (camelLoopIndex ==null){
			camelLoopIndex = -1;
		}
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("loopEvaluator loopMaxCount:" + loopMaxCount + " camelLoopIndex:" + camelLoopIndex + " hasMore:" + hasMore + " totalCount:" + totalCount + " pageSize :" + ps);
		}
		
		
		if ("1".equals(hasMore) && (loopMaxCount -1) > (camelLoopIndex) && (totalCount < ps) ){
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("loopEvaluator -> 1");
			}
			return true;
		} else {
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("loopEvaluator -> 0");
			}
			return false;
		}
	}
	

}