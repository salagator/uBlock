package gr.alpha.cbs.fuse.support;

public interface RemoteDataGridHelperInitializer {
    void init();
}
