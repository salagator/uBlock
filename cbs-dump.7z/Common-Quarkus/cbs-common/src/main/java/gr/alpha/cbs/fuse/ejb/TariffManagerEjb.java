package gr.alpha.cbs.fuse.ejb;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import gr.alpha.cbs.fuse.ifaces.TariffManagerInterface;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;
import jakarta.transaction.Transactional;
import java.sql.*;
import java.util.*;

@Named("tariffManagerEjb")
@Dependent
@RegisterForReflection
@Transactional(Transactional.TxType.NOT_SUPPORTED)
public class TariffManagerEjb implements TariffManagerInterface {
    private static final Logger LOGGER = Logger.getLogger(TariffManagerEjb.class);
    private static final String ACCOUNTING_ENTRIES_LIST = "AccountingEntriesList";
    private static final String COMMISSION_LIST = "CommissionsList";
    private static final String EXPENSES_LIST = "ExpensesList";

    @Inject
    @io.quarkus.agroal.DataSource("hostps")
    DataSource sqlDS;

    @Override
    public Map<String, List<HashMap<String, String>>> getCommissionsWithMandatoryFieldsOnly(String serviceName, String operationName, String amount) throws Exception {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getCommissionsWithMandatoryFieldsOnly called...");
        }
        return executeQuery(serviceName, operationName, amount, "0", "-1", "-1", "-1", "-1", "-1", 1, " ", "1");
    }

    @Override
    public Map<String, List<HashMap<String, String>>> getCommissionsFull(String serviceName, String operationName, String amount, String currency, String productCategoryCode, String productCode, String customerCategory, String accountCategory,
                                                    String commissionCarrierID, int languageIC, String commissionAttributesXML, String multiplier) throws Exception {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getCommissions called...");
        }
        return executeQuery(serviceName, operationName, amount, currency, productCategoryCode, productCode, customerCategory, accountCategory, commissionCarrierID, languageIC, commissionAttributesXML, multiplier);
    }

    /**
     * <h1>Executes Query</h1> The executeQuery method executes the USP that
     * returns the Commissions
     * <p>
     * In order for developers to implement new methods with different
     * parameters, the below default values should be set in the remaining USP
     * parameters.
     *
     * @param serviceName         This is the 1st parameter for the method. Is a MANDATORY field
     *                            for the USP. No default value e.x. DepositFC
     * @param operationName       This is the 2nd parameter for the method. Is a MANDATORY field
     *                            for the USP. No default value e.x. CreateExchangeBankNoteFC
     * @param amount              This is the 3rd parameter for the method. Is a MANDATORY field
     *                            for the USP. No default value e.x. 100.00
     * @param currency            This is the 4th parameter for the method. Is an OPTIONAL field
     *                            for the USP. Default value "0"
     * @param productCategoryCode This is the 5th parameter for the method. Is an OPTIONAL field
     *                            for the USP. Default value "-1"
     * @param productCode         This is the 6th parameter for the method. Is an OPTIONAL field
     *                            for the USP. Default value "-1"
     * @param customerCategory    This is the 9th parameter for the method. Is an OPTIONAL field
     *                            for the USP. Default value 1
     * @param accountCategory     This is the 10th parameter for the method. Is an OPTIONAL
     *                            field for the USP. Default value "-1"
     * @param commissionCarrierID This is the 11th parameter for the method. Is an OPTIONAL
     *                            field for the USP. Default value "1"
     * @param languageIC          This is the 12th parameter for the method. Is an OPTIONAL
     *                            field for the USP. Default value 1
     * @return HashMap<String, List> This returns A HashMap that contains three
     * lists. 1st list: CommissionsList, 2nd list: ExpensesList, 3rd
     * list: AccountingEntriesList. Each of the lists is populated with
     * HashMaps that contain (K,V) with the columns and corresponding
     * values of the USP.
     */
    private Map<String, List<HashMap<String, String>>> executeQuery(String serviceName, String operationName, String amount, String currency,
                                               String productCategoryCode, String productCode, String customerCategory, String accountCategory,
                                               String commissionCarrierID, int languageIC, String commissionAttributesXML, String multiplier) throws Exception {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("executeQueryForTariffCommissionsOnly initiated...");
            LOGGER.debug("executeQuery method was called with:-> ServiceName: " + serviceName +
                    "|OperationName: " + operationName +
                    "|Amount: " + amount +
                    "|Currency: " + currency +
                    "|ProductCategoryCode: " + productCategoryCode +
                    "|ProductCode: " + productCode +
                    "|CustomerCategory: " + customerCategory +
                    "|AccountCategory: " + accountCategory +
                    "|CommissionCarrierID: " + commissionCarrierID +
                    "|LanguageIC: " + languageIC +
                    "|CommissionAttributesXML: " + commissionAttributesXML +
                    "|Multiplier: " + multiplier);
        }

        Connection conn = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;

        //hasResults variable is used to iterate over the 3 consequent result sets returned from the USP
        boolean hasResults;

        // These 3 lists will be populated with commissions, Expenses and
        // Accounting Entries, after the query (USP Call).
        List<HashMap<String, String>> commissionsList = new ArrayList<>();
        List<HashMap<String, String>> expensesList = new ArrayList<>();
        List<HashMap<String, String>> accountingEntriesList = new ArrayList<>();

        // The hashMap below will be populated with the three lists described
        // above. Will also be returned as the result of the function.
        Map<String, List<HashMap<String, String>>> allEntries = new HashMap<>();

        try {
            conn = this.sqlDS.getConnection();
            pstm = conn.prepareStatement("exec usp_PRD_GetCommissions ?,?,?,?,?,?,?,?,?,?,?,?");
            setValuesForUSP(pstm, serviceName, operationName, amount, currency, productCategoryCode, productCode, customerCategory, accountCategory, commissionCarrierID, languageIC, commissionAttributesXML, multiplier);
            hasResults = pstm.execute();

            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("hasResults after execute() is...:" + hasResults);
            }

            while (hasResults) {
                rs = pstm.getResultSet();

                if (LOGGER.isDebugEnabled()) {
                    LOGGER.debug("The Statement is..." + rs.getStatement().toString());
                }

                if (rs != null) {
                    while (rs.next()) {
                        commissionsList.add(getCommissionsEntry(rs));
                    }

                    if (pstm.getMoreResults()) {
                        rs = pstm.getResultSet();
                        if (rs != null) {
                            while (rs.next()) {
                                expensesList.add(getExpenseEntry(rs));
                            }
                        }
                    }

                    if (pstm.getMoreResults()) {
                        rs = pstm.getResultSet();
                        if (rs != null) {
                            while (rs.next()) {
                                accountingEntriesList.add(getAccountingEntry(rs));
                            }
                        }
                    }

                }

                hasResults = pstm.getMoreResults();
                if (LOGGER.isDebugEnabled()) {
                    LOGGER.debug("hasResults after getMoreResults() is...:" + hasResults);
                }
            }

            allEntries.put(COMMISSION_LIST, commissionsList);
            allEntries.put(EXPENSES_LIST, expensesList);
            allEntries.put(ACCOUNTING_ENTRIES_LIST, accountingEntriesList);

            if (LOGGER.isDebugEnabled()) {
                printAllEntries(allEntries);
            }
        } catch (SQLException se) {
            ErrorUtils.throwCBSException(se, String.valueOf(ConstantError_Types._Technical),
                    String.valueOf(ConstantError_System_IDs._FUSE), this.getClass().getCanonicalName(),
                    String.valueOf(300051), String.valueOf(ConstantError_Levels._Error),
                    "Λάθος κατά την εκτέλεση του Tariff Manager(usp_PRD_GetCommissions)", "", "");

        } catch (Exception e) {
            LOGGER.error("Error In Tariff Manager query", e);
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pstm != null) {
                pstm.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return allEntries;
    }

    private void setValuesForUSP(PreparedStatement pstm, String serviceName, String operationName,
                                              String amount, String currency, String productCategoryCode, String productCode, String customerCategory,
                                              String accountCategory, String commissCarrierID, int languageIC, String commissionAttributesXML, String multiplier)
            throws SQLException {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Setting default values for Tariff Manager USP.");
        }
        if (pstm != null) {
            try {
                pstm.setString(1, StringUtils.isNotBlank(serviceName) ? serviceName : "");
                pstm.setString(2, StringUtils.isNotBlank(operationName) ? operationName : "");
                pstm.setString(3, StringUtils.isNotBlank(amount) ? amount : "0");
                pstm.setString(4, StringUtils.isNotBlank(currency) ? currency : "0");
                pstm.setString(5, StringUtils.isNotBlank(productCategoryCode) ? productCategoryCode : "-1");
                pstm.setString(6, StringUtils.isNotBlank(productCode) ? productCode : "-1");
                pstm.setString(7, StringUtils.isNotBlank(customerCategory) ? customerCategory : "-1");
                pstm.setString(8, StringUtils.isNotBlank(accountCategory) ? accountCategory : "-1");
                pstm.setString(9, StringUtils.isNotBlank(commissCarrierID) ? commissCarrierID : "-1");
                pstm.setInt(10, languageIC != 0 ? languageIC : 1);
                pstm.setString(11, StringUtils.isNotBlank(commissionAttributesXML) ? commissionAttributesXML : StringUtils.SPACE);
                pstm.setString(12, StringUtils.isNotBlank(multiplier) ? multiplier : "1");
            } catch (SQLException e) {
                LOGGER.error("Error In TarrifManager. Setting default values for USP Failed.", e);
                throw e;
            }
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Default values for Tariff Manager USP were set...");
            }
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Returning statement with default values set in Tariff Manager USP.\n");

        }
    }

    // this method is only called when debug is enabled
    private void printAllEntries(Map<String, List<HashMap<String, String>>> allEntries) {
        if (allEntries != null && !allEntries.isEmpty()) {
            if (allEntries.containsKey(COMMISSION_LIST)) {

                List<HashMap<String, String>> entries = allEntries.get(COMMISSION_LIST);

                for (HashMap<String, String> entry : entries) {
                    LOGGER.debug(entry);
                }
            }
            if (allEntries.containsKey(EXPENSES_LIST)) {

                List<HashMap<String, String>> entries = allEntries.get(EXPENSES_LIST);

                for (HashMap<String, String> entry : entries) {
                    LOGGER.debug(entry);
                }
            }

            if (allEntries.containsKey(ACCOUNTING_ENTRIES_LIST)) {

                List<HashMap<String, String>> entries = allEntries.get(ACCOUNTING_ENTRIES_LIST);

                for (HashMap<String, String> entry : entries) {
                    LOGGER.debug(entry);
                }
            }
        }
    }

    private HashMap<String, String> getCommissionsEntry(ResultSet rs) throws SQLException {

        HashMap<String, String> entry = new HashMap<>();

        String commissionID = rs.getString("CommissionID");

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("commissionID: " + commissionID);
        }

        entry.put("CommissionID", commissionID);
        entry.putAll(getHorizontalEntries(entry, rs));

        return entry;
    }

    private HashMap<String, String> getExpenseEntry(ResultSet rs) throws SQLException {

        HashMap<String, String> entry = new HashMap<>();

        String expenseID = rs.getString("expenseID");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("expenseID: " + expenseID);
        }
        entry.put("ExpenseID", expenseID);
        entry.putAll(getHorizontalEntries(entry, rs));

        return entry;
    }

    private HashMap<String, String> getAccountingEntry(ResultSet rs) throws SQLException {

        HashMap<String, String> entry = new HashMap<>();

        String accountingEntryID = rs.getString("AccountingEntryID");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("expeAccountingEntryIDnseID: " + accountingEntryID);
        }
        entry.put("AccountingEntryID", accountingEntryID);
        entry.putAll(getHorizontalEntries(entry, rs));

        return entry;
    }

    private HashMap<String, String> getHorizontalEntries(HashMap<String, String> map, ResultSet rs) throws SQLException {

        String desciption = rs.getString("Description");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Description: " + desciption);
        }
        String cur = rs.getString("Currency");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Currency: " + cur);
        }
        String amnt = rs.getString("Amount");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Amount: " + amnt);
        }
        String tariffType = rs.getString("TariffType");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("TariffType: " + tariffType);
        }
        String fromAmount = rs.getString("FromAmount");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("FromAmount: " + fromAmount);
        }
        String toAmount = rs.getString("ToAmount");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("ToAmount: " + toAmount);
        }
        String flatCommissionAmount = rs.getString("FlatCommissionAmount");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("FlatCommissionAmount: " + flatCommissionAmount);
        }
        String percentageCommission = rs.getString("PercentageCommission");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("TariffType: " + percentageCommission);
        }
        String minCommissionOrExpenseAmount = rs.getString("MinCommissionOrExpenseAmount");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("MinCommissionOrExpenseAmount: " + minCommissionOrExpenseAmount);
        }
        String maxCommissionOrExpenseAmount = rs.getString("MaxCommissionOrExpenseAmount");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("MaxCommissionOrExpenseAmount: " + maxCommissionOrExpenseAmount);
        }
        String calculatedAlgorithm = rs.getString("CalculatedAlgorithm");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("CalculatedAlgorithm: " + calculatedAlgorithm);
        }

        map.put("Description", desciption);
        map.put("Currency", cur);
        map.put("Amount", amnt);
        map.put("TariffType", tariffType);

        map.put("FromAmount", fromAmount);
        map.put("ToAmount", toAmount);
        map.put("FlatCommissionAmount", flatCommissionAmount);
        map.put("PercentageCommission", percentageCommission);
        map.put("MinCommissionOrExpenseAmount", minCommissionOrExpenseAmount);
        map.put("MaxCommissionOrExpenseAmount", maxCommissionOrExpenseAmount);
        map.put("CalculatedAlgorithm", calculatedAlgorithm);

        return map;
    }

    public List<Map<String, String>> getCommissionParameters(String serviceName, String operationName, String currency, String language, String commissionAttributesXML) throws CBSException {
        List<Map<String, String>> commissions = new ArrayList<>();

        try (
                Connection conn = sqlDS.getConnection();
                PreparedStatement ps = conn.prepareStatement("exec usp_PRD_GetCommissionParams ?,?,?,?,?");) {
            ps.setString(1, serviceName);
            ps.setString(2, operationName);
            ps.setString(3, currency);
            ps.setString(4, language);
            ps.setString(5, commissionAttributesXML);
            try (ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData meta = rs.getMetaData();
                int columns = meta.getColumnCount();
                while (rs.next()) {
                    Map<String, String> singleCommissionData = new HashMap<>(columns);

                    for (int i = 1; i <= columns; i++) {
                        singleCommissionData.put(meta.getColumnName(i), Optional.ofNullable(rs.getObject(i)).map(Object::toString).orElse(""));
                    }
                    commissions.add(singleCommissionData);
                }
            }

        } catch (SQLException e) {
            ErrorUtils.throwCBSException(e, String.valueOf(ConstantError_Types._Technical),
                    String.valueOf(ConstantError_System_IDs._FUSE), this.getClass().getCanonicalName(),
                    String.valueOf(300051), String.valueOf(ConstantError_Levels._Error),
                    "Λάθος κατά την εκτέλεση του Tariff Manager(usp_PRD_GetCommissionParams)", "", "");
        }
        return commissions;
    }
}