//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class RoundRobinBalancerStrategy extends AbstractBalancerStrategy {
    private ArrayDeque<String> availableEndpoints = new ArrayDeque();

    public RoundRobinBalancerStrategy(ArrayDeque<String> availableEndpoints) {
        this.availableEndpoints = availableEndpoints;
    }

    public RoundRobinBalancerStrategy(Collection<String> availableEndpoints) {
        availableEndpoints.forEach((endpoint) -> this.markAsOnline(endpoint));
    }

    public String next() {
        this.checkEmpty(this.availableEndpoints);
        return this.availableEndpoints.size() == 1 ? (String)this.availableEndpoints.peekFirst() : this.roundRobin();
    }

    public String markAsOffline(String url) {
        this.checkEmpty(this.availableEndpoints);
        synchronized(this.availableEndpoints) {
            this.checkEmpty(this.availableEndpoints);
            String baseUrl = this.locateUrl(this.availableEndpoints, url);
            this.availableEndpoints.remove(baseUrl);
            return baseUrl;
        }
    }

    public String markAsOnline(String url) {
        synchronized(this.availableEndpoints) {
            String baseUrl = this.locateUrl(this.availableEndpoints, url);
            if (!this.availableEndpoints.contains(baseUrl)) {
                this.availableEndpoints.addLast(baseUrl);
            }

            return baseUrl;
        }
    }

    public List<String> getAvailableEndpoints() {
        return new ArrayList(this.availableEndpoints.clone());
    }

    protected String roundRobin() {
        synchronized(this.availableEndpoints) {
            String selected = (String)this.availableEndpoints.pollFirst();
            this.availableEndpoints.addLast(selected);
            return selected;
        }
    }

    public String toString() {
        return "RoundRobinBalancerStrategy{availableEndpoints=" + this.availableEndpoints + '}';
    }
}
