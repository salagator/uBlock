package gr.alpha.cbs.fuse.service;

import jakarta.enterprise.inject.spi.CDI;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;

@Path("/faultToleranceClean")
public class FaultToleranceRESTAPI {

    @GET
    public String cleanGuards() {
        // get all beans of type AbstractCamelRouteDrivingProvider and call their clearFaultToleranceGuards method
        CDI.current().select(AbstractCamelRouteDrivingProvider.class).stream()
            .forEach(AbstractCamelRouteDrivingProvider::clearFaultToleranceGuards);
        // get all beans of type AbstractCamelRouteDrivingKafkaConsumer and call their clearFaultToleranceGuards method
        CDI.current().select(AbstractCamelRouteDrivingKafkaConsumer.class).stream()
                .forEach(AbstractCamelRouteDrivingKafkaConsumer::clearFaultToleranceGuards);
        // get all beans of type AbstractCamelRouteDrivingKafkaConsumer and call their clearFaultToleranceGuards method
        CDI.current().select(AbstractCamelRouteDrivingRESTAPI.class).stream()
                .forEach(AbstractCamelRouteDrivingRESTAPI::clearFaultToleranceGuards);
        return "Fault tolerance guards cleared";
    }
}
