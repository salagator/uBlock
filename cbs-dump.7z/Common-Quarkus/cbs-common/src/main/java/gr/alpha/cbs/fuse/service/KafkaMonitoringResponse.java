package gr.alpha.cbs.fuse.service;

public class KafkaMonitoringResponse {
    private String content;
    private int status;
    private String kafkaTimestamp;
    private String createdTimestamp;
    private String reservedTimestamp;
    private String responseTimestamp;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getKafkaTimestamp() {
        return kafkaTimestamp;
    }

    public void setKafkaTimestamp(String kafkaTimestamp) {
        this.kafkaTimestamp = kafkaTimestamp;
    }

    public String getCreatedTimestamp() {
        return createdTimestamp;
    }

    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    public String getReservedTimestamp() {
        return reservedTimestamp;
    }

    public void setReservedTimestamp(String reservedTimestamp) {
        this.reservedTimestamp = reservedTimestamp;
    }

    public String getResponseTimestamp() {
        return responseTimestamp;
    }

    public void setResponseTimestamp(String responseTimestamp) {
        this.responseTimestamp = responseTimestamp;
    }
}
