package gr.alpha.cbs.fuse.support;

import gr.alpha.cbs.fuse.common.ifaces.RefDataTranslator;
import io.quarkus.runtime.annotations.RegisterForReflection;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;
import org.jboss.logging.Logger;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;

@Named("functionTranslator")
@ApplicationScoped
@RegisterForReflection
public class TranslatorXsltExtension extends ExtensionFunctionDefinition {
    private static final Logger LOGGER = Logger.getLogger(TranslatorXsltExtension.class);
    private static final long serialVersionUID = 1862024181840326214L;

    @Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("tr", "http://fuse.cbs.alpha.gr/translator/", "translator");
    }

    @Override
    public SequenceType[] getArgumentTypes() {
        return new SequenceType[] { SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING, SequenceType.OPTIONAL_STRING };

    }

    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
        return SequenceType.SINGLE_STRING;
    }

    @Inject
    @Named("refDataTranslatorEjb")
    RefDataTranslator translator;

    @Override
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {
            private static final long serialVersionUID = 5090616615262067008L;

            @Override
            @SuppressWarnings("rawtypes")
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
                Long timer = 0L;


                try {
                    String fromSystem = ((StringValue) arguments[0]).getStringValue();
                    String toSystem = null;
                    if (arguments[1] instanceof LazySequence) {
                        Item it = ((LazySequence) arguments[1]).head();
                        if (it == null) {
                            throw new Exception(
                                    "Unrecognized argument type: " + arguments[1].getClass().getCanonicalName());
                        } else {
                            toSystem = it.getStringValue();
                        }
                    } else if (arguments[1] instanceof StringValue) {
                        toSystem = ((StringValue) arguments[1]).getStringValue();
                    } else {
                        throw new Exception(
                                "Unrecognized argument type: " + arguments[1].getClass().getCanonicalName());
                    }

                    String table = ((StringValue) arguments[2]).getStringValue();
                    String value = null;

                    if (arguments[3] instanceof LazySequence) {
                        Item it = ((LazySequence) arguments[3]).head();
                        if (it == null) {
                            // The fourth argument is optional, as it might be empty from the call to the back end.
                            // In that case, the LazySequence will be empty and so we will return the empty string.
                            return StringValue.makeStringValue("");
                        } else {
                            value = it.getStringValue();
                        }
                    } else if (arguments[3] instanceof StringValue) {
                        value = ((StringValue) arguments[3]).getStringValue();
                    } else {
                        throw new Exception(
                                "Unrecognized argument type: " + arguments[3].getClass().getCanonicalName());
                    }
                    if (value == null || value.isEmpty()) {
                        return StringValue.makeStringValue("");
                    }
                    if (LOGGER.isTraceEnabled()){
                        timer = System.nanoTime();
                    }

                    long initcontext = System.nanoTime() - timer;
                    String result = value.trim();
                    long lookup = System.nanoTime() - timer;
                    result = translator.translateData(fromSystem, toSystem, table, result);

                    if (LOGGER.isTraceEnabled()){
                        timer = System.nanoTime() - timer;
                        LOGGER.trace("XSL call completed " + timer / 1000 + ",init:"  + initcontext / 1000 + ",lookup:" +  lookup/1000 + " microseconds");
                    }

                    return StringValue.makeStringValue(result);
                } catch (Exception e) {
                    throw new XPathException("Unable to translate value", e);
                }
            }
        };
    }

}
