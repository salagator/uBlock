package gr.alpha.cbs.fuse.ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;

import javax.sql.DataSource;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.transaction.Transactional;
import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.ifaces.MasterDataInterface;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantNationalClearingCodeSwiftInstruction;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;

@Named("validatorsEjb")
@ApplicationScoped
@RegisterForReflection
public class ValidatorsEjb {
	
	private static final Logger LOGGER = Logger.getLogger(ValidatorsEjb.class);

	@Inject
	@io.quarkus.agroal.DataSource("hostps")
	DataSource sqlDS;
	
	@Inject
	MasterDataInterface masterDataEjb;
	
	@Transactional(Transactional.TxType.NOT_SUPPORTED)
	public void validateBICCode(String bicCode) throws Exception {
		
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("in validateBICCode bicCode is: "+ bicCode);
		}
		
		String sqlQuery = "SELECT 1 FROM PRD_BICDirectory WHERE SwiftCode = ?  ";
		try(Connection conn = this.sqlDS.getConnection();PreparedStatement pstm = conn.prepareStatement(sqlQuery);) {
			pstm.setString(1, bicCode);
			try(ResultSet res = pstm.executeQuery()){
				if (!res.next()) {
					ErrorUtils.throwCBSException(null ,  
							ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, 
							ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, 
							ValidatorsEjb.class.getCanonicalName(), 
							ConstantErrorMessages._ANYPARKTOS_BIC_KODIKOS,
							"3",
							"", "", "");
				}
			}
		}
	}
	
	/**
	 * 
	 * MW function ValidateNationalClearingCode as described on ESB.CreateFundTransferOfflinePayByAccount V0.5.docx file
	 * 
	 * @param nccID
	 * @param nccValue
	 * @throws Exception
	 */
	@Transactional(Transactional.TxType.NOT_SUPPORTED)
	@SuppressWarnings("resource")
	public void validateNationalClearingCode(String nccID, String nccValue) throws Exception{
		
		HashMap<String,String> map = masterDataEjb.getMasterDetailsByItemNameLists("NationalClearingCodeSwiftInstruction", nccID);
		int minDigits = 0;
		int maxDigits = 0;
		
		if (map!=null && !map.isEmpty() && map.containsKey("MinDigits") && map.containsKey("MaxDigits")){
			minDigits = Integer.parseInt(map.get("MinDigits"));
			maxDigits = Integer.parseInt(map.get("MaxDigits"));
		}
		
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("in validateNationalClearingCode nccID : "+ nccID + " and nccValue: "+nccValue);
			LOGGER.debug("in validateNationalClearingCode minDigits : "+ minDigits + " and maxDigits: "+maxDigits);
		}
		
		int nccValueLength = nccValue.length();
		if (nccValueLength < minDigits || nccValueLength > maxDigits){
			ErrorUtils.throwCBSException(null ,  
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, 
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, 
					ValidatorsEjb.class.getCanonicalName(), 
					ConstantErrorMessages._TO_SYNOLIKO_MIKOS_TON_PSIFION_TU_National_Clearing_Code_EINAI_LATHOS,
					"3",
					"", "", "");
		}
		
		if (nccID.equals(String.valueOf(ConstantNationalClearingCodeSwiftInstruction._CH_CHIPS_Universal_Id))){
			
			String sqlQuery = "SELECT 1 FROM PRD_BICDirectory WHERE CHIPSUID = ? AND CHIPSUID<>'000000'";
			
			try(Connection conn = this.sqlDS.getConnection();PreparedStatement pstm = conn.prepareStatement(sqlQuery);) {
				pstm.setString(1, nccValue);
				try(ResultSet res = pstm.executeQuery()){
					if (!res.next()) {
						ErrorUtils.throwCBSException(null ,  
								ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, 
								ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, 
								ValidatorsEjb.class.getCanonicalName(), 
								ConstantErrorMessages._ANYPARKTOS_National_Clearing_Code,
								"3",
								"", "", "");
					}
				}
			}
		}else{
			String sqlQuery = "SELECT 1 FROM PRD_BICDirectory WHERE NATCODE = ? AND NATIONALID = ? ";
			String natCode = StringUtils.EMPTY;
			if (map!=null && !map.isEmpty() && map.containsKey("Value")){
				natCode = map.get("Value");
			}
			if (LOGGER.isDebugEnabled()){
				LOGGER.debug("in validateNationalClearingCode natCode : "+ natCode);
			}
			try(Connection conn = this.sqlDS.getConnection();PreparedStatement pstm = conn.prepareStatement(sqlQuery);) {
				pstm.setString(1, natCode);
				pstm.setString(2, nccValue);
				try(ResultSet res = pstm.executeQuery()){
					if (!res.next()) {
						ErrorUtils.throwCBSException(null ,  
								ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, 
								ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, 
								ValidatorsEjb.class.getCanonicalName(), 
								ConstantErrorMessages._ANYPARKTOS_National_Clearing_Code,
								"3",
								"", "", "");
					}
				}
			}
		}
		
	}
	
}
