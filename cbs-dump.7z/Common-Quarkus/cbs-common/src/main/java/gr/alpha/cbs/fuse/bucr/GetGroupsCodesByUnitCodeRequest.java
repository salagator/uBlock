package gr.alpha.cbs.fuse.bucr;

public class GetGroupsCodesByUnitCodeRequest {
	
	private String unitCode;
	
	public GetGroupsCodesByUnitCodeRequest(){
		
	}

	public String getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(String unitCode) {
		this.unitCode = unitCode;
	}

	@Override
	public String toString() {
		return "GetGroupsCodesByUnitCodeRequest{" +
				"unitCode='" + unitCode + '\'' +
				'}';
	}
}
