package gr.alpha.cbs.fuse.ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.inject.Singleton;
import jakarta.transaction.Transactional;
import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import gr.alpha.cbs.fuse.ifaces.ICreateAccountingEntriesHelper;

@Named("accountingPlanHandlerEjb")
@Singleton
@RegisterForReflection
@Transactional(Transactional.TxType.NOT_SUPPORTED)
public class AccountingPlanHandlerEjb implements ICreateAccountingEntriesHelper{
    @Inject
    @io.quarkus.agroal.DataSource("hostps")
    DataSource sqlDS;

    private static final Logger LOGGER = Logger.getLogger(AccountingPlanHandlerEjb.class);

    /**
     * Retrieves Accounting Plan record from ACG_Accounting_Plan table according to accountingCode
     * The property "cbs.common.AccountingCode" must be set before calling the method
     * The ResultSet is returned through a property --> deposits.journal.accountingRecord
     *
     * @param exchange
     * @throws Exception
     */

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    @SuppressWarnings("resource")
    @Override
    public Map<String, String> getAccountingPlanRecord(String accountingCode) throws Exception {
        ResultSet res = null;

        Map<String, String> record = new HashMap<>();

        LOGGER.debug("Accounting code: " + accountingCode.substring(5, 14));
        String sql = "select * FROM ACG_Accounting_Plan WHERE AccountNumber = ?";

        try (Connection conn = this.sqlDS.getConnection();PreparedStatement pstm = conn.prepareStatement(sql)) {

            pstm.setString(1, accountingCode.substring(5,14));
            res = pstm.executeQuery();

            if (!res.next()) {
                ErrorUtils.throwCBSException(null,
                        String.valueOf(ConstantError_Types._Functional),
                        String.valueOf(ConstantError_System_IDs._FUSE),
                        this.getClass().getCanonicalName(),
                        String.valueOf(ConstantErrorMessages._Account_Not_Found),
                        String.valueOf(ConstantError_Levels._Error),
                        "Accounting Code " + accountingCode + " not found in database",
                        "",
                        "");
            }

            LOGGER.debug("Account record: " + res.getString("AccountNumber"));


            ResultSetMetaData md = res.getMetaData();
            int columns = md.getColumnCount();
            if (LOGGER.isDebugEnabled()){
                LOGGER.debug("Columns " + columns);
            }
            record = new HashMap<>(columns);
            for(int i=1; i<=columns; ++i){
                if (LOGGER.isDebugEnabled()){
                    LOGGER.debug("key: " + md.getColumnName(i));
                    LOGGER.debug("value: " + res.getString(i));
                }
                record.put(md.getColumnName(i), res.getString(i));
            }


            return record;

        } catch (Exception ex) {
            if (!(ex instanceof CBSException)){
                ErrorUtils.throwCBSException(ex,
                        String.valueOf(ConstantError_Types._Functional),
                        String.valueOf(ConstantError_System_IDs._FUSE),
                        this.getClass().getCanonicalName(),
                        String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob),
                        String.valueOf(ConstantError_Levels._Error),
                        ex.getMessage(),
                        "",
                        "");
            }else
                throw ex;
        } finally {
            if (res != null) {
                res.close();
            }
        }

        return record;

    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    @SuppressWarnings("resource")
    @Override
    public String getSAPAccountsData(int accountType, int currency1, String accountNumber) throws Exception {

        String sql = "SELECT (select * FROM ACG_Accounting_Plan WHERE AccountType <> ? AND Currency1 = ? AND AccountNumber LIKE ? FOR XML RAW, root, elements) AS XMLRESULT";

        try (Connection conn = this.sqlDS.getConnection();PreparedStatement pstm = conn.prepareStatement(sql)) {
            pstm.setInt(1, accountType);
            pstm.setInt(2, currency1);
            pstm.setString(3, accountNumber);
            try (ResultSet rs = pstm.executeQuery()) {
                if (rs.next() && !StringUtils.isEmpty(rs.getString("XMLRESULT"))){
                    LOGGER.debug("Found entries");
                    return  rs.getString("XMLRESULT");
                }
                else{
                    LOGGER.debug("No entries!");
                    return "EmptyResponse";
                }

            }

        }catch (Exception ex) {
            throw ex;
        }
    }
    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    @SuppressWarnings("resource")
    @Override
    public List<Map<String, String>> getExceptionsList(String accountMask) throws Exception{

        String accountSixDigitsMask = accountMask.substring(0, 6) + "XXX";
        String accountFourDigitsMask =  accountMask.substring(0, 4) + "XXXXX";
        String accountTwoDigitsMask =  accountMask.substring(0, 2) + "XXXXXXX";
        String sql = "SELECT * FROM ACG_GP_Exceptions WHERE AccountMask = ? OR AccountMask = ? OR AccountMask = ? OR AccountMask = ? ";
        List<Map<String, String>> list = new ArrayList<>();

        try (Connection conn = this.sqlDS.getConnection();PreparedStatement pstm = conn.prepareStatement(sql)) {

            pstm.setString(1, accountMask);
            pstm.setString(2, accountSixDigitsMask);
            pstm.setString(3, accountFourDigitsMask);
            pstm.setString(4, accountTwoDigitsMask);


            try(ResultSet res = pstm.executeQuery()){
                while(res.next()){

                    ResultSetMetaData md = res.getMetaData();
                    int columns = md.getColumnCount();
                    if (LOGGER.isDebugEnabled()){
                        LOGGER.debug("Columns " + columns);
                    }

                    HashMap<String, String> record = new HashMap<>(columns);
                    for(int i=1; i<=columns; ++i){
                        if (LOGGER.isDebugEnabled()){
                            LOGGER.debug("key: " + md.getColumnName(i));
                            LOGGER.debug("value: " + res.getObject(i));
                        }
                        record.put(md.getColumnName(i), res.getString(i));
                    }
                    list.add(record);
                }
            }
        } catch (Exception ex) {
            throw ex;
        }

        return list;
    }


    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    @SuppressWarnings("resource")
    @Override
    public List<Map<String, String>> getPairAccountsList(String accountMask) throws Exception {

        String accountMask_6Digits = accountMask.substring(0, 6) + "XXX";
        String accountMask_4Digits = accountMask.substring(0, 4) + "XXXXX";


        List<Map<String, String>> list = new ArrayList<>();
        HashMap<String, String> row;
        String sql = "SELECT * FROM ACG_ORDERACC_PAIRS WHERE AccountMask1 IN ( ? , ? , ? ) OR AccountMask2 IN ( ? , ? , ? ) ";

        try (Connection conn = this.sqlDS.getConnection();PreparedStatement pstm = conn.prepareStatement(sql)) {

            pstm.setString(1, accountMask);
            pstm.setString(2, accountMask_6Digits);
            pstm.setString(3, accountMask_4Digits);
            pstm.setString(4, accountMask);
            pstm.setString(5, accountMask_6Digits);
            pstm.setString(6, accountMask_4Digits);

            if(LOGGER.isDebugEnabled()){
                LOGGER.debug("SQL: " + sql);
            }

            try(ResultSet res = pstm.executeQuery()){

                while(res.next()){

                    // Create new HashMap for new row
                    row =  new HashMap<>();

                    // fill new row with DB row data
                    ResultSetMetaData md = res.getMetaData();
                    int columns = md.getColumnCount();
                    if (LOGGER.isDebugEnabled()){
                        LOGGER.debug("Columns " + columns);
                    }
                    for(int i=1; i<=columns; ++i){
                        if (LOGGER.isDebugEnabled()){
                            LOGGER.debug("key: " + md.getColumnName(i));
                            LOGGER.debug("value: " + res.getObject(i));
                        }
                        row.put(md.getColumnName(i), res.getString(i));
                    }

                    // add new row to list
                    list.add(row);
                }
            }
            return list;
        } catch (Exception ex) {
            if (!(ex instanceof CBSException)){

                ErrorUtils.throwCBSException(ex,
                        String.valueOf(ConstantError_Types._Functional),
                        String.valueOf(ConstantError_System_IDs._FUSE),
                        this.getClass().getCanonicalName(),
                        String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob),
                        String.valueOf(ConstantError_Levels._Error),
                        ex.getMessage(),
                        "",
                        "");
            }
        }

        return list;
    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    @SuppressWarnings("resource")
    @Override
    public List<Map<String, String>> getSpecificAccountingTemplateFC(String operationCode,String acgfcIncomeKind,String acgfcOutcomeKind) throws Exception {
        List<Map<String, String>> list = new ArrayList<>();

        String sql = "SELECT * FROM ACG_Scenario_Template_FC WHERE OperationCode = ? AND IncomeKind = ? AND OutcomeKind = ?";

        try (Connection conn = this.sqlDS.getConnection();PreparedStatement pstm = conn.prepareStatement(sql)) {

            pstm.setString(1, operationCode);
            pstm.setString(2, acgfcIncomeKind);
            pstm.setString(3, acgfcOutcomeKind);

            if(LOGGER.isDebugEnabled()){
                LOGGER.debug("Prepared Statement: " + pstm);
            }

            try(ResultSet res = pstm.executeQuery()){
                while(res.next()){

                    ResultSetMetaData md = res.getMetaData();
                    int columns = md.getColumnCount();
                    if (LOGGER.isDebugEnabled()){
                        LOGGER.debug("Columns " + columns);
                    }

                    HashMap<String, String> record = new HashMap<>(columns);
                    for(int i=1; i<=columns; ++i){
                        if (LOGGER.isDebugEnabled()){
                            LOGGER.debug("key: " + md.getColumnName(i));
                            LOGGER.debug("value: " + res.getObject(i));
                        }
                        record.put(md.getColumnName(i), res.getString(i));
                    }
                    list.add(record);
                }
            }
        } catch (Exception ex) {
            throw ex;
        }

        return list;
    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    @Override
    public String getAccountingModelFC(String operationCode, String incomeKind, String outcomeKind, Boolean calcSameInAndOut, String exchangeTypePosition, String specialCase) throws Exception {

        String sql = "SELECT Accounting_Model_Code FROM ACG_Accounting_Models_FC  WITH (NOLOCK)" +
                "WHERE OperationCode = ? AND IncomeKind = ? AND OutcomeKInd = ? AND Same_In_Out_Curr = ? AND Exchange_Type_Position =  ? AND Special_Case = ?";
        String accountingModel = null;
        if(LOGGER.isDebugEnabled()){
            LOGGER.debug("OperationCode: " + operationCode);
            LOGGER.debug("IncomeKind: " + incomeKind);
            LOGGER.debug("OutcomeKInd: " + outcomeKind);
            LOGGER.debug("Same_In_Out_Curr: " + calcSameInAndOut);
            LOGGER.debug("Exchange_Type_Position: " + exchangeTypePosition);
            LOGGER.debug("Special_Case: " + specialCase);
        }
        try (Connection conn = this.sqlDS.getConnection();PreparedStatement pstm = conn.prepareStatement(sql)) {
            pstm.setInt(1, Integer.parseInt(operationCode));
            pstm.setInt(2, Integer.parseInt(incomeKind));
            pstm.setInt(3, Integer.parseInt(outcomeKind));
            pstm.setBoolean(4, calcSameInAndOut);
            pstm.setInt(5, Integer.parseInt(exchangeTypePosition));
            pstm.setInt(6, Integer.parseInt(specialCase));

            try (ResultSet rs = pstm.executeQuery()) {
                if (rs.next()){
                    accountingModel = rs.getString("Accounting_Model_Code");
                }
            }

            return StringUtils.isEmpty(accountingModel) ? null : accountingModel;

        }catch (Exception ex) {
            LOGGER.error("Exception on getAccountingModelFC method", ex);
            throw ex;
        }
    }

}