package gr.alpha.cbs.fuse.ifaces;

import gr.alpha.cbs.fuse.common.exceptions.CBSException;

public interface BankCodeDirectory {

    int getBankCode(String creditCardNumber) throws CBSException;

    /**
     * Get BnkCode by providing the first six digits of the credit card number and the net codes to look in.
     *
     * @param sixFirstDigitsOfCreditCard the first six digits of the credit card
     * @param netCodes the netCodes to look in
     * @return the BnkCode found in the database
     * @throws CBSException
     */
    String getBankCode(String sixFirstDigitsOfCreditCard, String... netCodes) throws CBSException;

}
