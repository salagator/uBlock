package gr.alpha.cbs.fuse.ejb;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;
import jakarta.transaction.Transactional;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;
import org.jboss.logging.Logger;

@Named("executionModeHandlerBean")
@Dependent
@RegisterForReflection
public class ExecutionModeHandlerBean {
	@Inject
	@io.quarkus.agroal.DataSource("cbs")
	DataSource sqlDS;

	private static final Logger LOGGER = Logger.getLogger(ExecutionModeHandlerBean.class);

	@Transactional(Transactional.TxType.NOT_SUPPORTED)
	public void readHostExecutionMode(Exchange exchange) throws Exception {
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("ReadHostExecutionMode start");
		}

		String executionMode = "";
		String sqlQuery = "SELECT SystemMode FROM REF_SystemTypes WHERE SystemName = 'OS2200'";
		try(Connection conn = this.sqlDS.getConnection();Statement stm = conn.createStatement();ResultSet result = stm.executeQuery(sqlQuery)) {

			if (result.next()) {
				if(!result.wasNull()){
					executionMode = result.getString("SystemMode");
					exchange.setProperty("hostExecutionMode", executionMode);
				} else{
					ErrorUtils.throwCBSException(null,
							String.valueOf(ConstantError_Types._Functional),
							String.valueOf(ConstantError_System_IDs._FUSE),
							this.getClass().getCanonicalName(),
							String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob),
							String.valueOf(ConstantError_Levels._Error),
							"Δεν υπάρχει ένδειξη κατάστασης λειτουργίας του HOST στην βάση!!",
							"",
							"",
							"");
				}
			}

		} catch (Exception ex) {
			if (!(ex instanceof CBSException)){
				ErrorUtils.throwCBSException(ex,
						String.valueOf(ConstantError_Types._Functional),
						String.valueOf(ConstantError_System_IDs._FUSE),
						this.getClass().getCanonicalName(),
						String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob),
						String.valueOf(ConstantError_Levels._Error),
						ex.getMessage(),
						"",
						"",
						"");
			}else{
				throw ex;
			}
		}
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("ReadHostExecutionMode  end");
		}

	}
}
