//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

import java.util.List;

public interface BalancerStrategy {
    String next();

    String markAsOffline(String url);

    String markAsOnline(String url);

    List<String> getAvailableEndpoints();

    public static enum Type {
        RANDOM_STRATEGY,
        ROUND_ROBIN_STRATEGY;
    }
}
