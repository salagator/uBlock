package gr.alpha.cbs.fuse.tools;

public class ConvertMoneyToStringEnglish {
    private static final String[] ones = { "ZERO", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN", "ELEVEN", "TWELVE", "THIRTEEN", "FOURTEEN", "FIFTEEN", "SIXTEEN", "SEVENTEEN", "EIGHTEEN", "NINETEEN" };

    private static final String[] tens = {
            "", // 0
            "", // 1
            "TWENTY", // 2
            "THIRTY", // 3
            "FORTY", // 4
            "FIFTY", // 5
            "SIXTY", // 6
            "SEVENTY", // 7
            "EIGHTY", // 8
            "NINETY" // 9
    };

    public static String getVerbalFinancial(final double money, final int decimals, final String currency) {
        return getVerbal(money,decimals,currency,null,true);
    }

    public static String getVerbalStandart(final double money, final int decimals, final String currency, final String subcurrency) {
        return getVerbal(money,decimals,currency,subcurrency,false);
    }

    public static String getVerbal(final double money, final int decimals, final String currency, final String subcurrency, final boolean financialRepresetation) {
        String sign="";
        int decimalCalc = (int)Math.pow(10, decimals);
        long integerPart = (long) Math.abs(money);
        long decimalPart = Math.round((Math.abs(money) - integerPart) * decimalCalc);
//        if (money == 0D) {
//            return "";
//        }
        if (money < 0) {
            sign="MINUS ";
        }
        String integerPartWord = "";
        if (integerPart >= 0) {
            integerPartWord = sign +convert(integerPart) + (!financialRepresetation ? " "+currency : "");
        }
        String decimalPartWord = "";
        if (decimalPart > 0) {
            if (integerPartWord.length() > 0) {
                decimalPartWord = " AND ";
            }
            if(financialRepresetation){
                decimalPartWord += decimalPart + " / "+ decimalCalc;
            }else{
                decimalPartWord += convert(decimalPart) + " " + subcurrency + (decimalPart == 1 ? "" : "S");
            }
        }
        return integerPartWord + decimalPartWord + (financialRepresetation ? " "+currency : "");
    }

    private static String convert(final long n) {
        if (n < 20) {
            return ones[(int) n];
        }
        if (n < 100) {
            return tens[(int) n / 10] + ((n % 10 != 0) ? " " : "") + ((ones[(int) n % 10].equals("ZERO")?"":ones[(int) n % 10]));
        }
        if (n < 1000) {
            return ones[(int) n / 100] + " HUNDRED" + ((n % 100 != 0) ? " " : "") + (convert(n % 100).equals("ZERO")?"":convert(n % 100));
        }
        if (n < 1_000_000) {
            return convert(n / 1000) + " THOUSAND" + ((n % 1000 != 0) ? " " : "") + (convert(n % 1000).equals("ZERO")?"":convert(n % 1000));
        }
        if (n < 1_000_000_000) {
            return convert(n / 1_000_000) + " MILLION" + ((n % 1_000_000 != 0) ? " " : "") + (convert(n % 1_000_000).equals("ZERO")?"":convert(n % 1_000_000));
        }
        return convert(n / 1_000_000_000) + " BILLION" + ((n % 1_000_000_000 != 0) ? " " : "") + (convert(n % 1_000_000_000).equals("ZERO")?"":convert(n % 1_000_000_000));
    }
}
