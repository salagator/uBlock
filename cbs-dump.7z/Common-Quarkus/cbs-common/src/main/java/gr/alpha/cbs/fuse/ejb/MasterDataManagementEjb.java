package gr.alpha.cbs.fuse.ejb;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;
import jakarta.transaction.Transactional;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@Named("masterDataManagementEjb")
@ApplicationScoped
@RegisterForReflection
public class MasterDataManagementEjb {
    private static final Logger LOGGER = LoggerFactory.getLogger(MasterDataManagementEjb.class);

    @Inject
    @io.quarkus.agroal.DataSource("hostps")
    DataSource sqlDS;

    @Inject
    @io.quarkus.agroal.DataSource("hostpsxa")
    DataSource sqlDSXA;

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public String getMasterDataItems(String action, String masterName, String requestXml, String pageKey, String pageSize) throws CBSException {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Action:" + action);
            LOGGER.debug("MasterName:" + masterName);
            LOGGER.debug("RequestXML:" + requestXml);
            LOGGER.debug("PageKey:" + requestXml);
            LOGGER.debug("PageSize:" + pageSize);
        }

        String sqlQuery = "exec usp_MST_MasterData ?,?,?,?,?";
        String queryResult = null;
        try (Connection conn = this.sqlDS.getConnection(); PreparedStatement pstm = conn.prepareStatement(sqlQuery);) {

            pstm.setInt(1, Integer.parseInt(action));
            pstm.setString(2, masterName);
            pstm.setString(3, requestXml);

            int pageKeyValue = NumberUtils.toInt(pageKey);
            pstm.setInt(4, (pageKeyValue == 0) ? 1 : pageKeyValue); // default
            // key: 1

            int pageSizeValue = NumberUtils.toInt(pageSize);
            pstm.setInt(5, (pageSizeValue == 0) ? 20 : pageSizeValue); // default
            // size:
            // 20
            queryResult = executeQuery(pstm);
        } catch (SQLException se) {
            ErrorUtils.throwCBSException(se, String.valueOf(ConstantError_Types._Technical),
                    String.valueOf(ConstantError_System_IDs._FUSE), this.getClass().getCanonicalName(),
                    String.valueOf(300051), String.valueOf(ConstantError_Levels._Error),
                    "Λάθος κατά την εκτέλεση της usp_MST_Master (" + masterName + ")", "", "");

        }

        return queryResult;
    }

    @Transactional(Transactional.TxType.REQUIRED)
    public void alterMasterDataItems(String action, String masterName, String requestXml) throws CBSException {

        String sqlQuery = "exec usp_MST_MasterData ?,?,?";
        try (Connection conn = this.sqlDSXA.getConnection(); PreparedStatement pstm = conn.prepareStatement(sqlQuery);) {
            pstm.setInt(1, Integer.parseInt(action));
            pstm.setString(2, masterName);
            pstm.setString(3, requestXml);

            pstm.execute();
        } catch (SQLException se) {
            ErrorUtils.throwCBSException(se, String.valueOf(ConstantError_Types._Technical),
                    String.valueOf(ConstantError_System_IDs._FUSE), this.getClass().getCanonicalName(),
                    String.valueOf(300051), String.valueOf(ConstantError_Levels._Error),
                    "Λάθος κατά την εκτέλεση της usp_MST_Master (" + masterName + ")", "", "");

        }

    }


    private String executeQuery(PreparedStatement pstm) throws SQLException {
        String result = null;
        try (ResultSet rs = pstm.executeQuery();) {
            StringBuilder sb = new StringBuilder();
            if (rs.next()) {
                result = rs.getString("XML_Results");
                if (result != null) {
                    sb.append(result);
                    result = sb.toString();
                    LOGGER.error("RESULT:" + sb.toString());
                }
            }
        } catch (SQLException e) {
            LOGGER.error("Error In Master Data query");
            throw e;
        }
        return result;
    }

}
