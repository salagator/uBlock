package gr.alpha.cbs.fuse.support;

import gr.alpha.cbs.fuse.ejb.MasterDataEjb;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

@Named("functionMasterDataAttributeValueRetriever")
@ApplicationScoped
@RegisterForReflection
public class MasterDataAttributeValueRetrieverXsltExtension extends ExtensionFunctionDefinition {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2060328814415747862L;

	@Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("mdr", "http://fuse.cbs.alpha.gr/masterDataAttributeValueRetriever/", "masterDataAttributeValueRetriever");
    }

	 @Override
	 public SequenceType[] getArgumentTypes() {
	    return new SequenceType[]{SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING};
	 }
    
    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
    	return SequenceType.SINGLE_STRING;
    }

	@Inject
	@Named("masterDataInterface")
	MasterDataEjb masterStudio;

    @Override
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {
			
			/**
			 * 
			 */
			private static final long serialVersionUID = -2058456742203368019L;

			@Override
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
				try {
					
	                String masterName = null;
	                String masterValue = null;
	                String attributeName = null;
	                //Check masterName - Required field
	                if (arguments[0] instanceof LazySequence) {
	                	masterName = ((LazySequence)arguments[0]).head().getStringValue();
	                } else if (arguments[0] instanceof StringValue) {
	                	masterName = ((StringValue)arguments[0]).getStringValue();
	                } else {
	                	throw new Exception("Unrecognized argument type for masterName parameter: " + arguments[0].getClass().getCanonicalName());
	                }
	                
	                //Check masterValue - Required field
	                if (arguments[1] instanceof LazySequence) {
	                	masterValue = ((LazySequence)arguments[1]).head().getStringValue();
	                } else if (arguments[1] instanceof StringValue) {
	                	masterValue = ((StringValue)arguments[1]).getStringValue();
	                } else {
	                	throw new Exception("Unrecognized argument type for masterValue parameter: " + arguments[1].getClass().getCanonicalName());
	                }
	                
	                //Check attributeName - Required field
	                if (arguments[2] instanceof LazySequence) {
	                	attributeName = ((LazySequence)arguments[2]).head().getStringValue();
	                } else if (arguments[2] instanceof StringValue) {
	                	attributeName = ((StringValue)arguments[2]).getStringValue();
	                } else {
	                	throw new Exception("Unrecognized argument type for attributeName parameter: " + arguments[2].getClass().getCanonicalName());
	                }

	        		HashMap<String,HashMap<String,String>> map = masterStudio.getMasterDetailsLists(masterName);
	        		String attributeValue = "";
	        		
	        		//Create effectively final variables to use in stream lambdas
	        		String masterValueEF = masterValue;
	        		String attributeNameEF = attributeName;
	        		
	        		if (map!=null && !map.isEmpty()){
	        			
	        			attributeValue = map.entrySet()
			        					.stream()
			        					.map(Map.Entry::getValue)
			        					.filter(n -> n.get("Value").equals(masterValueEF))
			        					.map(l -> l.get(attributeNameEF))
			        					.collect(Collectors.joining());
	        		}
	                
                	return StringValue.makeStringValue(attributeValue);

				} catch (Exception e) {
					throw new XPathException("Unable to retrieve attribute Value", e);
				}
            }
			
        };
    }
}
