package gr.alpha.cbs.fuse.tools;

import jakarta.xml.bind.annotation.adapters.XmlAdapter;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class XMLGregorianCalendarAdapter extends XmlAdapter<String, XMLGregorianCalendar> {
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Override
    public XMLGregorianCalendar unmarshal(String value) throws Exception {
        LocalDate date = LocalDate.parse(value, formatter);
        return DatatypeFactory.newInstance().newXMLGregorianCalendar(date.toString());
    }

    @Override
    public String marshal(XMLGregorianCalendar value) throws Exception {
        if (value == null) {
            return null;
        }
        return value.toGregorianCalendar().toZonedDateTime().toLocalDate().format(formatter);
    }
}
