package gr.alpha.cbs.fuse.strategies;

import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.AggregationStrategy;
import org.apache.camel.Exchange;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

@RegisterForReflection
public abstract class BaseSplitConcatAggregationStrategy implements AggregationStrategy {

    protected boolean copyHeaders = false;
    protected String concatTagName;

    @Override
    public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
        try {
            // guard against unlikely NPE
            if (oldExchange == null) {
                Document targetDocument = (Document) newExchange.getIn().getBody();
                Element docElem = targetDocument.getDocumentElement();

                DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
                Document newDocument = docBuilder.newDocument();
                newDocument.appendChild(newDocument.createElement(concatTagName));
                newDocument.getDocumentElement().appendChild(newDocument.adoptNode(docElem.cloneNode(true)));

                newExchange.getIn().setBody(newDocument);

                return newExchange;
            }

            Document srcDocument = (Document) newExchange.getIn().getBody();
            Document targetDocument = (Document) oldExchange.getIn().getBody();
            targetDocument.getDocumentElement().appendChild(targetDocument.adoptNode(srcDocument.getDocumentElement().cloneNode(true)));

            if (copyHeaders) {
                newExchange.getIn().getHeaders().forEach((k,v)->{
                    if (!oldExchange.getIn().getHeaders().containsKey(k)) {
                        oldExchange.getIn().getHeaders().put(k, v);
                    }
                });
            }

            return oldExchange;
        } catch (ParserConfigurationException pce) {
            throw new RuntimeException("Unable to aggregate.", pce);
        }
    }

    public void setCopyHeaders(boolean copyHeaders) {
        this.copyHeaders = copyHeaders;
    }

    public void setConcatTagName(String concatTagName) {
        this.concatTagName = concatTagName;
    }

}

