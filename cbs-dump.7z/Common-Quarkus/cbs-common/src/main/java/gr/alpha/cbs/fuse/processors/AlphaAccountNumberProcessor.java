package gr.alpha.cbs.fuse.processors;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.common.ifaces.RefDataTranslator;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Named("AlphaAccountNumberProcessor")
@ApplicationScoped
@RegisterForReflection
public class AlphaAccountNumberProcessor implements Processor {
    private static final Logger logger = LoggerFactory.getLogger(AlphaAccountNumberProcessor.class);

    @Inject
    RefDataTranslator translator;

    @Override
    public void process(Exchange exchange) throws Exception {
        String str_codeForCurrency = exchange.getIn().getHeader("LoanCodeForCurrency", String.class);
        String accountNumber = exchange.getIn().getHeader("LoanAccountNumber_forAlphaAccountNumberGeneration", String.class);
        String accountType = exchange.getIn().getHeader("LoanAccountType_forAlphaAccountNumberGeneration", String.class);
        String alphaAccountNumber = null;

        if (logger.isDebugEnabled()) {
            logger.debug("Currency code is: '" + str_codeForCurrency + "'.");
            logger.debug("Account is: '" + accountNumber + "'.");
            logger.debug("Account type is: '" + accountType + "'.");
        }

        if ((accountNumber==null || accountNumber.isEmpty()) || (accountType==null || accountType.isEmpty()) || (str_codeForCurrency==null || str_codeForCurrency.isEmpty()))
        {
            exchange.getIn().setHeader("LoanAlphaAccountNumber",alphaAccountNumber);
        }
        else
        {
            String tmp_codeForCurrency = translator.translateData(CBSConstants.REF_DATA_SYSTEM_SIGLO, "Greek", CBSConstants.REF_NAME_CURRENCIES, str_codeForCurrency);
            String codeForCurrency = translator.reverseTranslateData("Greek", CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_NAME_CURRENCIES, tmp_codeForCurrency);

            String alphaLoan = "";

            if (accountType.startsWith("2"))
            {
                alphaLoan = "989";
            }

            alphaLoan = alphaLoan.concat(codeForCurrency.concat(accountNumber.concat(accountType.substring(1, 2))));

            int digit;
            double sum = 0;

            // Protect the loop below from throwing an IndexOutOfBounds exception, by throwing first something more meaningful.
            if (alphaLoan.length() < 14) {
                ErrorUtils.throwCBSException(null ,
                        ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
                        ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
                        AlphaAccountNumberProcessor.class.getCanonicalName(),
                        "700745",
                        "3",
                        "Δεν μπορεί να ανακτηθεί το LoanAlphaAccountNumber από το " + accountNumber + " και το " + accountType + " (" + str_codeForCurrency + ").", "", "");
            }

            for (int i = 0; i < 14; i++)
            {
                digit = Integer.parseInt((alphaLoan.substring(i,i+1)));
                sum = sum + (Math.pow(2, (14 - i)) * digit);
            }

            int balance = ((int)sum) % 11;
            digit = 11 - balance;

            if (digit == 10 || digit == 11)
            {
                digit = 0;
            }
            alphaAccountNumber = alphaLoan.concat(String.valueOf(digit).substring(0,1));
            exchange.getIn().setHeader("LoanAlphaAccountNumber",alphaAccountNumber);
            if (logger.isDebugEnabled())
                logger.debug("LoanAlphaAccountNumber is: '" + alphaAccountNumber + "'.");
        }

    }
}
