package gr.alpha.cbs.fuse.tools;

public class Holder<V> {

    public V value;

    public Holder(V value) {
        this.value = value;
    }
}
