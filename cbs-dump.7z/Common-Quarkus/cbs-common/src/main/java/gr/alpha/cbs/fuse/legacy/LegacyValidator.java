package gr.alpha.cbs.fuse.legacy;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.enums.*;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import java.util.Arrays;

@Named("legacyValidator")
@ApplicationScoped
@RegisterForReflection
public class LegacyValidator {

    private static final Logger LOGGER = Logger.getLogger(LegacyValidator.class);
    
    public void checkIfEmulatorServiceIsValid(Exchange ex) throws Exception{
    	String serviceName = ex.getProperty("legacyDispatcher.common.Request.ServiceName", String.class);
 	    if (StringUtils.isBlank(serviceName) || !Arrays.stream(EmulatorMonitorSrvs.values()).anyMatch(t -> t.getValue().equals(serviceName))){
 	    	ErrorUtils.throwCBSException(null ,
					String.valueOf(ConstantError_Types._Functional),
					String.valueOf(ConstantError_System_IDs._FUSE),
					this.getClass().getCanonicalName(),
					ConstantErrorMessages._SFALMA_PARAMETRON_I_TIMI_DEN_ANOIKEI_STIS_APODEKTES_TIMES_TIS_LISTAS,
					String.valueOf(ConstantError_Levels._Error),
					"", "", "", "");
 	    }
    }
        
    public void checkServiceNameValidity(Exchange exchange) throws Exception{
    	
    	String serviceName = exchange.getProperty("legacyDispatcher.common.Request.ServiceName", String.class);
    	String value = "";
		
		try{
			value = exchange.getContext().resolvePropertyPlaceholders("{{"+serviceName+"}}");		
		} catch(IllegalArgumentException e) {
			LOGGER.error("Unable to retrieve value for placeholder with name: " + serviceName + e.getMessage());
		}
		
		if(value.isEmpty()) {
			ErrorUtils.throwCBSException(null ,
					String.valueOf(ConstantError_Types._Functional),
					String.valueOf(ConstantError_System_IDs._FUSE),
					this.getClass().getCanonicalName(),
					ConstantErrorMessages._SFALMA_PARAMETRON_I_TIMI_DEN_ANOIKEI_STIS_APODEKTES_TIMES_TIS_LISTAS,
					String.valueOf(ConstantError_Levels._Error),
					"", "", "", serviceName+"|ServiceNames");
		}
    	
    }
    
}
