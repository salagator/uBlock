package gr.alpha.cbs.fuse.masking;

public class MiddleMask implements IMask{
	
	@Override
	public String mask(String value, int length) {
		
		StringBuilder builder = new StringBuilder(value);
        int halfStringLength = value.length() /2 ;

        int i =  halfStringLength - length/2;
       
        for (int j = 0; j < length; j++) {
            builder.setCharAt(i, '*');
            i++;
        }
    		
		return builder.toString();
	}
}
