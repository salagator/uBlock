package gr.alpha.cbs.fuse.tools;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

public class DoubleSerializer extends StdSerializer<Double> {

    public DoubleSerializer() {
        this(null);
    }

    public DoubleSerializer(Class<Double> t) {
        super(t);
    }
    @Override
    public void serialize(Double value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        if (value.isNaN() || value.isInfinite()) {
            gen.writeNumber(0.0d);
            return;
        }
        gen.writeNumber(value);
    }
}
