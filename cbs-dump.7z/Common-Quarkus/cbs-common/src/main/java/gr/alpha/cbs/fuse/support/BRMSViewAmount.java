package gr.alpha.cbs.fuse.support;

import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpHeaderValues;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.eclipse.microprofile.config.ConfigProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Node;

import javax.xml.xpath.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.w3c.dom.NodeList;

import jakarta.ws.rs.core.MediaType;

@Named("brmsViewAmount")
@ApplicationScoped
@RegisterForReflection
public class BRMSViewAmount {
    private static final Logger logger = LoggerFactory.getLogger(BRMSViewAmount.class);

    public static final String BRMSViewAmount_POST_FIX = "/hor-brms-service/services/view-amount-brms";

    private static final String CUSTOMER_NUMBER = "$Customer.Number$";
    private static final String ACCOUNT_NUMBER = "$Account.Number$";
    private static final String INDICATOR = "$Indicator$";
    private static final String REQUEST_ID = "$Request.Id$";
    private static final String SESSION_ID = "$Session.Id$";
    private static final String BUSINESS_CASE_ID = "$Business.Case.Id$";
    private static final String SEQUENCE_ID = "$Sequence.Id$";
    private static final String USER_ID = "$User.Id$";
    private static final String WORKING_DATE = "$Working.Date$";
    private static final String PREVIOUS_WORKING_DATE = "$Previous.Working.Date$";
    private static final String NEXT_WORKING_DATE = "$Next.Working.Date$";
    private static final String VALEUR_DATE = "$Valeur.Date$";
    private static final String MACHINE_DATE = "Machine.Date$";
    private static final String RESOURCE_ID = "$Resource.ID$";
    private static final String RESOURCE_NAME = "$Resource.Name$";
    private static final String UNIT_CODE_LEVEL_1 = "$Unit.Code.Level1$";
    private static final String UNIT_TYPE_CODE_LEVEL_1 = "$Unit.Type.Code.Level1$";
    private static final String UNIT_CODE_LEVEL_2 = "$Unit.Code.Level2$";
    private static final String UNIT_TYPE_CODE_LEVEL_2 = "$Unit.Type.Code.Level2$";
    private static final String UNIT_CODE_LEVEL_3 = "$Unit.Code.Level3$";
    private static final String UNIT_TYPE_CODE_LEVEL_3 = "$Unit.Type.Code.Level3$";
    private static final String CHANNEL_TYPE_CODE = "$Channel.Type.Code$";
    private static final String RESOURCE_TYPE_CODE = "$Resource.Type.Code$";
    private static final String RELEASE_TYPE = "$Release.Type$";
    private static final String USER_ROLE_LIST = "User.Role.List";

    private String requestViewAmountBrms ="<?xml version=\"1.0\" encoding=\"utf-8\"?>"
            +"<model xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">"
            +"<gr.alpha.cbs.brms.model.LogHeader> "
            +"<requestId>" + REQUEST_ID + "</requestId> "
            +"<sequenceId>" + SEQUENCE_ID + "</sequenceId> "
            +"<sessionId>" + SESSION_ID + "</sessionId> "
            +"<businessCaseId>" + BUSINESS_CASE_ID + "</businessCaseId> "
            +"<userId>" + USER_ID + "</userId> "
            +"<cbsUnId /> "
            +"</gr.alpha.cbs.brms.model.LogHeader> "
            +"<gr.alpha.cbs.brms.model.EnvHeader> "
            +"<workingDate>" + WORKING_DATE + "</workingDate> "
            +"<previousWorkingDate>" + PREVIOUS_WORKING_DATE + "</previousWorkingDate> "
            +"<nextWorkingDate>" + NEXT_WORKING_DATE + "</nextWorkingDate> "
            +"<valeurDate>" + VALEUR_DATE + "</valeurDate> "
            +"<machineDate>" + MACHINE_DATE + "</machineDate> "
            +"<resourceID>" + RESOURCE_ID + "</resourceID> "
            +"<resourceName>" + RESOURCE_NAME + "</resourceName> "
            +"<unitCodeLevel1>" + UNIT_CODE_LEVEL_1 + "</unitCodeLevel1> "
            +"<unitTypeCodeLevel1>" + UNIT_TYPE_CODE_LEVEL_1 + "</unitTypeCodeLevel1> "
            +"<unitCodeLevel2>" + UNIT_CODE_LEVEL_2 + "</unitCodeLevel2> "
            +"<unitTypeCodeLevel2>" + UNIT_TYPE_CODE_LEVEL_2 + "</unitTypeCodeLevel2> "
            +"<unitCodeLevel3>" + UNIT_CODE_LEVEL_3 + "</unitCodeLevel3> "
            +"<unitTypeCodeLevel3>" + UNIT_TYPE_CODE_LEVEL_3 + "</unitTypeCodeLevel3> "
            +"<channelTypeCode>" + CHANNEL_TYPE_CODE + "</channelTypeCode> "
            +"<resourceTypeCode>" + RESOURCE_TYPE_CODE + "</resourceTypeCode> "
            +"<releaseType>" + RELEASE_TYPE + "</releaseType> "
            +"<userRoleList>" + USER_ROLE_LIST + "</userRoleList> "
            +"</gr.alpha.cbs.brms.model.EnvHeader> "
            +"<gr.alpha.cbs.brms.model.HideAmountsDecisionRequest> "
            +"<cdi>" + CUSTOMER_NUMBER + "</cdi> "
            +"<accountNumber>" + ACCOUNT_NUMBER + "</accountNumber> "
            +"<indicator>" + INDICATOR + "</indicator> "
            +"</gr.alpha.cbs.brms.model.HideAmountsDecisionRequest> "
            +"</model>";


    public String getURLString() {
        String endpointForHorBRMS = "";
        try {
            endpointForHorBRMS = ConfigProvider.getConfig().getValue("cbs.hor.brms.endpoint", String.class) + BRMSViewAmount_POST_FIX;
            logger.info("Final endpoint for horBRMSUrl: {}.", endpointForHorBRMS);
        } catch (Exception error) {
            logger.error("Unable to get the correct endpoint for the call to the hor brms service.", error);
        }
        return endpointForHorBRMS;
    }


    public void callViewAmountBRMS(Exchange exchange, String propertyName, String accountNumber, String customerNumber, String indicator) throws Exception {
        Node requestNode = exchange.getProperty(propertyName, Node.class);

        XPathFactory xpathfactory = new net.sf.saxon.xpath.XPathFactoryImpl();
        XPath xpath = xpathfactory.newXPath();

        Map<String, String> placeholderValueMap = new HashMap<>();

        placeholderValueMap.put(ACCOUNT_NUMBER, Optional.ofNullable(accountNumber).orElse(""));
        placeholderValueMap.put(CUSTOMER_NUMBER, Optional.ofNullable(customerNumber).orElse(""));
        placeholderValueMap.put(INDICATOR, Optional.ofNullable(indicator).orElse(""));
        placeholderValueMap.put(REQUEST_ID, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:LoggingInfo/*:RequestId/text()")).orElse(""));
        placeholderValueMap.put(SEQUENCE_ID, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:LoggingInfo/*:SequenceId/text()")).orElse(""));
        placeholderValueMap.put(SESSION_ID, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:LoggingInfo/*:SessionId/text()")).orElse(""));
        placeholderValueMap.put(BUSINESS_CASE_ID, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:LoggingInfo/*:BusinessCaseId/text()")).orElse(""));
        placeholderValueMap.put(USER_ID, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:LoggingInfo/*:UserId/text()")).orElse(""));
        placeholderValueMap.put(WORKING_DATE, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:EnvParams/*:WorkingDate/text()")).orElse(""));
        placeholderValueMap.put(PREVIOUS_WORKING_DATE, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:EnvParams/*:PreviousWorkingDate/text()")).orElse(""));
        placeholderValueMap.put(NEXT_WORKING_DATE, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:EnvParams/*:NextWorkingDate/text()")).orElse(""));
        placeholderValueMap.put(VALEUR_DATE, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:EnvParams/*:ValeurDate/text()")).orElse(""));
        placeholderValueMap.put(MACHINE_DATE, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:EnvParams/*:MachineDate/text()")).orElse(""));
        placeholderValueMap.put(RESOURCE_ID, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:EnvParams/*:ResourceID/text()")).orElse(""));
        placeholderValueMap.put(RESOURCE_NAME, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:EnvParams/*:ResourceName/text()")).orElse(""));
        placeholderValueMap.put(UNIT_CODE_LEVEL_1, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:EnvParams/*:UnitCodeLevel1/text()")).orElse(""));
        placeholderValueMap.put(UNIT_TYPE_CODE_LEVEL_1, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:EnvParams/*:UnitTypeCodeLevel1/text()")).orElse(""));
        placeholderValueMap.put(UNIT_CODE_LEVEL_2, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:EnvParams/*:UnitCodeLevel2/text()")).orElse(""));
        placeholderValueMap.put(UNIT_TYPE_CODE_LEVEL_2, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:EnvParams/*:UnitTypeCodeLevel2/text()")).orElse(""));
        placeholderValueMap.put(UNIT_CODE_LEVEL_3, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:EnvParams/*:UnitCodeLevel3/text()")).orElse(""));
        placeholderValueMap.put(UNIT_TYPE_CODE_LEVEL_3, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:EnvParams/*:UnitTypeCodeLevel3/text()")).orElse(""));
        placeholderValueMap.put(CHANNEL_TYPE_CODE, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:EnvParams/*:ChannelTypeCode/text()")).orElse(""));
        placeholderValueMap.put(RESOURCE_TYPE_CODE, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:EnvParams/*:ResourceTypeCode/text()")).orElse(""));
        placeholderValueMap.put(RELEASE_TYPE, Optional.ofNullable(extractXPathValue(xpath, requestNode, "//*:EnvParams/*:ReleaseType/text()")).orElse(""));
        placeholderValueMap.put(USER_ROLE_LIST, Optional.ofNullable(extractXPathListValues(xpath, requestNode, "//*:EnvParams/*:UserRoleList/text()")).orElse(""));

        String actualInput = replaceValues(requestViewAmountBrms, placeholderValueMap);
        logger.info("host brms request body: " + actualInput);

        // Perform call to hor brms service
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .header(HttpHeaderNames.CONTENT_TYPE.toString(), HttpHeaderValues.APPLICATION_XML.toString())
                .POST(HttpRequest.BodyPublishers.ofString(actualInput))
                .uri(new URI(getURLString()))
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() == HttpResponseStatus.OK.code()){
            String xmlResponse = response.body();
            logger.info("hor brms response message: " + xmlResponse);

            String regex = "<result identifier=\"result\">(.*?)</result>";
            Pattern pattern = Pattern.compile(regex, Pattern.DOTALL);
            Matcher matcher = pattern.matcher(xmlResponse);

            if (matcher.find()) {
                String resultContent = matcher.group(1);
                exchange.getIn().setBody("<ViewAmountBRMS_Reply>" + resultContent + "</ViewAmountBRMS_Reply>");
            } else {
                logger.info("Element with identifier 'result' not found.");
            }
        }else{
            logger.info("Service hor brms replied with status: " +String.valueOf(response.statusCode()));
        }
    }

    public String extractXPathValue(XPath xpath, Node requestNode, String xpathToEvaluate) throws XPathExpressionException {
        XPathExpression expression = xpath.compile(xpathToEvaluate);
        return (String) expression.evaluate(requestNode, XPathConstants.STRING);
    }

    public String replaceValues(String request, Map<String, String> placeholderValueMap) {
        String returnValue = request;
        for (Entry<String, String> entry : placeholderValueMap.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            logger.debug("Mapping from {} to {}.", key, value);
            returnValue = returnValue.replace(key, value);
        }
        return returnValue;
    }

    public String extractXPathListValues(XPath xpath, Node requestNode, String xpathToEvaluate) throws XPathExpressionException{
        XPathExpression expression = xpath.compile(xpathToEvaluate);
        NodeList roleList = (NodeList) expression.evaluate(requestNode, XPathConstants.NODESET);
        Node nextsibling = null;
        String nextsiblingContent = null;
        StringBuilder result = new StringBuilder();

        if(roleList != null) {
            for (int j = 0; j < roleList.getLength(); j++) {
                nextsibling = roleList.item(j).getNextSibling();
                if (nextsibling != null){
                    nextsiblingContent = roleList.item(j).getNextSibling().getTextContent();
                    if (result.length() > 0) {
                        result.append(",").append(nextsiblingContent);
                    } else {
                        result.append(nextsiblingContent);
                    }
                }
            }
        }

        return result.toString();
    }

}
