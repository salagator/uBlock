
package gr.alpha.cbs.fuse.legacy;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlSchemaType;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ServeByNameResult" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Reply" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CommitStatus" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "serveByNameResult",
    "reply",
    "commitStatus"
})
@XmlRootElement(name = "ServeByNameResponse", namespace = "http://alpha.gr/odissy/dispatcher")
public class ServeByNameResponse {

    @XmlElement(name = "ServeByNameResult", namespace = "http://alpha.gr/odissy/dispatcher")
    protected String serveByNameResult;
    @XmlElement(name = "Reply", namespace = "http://alpha.gr/odissy/dispatcher")
    protected String reply;
    @XmlElement(name = "CommitStatus", namespace = "http://alpha.gr/odissy/dispatcher")
    @XmlSchemaType(name = "unsignedByte")
    protected short commitStatus;

    /**
     * Gets the value of the serveByNameResult property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServeByNameResult() {
        return serveByNameResult;
    }

    /**
     * Sets the value of the serveByNameResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServeByNameResult(String value) {
        this.serveByNameResult = value;
    }

    /**
     * Gets the value of the reply property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReply() {
        return reply;
    }

    /**
     * Sets the value of the reply property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReply(String value) {
        this.reply = value;
    }

    /**
     * Gets the value of the commitStatus property.
     * 
     */
    public short getCommitStatus() {
        return commitStatus;
    }

    /**
     * Sets the value of the commitStatus property.
     * 
     */
    public void setCommitStatus(short value) {
        this.commitStatus = value;
    }

}
