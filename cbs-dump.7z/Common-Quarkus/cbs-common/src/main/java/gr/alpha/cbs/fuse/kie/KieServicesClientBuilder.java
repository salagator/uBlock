//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

import java.util.Map;

public interface KieServicesClientBuilder {
    String getImplementedCapability();

    Map<Class<?>, Object> build(KieServicesConfiguration configuration, ClassLoader classLoader);
}
