package gr.alpha.cbs.fuse.ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;

import jakarta.inject.Singleton;
import jakarta.transaction.Transactional;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;
import org.jboss.logging.Logger;

@Named("accountingMetaDataEjb")
@Singleton
@RegisterForReflection
public class AccountingMetaDataEjb {
	private static final Logger LOGGER = Logger.getLogger(AccountingMetaDataEjb.class);

	private static final String ACCOUNTING_DICTIONARY_CACHE_NAME = "accountingDictionaryCache";
	private static final String ACCOUNTING_DICTIONARY_CACHE_KEY = "ACCOUNTING_DIC";

	private static final int COL_CODE = 1;
	private static final int COL_FIELD_KIND = 2;
	private static final int COL_FIELD_SIZE = 3;

	private static final String KIND = "Kind";
	private static final String LENGTH = "Length";
	private static final String GET_ACCOUNTING_DICTIONARY_QUERY = "SELECT Code , Field_Kind , Field_Size FROM PRD_AccountingDictionary";

	@Inject
	@io.quarkus.agroal.DataSource("hostps")
	DataSource sqlDS;

	RemoteDatagridClientHelper<String, Object> datagridHelper;

	@Transactional(Transactional.TxType.NOT_SUPPORTED)
	public void loadAccountingMetaData(Exchange exchange) throws SQLException, CBSException {
		LOGGER.debug("loadAccountingMetaData start");
		exchange.setProperty("accountingCodesConfiguration", getAccountingDictionary());
		LOGGER.debug("loadAccountingMetaData end");
	}

	private Map<String, Map<String, String>> getAccountingDictionary() throws SQLException, CBSException {
		Map<String, Map<String, String>> accountingDictionary = getAccountingDictionaryCache();
		if (accountingDictionary == null) {
			LOGGER.debug("No accounting dictionary found in cache");
			accountingDictionary = loadAccountingDictionaryFromDB();
		}
		return accountingDictionary;
	}

	private Map<String, Map<String, String>> loadAccountingDictionaryFromDB() throws SQLException, CBSException {
		Map<String, Map<String, String>> accountingDictionary = null;
		try (Connection conn = sqlDS.getConnection(); PreparedStatement stmt = conn.prepareStatement(GET_ACCOUNTING_DICTIONARY_QUERY);) {
			if (stmt.execute()) {
				try (ResultSet rs = stmt.getResultSet()) {
					accountingDictionary = new HashMap<>();
					while (rs.next()) {
						String keyCode = rs.getString(COL_CODE);
						String keyKind = rs.getString(COL_FIELD_KIND);
						String keyLength = rs.getString(COL_FIELD_SIZE);

						Map<String, String> keyAttributes = new HashMap<>();
						keyAttributes.put(KIND, keyKind);
						keyAttributes.put(LENGTH, keyLength);

						accountingDictionary.put(keyCode, keyAttributes);
					}
					storeAccountingDictionaryInCache(accountingDictionary);
				}
			}
		} catch (Exception e) {
			LOGGER.error("Error while loading configuration for field codes used in accounting : " + e.getCause());
			ErrorUtils.throwCBSException(e,
					ErrorTypeModel.ERROR_TYPE_TECHNICAL,
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					this.getClass().getCanonicalName(),
					ErrorTypeModel.DEFAULT_ERROR_CODE,
					ErrorTypeModel.SEVERITY_ERROR,
					e.getMessage(), "", "", "");
		}
		return accountingDictionary;
	}

	@SuppressWarnings("unchecked")
	private Map<String, Map<String, String>> getAccountingDictionaryCache() {
		Map<String, Map<String, String>> cachedValue = null;
		if (datagridHelper.getCache() != null) {
			Object value = datagridHelper.get(ACCOUNTING_DICTIONARY_CACHE_KEY);
			if (value != null) {
				cachedValue = (Map<String, Map<String, String>>) value;
			}
		}
		return cachedValue;
	}

	private void storeAccountingDictionaryInCache(Map<String, Map<String, String>> accountingDictionary) {
		if (datagridHelper.getCache() != null && accountingDictionary != null) {
			datagridHelper.put(ACCOUNTING_DICTIONARY_CACHE_KEY, accountingDictionary);
		}
	}

	@PostConstruct
	void postConstruct() {
		datagridHelper = new RemoteDatagridClientHelper<>();
		datagridHelper.initCacheManager();
		datagridHelper.setCache(ACCOUNTING_DICTIONARY_CACHE_NAME);
		LOGGER.debug("postConstruct called");
	}

	@PreDestroy
	void preDestroy() {
		datagridHelper.stopCacheManager();
	}

}
