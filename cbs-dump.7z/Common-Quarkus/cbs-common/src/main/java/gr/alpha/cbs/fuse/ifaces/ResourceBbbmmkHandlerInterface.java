package gr.alpha.cbs.fuse.ifaces;

public interface ResourceBbbmmkHandlerInterface {
	
	String readBbbmmk(String resource) throws Exception;

}
