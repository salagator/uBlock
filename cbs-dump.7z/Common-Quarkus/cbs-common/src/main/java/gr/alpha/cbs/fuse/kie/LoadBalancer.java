//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoadBalancer {
    public static final Long FAILED_ENDPOINT_INTERVAL_CHECK = Long.getLong("org.kie.server.client.loadbalancer.failedEndpointIntervalCheck", 5000L);
    private static final Logger logger = LoggerFactory.getLogger(LoadBalancer.class);
    private static final String URL_SEP = "\\|";
    private ScheduledExecutorService executorService = Executors.newScheduledThreadPool(4);
    private final BalancerStrategy balancerStrategy;
    private CopyOnWriteArraySet<String> failedEndpoints = new CopyOnWriteArraySet();
    private final List<EndpointListener> endpointListeners = new ArrayList();
    private String userName;
    private String password;
    private volatile boolean backgroundCheck = false;
    private boolean checkFailedEndpoint = true;

    public void addListener(EndpointListener listener) {
        synchronized(this.endpointListeners) {
            this.endpointListeners.add(listener);
        }
    }

    public LoadBalancer(BalancerStrategy balancerStrategy) {
        this.balancerStrategy = balancerStrategy;
    }

    public String getUrl() throws KieServerHttpRequestException {
        try {
            String selectedUrl = this.balancerStrategy.next();
            logger.debug("Load balancer {} selected url '{}'", this.balancerStrategy, selectedUrl);
            return selectedUrl;
        } catch (NoEndpointFoundException e) {
            this.checkFailedEndpoints();
            throw e;
        }
    }

    public String markAsFailed(String url) {
        String baseUrl = this.balancerStrategy.markAsOffline(url);
        this.failedEndpoints.add(baseUrl);
        logger.debug("Url '{}' is marked as failed and will be considered offline by {}", url, this.balancerStrategy);
        List<EndpointListener> threadSafeListeners = new ArrayList();
        synchronized(this.endpointListeners) {
            threadSafeListeners.addAll(this.endpointListeners);
        }

        threadSafeListeners.forEach((e) -> e.markAsFailed(baseUrl));
        return baseUrl;
    }

    public void activate(String url) {
        String baseUrl = this.balancerStrategy.markAsOnline(url);
        this.failedEndpoints.remove(baseUrl);
        logger.debug("Url '{}' is marked as activated and will be considered online by {}", url, this.balancerStrategy);
        List<EndpointListener> threadSafeListeners = new ArrayList();
        synchronized(this.endpointListeners) {
            threadSafeListeners.addAll(this.endpointListeners);
        }

        threadSafeListeners.forEach((e) -> e.markAsActive(baseUrl));
    }

    public void close() {
        try {
            this.executorService.shutdownNow();
        } catch (Exception var2) {
            logger.debug("Error when shutting down load balancer executor service");
        }

    }

    public List<String> getAvailableEndpoints() {
        return this.balancerStrategy.getAvailableEndpoints();
    }

    public List<String> getFailedEndpoints() {
        return new ArrayList(this.failedEndpoints);
    }

    public synchronized Future<?> checkFailedEndpoints() {
        if (!this.checkFailedEndpoint) {
            return null;
        } else {
            final CountDownLatch latch = new CountDownLatch(1);
            EndpointListener lst = new EndpointListener() {
                public void markAsActive(String endpoint) {
                    synchronized(LoadBalancer.this.endpointListeners) {
                        LoadBalancer.this.endpointListeners.remove(this);
                    }

                    latch.countDown();
                }
            };
            this.endpointListeners.add(lst);
            Future<Object> futureBridge = new Future<Object>() {
                public boolean cancel(boolean mayInterruptIfRunning) {
                    return false;
                }

                public boolean isCancelled() {
                    return false;
                }

                public boolean isDone() {
                    return latch.getCount() == 0L;
                }

                public Object get() throws InterruptedException, ExecutionException {
                    latch.await();
                    return null;
                }

                public Object get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
                    if (!latch.await(timeout, unit)) {
                        LoadBalancer.logger.debug("Load balancer await for termination expired");
                    }

                    return null;
                }
            };
            if (this.backgroundCheck) {
                return futureBridge;
            } else {
                this.executorService.scheduleWithFixedDelay(new CheckFailedEndpoints(), 0L, FAILED_ENDPOINT_INTERVAL_CHECK, TimeUnit.MILLISECONDS);
                this.backgroundCheck = true;
                return futureBridge;
            }
        }
    }

    public static LoadBalancer getDefault(String urls) {
        String[] endpoints = new String[0];
        if (urls != null) {
            endpoints = urls.split("\\|");
        }

        return getDefault(Arrays.asList(endpoints));
    }

    public static LoadBalancer getDefault(List<String> urls) {
        RoundRobinBalancerStrategy strategy = new RoundRobinBalancerStrategy(urls);
        return new LoadBalancer(strategy);
    }

    public static LoadBalancer forStrategy(String urls, BalancerStrategy.Type type) {
        String[] endpoints = urls.split("\\|");
        return forStrategy(Arrays.asList(endpoints), type);
    }

    public static LoadBalancer forStrategy(List<String> urls, BalancerStrategy.Type type) {
        BalancerStrategy strategy = null;
        switch (type) {
            case RANDOM_STRATEGY:
                strategy = new RandomBalancerStrategy(urls);
                break;
            case ROUND_ROBIN_STRATEGY:
                strategy = new RoundRobinBalancerStrategy(urls);
        }

        if (strategy == null) {
            throw new IllegalArgumentException("Unknown strategy type " + type);
        } else {
            return new LoadBalancer(strategy);
        }
    }

    public void setCheckFailedEndpoint(boolean checkFailedEndpoint) {
        this.checkFailedEndpoint = checkFailedEndpoint;
    }

    public boolean isCheckFailedEndpoint() {
        return this.checkFailedEndpoint;
    }

    public interface EndpointListener {
        default void markAsActive(String endpoint) {
        }

        default void markAsFailed(String endpoint) {
        }
    }

    private class CheckFailedEndpoints implements Runnable {
        private CheckFailedEndpoints() {
        }

        public void run() {
            if (LoadBalancer.this.failedEndpoints != null && !LoadBalancer.this.failedEndpoints.isEmpty()) {
                List<String> endpoints = new ArrayList(LoadBalancer.this.failedEndpoints);
                LoadBalancer.logger.debug("Starting to scan if any of the failed endpoints is back online. Endpoints about to check: {}", endpoints);

                for(String failedEndpoint : endpoints) {
                    try {
                        KieServerHttpRequest httpRequest = KieServerHttpRequest.newRequest(failedEndpoint, LoadBalancer.this.userName, LoadBalancer.this.password).followRedirects(true).timeout(1000L);
                        httpRequest.get();
                        LoadBalancer.logger.debug("Url '{}' is back online, adding it to load balancer", failedEndpoint);
                        LoadBalancer.this.activate(failedEndpoint);
                    } catch (Exception e) {
                        LoadBalancer.logger.debug("Url '{}' is still offline due to {}", failedEndpoint, e.getCause() == null ? e.getMessage() : e.getCause().getMessage());
                    }
                }

                LoadBalancer.logger.debug("Ending scan if any of the failed endpoints is back online");
            }
        }
    }
}
