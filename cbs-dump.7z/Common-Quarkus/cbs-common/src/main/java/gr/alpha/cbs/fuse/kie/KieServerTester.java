package gr.alpha.cbs.fuse.kie;

import java.util.List;
import java.util.Map;

import static java.util.Map.entry;

public class KieServerTester {
    public static void main(String[] args) {
        try {
            KieServicesConfiguration conf = getKieServicesConfiguration();
            KieServicesClientImpl kieServicesClient = new KieServicesClientImpl(conf);
            ProcessServicesClientImpl processClient = new ProcessServicesClientImpl(conf);
            processClient.setOwner(kieServicesClient);
            Map<String, Object> variables = Map.ofEntries(
                    entry("logBUN", ""),
                    entry("envUnitCodeLevel3", "sr0950"),
                    entry("envUnitCodeLevel2", "0950"),
                    entry("transactionPayloadSummary", "ΞΞ΅ΟΞ±Ξ²ΞΉΞ²Ξ¬ΟΞ΅ΞΉΟ Ξ Ξ±ΟΞ±Ξ»Ξ±Ξ²Ξ� Ξ¬Ξ½Ξ΅Ο Ξ Ξ»Ξ·Ο. 250.000,00 USD 216.001,38 "),
                    entry("notifyMakerForCheckerDetailView", true),
                    entry("makerComments", "aksjdfh"),
                    entry("makerFullName", "ΞΞΉΞΏΟΞ½ΟΟΞΉΞΏΟ Ξ£Ξ²Ξ±Ξ½Ξ¬Ο Ξ§ΟΟΞ―Ο Ξ₯ΟΞΏΞ³ΟΞ±ΟΞ�"),
                    entry("logRequestId", "4614ab6e-850c-4cbc-8456-840f1906196b"),
                    entry("transactionPayloadDetails", "{\"transactionData\":[{\"name\":\"ΞΞ΅ΟΞ―Ξ΄Ξ±:\",\"value\":\"95000001907071\",\"status\":\"CRITICAL\"},{\"name\":\"ISIN\",\"value\":\"XS0000003219\",\"status\":\"CRITICAL\"},{\"name\":\"ΞΞ½ΞΏΞΌΞ±ΟΞ―Ξ± Ξ€Ξ―ΟΞ»ΞΏΟ\",\"value\":\"UΞΞ€ FΞRΞLΞGΞΞΞ 1\",\"status\":\"CRITICAL\"},{\"name\":\"ΞΟΞΌΞΉΟΞΌΞ± Ξ€Ξ―ΟΞ»ΞΏΟ\",\"value\":\"USD\",\"status\":\"CRITICAL\"},{\"name\":\"ΞΞ½ΞΏΞΌΞ±ΟΟΞΉΞΊΞ� ΞΞΎΞ―Ξ±:\",\"value\":\"250.000,00\",\"status\":\"CRITICAL\"},{\"name\":\"ΞΟΞΏΞ΄ΟΞ½Ξ±ΞΌΞΏ Ξ ΞΏΟΟ ΟΞ΅ ΞΟΟΟ, \",\"value\":\"216.001,38\",\"status\":\"CRITICAL\"}]}"),
                    entry("envWorkingDate", "17/06/2025"),
                    entry("envChannelTypeCode", "01"),
                    entry("logUserId", "BANKTEST\\q30015"),
                    entry("checkerComments", ""),
                    entry("envUnitCode1", "014"),
                    entry("envUnitTypeCodeLevel3", "06"),
                    entry("envPreviousWorkingDate", "16/06/2025"),
                    entry("envUnitTypeCodeLevel2", "02"),
                    entry("envResourceTypeCode", "01"),
                    entry("maker", "BANKTEST\\q30015"),
                    entry("envUnitTypeCode1", "01"),
                    entry("checkerGroup", "[{BANKTEST\\Q30013|FIN - Ξ Ξ₯ΟΞΏΞ³ΟΞ±ΟΞ�|3|Ξ£Ξ²Ξ±Ξ½Ξ¬Ο Ξ  Ξ₯ΟΞΏΞ³ΟΞ±ΟΞ� ΞΞΉΞΏΞ½ΟΟΞΉΞΏΟ}]"),
                    entry("notifyMakerForCheckerNotification", true),
                    entry("timerToViewDetails", 999),
                    entry("envValeurDate", "17/06/2025"),
                    entry("logBusinessCaseId", "75b72442-fcb1-4b11-ad98-760eb545bed6"),
                    entry("intResult", 0),
                    entry("logSequenceId", 7),
                    entry("timerToNextChecker", 20),
                    entry("executionTimer", 500),
                    entry("envMachineDate", "17/06/2025"),
                    entry("logSessionId", "e8fc008e-0e09-4e"),
                    entry("detailsMandatory", false),
                    entry("envResourceID", "492"),
                    entry("envNextWorkingDate", "18/06/2025")
            );
            processClient.startProcess("NewApprovalProcessContainer", "gr.alpha.cbs.bpm.approval", variables);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static KieServicesConfiguration getKieServicesConfiguration() {
        KieServicesConfiguration conf = new KieServicesConfigurationImpl(
                "http://cbskie-ext-bamoe-approvals.apps.ocpuat1.caas.centraltest.roottest.alphatest.ab/services/rest/server",
//                "https://qdev-hor-approval.apps.ocp01.caas.centraltest.roottest.alphatest.ab/services/rest/server",
                "username",
                "password"
        );
        conf.setMarshallingFormat(MarshallingFormat.JSON);
        conf.setCapabilities(List.of("BPM"));
        return conf;
    }
}
