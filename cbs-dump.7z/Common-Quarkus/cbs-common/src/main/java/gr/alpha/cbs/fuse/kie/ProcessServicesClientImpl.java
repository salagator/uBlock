//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ProcessServicesClientImpl extends AbstractKieServicesClientImpl implements ProcessServicesClient {
    public ProcessServicesClientImpl(KieServicesConfiguration config) {
        super(config);
    }

    public ProcessServicesClientImpl(KieServicesConfiguration config, ClassLoader classLoader) {
        super(config, classLoader);
    }

    public Long startProcess(String containerId, String processId) {
        return this.startProcess(containerId, processId, new HashMap());
    }

    public Long startProcess(String containerId, String processId, Map<String, Object> variables) {
        Object result = null;
        Map<String, Object> valuesMap = new HashMap();
        valuesMap.put("containerId", containerId);
        valuesMap.put("processId", processId);
        result = this.makeHttpPostRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "containers/{containerId}/processes/{processId}/instances", valuesMap), variables, Object.class);

        return result instanceof Wrapped ? (Long)((Wrapped)result).unwrap() : ((Number)result).longValue();
    }

    public Object getProcessInstanceVariable(String containerId, Long processInstanceId, String variableName) {
        return this.getProcessInstanceVariable(containerId, processInstanceId, variableName, Object.class);
    }

    public <T> T getProcessInstanceVariable(String containerId, Long processInstanceId, String variableName, Class<T> type) {
        Object result = null;
        Map<String, Object> valuesMap = new HashMap();
        valuesMap.put("containerId", containerId);
        valuesMap.put("processInstanceId", processInstanceId);
        valuesMap.put("varName", variableName);
        result = this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "containers/{containerId}/processes/instances/{processInstanceId}/variable/{varName}", valuesMap), type);

        return (T)(result instanceof Wrapped ? ((Wrapped)result).unwrap() : result);
    }

    public Map<String, Object> getProcessInstanceVariables(String containerId, Long processInstanceId) {
        Object variables = null;
        Map<String, Object> valuesMap = new HashMap();
        valuesMap.put("containerId", containerId);
        valuesMap.put("processInstanceId", processInstanceId);
        variables = this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "containers/{containerId}/processes/instances/{processInstanceId}/variables", valuesMap), Object.class);

        return variables instanceof Wrapped ? (Map)((Wrapped)variables).unwrap() : (Map)variables;
    }

    public void signalProcessInstance(String containerId, Long processInstanceId, String signalName, Object event) {
        Map<String, Object> valuesMap = new HashMap();
        valuesMap.put("containerId", containerId);
        valuesMap.put("processInstanceId", processInstanceId);
        valuesMap.put("signalName", signalName);
        Map<String, String> headers = new HashMap();
        this.makeHttpPostRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "containers/{containerId}/processes/instances/{processInstanceId}/signal/{signalName}", valuesMap), event, String.class, headers);
    }

    public void signalProcessInstances(String containerId, List<Long> processInstanceIds, String signalName, Object event) {
        Map<String, Object> valuesMap = new HashMap();
        valuesMap.put("containerId", containerId);
        valuesMap.put("signalName", signalName);
        String queryStr = this.buildQueryString("instanceId", processInstanceIds);
        Map<String, String> headers = new HashMap();
        this.makeHttpPostRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "containers/{containerId}/processes/instances/signal/{signalName}", valuesMap) + queryStr, event, String.class, headers);
    }

    public void setProcessVariable(String containerId, Long processInstanceId, String variableId, Object value) {
        Map<String, Object> valuesMap = new HashMap();
        valuesMap.put("containerId", containerId);
        valuesMap.put("processInstanceId", processInstanceId);
        valuesMap.put("varName", variableId);
        this.makeHttpPutRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "containers/{containerId}/processes/instances/{processInstanceId}/variable/{varName}", valuesMap), value, String.class, this.getHeaders((Object)null));
    }

    public void setProcessVariables(String containerId, Long processInstanceId, Map<String, Object> variables) {
        Map<String, Object> valuesMap = new HashMap();
        valuesMap.put("containerId", containerId);
        valuesMap.put("processInstanceId", processInstanceId);
        this.makeHttpPostRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "containers/{containerId}/processes/instances/{processInstanceId}/variables", valuesMap), variables, String.class);
    }

}
