package gr.alpha.cbs.fuse.helpers;

import gr.alpha.cbs.fuse.enums.ConstantTransactionLanguages;
import gr.alpha.cbs.fuse.tools.ConvertMoneyToString;
import gr.alpha.cbs.fuse.tools.ConvertMoneyToStringELGSFormat;
import gr.alpha.cbs.fuse.tools.ConvertMoneyToStringEnglish;

import java.math.BigDecimal;

public class MoneyToStringHelper {
    public static String GetVerbalWithFraction(Double money, String lang) {
        if(ConstantTransactionLanguages._AGGLIKA.equals(lang)){
            return ConvertMoneyToStringEnglish.getVerbalFinancial(money, 2, "EUR");
        }
        return ConvertMoneyToString.GetVerbalWithFraction(money, 2, "EUR");
    }


    public static String GetVerbalWithFraction(Double money, Integer decimals, String currency, String lang) {
        if(ConstantTransactionLanguages._AGGLIKA.equals(lang)){
            return ConvertMoneyToStringEnglish.getVerbalFinancial(money, decimals, currency);
        }
        return ConvertMoneyToString.GetVerbal(money, true, false, true, decimals, currency);
    }


    public static String GetVerbalWithFractionELGSFormat(BigDecimal money, int currencyCode, int numCurrencyDecimals, String languageCode){
        if(ConstantTransactionLanguages._AGGLIKA.equals(languageCode)){
            return ConvertMoneyToStringELGSFormat.getVerbalInEnglish(money, currencyCode, numCurrencyDecimals);
        }
        return ConvertMoneyToStringELGSFormat.getVerbalInGreek(money,currencyCode,numCurrencyDecimals);
    }


}
