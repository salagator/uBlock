package gr.alpha.cbs.fuse.outgoing.helpers;

import java.io.File;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Map;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;

import io.quarkus.rest.client.reactive.QuarkusRestClientBuilder;
import org.apache.hc.client5.http.auth.AuthSchemeFactory;
import org.apache.hc.client5.http.auth.StandardAuthScheme;
import org.apache.hc.client5.http.impl.auth.BasicSchemeFactory;
import org.apache.hc.client5.http.impl.auth.DigestSchemeFactory;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.io.HttpClientConnectionManager;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactoryBuilder;
import org.apache.hc.core5.http.config.Lookup;
import org.apache.hc.core5.http.config.RegistryBuilder;
import org.apache.hc.core5.ssl.PrivateKeyDetails;
import org.apache.hc.core5.ssl.PrivateKeyStrategy;
import org.apache.hc.core5.ssl.SSLContexts;
import org.apache.hc.core5.ssl.TrustStrategy;
import org.eclipse.microprofile.config.ConfigProvider;

public class SSLContextHolder {
    private static SSLContext sslContext;

    private static synchronized SSLContext getSSLContext(String systemDesignator) throws UnrecoverableKeyException,
            CertificateException, NoSuchAlgorithmException, KeyStoreException,
            IOException, KeyManagementException {

        if (sslContext == null) {
			String keyStoreFilePath = ConfigProvider.getConfig().getValue("clientKeyStore", String.class);
			String keyStorePassword = ConfigProvider.getConfig().getValue("clientKeyStorePassword", String.class);
			String keyAlias = ConfigProvider.getConfig().getValue("clientKeyStore_" + systemDesignator + "_keyAlias", String.class);
			String keyPassword = ConfigProvider.getConfig().getValue("clientKeyStore_" + systemDesignator + "_keyPassword", String.class);
			if("DefaultKeyPass".equals(keyPassword)){
				// used when no password/certificate pair provided ex. paralos
				sslContext = SSLContexts.custom().loadTrustMaterial(
						new File(keyStoreFilePath),
						keyStorePassword.toCharArray()
					  ).build();
			} else {
				sslContext = SSLContexts.custom().loadKeyMaterial(
						new File(keyStoreFilePath),
						keyStorePassword.toCharArray(),
						keyPassword.toCharArray(),
						new PrivateKeyStrategy() {
							@Override
							public String chooseAlias(Map<String, PrivateKeyDetails> aliases, SSLParameters sslParameters) {
								return keyAlias;
							}
						}).
						loadTrustMaterial(new TrustStrategy() {
							@Override
							public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
								return true;
							}
						}).build();
			}
        }

        return sslContext;
    }

	public static QuarkusRestClientBuilder getQuarkusRestClientBuilder(String systemDesignator)
			throws UnrecoverableKeyException, CertificateException, NoSuchAlgorithmException, KeyStoreException,
			IOException, KeyManagementException {
		return QuarkusRestClientBuilder.newBuilder().
				sslContext(getSSLContext(systemDesignator));
	}

	public static HttpClientBuilder getClientBuilder(String systemDesignator) throws UnrecoverableKeyException,
			CertificateException, NoSuchAlgorithmException, KeyStoreException,
			IOException, KeyManagementException {
		Lookup<AuthSchemeFactory> authSchemeProviderRegistry =
				RegistryBuilder.<AuthSchemeFactory>create()
						.register(StandardAuthScheme.BASIC, new BasicSchemeFactory())
						.register(StandardAuthScheme.DIGEST, new DigestSchemeFactory())
						.build();
		final SSLConnectionSocketFactory sslSocketFactory = SSLConnectionSocketFactoryBuilder.create()
				.setSslContext(getSSLContext(systemDesignator))
				.build();
		final HttpClientConnectionManager cm = PoolingHttpClientConnectionManagerBuilder.create()
				.setSSLSocketFactory(sslSocketFactory)
				.build();
		return HttpClients.custom().
				setDefaultAuthSchemeRegistry(authSchemeProviderRegistry).
				setConnectionManager(cm);
	}


}
