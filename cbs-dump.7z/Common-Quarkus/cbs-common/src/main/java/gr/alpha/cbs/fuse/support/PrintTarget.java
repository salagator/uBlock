package gr.alpha.cbs.fuse.support;


public enum PrintTarget {
    Laser(1),
    Passbook(2),
    Email(3);

    private int dbValue;

    private PrintTarget(int dbValue) {
        this.dbValue = dbValue;
    }

    public int getDbValue() {
        return dbValue;
    }

    public static PrintTarget getForDbValue(int dbValue) {
        for (PrintTarget printTarget : values()) {
            if (printTarget.getDbValue() == dbValue) {
                return printTarget;
            }
        }
        return null;
    }
}