package gr.alpha.cbs.fuse.kafka;

import org.apache.camel.util.ObjectHelper;
import org.apache.camel.util.StringHelper;

public class KafkaConfigConsumer {
	private Boolean enabled;
	private String groupId;
	private Boolean persistMessage;
	private Boolean transactedPersistMessage;
	private String messageIdPath;
	private String messageIdPathType;
	private String routeForValidation;
	private String routeToExecute;

	private KafkaConfigConsumer(Boolean enabled, String groupId, Boolean persistMessage, Boolean transactedPersistMessage, String messageIdPath, String messageIdPathType, String routeForValidation, String routeToExecute) {
		this.enabled = enabled;
		this.groupId = groupId;
		this.persistMessage = persistMessage;
		this.transactedPersistMessage = transactedPersistMessage;
		this.messageIdPath = messageIdPath;
		this.messageIdPathType = messageIdPathType;
		this.routeForValidation = routeForValidation;
		this.routeToExecute = routeToExecute;
	}

	public Boolean isEnabled() {
		return this.enabled;
	}

	public String getGroupId() {
		return this.groupId;
	}

	public Boolean isPeristMessage() {
		return this.persistMessage;
	}

	public Boolean isTransactedPersistMessage() {
		return this.transactedPersistMessage;
	}

	public String getMessageIdPath() {
		return this.messageIdPath;
	}

	public String getMessageIdPathType() {
		return this.messageIdPathType;
	}

	public String getRouteForValidation() {
		return this.routeForValidation;
	}

	public String getRouteToExecute() {
		return this.routeToExecute;
	}

	public static class Builder {
		private Boolean enabled;
		private String groupId;
		private Boolean persistMessage;
		private Boolean transactedPersistMessage;
		private String messageIdPath;
		private String messageIdPathType;
		private String routeForValidation;
		private String routeToExecute;

		public Builder enabled(Boolean enabled) {
			this.enabled = enabled;
			return this;
		}

		public Builder groupId(String groupId) {
			this.groupId = groupId;
			return this;
		}

		public Builder persistMessage(Boolean persistMessage) {
			this.persistMessage = persistMessage;
			return this;
		}

		public Builder transactedPersistMessage(Boolean transactedPersistMessage) {
			this.transactedPersistMessage = transactedPersistMessage;
			return this;
		}

		public Builder messageIdPath(String messageIdPath) {
			this.messageIdPath = messageIdPath;
			return this;
		}

		public Builder messageIdPathType(String messageIdPathType) {
			this.messageIdPathType = messageIdPathType;
			return this;
		}

		public Builder routeForValidation(String routeForValidation) {
			this.routeForValidation = routeForValidation;
			return this;
		}

		public Builder routeToExecute(String routeToExecute) {
			this.routeToExecute = routeToExecute;
			return this;
		}

		public KafkaConfigConsumer build() {
			ObjectHelper.notNull(this.enabled, "enabled");
			if (this.enabled) {
				StringHelper.notEmpty(this.groupId, "groupId");

				if (this.persistMessage) {
					StringHelper.notEmpty(this.messageIdPath, "messageIdPath");
					StringHelper.notEmpty(this.messageIdPathType, "messageIdPathType");
					if (!ObjectHelper.isEqualToAny(this.messageIdPathType, "xpath", "json")) {
						throw new IllegalArgumentException("messageIdPathType must not be 'xpath' or 'json'");
					}
				}

				StringHelper.notEmpty(this.routeToExecute, "routeToExecute");
			}
			return new KafkaConfigConsumer(this.enabled, this.groupId, this.persistMessage, this.transactedPersistMessage, this.messageIdPath, this.messageIdPathType, this.routeForValidation, this.routeToExecute);
		}
	}
}
