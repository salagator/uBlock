package gr.alpha.cbs.fuse.tools;

import org.jboss.logging.Logger;

import java.math.BigDecimal;

public class ConvertMoneyToStringELGSFormat {
    private static final Logger LOGGER = Logger.getLogger(ConvertMoneyToStringELGSFormat.class);

    private static String[] ones = { "", "ENA", "ΔΥΟ", "ΤΡΙΑ", "ΤΕΣΣΕΡΑ", "ΠΕΝΤΕ", "ΕΞΙ", "ΕΠΤΑ", "ΟΚΤΩ", "ΕΝΝΕΑ",
            "ΔΕΚΑ", "ΕΝΤΕΚΑ", "ΔΩΔΕΚΑ", "ΔΕΚΑ", "ΔΕΚΑ", "ΔΕΚΑΠΕΝΤΕ", "ΔΕΚΑΕΞΙ", "ΔΕΚΑΕΠΤΑ", "ΔΕΚΑΟΚΤΩ",
            "ΔΕΚΑΕΝΝΕΑ" };
    private static String[] onesD = { "ΜΗΔΕΝ", "ΜΙΑ", "", "ΤΡΕΙΣ", "ΤΕΣΣΕΡΙΣ" };
    private static String[] tens = { "", "", "ΕΙΚΟΣΙ", "ΤΡΙΑΝΤΑ", "ΣΑΡΑΝΤΑ", "ΠΕΝΗΝΤΑ", "ΕΞΗΝΤΑ", "ΕΒΔΟΜΗΝΤΑ",
            "ΟΓΔΟΝΤΑ", "ΕΝΕΝΗΝΤΑ" };
    private static String[] hundreds = { "", "ΕΚΑΤΟ", "ΔΙΑΚΟΣΙ", "ΤΡΙΑΚΟΣΙ", "ΤΕΤΡΑΚΟΣΙ", "ΠΕΝΤΑΚΟΣΙ", "ΕΞΑΚΟΣΙ","ΕΠΤΑΚΟΣΙ", "ΟΚΤΑΚΟΣΙ", "ΕΝΝΙΑΚΟΣΙ" };
    private static String[] scales = { "", "ΧΙΛΙΑ", "ΕΚΑΤΟΜΜΥΡΙ", "ΔΙΣΕΚΑΤΟΜΜΥΡΙ" };

    private static String[] onesEnglish = { "ZERO", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE",
            "TEN", "ELEVEN", "TWELVE", "THIRTEEN", "FOURTEEN", "FIFTEEN", "SIXTEEN", "SEVENTEEN", "EIGHTEEN",
            "NINETEEN" };
    private static String[] tensEnglish = { "", "", "TWENTY", "THIRTY", "FORTY", "FIFTY", "SIXTY", "SEVENTY",
            "EIGHTY", "NINETY" };


    public static String getVerbalInGreek(BigDecimal money, int currencyCode,int currencyDecimals) {

        String stringMoney = money.toString();
        String finalString = "";
        int numberOfCurrencyDecimals = currencyDecimals;

        switch (currencyCode) {
            case 0:
                finalString = "ΕΥΡΩ";
                break;
            case 1:
                finalString = "ΔΟΛΛΑΡΙΟ ΗΠΑ";
                break;
            case 2:
                finalString = "ΛΙΡΕΣ ΑΓΓΛΙΑΣ";
                break;
            default:
                LOGGER.debug("Error:Unknown Currency Code " + currencyCode);
                break;
        }

        if(money.doubleValue() % 1 == 0){
            finalString += " " + moneyInGreek(money.longValue(),currencyCode,0);
        }else{
            String[] parts = stringMoney.split("\\.");
            String cents = String.valueOf(parts[1]);
            int scale = money.scale();
            if(scale<numberOfCurrencyDecimals){
                while(scale!=numberOfCurrencyDecimals){
                    cents +="0";
                    scale++;
                }
            }else{
                cents = String.valueOf(parts[1]).substring(0,numberOfCurrencyDecimals);
            }


            finalString += " " + moneyInGreek(Long.parseLong(parts[0]),currencyCode,0) +((Integer.parseInt(cents)!=0)? " ΚΑΙ " + centsInGreek(cents):"");
        }



        return finalString;
    }

    public static String centsInGreek(String centsString) {

        String greek = "";
        String verbalCents = " ΛΕΠΤΑ";
        int cents = Integer.parseInt(centsString);
        if(cents < 10){
            if(cents == 1){
                greek = ones[cents] + " ΛΕΠΤΟ";
            }else{
                greek =  ones[cents] + verbalCents;
            }

        }else if (cents < 20) {
            if(cents==13 || cents==14){
                greek =  ones[cents] + ones[cents%10] + verbalCents;
            }else{
                greek =  ones[cents] + verbalCents;
            }

        }else if (cents < 100) {
            greek = tens[cents / 10] + ((cents % 10 != 0) ? " " : "") + ones[cents % 10] + verbalCents;
        }else if (cents < 1000) {
            if(cents>100 && cents <200){
                greek = hundreds[(int)cents / 100]+ "N"+ ((cents % 100 != 0) ? " " : "") + tens[(int)cents % 100 / 10] + ((cents % 10 != 0) ? " " : "") + ones[(int)cents % 10] + verbalCents ;
            }else if(cents==100){
                greek = hundreds[(int)cents / 100] + ((cents % 100 != 0) ? " " : "") + tens[(int)cents % 100 / 10] + ((cents % 10 != 0) ? " " : "") + ones[(int)cents % 10] + verbalCents ;
            }else{
                greek = hundreds[(int)cents / 100]+ "Α"+ ((cents % 100 != 0) ? " " : "") + tens[(int)cents % 100 / 10] + ((cents % 10 != 0) ? " " : "") + ones[(int)cents % 10] + verbalCents ;
            }

        }

        return greek;


    }

    public static String moneyInGreek(long number,int currencyCode,int scaleForVerbal) {


        if (number == 0) {
            return onesD[(int)number];
        }
        if (number < 20) {
            if(currencyCode == 2){
                if((scaleForVerbal==1 || scaleForVerbal==0)  && (number==3 || number==4 || number == 1)){
                    return onesD[(int)number];
                }else if((scaleForVerbal==1 || scaleForVerbal==0) && (number==13 || number==14)){
                    return ones[(int)number]+ onesD[(int)number%10];
                }else{
                    return ones[(int)number];
                }
            }else{
                if(scaleForVerbal==1 && (number==3 || number==4)){
                    return onesD[(int)number];
                }else if(scaleForVerbal==1 && (number==13 || number==14)){
                    return ones[(int)number]+ onesD[(int)number%10];
                }else{
                    return ones[(int)number];
                }
            }


        }
        if (number < 100) {
            if(currencyCode == 2){
                if((scaleForVerbal==1 || scaleForVerbal==0) && (number%10==3 || number%10==4 || number%10 == 1)){
                    return tens[(int)number / 10] + ((number % 10 != 0) ? " " : "") + onesD[(int)number % 10];
                }else if(scaleForVerbal!=1 && (number%10==3 || number%10==4)){
                    return tens[(int)number / 10] + ((number % 10 != 0) ? " " : "") + ones[(int)number % 10];
                }else{
                    return tens[(int)number / 10] + ((number % 10 != 0) ? " " : "") + ones[(int)number % 10];
                }
            }else{
                if(scaleForVerbal==1 && (number%10==3 || number%10==4)){
                    return tens[(int)number / 10] + ((number % 10 != 0) ? " " : "") + onesD[(int)number % 10];
                }else if(scaleForVerbal!=1 && (number%10==3 || number%10==4)){
                    return tens[(int)number / 10] + ((number % 10 != 0) ? " " : "") + ones[(int)number % 10];
                }else{
                    return tens[(int)number / 10] + ((number % 10 != 0) ? " " : "") + ones[(int)number % 10];
                }
            }


        }
        if (number < 1000) {
            if(scaleForVerbal==1 && number>=200){
                return hundreds[(int)number / 100]+ "ΕΣ"+ ((number % 100 != 0) ? " " : "") + ((number%100==0) ? "" : moneyInGreek(number % 100,currencyCode,scaleForVerbal));
            }else if(scaleForVerbal!=1 && number>=200){
                if(currencyCode == 2){
                    return hundreds[(int)number / 100] + "ΕΣ" + ((number % 100 != 0) ? " " : "") + ((number%100==0) ? "" : moneyInGreek(number % 100,currencyCode,scaleForVerbal));
                }else{
                    return hundreds[(int)number / 100] + "Α" + ((number % 100 != 0) ? " " : "") + ((number%100==0) ? "" : moneyInGreek(number % 100,currencyCode,scaleForVerbal));
                }
            }else if(number>100 && number <200){
                return hundreds[(int)number / 100] + "Ν" + ((number % 100 != 0) ? " " : "") + ((number%100==0) ? "" : moneyInGreek(number % 100,currencyCode,scaleForVerbal));
            }else if(number==100){
                return hundreds[(int)number / 100] + ((number % 100 != 0) ? " " : "");
            }else{
                return hundreds[(int)number / 100] + ((number % 100 != 0) ? " " : "") + ((number%100==0) ? "" : moneyInGreek(number % 100,currencyCode,scaleForVerbal));
            }

        }
        int scale = 0;
        String words = "";
        while (number > 0) {
            long n = number % 1000;
            if (n != 0) {
                String s = moneyInGreek(n,currencyCode,scaleForVerbal);
                if (scale == 1 && n != 1) {
                    words = s + " " + scales[scale] + "ΔΕΣ " + words;
                } else if (scale == 1 && n == 1) {
                    if(currencyCode==2){
                        words = "ΧΙΛΙΕΣ " + words;
                    }else{
                        words = scales[scale] + " " + words;
                    }
                } else if (scale == 1 && n >= 200) {
                    words = s + " " + scales[scale].substring(0, scales[scale].length() - 1) + "ΕΣ " + words;
                } else if(scale >= 2 && n!=1){
                    words = s + " " + scales[scale] + "Α " + words;
                }else if(scale >= 2 && n==1){
                    words = s + " " + scales[scale] + "Ο " + words;
                }else {
                    words = s + " " + scales[scale] + " " + words;
                }

            }
            scale++;
            scaleForVerbal = scale;
            number /= 1000;
        }
        return words.trim();
    }

    public static String getVerbalInEnglish(BigDecimal money, int currencyCode, int numOfCurrencyDecimals){



        String stringMoney = money.toString();
        String finalString = "";
        int decimalCalc = (int)Math.pow(10, numOfCurrencyDecimals);
        long integerPart = (long) Math.abs(money.longValue());
        switch (currencyCode) {
            case 0:
                if(integerPart == 1){
                    finalString = "EURO ";
                }else{
                    finalString = "EUROS ";
                }
                break;
            case 1:
                if(integerPart == 1){
                    finalString = "U.S.DOLLAR ";
                }else{
                    finalString = "U.S.DOLLARS ";
                }
                break;
            case 2:
                if(integerPart == 1){
                    finalString = "STERLING POUND ";
                }else{
                    finalString = "STERLING POUNDS ";
                }
                break;
            default:
                LOGGER.debug("Error:Unknown Currency Code " + currencyCode);
                break;
        }
        String integerPartWord = "";
        String decimalPartWord = "";

        if(money.doubleValue() % 1 == 0){

            if (integerPart >= 0) {
                integerPartWord = finalString +convert(integerPart);
            }
        }else{
            String[] parts = stringMoney.split("\\.");
            String cents = String.valueOf(parts[1]);
            int scale = money.scale();
            if(scale<numOfCurrencyDecimals){
                while(scale!=numOfCurrencyDecimals){
                    cents +="0";
                    scale++;
                }
            }else{
                cents = String.valueOf(parts[1]).substring(0,numOfCurrencyDecimals);
            }

            if (integerPart >= 0) {
                integerPartWord = finalString +convert(integerPart);
            }

            if (integerPart >= 0) {
                integerPartWord = finalString +convert(integerPart);
            }
            if (Integer.parseInt(cents) > 0) {
                if(Integer.parseInt(cents)==1){
                    decimalPartWord = " AND " + convert(Long.parseLong(cents)) + " CENT";
                }else{
                    decimalPartWord = " AND " + convert(Long.parseLong(cents)) + " CENTS";
                }


            }
        }

        return integerPartWord + decimalPartWord ;




    }

    public static String convert(long number){
        if (number < 20) {
            return onesEnglish[(int) number];
        }
        if (number < 100) {
            return tensEnglish[(int) number / 10] + ((number % 10 != 0) ? " " : "") + ((onesEnglish[(int) number % 10].equals("ZERO")?"":onesEnglish[(int) number % 10]));
        }
        if (number < 1000) {
            return onesEnglish[(int) number / 100] + " HUNDRED" + ((number % 100 != 0) ? " " : "") + (convert(number % 100).equals("ZERO")?"":convert(number % 100));
        }
        if (number < 1_000_000) {
            return convert(number / 1000) + " THOUSAND" + ((number % 1000 != 0) ? " " : "") + (convert(number % 1000).equals("ZERO")?"":convert(number % 1000));
        }
        if (number < 1_000_000_000) {
            return convert(number / 1_000_000) + " MILLION" + ((number % 1_000_000 != 0) ? " " : "") + (convert(number % 1_000_000).equals("ZERO")?"":convert(number % 1_000_000));
        }
        return convert(number / 1_000_000_000) + " BILLION" + ((number % 1_000_000_000 != 0) ? " " : "") + (convert(number % 1_000_000_000).equals("ZERO")?"":convert(number % 1_000_000_000));

    }
}
