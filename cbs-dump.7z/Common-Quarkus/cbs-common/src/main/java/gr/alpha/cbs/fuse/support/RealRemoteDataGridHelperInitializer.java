package gr.alpha.cbs.fuse.support;

import gr.alpha.cbs.fuse.bean.AuthServerBean;
import gr.alpha.cbs.fuse.ejb.*;
import io.quarkus.runtime.StartupEvent;
import jakarta.enterprise.event.Observes;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RealRemoteDataGridHelperInitializer implements RemoteDataGridHelperInitializer {
    private static final Logger logger = LoggerFactory.getLogger(RealRemoteDataGridHelperInitializer.class);

    @Inject
    AuthServerBean authServerBean;
    @Inject
    AccountingMetaDataEjb accountingMetaDataEjb;
    @Inject
    ChannelBucrCallerEjb channelBucrCallerEjb;
    @Inject
    CorporateDividendsEjb corporateDividendsEjb;
    @Inject
    MasterDataEjb masterDataEjb;
    @Inject
    MetaDataEjb metaDataEjb;
    @Inject
    ProductStudioEjb productStudioEjb;
    @Inject
    RefDataTranslatorEjb refDataTranslatorEjb;

    public void init() {
        logger.info("RealRemoteDataGridHelperInitializer: init called");
        // This method will be called when the application starts
        // You can perform any initialization logic here
        // All injected beans above are singleton scope, so that they get
        // created upon injection (see https://quarkus.io/guides/cdi#bean-scope-available)

        // This is done so that we eagerly initialize the RemoteDatagridClientHelper
        // in the classes above, because lazy initialization leads to slow responses
        // on the first request that needs it. This causes exceptions to be thrown
        // and rollbacks to happen, which we want to avoid.
        // If you want to stick to lazy initialization, then use the
        // RemoteDataGridHelperConfigurer to produce a NoopRemoteDataGridHelperInitializer
        // which does nothing. This can happen if you set the property
        // remote.datagrid.helper.initializer.noop=true in application.properties
    }
}
