package gr.alpha.cbs.fuse.tools;

import javax.xml.XMLConstants;
import javax.xml.namespace.NamespaceContext;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;

public class XPathHelpers {
    public static XPath getXPath(final String namespace, final String namespacePrefix) {
        XPathFactory xpathFactory = new net.sf.saxon.xpath.XPathFactoryImpl();
        XPath xpath = xpathFactory.newXPath();
        xpath.setNamespaceContext(new NamespaceContext() {

            @Override
            public String getNamespaceURI(String prefix) {
                if (prefix == null) {
                    throw new NullPointerException();
                } else if (namespacePrefix.equals(prefix)) {
                    return namespace;
                }
                return XMLConstants.NULL_NS_URI;
            }

            @Override
            public String getPrefix(String namespaceURI) {
                if (namespace != null && namespace.equals(namespaceURI)) {
                    return namespacePrefix;
                }
                return null;
            }

            @Override
            public Iterator<String> getPrefixes(String namespaceURI) {
                if (namespace != null && namespace.equals(namespaceURI)) {
                    return Collections.singletonList(namespacePrefix).iterator();
                }
                return null;
            }
        });
        return xpath;
    }

    private XPathHelpers() {
        // Intentionally empty
    }
}
