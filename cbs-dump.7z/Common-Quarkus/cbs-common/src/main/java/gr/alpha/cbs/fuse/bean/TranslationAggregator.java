package gr.alpha.cbs.fuse.bean;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Named;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

@Named("translationAggregator")
@Dependent
@RegisterForReflection
public class TranslationAggregator implements Processor {
	
	private static String root = "root";
	private static String concatBody = "concatBody";

	public void process(Exchange exchange) throws Exception {

		Document doc = exchange.getIn().getBody(Document.class);

		Element he;

		if (exchange.getIn().getHeader(concatBody) instanceof Element) {
			he = (Element) exchange.getIn().getHeader(concatBody);
		} else if (exchange.getIn().getHeader(concatBody) instanceof Document) {
			he = ((Document) exchange.getIn().getHeader(concatBody)).getDocumentElement();
		} else {
			exchange.getIn().setHeader(concatBody, exchange.getIn().getBody());
			return;
		}

		DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		Document newDocument = docBuilder.newDocument();
		Element rootElement = newDocument.createElement(root);
		newDocument.appendChild(rootElement);

		Node bodyNode = newDocument.adoptNode(doc.getDocumentElement().cloneNode(true));
		rootElement.appendChild(bodyNode);

		if (!he.getNodeName().equals(root)) {
			Node propertyNode = newDocument.adoptNode(he.cloneNode(true));
			rootElement.appendChild(propertyNode);
		} else {
			for (int i = 0; i < he.getChildNodes().getLength(); i++) {
				Node childNode = he.getChildNodes().item(i);
				if (childNode instanceof Element) {
					Element childElement = (Element) childNode;
					Node propertyNode = newDocument.adoptNode(childElement.cloneNode(true));
					rootElement.appendChild(propertyNode);
				}
			}
		}

		exchange.getIn().setBody(newDocument);
		exchange.getIn().setHeader(concatBody, rootElement);

	}

	@SuppressWarnings("unused")
	private void alternativeProcess(Exchange exchange)
			throws TransformerException, IOException, ParserConfigurationException, SAXException {

		Document doc = (Document) exchange.getIn().getBody();

		String header = (String) exchange.getIn().getHeader(concatBody);
		String body = convertDocumentToString(doc);

		body = body.replace("<root>", "");
		body = body.replace("</root>", "");
		body = body.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
		exchange.getIn().setHeader(concatBody, "<root>" + header + body + "</root>");
		exchange.getIn().setBody(convertStringUTFToDOM("<root>" + header + body + "</root>"));

	}

	private String convertDocumentToString(Document document) throws TransformerException {
		return FormatUtils.nodeToString(document, FormatUtils.OMIT_XML_DECLARATION_NO, FormatUtils.INDENT_YES);
	}

	private Document convertStringUTFToDOM(String str)
			throws IOException, ParserConfigurationException, SAXException {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		InputSource is = new InputSource();
		is.setCharacterStream(new StringReader(str));
		return dBuilder.parse(is);
	}

}