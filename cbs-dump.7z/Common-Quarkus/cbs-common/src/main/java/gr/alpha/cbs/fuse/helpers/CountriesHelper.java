package gr.alpha.cbs.fuse.helpers;
import java.util.HashMap;
import java.util.Map;


import gr.alpha.cbs.fuse.ifaces.MasterDataInterface;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.jboss.logging.Logger;

@Named("CountriesHelper")
@ApplicationScoped
@RegisterForReflection
public class CountriesHelper {

	private static final Logger LOGGER = Logger.getLogger(CountriesHelper.class);
	private static final String countries = "Countries";

	@Inject
	MasterDataInterface masterData;
	public CountriesHelper() {

	}

	/* Default call to MasterData to retrieve response */
	public HashMap<String, String> callToMasterData(String currencyValue) throws Exception {
		return masterData.getMasterDetailsByItemNameLists(countries, currencyValue);
	}
	
	/***
	 * Retrieve MasterData values by MasterDataName
	 *  
	 * @param masterName
	 * @return a HashMap of MasterData values
	 * @throws Exception
	 */
	public HashMap<String, HashMap<String, String>> callToMasterDataByName(String masterName) throws Exception {
		return masterData.getMasterDetailsLists(masterName);
	}

	/**
	 * 
	 * MW function IsEoxCountry as described on
	 * ESB.CreateFundTransferOfflinePayByAccount V0.5.docx file
	 * 
	 * @param countryISO
	 * @return 
	 * @throws Exception
	 */
	public boolean isEuropeanUnionCountry(String countryISO) throws Exception {
		HashMap<String, String> map = callToMasterData(countryISO);
		if (map != null && !map.isEmpty() && map.containsKey("IsEOX")) {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("in isEuropeanUnionCountry isEOX value: " + map.get("IsEOX"));
			}
			if ("1".equals(map.get("IsEOX"))) {
				return true;
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("in isEuropeanUnionCountry isEOX value not found or is not equal to 0");
		}
		return false;
	}

	public String getCountryMasterCode(String countryISO) throws Exception {
		LOGGER.debug("Before call masterdata: " + countryISO);
		HashMap<String, HashMap<String, String>> isoCode = callToMasterDataByName(countries);
		
		String value = null;
		for (Map.Entry<String, HashMap<String, String>> entry : isoCode.entrySet()) {
			LOGGER.debug("AFTER call masterdata value " + entry.getKey());
			for (Map.Entry<String, String> attribute : entry.getValue().entrySet()) {
				if (attribute.getKey().equals("CNN_ISO") && attribute.getValue().equals(countryISO)) {
					value = entry.getKey();
					LOGGER.debug("code value : " + value);
					break;
				}
			}
		}

		return value;
	}
}
