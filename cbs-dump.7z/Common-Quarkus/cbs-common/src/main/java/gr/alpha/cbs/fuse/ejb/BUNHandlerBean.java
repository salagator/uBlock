package gr.alpha.cbs.fuse.ejb;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;
import jakarta.transaction.Transactional;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.ifaces.BUNHandlerInterface;
import gr.alpha.cbs.fuse.ifaces.ResourceBbbmmkHandlerInterface;
import gr.alpha.cbs.fuse.common.support.TransactionConfig;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Body;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangeProperties;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.config.ConfigProvider;
import org.jboss.logging.Logger;
import org.slf4j.MDC;

@Named("bunHandlerBean")
@Dependent
@RegisterForReflection
public class BUNHandlerBean implements BUNHandlerInterface {
	private static final String CBS_COMMON_TUN_MAP = "cbs.common.tunMap";
	private static final String CBS_COMMONS_BUN_FROM_TUN = "cbs.commons.bun.from.tun";
	private static final String CBS_COMMONS_TUN_NOT_FROM_CBS = "cbs.commons.tun.not.from.cbs";
	private static final Logger LOGGER = Logger.getLogger(BUNHandlerBean.class);

	@Inject
	@io.quarkus.agroal.DataSource("cbsun")
	DataSource sqlDsCBSUN;

	@Inject
	@io.quarkus.agroal.DataSource("cbsxa")
	DataSource sqlDSXA;

	@Inject
	ResourceBbbmmkHandlerInterface resourceBbmmk;


	@Transactional(Transactional.TxType.REQUIRED)
	public Object completeTransaction(@Body Object body, @ExchangeProperties Map<String, Object> properties) throws Exception {
		LOGGER.debug("completeTransaction start");

		Long bunReference = Long.valueOf(properties.get(CBSConstants.HEADER_BUN_REFERENCE).toString());
		String bun = properties.get(CBSConstants.HEADER_BUN).toString();
		@SuppressWarnings("unchecked")
		HashMap<String, String> tunMap = (HashMap<String, String>) properties.get(CBS_COMMON_TUN_MAP);

		String sql = "insert into TRN_TransactionUniqueNumbers (BankUniqueNumbersId, TargetSystemsId, TargetSystemUN, BUN, UTimeStamp) values(?,?,?,?,SYSDATETIME())";
		try (Connection conn = this.sqlDSXA.getConnection(); PreparedStatement statement = conn.prepareStatement(sql)) {
			LOGGER.debug("prepareStatement:" + sql);

			for (Map.Entry<String, String> e : tunMap.entrySet()) {
				String tun = e.getKey();
				String systemId = e.getValue();

				LOGGER.debug("before statement.execute|" + bunReference + "|" + systemId + "|" + tun + "|" + bun + "|");
				statement.setLong(1, bunReference);
				statement.setLong(2, Long.parseLong(systemId));
				statement.setString(3, tun);
				statement.setString(4, bun);

				LOGGER.debug("statement.execute");
				statement.execute();
			}

			LOGGER.debug("completeTransaction end");
			return body;
		} catch (Exception ex) {
			LOGGER.error("Exception on completeTransaction", ex);
			throw ex;
		}
	}

	/**
	 * Used in doBUN() private method below to return multiple results for usage in createBUN()
	 */
	private static class BUNInfo {
		Long bunReference;
		String bun;
		String bunDecimal;
	}

	@Transactional(Transactional.TxType.NOT_SUPPORTED)
	public Object createBUN(@Body Object body, @ExchangeProperties Map<String, Object> properties) throws Exception {
		Map<String, String> map = new HashMap<>();
		properties.put(CBS_COMMON_TUN_MAP, map);

		try (Connection conn = sqlDSXA.getConnection()) {
			conn.setAutoCommit(false);
			try {
				BUNInfo bunInfo = doBUN(conn);
				properties.put(CBSConstants.HEADER_BUN_REFERENCE, bunInfo.bunReference);
				properties.put(CBSConstants.HEADER_BUN, bunInfo.bun);
				properties.put(CBSConstants.HEADER_BUN_DECIMAL, bunInfo.bunDecimal);
				MDC.put(CBSConstants.MDC_KEY_CBS_UN_ID, bunInfo.bun);
				LOGGER.debug("Pre Commit");
				conn.commit();
				LOGGER.debug("Commited");
				return body;
			} catch (Exception ex) {
				LOGGER.error("Exception on createBUN", ex);
				conn.rollback();
				throw ex;
			}
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Object addTUN(@Body Object body, @ExchangeProperties Map<String, Object> properties) throws Exception {
		String tun = "";
		if (properties.get(CBSConstants.HEADER_TUN) == null) {
			TransactionConfig config = (TransactionConfig) properties.get("configuration");

			if (!"0".equals(config.getUnTransNumberType())) {
				String errMsg = "Πρόβλημα της addTUN(). Δεν υπάρχει HEADER_TUN. " + properties.get(CBSConstants.HEADER_TRANSACTION_NAME).toString();
				LOGGER.error(errMsg);
				ErrorUtils.throwCBSException(null, String.valueOf(ConstantError_Types._Technical), String.valueOf(ConstantError_System_IDs._FUSE), this.getClass().getCanonicalName(),
						String.valueOf(ConstantErrorMessages._ServiceNotParameterizedEventsRegistry), String.valueOf(ConstantError_Levels._Error), errMsg, "", "", "");
			}
		} else {
			tun = properties.get(CBSConstants.HEADER_TUN).toString();
		}

		String systemId = properties.get(CBSConstants.HEADER_SYSTEM_ID).toString();
		Map map;
		if ((Map) properties.get(CBS_COMMON_TUN_MAP) != null) {
			map = (Map) properties.get(CBS_COMMON_TUN_MAP);
		} else {
			map = new HashMap<String, String>();
		}

		if (!"".equals(tun)) {
			map.put(tun, systemId);
		}

		properties.put(CBS_COMMON_TUN_MAP, map);

		return body;
	}

	public void getTUNFromBUN(Exchange exchange, String bun) throws Exception {
		getTUNFromBUN(exchange, bun, "cbs.commons.tun.from.bun");
	}

	public void getTUNFromBUN(Exchange exchange, String bun, String outputHeader) throws Exception {
		try (Connection conn = this.sqlDsCBSUN.getConnection();
			 PreparedStatement pstm = conn.prepareStatement("select TargetSystemUN from TRN_TransactionUniqueNumbers where bankUniqueNumbersId = (select id from TRN_BankUniqueNumbers where BUN = ? )")) {
			pstm.setString(1, bun);
			try (ResultSet rs = pstm.executeQuery()) {
				String tun = null;
				if (rs.next()) {
					tun = rs.getString(1);
				} else {
					throw new SQLException("Unable to get TUNfromBUN");
				}
				exchange.getIn().setHeader(outputHeader, tun);
			}
		} catch (Exception ex) {
			LOGGER.error("Exception on getting TUN from BUN", ex);
			ErrorUtils.throwCBSException(ex, ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, BUNHandlerBean.class.getCanonicalName(), ConstantErrorMessages._SQL_Could_not_retreive_TUN_or_RTUN_from_BUN, ErrorTypeModel.SEVERITY_ERROR,
					"Δεν μπορεί να ανακτηθεί το TUN από το BUN " + bun, "", "", "");
		}
	}

	/**
	 * Dont throw exception if you dont find BUN
	 *
	 * @param exchange
	 * @param tun
	 * @throws Exception
	 */
	public void getBUNFromTUN(Exchange exchange, String tun) throws Exception {
		String sql = "select BUN from TRN_BankUniqueNumbers where id = (select BankUniqueNumbersId from TRN_TransactionUniqueNumbers where TargetSystemUN = ?)";
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("SQL: " + sql);
			LOGGER.debug("TUN: " + tun);
		}

		try (Connection conn = this.sqlDsCBSUN.getConnection(); PreparedStatement pstm = conn.prepareStatement(sql)) {
			pstm.setString(1, tun);
			try (ResultSet rs = pstm.executeQuery()) {
				if (rs.next()) {
					String bun = rs.getString(1);
					exchange.getIn().setHeader(CBS_COMMONS_BUN_FROM_TUN, bun);
					exchange.getIn().setHeader(CBS_COMMONS_TUN_NOT_FROM_CBS, false);
				} else {
					exchange.getIn().setHeader(CBS_COMMONS_BUN_FROM_TUN, tun);
					exchange.getIn().setHeader(CBS_COMMONS_TUN_NOT_FROM_CBS, true);
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Exception on getting BUN from TUN", ex);
			ErrorUtils.throwCBSException(ex, ErrorTypeModel.ERROR_TYPE_TECHNICAL, ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, BUNHandlerBean.class.getCanonicalName(), ConstantErrorMessages._SQL_Could_not_retreive_BUN_from_TUN, ErrorTypeModel.SEVERITY_ERROR,
					"Δεν μπορεί να ανακτηθεί το BUN από το TUN", "", "", "");
		}
	}

	public void getBUNFromSigloTUN(Exchange exchange, String valeurDate, String unitCode, String tun) throws SQLException {
		String sql = "select TRN_BankUniqueNumbers.BUN from TRN_BankUniqueNumbers join TRN_TransactionUniqueNumbers on TRN_BankUniqueNumbers.Id = TRN_TransactionUniqueNumbers.BankUniqueNumbersId where TRN_TransactionUniqueNumbers.TargetSystemUN = ? and TRN_TransactionUniqueNumbers.TargetSystemsId = 3";
		try (Connection conn = this.sqlDsCBSUN.getConnection(); PreparedStatement pstm = conn.prepareStatement(sql)) {
			LOGGER.debug(sql);

			String tunPadded = StringUtils.leftPad(tun, 9, '0');
			String unitCodePadded = StringUtils.leftPad(unitCode, 4, '0');
			String valeurDateSanitized = valeurDate == null ? null : valeurDate.replace("+00:00", "").replace("-", "");
			String tunToSearch = valeurDateSanitized + unitCodePadded + tunPadded;

			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("tun= " + tunPadded);
				LOGGER.info("unitCode= " + unitCodePadded);
				LOGGER.info("valeurDate= " + valeurDateSanitized);
				LOGGER.info("TUN to search: " + tunToSearch);
			}

			pstm.setString(1, tunToSearch);
			try (ResultSet rs = pstm.executeQuery()) {
				if (rs.next()) {
					String bun = rs.getString(1);
					LOGGER.info("Found BUN: " + bun);
					exchange.getIn().setHeader(CBS_COMMONS_BUN_FROM_TUN, bun);
					exchange.getIn().setHeader(CBS_COMMONS_TUN_NOT_FROM_CBS, false);
				} else {
					LOGGER.info("No BUN found");
					exchange.getIn().setHeader(CBS_COMMONS_BUN_FROM_TUN, "");
					exchange.getIn().setHeader(CBS_COMMONS_TUN_NOT_FROM_CBS, true);
				}
			}
		}
	}

	private String getWorkDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		sdf.setTimeZone(TimeZone.getTimeZone(ZoneId.of(ConfigProvider.getConfig().getOptionalValue("cbs.time.zone", String.class).orElse("Europe/Athens"))));
		return sdf.format(Calendar.getInstance().getTime());
	}

	private BUNInfo doBUN(Connection conn) throws SQLException {
		BUNInfo bunInfo = new BUNInfo();
		String workDate = getWorkDate();
		Long sequence = null;
		String sql = "select NEXT VALUE FOR  BUN_SEQ";

		try (Statement stm = conn.createStatement(); ResultSet rs = stm.executeQuery(sql)) {
			if (rs.next()) {
				sequence = rs.getLong(1);
			} else {
				throw new SQLException("Unable to get Sequence");
			}

			bunInfo.bun = workDate + "0" + StringUtils.leftPad(Long.toHexString(sequence).toUpperCase(), 9, '0');
			bunInfo.bunDecimal = workDate + "0" + StringUtils.leftPad(sequence.toString(), 12, '0');

			sql = "insert into TRN_BankUniqueNumbers (TranDateTime,BUN) values(SYSDATETIME(),?)";
			LOGGER.debug("createBUN prepareStatement, sql:" + sql);

			try (PreparedStatement pst = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
				pst.setString(1, bunInfo.bun);

				int affectedRows = pst.executeUpdate();
				LOGGER.debug("createBUN executeUpdate");
				if (affectedRows == 0) {
					throw new SQLException("Unable to insert to database");
				}

				try (ResultSet generatedKeys = pst.getGeneratedKeys()) {
					if (generatedKeys.next()) {
						bunInfo.bunReference = generatedKeys.getLong(1);
					} else {
						LOGGER.error("Exception on getting BUN");
						throw new SQLException("Unable to get the generated key");
					}
				}

				LOGGER.debug("createBUN BUNReference:" + bunInfo.bunReference);
			}
		} catch (SQLException ex) {
			LOGGER.error("Exception on getting BUN", ex);
			throw ex;
		}

		return bunInfo;
	}

	private String getCurrentDate(Exchange exchange) throws ParseException {
		SimpleDateFormat requestPayloadDateFormatter = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat currentDateFormatter = new SimpleDateFormat("yyyyMMdd");
		return currentDateFormatter.format(requestPayloadDateFormatter.parse(exchange.getProperty(CBSConstants.HEADER_WORK_DATE, String.class)));
	}

	private String getTransactionBranch(Exchange exchange) {
		int transBranch = exchange.getProperty(CBSConstants.HEADER_BRANCH_CODE, Integer.class);
		return String.valueOf(transBranch);
	}

	private String getDUNSequence(Connection connection, String branch, String currentDate) throws CBSException, SQLException {
		String dunSeq = "";

		LOGGER.debug("Call stored procedure get_Dun_Seq with branch:" + branch + " and date:" + currentDate);

		try (CallableStatement statement = connection.prepareCall("{call get_Dun_Seq(?,?,?,?,?,?)}")) {

			// INPUT PARAMETERS -> 1:branch 2:currentDate in YYYYMMDD format
			statement.setObject(1, branch, java.sql.Types.VARCHAR);
			statement.setObject(2, currentDate, java.sql.Types.VARCHAR);

			// OUTPUT PARAMETERS -> 3:key 4:dun_seq 5:errorCode 6:errorMessage
			statement.registerOutParameter(3, java.sql.Types.NUMERIC);
			statement.registerOutParameter(4, java.sql.Types.NUMERIC);
			statement.registerOutParameter(5, java.sql.Types.INTEGER);
			statement.registerOutParameter(6, java.sql.Types.VARCHAR);

			statement.execute();

			// if errorCode = 0 means that no error has been returned and we successfully retrieve the DUN_SEQ from the db
			// if errorCode = 8115 means that the maximum DUN_SEQ has been achieved and an arithmetic overflow exception is thrown, throw technical CBSException
			// otherwise throw an sql exception with the errorMessage returned from the stored procedure
			int errorCode = statement.getInt(5);
			String errorMessage = statement.getString(6);
			if (errorCode == 0) {
				//Instructions to get dun sequence: 00 + key + Δ + dun sequence from db
				dunSeq = "00" + statement.getInt(3) + "Δ" + StringUtils.leftPad(Integer.toString(statement.getInt(4)), 3, '0');
				LOGGER.debug("DUN_SEQ retrieved is : " + dunSeq);
			} else if (errorCode == 8115) {
				ErrorUtils.throwCBSException(null, ErrorTypeModel.ERROR_TYPE_TECHNICAL, ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, this.getClass().getCanonicalName(), ConstantErrorMessages._CannnotCreateDunForOdissy, ErrorTypeModel.SEVERITY_ERROR, errorMessage, "", "", "");
			} else {
				LOGGER.debug("Stored Procedure get_Dun_Seq returned error: " + errorCode);
				throw new SQLException(errorMessage);
			}
		} catch (SQLException e) {
			LOGGER.error("Error in stored procedure get_Dun_Seq", e);
			throw e;
		}

		return dunSeq;
	}

	@Transactional(Transactional.TxType.NOT_SUPPORTED)
	public void createDUNv2(Exchange exchange) throws Exception {
		String currentDate = getCurrentDate(exchange);
		String branch = getTransactionBranch(exchange);

		try (Connection conn = sqlDSXA.getConnection()) {
			conn.setAutoCommit(false);

			String odissyDun = "";

			try {
				String dunSequence = getDUNSequence(conn, branch, currentDate);

				// Instructions to get odissy dun : 20200101(date) - 101(branch) - dun sequence
				odissyDun = currentDate + StringUtils.leftPad(branch, 3, '0') + dunSequence;
			} catch (SQLException | CBSException e) {
				LOGGER.error("Error on getting DUN SEQ",e);
				conn.rollback();
				throw e;
			}

			try {
				Long bunReference = Long.valueOf(exchange.getProperty(CBSConstants.HEADER_BUN_REFERENCE, String.class));
				String bun = exchange.getProperty(CBSConstants.HEADER_BUN).toString();

				saveDUN(bun, bunReference, odissyDun, conn);
				LOGGER.debug("DUN for odissy call has been saved successfully.");
			} catch (Exception e) {
				LOGGER.error("Error on saving DUN ", e);
				conn.rollback();
				throw e;
			}

			conn.commit();
			exchange.setProperty(CBSConstants.HEADER_ODISSY_DUN, odissyDun);
		}
	}

	@Transactional(Transactional.TxType.NOT_SUPPORTED)
	public void createDUN(Exchange exchange) throws Exception {
		String currDate = getCurrentDate(exchange);
		String branch = getTransactionBranch(exchange);

		String resoureID = exchange.getProperty(CBSConstants.HEADER_RESOURCE_ID,String.class);
		String rscBbbmmk = resourceBbmmk.readBbbmmk(resoureID);

		if(StringUtils.isBlank(rscBbbmmk)){
			ErrorUtils.throwCBSException(null,
					String.valueOf(ConstantError_Types._Technical),
					String.valueOf(ConstantError_System_IDs._FUSE),
					this.getClass().getCanonicalName(),
					ConstantErrorMessages._UERRMSGS_300001_texniko_prob,
					String.valueOf(ConstantError_Levels._Error),
					"Απαιτείται η ύπαρξη τερματικού χρήστη για την δημιουργία DUN", "", "", "");
		}

		LOGGER.debug("Retrieved bbbmmk from resourceId :" + resoureID + " is :" + rscBbbmmk);

		String bbbmmk = rscBbbmmk.substring(rscBbbmmk.length()-3);
		exchange.setProperty("cbs.saep.workstation", bbbmmk);

		String dunSeq = "";
		String odissyDun = "";

		Long bunReference = Long.valueOf(exchange.getProperty(CBSConstants.HEADER_BUN_REFERENCE, String.class));
		String bun = exchange.getProperty(CBSConstants.HEADER_BUN).toString();

		try (Connection conn = sqlDSXA.getConnection()) {
			conn.setAutoCommit(false);

			try {
				dunSeq = retrieveDunSeq(rscBbbmmk, currDate, conn);
				LOGGER.debug("DUN Seq retrieved successfully.");
			} catch (Exception e) {
				LOGGER.error("Error on getting DUN SEQ", e);
				conn.rollback();
				throw e;
			}

			LOGGER.debug("DUN Sequence retrieved for bbbmmk: " + rscBbbmmk + " and date: " + currDate + " is : " + dunSeq);

			// Instructions to get odissy dun : 20181022(date) - 101(branch) - 085(last 3 digits of bbbmmk) - Δ - 001(seq from db)
			odissyDun = currDate + StringUtils.leftPad(branch, 3, '0') + bbbmmk + "Δ" + StringUtils.leftPad(dunSeq, 3, '0');

			LOGGER.debug("DUN for odissy calss constructed successfully :" + odissyDun);

			try {
				saveDUN(bun, bunReference, odissyDun, conn);
				LOGGER.debug("DUN for odissy call has been saved successfully.");
			} catch (Exception e) {
				LOGGER.error("Error on saving DUN ", e);
				conn.rollback();
				throw e;
			}

			conn.commit();
		}

		exchange.setProperty(CBSConstants.HEADER_ODISSY_DUN, odissyDun);
	}

	/**
	 * Call stored procedure get_Odissy_Seq to get the next available sequence in order to construct the DUN key for odissy calls
	 *
	 * @param bbbmmk
	 * @param currDate
	 * @param connection
	 * @return
	 * @throws Exception
	 */
	private String retrieveDunSeq(String bbbmmk, String currDate, Connection connection) throws Exception {
		String dunSeq = "";

		LOGGER.debug("Call stored procedure get_Odissy_Seq with bbbmmk:" + bbbmmk + " and date:" + currDate);

		try (CallableStatement statement = connection.prepareCall("{call get_Odissy_Seq(?,?,?,?,?)}")) {

			// INPUT PARAMETERS -> 1:bbbmmk 2:currentDate in YYYYMMDD format
			statement.setObject(1, bbbmmk, java.sql.Types.VARCHAR);
			statement.setObject(2, currDate, java.sql.Types.VARCHAR);

			// OUTPUT PARAMETERS -> 3:dun_seq 4:errorCode 5:errorMessage
			statement.registerOutParameter(3, java.sql.Types.NUMERIC);
			statement.registerOutParameter(4, java.sql.Types.INTEGER);
			statement.registerOutParameter(5, java.sql.Types.VARCHAR);

			statement.execute();

			// if errorCode = 0 means that no error has been returned and we successfully retrieve the DUN_SEQ from the db
			// if errorCode = 8115 means that the maximum DUN_SEQ has been achieved and an arithmetic overflow exception is thrown, throw technical CBSException
			// otherwise throw an sql exception with the errorMessage returned from the stored procedure
			if (statement.getInt(4) == 0) {
				dunSeq = String.valueOf(statement.getInt(3));
				LOGGER.debug("DUN_SEQ retrieved is : " + dunSeq);
			} else if (statement.getInt(4) == 8115) {
				ErrorUtils.throwCBSException(null, ErrorTypeModel.ERROR_TYPE_TECHNICAL, ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, this.getClass().getCanonicalName(), ConstantErrorMessages._CannnotCreateDunForOdissy, ErrorTypeModel.SEVERITY_ERROR, statement.getString(5), "", "", "");
			} else {
				LOGGER.debug("Stored Procedure get_Odissy_Seq returned error: " + statement.getString(4));
				throw new SQLException(statement.getString(5));
			}
		} catch (Exception e) {
			LOGGER.error("Error in stored procedure get_Odissy_Seq ", e);
			throw e;
		}

		return dunSeq;
	}

	/**
	 * Add a row in the TRN_TransactionUniqueNumbers table to keep the correlation between BUN and DUN.
	 *
	 * @param bunReference
	 * @param odissyDun
	 * @param connection
	 * @throws Exception
	 */
	private void saveDUN(String bun, Long bunReference, String odissyDun, Connection connection) throws SQLException {
		String sql = "insert into TRN_TransactionUniqueNumbers (BankUniqueNumbersId, TargetSystemsId, TargetSystemUN, BUN, UTimeStamp) values(?,?,?,?,SYSDATETIME())";
		try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
			preparedStatement.setLong(1, bunReference);
			preparedStatement.setLong(2, Long.parseLong(CBSConstants.SYSTEM_ID_ODISSY));
			preparedStatement.setString(3, odissyDun);
			preparedStatement.setString(4, bun);
			preparedStatement.execute();
		} catch (SQLException e) {
			LOGGER.error("Exception on saving DUN", e);
			throw e;
		}
	}

	@Transactional(Transactional.TxType.NOT_SUPPORTED)
	public String createBUNnoArgs() throws Exception{
		try (Connection conn = sqlDSXA.getConnection()) {
			conn.setAutoCommit(false);
			try {
				BUNInfo bunInfo = doBUN(conn);
				LOGGER.debug("Pre Commit");
				conn.commit();
				LOGGER.debug("Commited");
				return bunInfo.bun;
			} catch (Exception ex) {
				LOGGER.error("Exception on createBUN", ex);
				conn.rollback();
				throw ex;
			}
		}
	}
}
