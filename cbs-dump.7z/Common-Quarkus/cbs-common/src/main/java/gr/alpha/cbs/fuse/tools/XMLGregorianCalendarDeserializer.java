package gr.alpha.cbs.fuse.tools;

import java.io.IOException;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

public class XMLGregorianCalendarDeserializer extends StdDeserializer<XMLGregorianCalendar> { 

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public XMLGregorianCalendarDeserializer() { 
        this(null); 
    } 

    public XMLGregorianCalendarDeserializer(Class<?> vc) { 
        super(vc); 
    }

    @Override
    public XMLGregorianCalendar deserialize(JsonParser jp, DeserializationContext ctxt) 
      throws IOException, JsonProcessingException {
    	JsonNode node = jp.getCodec().readTree(jp);
    	String jsonValue = node.asText();
    	XMLGregorianCalendar value;
		try {
			value = DatatypeFactory.newInstance().newXMLGregorianCalendar(jsonValue);
		} catch (DatatypeConfigurationException e) {
			throw new JsonParseException(jp, "Unable to parse JsonNode value to XMLGregorianCalendar", e);
		}
        return value;
    }
}
