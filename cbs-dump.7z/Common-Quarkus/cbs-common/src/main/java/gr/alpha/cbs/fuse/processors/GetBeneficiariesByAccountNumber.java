package gr.alpha.cbs.fuse.processors;

//import gr.alpha.cbs.fuse.support.HostInformationHelper;
import gr.alpha.cbs.fuse.support.WsCallingProcessor;
import org.apache.camel.Exchange;
import org.eclipse.microprofile.config.ConfigProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Node;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

import javax.xml.namespace.QName;
import javax.xml.xpath.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

@Named("getBeneficiariesByAccountNumber")
@ApplicationScoped
@RegisterForReflection
public class GetBeneficiariesByAccountNumber extends WsCallingProcessor {
	private static final Logger logger = LoggerFactory.getLogger(GetBeneficiariesByAccountNumber.class);
	
	public static final String CUSTOMER_DEPOSITS_POST_FIX = "/ops-customer-deposits/customerdeposits-inquiry";
	
	private static final String ACCOUNT_NUMBER = "$Account.Number$";
	private static final String REQUEST_ID = "$Request.Id$";
	private static final String SESSION_ID = "$Session.Id$";
	private static final String BUSINESS_CASE_ID = "$Business.Case.Id$";
	private static final String SEQUENCE_ID = "$Sequence.Id$";
	private static final String USER_ID = "$User.Id$";
	private static final String WORKING_DATE = "$Working.Date$";
	private static final String PREVIOUS_WORKING_DATE = "$Previous.Working.Date$";
	private static final String NEXT_WORKING_DATE = "$Next.Working.Date$";
	private static final String RESOURCE_ID = "$Resource.ID$";
	private static final String UNIT_CODE_LEVEL_1 = "$Unit.Code.Level1$";
	private static final String UNIT_TYPE_CODE_LEVEL_1 = "$Unit.Type.Code.Level1$";
	private static final String UNIT_CODE_LEVEL_2 = "$Unit.Code.Level2$";
	private static final String UNIT_TYPE_CODE_LEVEL_2 = "$Unit.Type.Code.Level2$";
	private static final String CHANNEL_TYPE_CODE = "$Channel.Type.Code$";
	private static final String RESOURCE_TYPE_CODE = "$Resource.Type.Code$";
	
	private String requestGetBeneficiariesByAccountNumber ="<GetBeneficiariesByAccountNumber xmlns=\"http://fuse.ml.cbs.alpha.gr/customerdeposits/\">"
																+"<GetBeneficiariesByAccountNumberPayload>"
															    	+"<GetBeneficiariesByAccountNumberRequestItem>"
															    		+"<AccountNumber>" + ACCOUNT_NUMBER + "</AccountNumber>"
															    		+"<CustomerIdentificationIsRequired>false</CustomerIdentificationIsRequired>"
															    	+"</GetBeneficiariesByAccountNumberRequestItem> "
															    	+"<LoggingInfo> "
															    		+"<RequestId>" + REQUEST_ID + "</RequestId> " 
															    		+"<SessionId>" + SESSION_ID + "</SessionId> " 
															    		+"<BusinessCaseId>" + BUSINESS_CASE_ID + "</BusinessCaseId> "
															    		+"<SequenceId>" + SEQUENCE_ID + "</SequenceId> "
															    		+"<UserId>" + USER_ID + "</UserId> "
															    		+"<CBSUnId /> "
															    	+"</LoggingInfo> "
															    	+"<EnvParams> " 
															    		+"<WorkingDate>" + WORKING_DATE + "</WorkingDate> " 
															    		+"<PreviousWorkingDate>" + PREVIOUS_WORKING_DATE + "</PreviousWorkingDate> "
															    		+"<NextWorkingDate>" + NEXT_WORKING_DATE + "</NextWorkingDate> "
															    		+"<ResourceID>" + RESOURCE_ID + "</ResourceID> "
															    		+"<UnitCodeLevel1>" + UNIT_CODE_LEVEL_1 + "</UnitCodeLevel1> "
															    		+"<UnitTypeCodeLevel1>" + UNIT_TYPE_CODE_LEVEL_1 + "</UnitTypeCodeLevel1> "
															    		+"<UnitCodeLevel2>" + UNIT_CODE_LEVEL_2 + "</UnitCodeLevel2> "
															    		+"<UnitTypeCodeLevel2>" + UNIT_TYPE_CODE_LEVEL_2 + "</UnitTypeCodeLevel2> "
															    		+"<ChannelTypeCode>" + CHANNEL_TYPE_CODE + "</ChannelTypeCode> " 
															    		+"<ResourceTypeCode>" + RESOURCE_TYPE_CODE + "</ResourceTypeCode> "
															    	+"</EnvParams> "
															    +"</GetBeneficiariesByAccountNumberPayload> "
															+"</GetBeneficiariesByAccountNumber>";

	@Override
	public QName getPortQName() {
		return new QName("http://fuse.ml.cbs.alpha.gr/custromerdeposits/", "CustDepositsSOAP");
	}

	@Override
	public QName getServiceQName() {
		return new QName("http://fuse.ml.cbs.alpha.gr/customerdeposits/", "customerdeposits-inquiry");
	}

	@Override
	public String getURLString() {
		String endpointForCustomerDeposits = "";
		try {
			// the cbs.customer.deposits.endpoint should have the url for LB
			String wsatCustomerDepositsUrl = ConfigProvider.getConfig().getValue("cbs.customer.deposits.endpoint", String.class);
			//System.getProperty("cbs.customer.deposits.endpoint", HostInformationHelper.getHostWSUrl(true));
			endpointForCustomerDeposits = wsatCustomerDepositsUrl + CUSTOMER_DEPOSITS_POST_FIX;
			logger.info("Final endpoint for customer deposits: {}.", endpointForCustomerDeposits);
		} catch (Exception error) {
			logger.error("Unable to get the correct endpoint for the call to the customer deposits.", error);
		}
		return endpointForCustomerDeposits;
	}
	
	@Override
	public void process(Exchange exchange) throws Exception {
		String accountNumber = exchange.getProperty("AccountNumber", String.class);
		Node requestNode = exchange.getProperty("payload", Node.class);
		
		XPathFactory xpathfactory = new net.sf.saxon.xpath.XPathFactoryImpl();
		XPath xpath = xpathfactory.newXPath();
		
		Map<String, String> placeholderValueMap = new HashMap<>();
		placeholderValueMap.put(ACCOUNT_NUMBER, accountNumber);
		placeholderValueMap.put(REQUEST_ID, extractXPathValue(xpath, requestNode, "//*:LoggingInfo/*:RequestId/text()"));
		placeholderValueMap.put(SESSION_ID, extractXPathValue(xpath, requestNode, "//*:LoggingInfo/*:SessionId/text()"));
		placeholderValueMap.put(BUSINESS_CASE_ID, extractXPathValue(xpath, requestNode, "//*:LoggingInfo/*:BusinessCaseId/text()"));
		placeholderValueMap.put(SEQUENCE_ID, extractXPathValue(xpath, requestNode, "//*:LoggingInfo/*:SequenceId/text()"));
		placeholderValueMap.put(USER_ID, extractXPathValue(xpath, requestNode, "//*:LoggingInfo/*:UserId/text()"));
		placeholderValueMap.put(WORKING_DATE, extractXPathValue(xpath, requestNode, "//*:EnvParams/*:WorkingDate/text()"));
		placeholderValueMap.put(PREVIOUS_WORKING_DATE, extractXPathValue(xpath, requestNode, "//*:EnvParams/*:PreviousWorkingDate/text()"));
		placeholderValueMap.put(NEXT_WORKING_DATE, extractXPathValue(xpath, requestNode, "//*:EnvParams/*:NextWorkingDate/text()"));
		placeholderValueMap.put(RESOURCE_ID, extractXPathValue(xpath, requestNode, "//*:EnvParams/*:ResourceID/text()"));
		placeholderValueMap.put(UNIT_CODE_LEVEL_1, extractXPathValue(xpath, requestNode, "//*:EnvParams/*:UnitCodeLevel1/text()"));
		placeholderValueMap.put(UNIT_TYPE_CODE_LEVEL_1, extractXPathValue(xpath, requestNode, "//*:EnvParams/*:UnitTypeCodeLevel1/text()"));
		placeholderValueMap.put(UNIT_CODE_LEVEL_2, extractXPathValue(xpath, requestNode, "//*:EnvParams/*:UnitCodeLevel2/text()"));
		placeholderValueMap.put(UNIT_TYPE_CODE_LEVEL_2, extractXPathValue(xpath, requestNode, "//*:EnvParams/*:UnitTypeCodeLevel2/text()"));
		placeholderValueMap.put(CHANNEL_TYPE_CODE, extractXPathValue(xpath, requestNode, "//*:EnvParams/*:ChannelTypeCode/text()"));
		placeholderValueMap.put(RESOURCE_TYPE_CODE, extractXPathValue(xpath, requestNode, "//*:EnvParams/*:ResourceTypeCode/text()"));
		
		String actualInput = replaceValues(requestGetBeneficiariesByAccountNumber, placeholderValueMap);
		
		exchange.getIn().setBody(actualInput);
		
		// Perform the actual call to CustomerDeposits
		super.process(exchange);
		
		// This will leave the result of the call to the exchange body.
	}
	
	public String extractXPathValue(XPath xpath, Node requestNode, String xpathToEvaluate) throws XPathExpressionException {
		XPathExpression expression = xpath.compile(xpathToEvaluate);
		return (String) expression.evaluate(requestNode, XPathConstants.STRING);
	}
	
	public String replaceValues(String request, Map<String, String> placeholderValueMap) {
		String returnValue = request;
		for (Entry<String, String> entry : placeholderValueMap.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue();
			logger.info("Mapping from {} to {}.", key, value);
			returnValue = returnValue.replace(key, value);
		}
		return returnValue;
	}

}
