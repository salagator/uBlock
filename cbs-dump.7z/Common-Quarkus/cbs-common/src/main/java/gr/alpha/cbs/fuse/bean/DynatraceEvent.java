package gr.alpha.cbs.fuse.bean;

public class DynatraceEvent {
	private String eventType;
	private String title;
	private String description;
	private String source;
	private DynatraceEventAttachRules attachRules;

	public DynatraceEvent(String eventType, String title, String description, String source, DynatraceEventAttachRules attachRules) {
		this.eventType = eventType;
		this.title = title;
		this.description = description;
		this.source = source;
		this.attachRules = attachRules;
	}

	public String getEventType() {
		return eventType;
	}

	public String getTitle() {
		return title;
	}

	public String getDescription() {
		return description;
	}

	public String getSource() {
		return source;
	}

	public DynatraceEventAttachRules getAttachRules() {
		return attachRules;
	}
}
