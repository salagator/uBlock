package gr.alpha.cbs.fuse.support;


import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;

@Named("functionAmountTranslator")
@ApplicationScoped
@RegisterForReflection

public class AmountTranslatorXsltExtension extends ExtensionFunctionDefinition {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -521757729150776981L;

	/**
	 * 
	 */
	
	@Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("sb", "http://fuse.cbs.alpha.gr/amountTranslator/", "amountTranslator");
    }
    
    @Override
    public SequenceType[] getArgumentTypes() {
    	return new SequenceType[]{SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING};

    }
    
    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
    	return SequenceType.SINGLE_STRING;
    }
    
    @Override
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {
			
			/**
			 * 
			 */
			private static final long serialVersionUID = -2058195256803838019L;

			@Override
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
				try {
					
					String fromSystem = null;
	                String toSystem = null;
	                String amount = null;
	                String integerLength = null;
	                String fractionalLength = null;
	                
	                
	                if (arguments[0] instanceof LazySequence) {
	                	fromSystem = ((LazySequence)arguments[0]).head().getStringValue();
	                } else if (arguments[0] instanceof StringValue) {
	                	fromSystem = ((StringValue)arguments[0]).getStringValue();
	                } else {
	                	throw new Exception("Unrecognized argument type: " + arguments[1].getClass().getCanonicalName());
	                }
	                
	                if (arguments[1] instanceof LazySequence) {
	                	toSystem = ((LazySequence)arguments[1]).head().getStringValue();
	                } else if (arguments[1] instanceof StringValue) {
	                	toSystem = ((StringValue)arguments[1]).getStringValue();
	                } else {
	                	throw new Exception("Unrecognized argument type: " + arguments[1].getClass().getCanonicalName());
	                }
	                
	                if (arguments[2] instanceof LazySequence) {
	                	amount = ((LazySequence)arguments[2]).head().getStringValue();
	                } else if (arguments[2] instanceof StringValue) {
	                	amount = ((StringValue)arguments[2]).getStringValue();
	                } else {
	                	throw new Exception("Unrecognized argument type: " + arguments[1].getClass().getCanonicalName());
	                }
	                
	                if (arguments[3] instanceof LazySequence) {
	                	integerLength = ((LazySequence)arguments[3]).head().getStringValue();
	                } else if (arguments[3] instanceof StringValue) {
	                	integerLength = ((StringValue)arguments[3]).getStringValue();
	                } else {
	                	throw new Exception("Unrecognized argument type: " + arguments[1].getClass().getCanonicalName());
	                }
	                
	                if (arguments[4] instanceof LazySequence) {
	                	fractionalLength = ((LazySequence)arguments[4]).head().getStringValue();
	                } else if (arguments[4] instanceof StringValue) {
	                	fractionalLength = ((StringValue)arguments[4]).getStringValue();
	                } else {
	                	throw new Exception("Unrecognized argument type: " + arguments[1].getClass().getCanonicalName());
	                }
	                
	                
	                if(CBSConstants.REF_DATA_SYSTEM_UI.equals(fromSystem.trim()))
	                	return StringValue.makeStringValue(FormatUtils.getDecimalToHost(amount, Integer.parseInt(integerLength),Integer.parseInt(fractionalLength)));
	                else if(CBSConstants.REF_DATA_SYSTEM_OS2200.equals(fromSystem.trim()))
	                	return StringValue.makeStringValue(FormatUtils.getDecimalFromHost(amount, Integer.parseInt(integerLength)).toPlainString());
	                else 
	                	return StringValue.makeStringValue(amount) ;
	                
				} catch (Exception e) {
					throw new XPathException("Unable to translate value", e);
				}
            }
        };
    }

}
