package gr.alpha.cbs.fuse.bean;

import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.inject.Named;
import jakarta.inject.Singleton;
import org.infinispan.protostream.SerializationContextInitializer;
import org.jboss.logging.Logger;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

@Named("killSwitchBean")
@Singleton
@RegisterForReflection
public class KillSwitchBean {
    private static final Logger LOGGER = Logger.getLogger(KillSwitchBean.class);
    private static final String CONTAINER_NAME = "KillSwitchCache";
    private static RemoteDatagridClientHelper<String, String> datagridHelper;
    private SerializationContextInitializer contextInitializer = null;

    @PostConstruct
    private void postConstruct() {
        datagridHelper = new RemoteDatagridClientHelper<>();
        datagridHelper.initCacheManagerWithMarshaller(contextInitializer);
        datagridHelper.setCache(CONTAINER_NAME);
        LOGGER.debug("postConstruct called");
    }

    @PreDestroy
    private void preDestroy() {
        datagridHelper.stopCacheManager();
        LOGGER.debug("preDestroy called");
    }

    public boolean getStatusFromCache(String serviceName, String operationName) throws Exception {
        String status = null;
        String key = serviceName + operationName;
        if (key != null) {
            /* Get from Datagrid */
            status = getEntry(key);
            /* If the operation exists in datagrid return status */
            if (status != null && !status.equals("")){
                LOGGER.info("Status of serviceName " + serviceName + "and operationName " + operationName + " found in Datagrid: " + status);
                if (status.equals("true"))
                    return true;
            }
        }
        return false;
    }

    private String getEntry(String key) {
        String cacheEntry = null;
        if (datagridHelper.getCache() != null) {
            LOGGER.info("DataGridEJB: Will now try to retrieve from " + CONTAINER_NAME + " DataGrid for key:" + key);
            Object value = datagridHelper.get(key);
            if (value != null) {
                cacheEntry = (String) value;
            }
        }
        return cacheEntry;
    }

    private void putEntry(String key, String value) {
        if (datagridHelper.getCache() != null) {
            datagridHelper.put(key, value);
            LOGGER.info("DataGridEJB: Entry saved to " + CONTAINER_NAME + " DataGrid with key:" + key);
        }
        else {
            LOGGER.info("DataGridEJB: Entry not saved to " + CONTAINER_NAME + " DataGrid with key:" + key);

        }
    }
}
