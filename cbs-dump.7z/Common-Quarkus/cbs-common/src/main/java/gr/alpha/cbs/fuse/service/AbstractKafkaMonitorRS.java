package gr.alpha.cbs.fuse.service;

import jakarta.ws.rs.ApplicationPath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.core.Application;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

/**
 * To use implement a subclass of this abstract class as follows:
 * @Path("/api/kafka-monitor")
 * public class FooRS extends AbstractKafkaMonitorRS {
 *    ... implement the abstract methods ...
 *
 *    @GET
 *    @Produces(MediaType.APPLICATION_JSON)
 *    public KafkaMonitoringResponse getKafkaMonitoringResponse(@HeaderParam("kafkaKey") String kafkaKey) {
 *        return super.getKafkaMonitoringResponse(kafkaKey);
 *    }
 * }
 */
public abstract class AbstractKafkaMonitorRS {
    private static final Logger logger = LoggerFactory.getLogger(AbstractKafkaMonitorRS.class);

    /**
     * The following could have been set up as follows:
     @Inject
     @io.quarkus.agroal.DataSource("kafkaMonitorDB")
     DataSource kafkaDBDataSource;
     However since an ops-project can potentially need to monitor multiple kafka topics
    */
    public abstract DataSource getKafkaDBDataSource();

    public abstract String getOutboxTableName();
    public abstract String getOutboxTableName_History();

    public KafkaMonitoringResponse getKafkaMonitoringResponse(String kafkaKey) {
        try {
            try (Connection connection = getKafkaDBDataSource().getConnection();
                 PreparedStatement pstmt = connection.prepareStatement(
                         "SELECT ResponseXML, Status, KafkaTimestamp, Created, ReservedAt, ProcessedTimestamp " +
                                 "FROM " + getOutboxTableName_History() + " WITH (NOLOCK) WHERE KafkaKey=?")) {
                pstmt.setString(1, kafkaKey);
                ResultSet rs = pstmt.executeQuery();
                if (!rs.next()) {
                     PreparedStatement pstmt2 = connection.prepareStatement(
                             "SELECT ResponseXML, Status, KafkaTimestamp, Created, ReservedAt, ProcessedTimestamp " +
                                     "FROM " + getOutboxTableName() + " WITH (NOLOCK) WHERE KafkaKey=?");
                    pstmt2.setString(1, kafkaKey);
                    ResultSet rs2 = pstmt.executeQuery();

                    if (!rs2.next()) {
                        throw new NotFoundException("Kafka key " + kafkaKey + " not found");
                    }
                    KafkaMonitoringResponse response = new KafkaMonitoringResponse();
                    response.setContent(rs2.getString("ResponseXML"));
                    response.setStatus(rs2.getInt("Status"));
                    response.setKafkaTimestamp(toISOInstantUTC(rs2.getTimestamp("KafkaTimestamp")).orElse(null));
                    response.setCreatedTimestamp(toISOInstantUTC(rs2.getTimestamp("Created")).orElse(null));
                    response.setReservedTimestamp(toISOInstantUTC(rs2.getTimestamp("ReservedAt")).orElse(null));
                    response.setResponseTimestamp(toISOInstantUTC(rs2.getTimestamp("ProcessedTimestamp")).orElse(null));
                    return response;
                }
                KafkaMonitoringResponse response = new KafkaMonitoringResponse();
                response.setContent(rs.getString("ResponseXML"));
                response.setStatus(rs.getInt("Status"));
                response.setKafkaTimestamp(toISOInstantUTC(rs.getTimestamp("KafkaTimestamp")).orElse(null));
                response.setCreatedTimestamp(toISOInstantUTC(rs.getTimestamp("Created")).orElse(null));
                response.setReservedTimestamp(toISOInstantUTC(rs.getTimestamp("ReservedAt")).orElse(null));
                response.setResponseTimestamp(toISOInstantUTC(rs.getTimestamp("ProcessedTimestamp")).orElse(null));
                return response;
            }
        } catch (NotFoundException nfe) {
            throw nfe;
        } catch (Exception e) {
            logger.error("Unable to get Kafka monitoring response", e);
            throw new InternalServerErrorException(e.getMessage());
        }
    }

    private Optional<String> toISOInstantUTC(Timestamp bankTimestamp) {
        return Optional.ofNullable(bankTimestamp)
            .map(t -> t.toInstant()
                .atZone(ZoneId.of("Europe/Athens"))
                .withZoneSameInstant(ZoneOffset.UTC)
                .format(DateTimeFormatter.ISO_INSTANT));
    }
}
