package gr.alpha.cbs.fuse.printing;


public class TransactionDescription {
	private int index;
	private String description;
	
	public TransactionDescription(int index, String description) {
		this.index = index;
		this.description = description;
	}
	
	public int getIndex() {
		return index;
	}
	
	public String getDescription() {
		return description;
	}
	
		
}
