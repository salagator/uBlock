package gr.alpha.cbs.fuse.ejb;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import gr.alpha.cbs.fuse.ifaces.MasterDataInterface;
import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.inject.Singleton;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;
import jakarta.transaction.Transactional;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

@Named("masterDataInterface")
@Singleton
@RegisterForReflection
@Transactional(Transactional.TxType.NOT_SUPPORTED)
public class MasterDataEjb implements MasterDataInterface {

    private static final Logger LOGGER = Logger.getLogger(MasterDataEjb.class);

    @Inject
    @io.quarkus.agroal.DataSource("hostcbsparams")
    DataSource sqlDS;

    RemoteDatagridClientHelper<String,String> datagridHelper;

    @Override
    public String getMasterDetailsXML(String masterName) throws Exception{
        String queryResult = null;
        long startTime = System.currentTimeMillis();
        long endTime = 0;

        if(LOGGER.isDebugEnabled()){
            LOGGER.debug("Starting getMasterDetailsXML");
        }

        try {

            String key = null;
            String cachedValue = null;

            if (datagridHelper.getCache() != null){
                key = "MST_NM:" +masterName;
                cachedValue = datagridHelper.get(key);
            }else{
                LOGGER.warn("Will not use datagrid. Stored procedure usp_MST_GetMasterXML will be called");
            }
            if (cachedValue != null) {
                queryResult = cachedValue;
                endTime = System.currentTimeMillis() - startTime;
                if(LOGGER.isDebugEnabled()){
                    LOGGER.debug("fetched product attributes from cache (Datagrid) with key:" + key +":-> Cache time:" + endTime + "ms");
                    if(LOGGER.isTraceEnabled()){
                        LOGGER.trace("Query result:"+queryResult);
                    }
                }
            } else {
                if(LOGGER.isDebugEnabled()){
                    LOGGER.debug("fetching from database key:" + key);
                }

                queryResult = executeQueryForMasterData(masterName);
                endTime = System.currentTimeMillis() - startTime;
                if(LOGGER.isDebugEnabled()){
                    LOGGER.debug("database time:" + endTime +"ms");
                }
                if (datagridHelper.getCache() !=null){
                    datagridHelper.put(key, queryResult);

                    endTime = System.currentTimeMillis() - startTime;
                    if(LOGGER.isDebugEnabled()){
                        LOGGER.debug("Storing to datagrid time:" + endTime +"ms");
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error("Error In Master Data query");
            throw e;
        }
        if(LOGGER.isDebugEnabled()){
            LOGGER.debug("Ending getMasterDetailsXML");
        }
        return  queryResult;
    }

    String executeQueryForMasterData(String masterName) throws Exception{
        Connection conn = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        String queryResult = null;

        try {
            conn = this.sqlDS.getConnection();
            pstm = conn.prepareStatement("exec usp_MST_GetMasterXML ? ");
            pstm.setString(1, masterName);

            rs = pstm.executeQuery();
            StringBuilder sb = new StringBuilder();
            while(rs.next()) {
                queryResult = rs.getString("XML_RESULTS");
                if (queryResult != null){
                    sb.append(queryResult);
                    queryResult = sb.toString();
                }
            }
        } catch (SQLException se) {

            ErrorUtils.throwCBSException(se,
                    String.valueOf(ConstantError_Types._Technical),
                    String.valueOf(ConstantError_System_IDs._FUSE),
                    this.getClass().getCanonicalName(),
                    String.valueOf(300051),
                    String.valueOf(ConstantError_Levels._Error),
                    "Λάθος κατά την εκτέλεση Master Data MD (usp_MST_GetMasterXML "+masterName+")",
                    "",
                    "",
                    "");

        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error("Error In Master Data query");
            throw e;
        } finally {
            if(rs!=null){
                rs.close();
            }
            if(pstm!=null) {
                pstm.close();
            }
            if(conn!=null) {
                conn.close();
            }
        }

        return queryResult;
    }

    @Override
    public String getMasterDataDetailsByItemAndAttributeName (String masterName, String itemName, String attributeName) throws Exception{
        return null;
    }

    @Override
    @SuppressWarnings("unchecked")
    public HashMap<String, String> getMasterDetailsByItemNameLists (String masterName, String itemValue) throws Exception{
        HashMap<String, String> response = new HashMap<String, String>();
        String queryResult = null;
        long startTime = System.currentTimeMillis();
        long endTime = 0;

        if(LOGGER.isDebugEnabled()){
            LOGGER.debug("Starting getMasterDetailsByItemNameLists:" + masterName + ":"  + itemValue);
        }

        try {

            String key = null;
            String cachedValue = null;

            if (datagridHelper.getCache() != null){
                key = "MST_DTL_NM_LST:" + masterName +"|"+ itemValue;
                cachedValue = datagridHelper.get(key);
            }else{
                LOGGER.warn("Will not use datagrid. Stored procedure usp_MST_GetMasterXML will be called");
            }
            if (cachedValue != null) {
                queryResult = cachedValue;
                response = (HashMap<String, String>) FormatUtils.deserialize(queryResult);

                endTime = System.currentTimeMillis() - startTime;
                if(LOGGER.isDebugEnabled()){
                    LOGGER.debug("fetched product attributes from cache (Datagrid) with key:" + key +":-> Cache time:" + endTime + "ms");
                    if(LOGGER.isTraceEnabled()){
                        LOGGER.trace("Query result:"+queryResult);
                    }
                }
            } else {
                if(LOGGER.isDebugEnabled()){
                    LOGGER.debug("fetching from database key:"  + masterName + ":"  + itemValue);
                }

                response = getMasterDetailsByItemNameListsAsMap(masterName,itemValue);
                queryResult = FormatUtils.serialize(response);

                endTime = System.currentTimeMillis() - startTime;
                if(LOGGER.isDebugEnabled()){
                    LOGGER.debug("database time:" + endTime +"ms");
                }

                if (datagridHelper.getCache() !=null){
                    datagridHelper.put(key, queryResult);

                    endTime = System.currentTimeMillis() - startTime;
                    if(LOGGER.isDebugEnabled()){
                        LOGGER.debug("Storing to datagrid time:" + endTime +"ms");
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error("Error In Master Data query");
            throw e;
        }

        if(LOGGER.isDebugEnabled()){
            LOGGER.debug("Ending getMasterDetailsByItemNameLists");
        }
        return  response;
    }

    /**
     * Method read master data from database and iterates over Nodelist and creates a HashMap response.
     * @param masterName
     * @param itemValue
     * @return
     * @throws Exception
     */
    HashMap<String, String> getMasterDetailsByItemNameListsAsMap (String masterName, String itemValue) throws Exception{
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        HashMap <String,String> response = null;

        builder = factory.newDocumentBuilder();
        Document doc = builder.parse( new InputSource( new StringReader( this.executeQueryForMasterData(masterName) )));
        NodeList itemsNodes = doc.getElementsByTagName("items");
        boolean mustContinue = true;
        if(itemsNodes!=null) {

            response = new HashMap<String,String>();

            for(int i=0;i<itemsNodes.getLength();i++) {
                Element itemsElement = (Element) itemsNodes.item(i);
                NodeList itemNode = itemsElement.getElementsByTagName("item");

                if (itemNode!=null){
                    for(int j=0;j<itemNode.getLength();j++) {
                        Element itemElement = (Element) itemNode.item(j);
                        NodeList nameItemNode = itemElement.getElementsByTagName("value");
                        Element nameItemElement = (Element) nameItemNode.item(0);
                        if (itemValue.equals(nameItemElement.getTextContent())){

                            NodeList attributesNode = itemElement.getElementsByTagName("attributes");
                            if (attributesNode != null){
                                for(int k=0;k<attributesNode.getLength();k++) {
                                    Element attributesElement = (Element) attributesNode.item(k);
                                    NodeList attributeNode = attributesElement.getElementsByTagName("attribute");

                                    if (attributeNode!=null){
                                        for(int l=0;l<attributeNode.getLength();l++) {
                                            Element attributeElement = (Element) attributeNode.item(l);
                                            NodeList nameNode = attributeElement.getElementsByTagName("name");
                                            NodeList valueNode = attributeElement.getElementsByTagName("value");
                                            Element attributeValueElement = (Element) valueNode.item(0);
                                            Element attributeNameElement = (Element) nameNode.item(0);
                                            if (attributeValueElement!=null && attributeNameElement!=null){
                                                response.put(attributeNameElement.getTextContent(), attributeValueElement.getTextContent());
                                            }
                                        }
                                    }
                                }
                            }
                            mustContinue = false;
                            break;
                        }

                    }
                    if (!mustContinue)
                        break;
                }
            }
        }

        return response;
    }

    @Override
    @SuppressWarnings("unchecked")
    public HashMap<String, HashMap<String,String>> getMasterDetailsLists (String masterName) throws Exception{
        HashMap<String, HashMap<String,String>> response = new HashMap<String, HashMap<String,String>>();
        String queryResult = null;
        long startTime = System.currentTimeMillis();
        long endTime = 0;

        if(LOGGER.isDebugEnabled()){
            LOGGER.debug("Starting getMasterDetailsLists");
        }

        try {

            String key = null;
            String cachedValue = null;

            if (datagridHelper.getCache() != null){
                key = "MST_DTL_LST:" +masterName;
                cachedValue = datagridHelper.get(key);
            }else{
                LOGGER.warn("Will not use datagrid. Stored procedure usp_MST_GetMasterXML will be called");
            }
            if (cachedValue != null) {
                queryResult = cachedValue;
                response = (HashMap<String, HashMap<String,String>>)FormatUtils.deserialize(queryResult);

                endTime = System.currentTimeMillis() - startTime;
                if(LOGGER.isDebugEnabled()){
                    LOGGER.debug("fetched product attributes from cache (Datagrid) with key:" + key +":-> Cache time:" + endTime + "ms");
                    if(LOGGER.isTraceEnabled()){
                        LOGGER.trace("Query result:"+queryResult);
                    }
                }
            } else {
                if(LOGGER.isDebugEnabled()){
                    LOGGER.debug("fetching from database key:" + key);
                }

                response = getMasterDetailsListsAsMap(masterName);
                queryResult = FormatUtils.serialize(response);

                endTime = System.currentTimeMillis() - startTime;
                if(LOGGER.isDebugEnabled()){
                    LOGGER.debug("database time:" + endTime +"ms");
                }

                if (datagridHelper.getCache() !=null){
                    datagridHelper.put(key, queryResult);

                    endTime = System.currentTimeMillis() - startTime;
                    if(LOGGER.isDebugEnabled()){
                        LOGGER.debug("Storing to datagrid time:" + endTime +"ms");
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error("Error In Master Data query");
            throw e;
        }

        if(LOGGER.isDebugEnabled()){
            LOGGER.debug("Ending getMasterDetailsLists");
        }
        return  response;
    }

    HashMap<String, HashMap<String,String>> getMasterDetailsListsAsMap (String masterName) throws Exception{

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        HashMap <String,HashMap<String,String>> response = null;
        HashMap <String,String> attrList = null;

        builder = factory.newDocumentBuilder();
        Document doc = builder.parse( new InputSource( new StringReader( this.executeQueryForMasterData(masterName) )));
        NodeList itemsNodes = doc.getElementsByTagName("items");
        if(itemsNodes!=null) {

            response = new HashMap<>();

            for(int i=0;i<itemsNodes.getLength();i++) {
                Element itemsElement = (Element) itemsNodes.item(i);
                NodeList itemNode = itemsElement.getElementsByTagName("item");


                if (itemNode!=null){
                    for(int j=0;j<itemNode.getLength();j++) {
                        attrList = new HashMap<>();

                        Element itemElement = (Element) itemNode.item(j);

                        NodeList nameItemNode = itemElement.getElementsByTagName("name");
                        Element nameElement = (Element) nameItemNode.item(0);

                        NodeList userDisplayItemNode = itemElement.getElementsByTagName("userdisplay");
                        Element userDisplayElement = (Element) userDisplayItemNode.item(0);

                        NodeList valueItemNode = itemElement.getElementsByTagName("value");
                        Element valueElement = (Element) valueItemNode.item(0);

                        attrList.put("UserDisplay", userDisplayElement.getTextContent());
                        attrList.put("Value", valueElement.getTextContent());
                        attrList.put("Name", nameElement.getTextContent());

                        NodeList attributesNode = itemElement.getElementsByTagName("attributes");

                        if (attributesNode != null){
                            for(int k=0;k<attributesNode.getLength();k++) {
                                Element attributesElement = (Element) attributesNode.item(k);
                                NodeList attributeNode = attributesElement.getElementsByTagName("attribute");

                                if (attributeNode!=null){
                                    String attributeName="";
                                    String attributeValue="";

                                    for(int l=0;l<attributeNode.getLength();l++){
                                        Element attributeElement = (Element) attributeNode.item(l);
                                        NodeList nameNode = attributeElement.getElementsByTagName("name");
                                        NodeList valueNode = attributeElement.getElementsByTagName("value");
                                        Element attributeValueElement = (Element) valueNode.item(0);
                                        Element attributeNameElement = (Element) nameNode.item(0);

                                        if (attributeNameElement != null){
                                            attributeName = attributeNameElement.getTextContent();
                                            //LOGGER.info("attributeNameElement :"+attributeName);
                                        }

                                        if (attributeValueElement != null){
                                            attributeValue = attributeValueElement.getTextContent();
                                            //LOGGER.info("attributeValueElement :"+attributeValue);
                                        }else{
                                            attributeValue = "";
                                        }

                                        //LOGGER.info("Items to be inserted : "+attributeName+" - "+attributeValue);
                                        attrList.put(attributeName, attributeValue);
                                    }
                                }
                            }
                        }
                        //LOGGER.info("Final Values to be inserted: "+valueElement.getTextContent()+" - "+"List: " +attrList);
                        //use value element as key in order to be able to retrieve submap efficiently
                        response.put(valueElement.getTextContent(), attrList);
                    }
                }
            }
        }
        return response;
    }

    @PostConstruct
    void postConstruct() {
        datagridHelper = new RemoteDatagridClientHelper<>();
        datagridHelper.initCacheManager();
        datagridHelper.setCache("ref-datalookup");
        LOGGER.debug("postConstruct called");
    }

    @PreDestroy
    void preDestroy() {
        datagridHelper.stopCacheManager();
    }

}