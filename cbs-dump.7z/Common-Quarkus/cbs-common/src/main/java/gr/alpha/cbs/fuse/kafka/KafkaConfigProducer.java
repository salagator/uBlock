package gr.alpha.cbs.fuse.kafka;

import org.apache.camel.util.ObjectHelper;
import org.apache.camel.util.StringHelper;

public class KafkaConfigProducer {
	private Boolean enabled;
	private String receiveMessageFromRouteId;

	private KafkaConfigProducer(Boolean enabled, String receiveMessageFromRouteId) {
		this.enabled = enabled;
		this.receiveMessageFromRouteId = receiveMessageFromRouteId;
	}

	public Boolean isEnabled() {
		return this.enabled;
	}

	public String getReceiveMessageFromRouteId() {
		return this.receiveMessageFromRouteId;
	}

	public static class Builder {
		private Boolean enabled;
		private String receiveMessageFromRouteId;

		public Builder enabled(Boolean enabled) {
			this.enabled = enabled;
			return this;
		}

		public Builder receiveMessageFromRouteId(String receiveMessageFromRouteId) {
			this.receiveMessageFromRouteId = receiveMessageFromRouteId;
			return this;
		}

		public KafkaConfigProducer build() {
			ObjectHelper.notNull(this.enabled, "enabled");
			if (this.enabled) {
				StringHelper.notEmpty(this.receiveMessageFromRouteId, "receiveMessageFromRouteId");
			}
			return new KafkaConfigProducer(this.enabled, this.receiveMessageFromRouteId);
		}
	}
}
