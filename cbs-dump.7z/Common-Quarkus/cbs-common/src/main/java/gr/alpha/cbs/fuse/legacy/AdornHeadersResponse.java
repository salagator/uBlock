
package gr.alpha.cbs.fuse.legacy;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "loggingInfo",
    "envParams"
})
@XmlRootElement(name = "AdornHeadersResponse")
public class AdornHeadersResponse {

    @XmlElement(name = "LoggingInfo", required = true)
    protected LoggingInfoType loggingInfo;
    @XmlElement(name = "EnvParams", required = true)
    protected EnvParamsType envParams;

    
    /**
     * Gets the value of the loggingInfo property.
     * 
     * @return
     *     possible object is
     *     {@link LoggingInfoType }
     *     
     */
    public LoggingInfoType getLoggingInfo() {
        return loggingInfo;
    }

    /**
     * Sets the value of the loggingInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link LoggingInfoType }
     *     
     */
    public void setLoggingInfo(LoggingInfoType value) {
        this.loggingInfo = value;
    }

    /**
     * Gets the value of the envParams property.
     * 
     * @return
     *     possible object is
     *     {@link EnvParamsType }
     *     
     */
    public EnvParamsType getEnvParams() {
        return envParams;
    }

    /**
     * Sets the value of the envParams property.
     * 
     * @param value
     *     allowed object is
     *     {@link EnvParamsType }
     *     
     */
    public void setEnvParams(EnvParamsType value) {
        this.envParams = value;
    }

}
