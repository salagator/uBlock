package gr.alpha.cbs.fuse.support;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.config.ConfigProvider;
import org.infinispan.client.hotrod.RemoteCache;
import org.infinispan.client.hotrod.RemoteCacheManager;
import org.infinispan.client.hotrod.configuration.ClientIntelligence;
import org.infinispan.client.hotrod.configuration.ConfigurationBuilder;
import org.infinispan.client.hotrod.configuration.SaslQop;
import org.infinispan.client.hotrod.exceptions.HotRodClientException;
import org.infinispan.commons.marshall.JavaSerializationMarshaller;
import org.infinispan.commons.marshall.Marshaller;
import org.infinispan.commons.marshall.ProtoStreamMarshaller;
import org.infinispan.protostream.SerializationContextInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InvalidClassException;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class RemoteDatagridClientHelper<K,V> implements Map<K,V>{

    private RemoteCacheManager cacheManager;
    private RemoteCache<K,V> cache;

    private static final Logger LOGGER = LoggerFactory.getLogger(RemoteDatagridClientHelper.class);

    public void initCacheManager() {

        try {
            ConfigurationBuilder builder = initializeDefaultConfigurationBuilder()
                    .marshaller(new JavaSerializationMarshaller())
                    .addJavaSerialAllowList(
                            "gr.alpha.cbs.fuse.support.*",
                            "gr.alpha.cbs.fuse.common.support.*",
                            "gr.alpha.cbs.fuse.shorttermcertificates.beans",
                            "gr.alpha.cbs.fuse.loan.beans.*",
                            "java.util.ArrayList",
                            "java.util.HashMap");
            cacheManager = new RemoteCacheManager(builder.build(), true);
        } catch (Exception e) {
            LOGGER.error("Something went really wrong");
        }

    }

    public void initCacheManager(Marshaller marshaller) {

       try {
            ConfigurationBuilder builder = initializeDefaultConfigurationBuilder()
                    .marshaller(marshaller);

            cacheManager = new RemoteCacheManager(builder.build(), true);
        } catch (Exception e) {
            LOGGER.error("Something went really wrong");
        }


    }

    public <T> void initCacheManagerWithMarshaller(SerializationContextInitializer contextInitializer) {

        try {

            ConfigurationBuilder builder = initializeDefaultConfigurationBuilder()
                    .addContextInitializer(contextInitializer)
                    .marshaller(new ProtoStreamMarshaller());

            cacheManager = new RemoteCacheManager(builder.build(), true);
        } catch (Exception e) {
            LOGGER.error("Something went really wrong");
        }


    }

    public void stopCacheManager() {
        if (this.cacheManager != null) {
            cacheManager.stop();
        }
    }

    public RemoteCacheManager getCacheManager() {
        return cacheManager;
    }

    public RemoteCache<K, V> getCache() {
        return cache;
    }

    public void setCache(String cacheName){
        try{
            if(cacheManager != null){
                this.cache = cacheManager.getCache(cacheName);
            }
        }catch(HotRodClientException e) {
            LOGGER.error("Exception when retrieving cache. Suppressing...", e);
            this.cache = null;
        }
    }

    public void setModifiedCache(RemoteCache<K, V> cache){
        this.cache = cache;
    }

    private ConfigurationBuilder initializeDefaultConfigurationBuilder() {

        String dataGridHost = ConfigProvider.getConfig().getValue("cbs.infinispan-client.host", String.class);
        String dataGridPort = ConfigProvider.getConfig().getValue("cbs.infinispan-client.port", String.class);
        String dataGridUsername = ConfigProvider.getConfig().getValue("cbs.infinispan-client.auth-username", String.class);
        String dataGridPwd = ConfigProvider.getConfig().getValue("cbs.infinispan-client.auth-password", String.class);
        String clientIntelligence = ConfigProvider.getConfig().getValue("cbs.infinispan-client.client-intelligence", String.class);

        if (StringUtils.isEmpty(dataGridHost) || StringUtils.isEmpty(dataGridPort) || StringUtils.isEmpty(dataGridUsername) ||
                StringUtils.isEmpty(dataGridPwd)  || StringUtils.isEmpty(clientIntelligence)) {
            LOGGER.warn(
                    "One of dataGridHost, dataGridPort, dataGridUsername, dataGridPwd, clientIntelligence "
                            + "system params is not set. Will not use datagrid");
        }

        ConfigurationBuilder builder = new ConfigurationBuilder();
        builder.addServer()
                .host(dataGridHost)
                .port(Integer.parseInt(dataGridPort))
                .clientIntelligence(ClientIntelligence.valueOf(clientIntelligence))
                .security()
                .authentication()
                .username(dataGridUsername)
                .password(dataGridPwd)
                .realm("default")
                .saslMechanism("DIGEST-MD5")
                .saslQop(SaslQop.AUTH)
                .serverName("infinispan")
                .enable();
        builder.connectionTimeout(5000).socketTimeout(5000).maxRetries(10);

        return builder;
    }

    @Override
    public V put(K k, V v){
        try{
            return cache.put(k, v);
        }catch(HotRodClientException e) {
            LOGGER.error("Exception when putting value in cache. Suppressing...", e);
            return null;
        }
    }


    public V put(K k, V v, long lifespan, TimeUnit unit){
        try{
            return cache.put(k, v, lifespan, unit);
        }catch(HotRodClientException e) {
            LOGGER.error("Exception when putting value in cache. Suppressing...", e);
            return null;
        }
    }

    public boolean isCausedByInvalidClass(Throwable t) {
        Throwable cause = t;
        while (cause != null) {
            if (cause instanceof InvalidClassException) {
                return true;
            }
            cause = cause.getCause();
        }
        return false;
    }

    @Override
    public V get(Object key){
        try {
            return cache.get(key);
        } catch(HotRodClientException e) {
            LOGGER.error("Exception when getting value from cache. Suppressing...", e);
            return null;
        }
    }

    public V getNoErrorSuppression(Object key) throws HotRodClientException {
        try {
            return cache.get(key);
        } catch(HotRodClientException e) {
            if (isCausedByInvalidClass(e)) {
                LOGGER.error("Invalid class when getting value in cache. Suppressing... (" + e.getMessage() + ")");
                throw e;
            }
            LOGGER.error("Exception when getting value from cache. Suppressing...", e);
            return null;
        }
    }

    @Override
    public void putAll(Map<? extends K,? extends V> m) {
        try{
            cache.putAll(m);
        }catch(HotRodClientException e) {
            LOGGER.error("Exception when putting value in cache. Suppressing...", e);
        }
    }

    @Override
    public int size() {
        try{
            return cache.size();
        }catch(HotRodClientException e) {
            LOGGER.error("Exception when calling size method. Suppressing...", e);
            return 0;
        }
    }

    @Override
    public boolean isEmpty(){
        try{
            return cache.isEmpty();
        }catch(HotRodClientException e) {
            LOGGER.error("Exception when calling isEmpty method. Suppressing...", e);
            return true;
        }
    }

    @Override
    public boolean containsKey(Object key) {
        try{
            return cache.containsKey(key);
        }catch(HotRodClientException e) {
            LOGGER.error("Exception when calling containsKey method. Suppressing...", e);
            return false;
        }
    }

    @Override
    public boolean containsValue(Object value) {
        try{
            return cache.containsValue(value);
        }catch(HotRodClientException e) {
            LOGGER.error("Exception when calling containsValue method. Suppressing...", e);
            return false;
        }
    }

    @Override
    public V remove(Object key) {
        try{
            return cache.remove(key);
        }catch(HotRodClientException e) {
            LOGGER.error("Exception when removing key from cache. Suppressing...", e);
            return null;
        }
    }

    @Override
    public void clear() {
        try{
            cache.clear();
        }catch(HotRodClientException e) {
            LOGGER.error("Exception when clearing the cache. Suppressing...", e);
        }

    }

    @Override
    public Set<K> keySet() {
        try{
            return cache.keySet();
        }catch(HotRodClientException e) {
            LOGGER.error("Exception when calling keySet method. Suppressing...", e);
            return Collections.emptySet();
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public Collection<V> values() {
        try{
            return cache.values();
        }catch(HotRodClientException e) {
            LOGGER.error("Exception when calling values method. Suppressing...", e);
            return (Collection<V>) Collections.emptyMap();
        }
    }

    @Override
    public Set<java.util.Map.Entry<K, V>> entrySet() {
        try{
            return cache.entrySet();
        }catch(HotRodClientException e) {
            LOGGER.error("Exception when calling entrySet method. Suppressing...", e);
            return Collections.emptySet();
        }
    }

    public void clearAsync(){
        try{
            cache.clearAsync();
        }catch(HotRodClientException e) {
            LOGGER.error("Exception when async clearing the cache. Suppressing...", e);
        }
    }
}
