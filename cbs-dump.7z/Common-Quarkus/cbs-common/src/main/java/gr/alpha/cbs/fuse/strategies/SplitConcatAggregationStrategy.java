package gr.alpha.cbs.fuse.strategies;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.camel.Exchange;
import org.apache.camel.AggregationStrategy;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import jakarta.inject.Named;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;

@Named("splitConcatAggregationStrategy")
@ApplicationScoped
@RegisterForReflection
public class SplitConcatAggregationStrategy implements AggregationStrategy {
	
	private boolean copyHeaders = false;
	private String concatTagName;

	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
		try {
			// guard against unlikely NPE
	        if (oldExchange == null) {
	        	Document targetDocument = (Document) newExchange.getIn().getBody();
	            Element docElem = targetDocument.getDocumentElement();
	            
	        	DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	        	Document newDocument = docBuilder.newDocument();
	        	newDocument.appendChild(newDocument.createElement(concatTagName));
	        	newDocument.getDocumentElement().appendChild(newDocument.importNode(docElem,true));
	        	
	        	newExchange.getIn().setBody(newDocument);
	            
	            return newExchange;
	        }
	
	        Document srcDocument = (Document) newExchange.getIn().getBody();
	        Document targetDocument = (Document) oldExchange.getIn().getBody();
	    	targetDocument.getDocumentElement().appendChild(targetDocument.importNode(srcDocument.getDocumentElement(),true));
	    	
	    	if (copyHeaders) {
	    		newExchange.getIn().getHeaders().forEach((k,v)->{
	    			if (!oldExchange.getIn().getHeaders().containsKey(k)) {
	    				oldExchange.getIn().getHeaders().put(k, v);
	    			}
	    		});
	    	}
	    	
	    	return oldExchange;
		} catch (ParserConfigurationException pce) {
			throw new RuntimeException("Unable to aggregate.", pce);
		}
	}
	
	public void setCopyHeaders(boolean copyHeaders) {
		this.copyHeaders = copyHeaders;
	}
	
	public void setConcatTagName(String concatTagName) {
		this.concatTagName = concatTagName;
	}

}
