//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

import java.util.Collection;

public abstract class AbstractBalancerStrategy implements BalancerStrategy {
    protected void checkEmpty(Collection<?> endpoints) {
        if (endpoints.isEmpty()) {
            throw new NoEndpointFoundException("No available endpoints found");
        }
    }

    protected String locateUrl(Collection<String> baseUrls, String url) {
        return (String)baseUrls.stream().filter((baseUrl) -> url.startsWith(baseUrl)).findFirst().orElse(url);
    }
}
