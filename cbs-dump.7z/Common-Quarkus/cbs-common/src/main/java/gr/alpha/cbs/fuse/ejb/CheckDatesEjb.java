package gr.alpha.cbs.fuse.ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;
import jakarta.transaction.Transactional;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;
import org.jboss.logging.Logger;

@Named("checkDatesEjb")
@Dependent
@RegisterForReflection
public class CheckDatesEjb {
	@Inject
	@io.quarkus.agroal.DataSource("cbs")
	DataSource sqlDS;

	private static final Logger LOGGER = Logger.getLogger(CheckDatesEjb.class);

	@Transactional(Transactional.TxType.NOT_SUPPORTED)
	@SuppressWarnings("resource")
	public void checkCurrentDate(Exchange exchange) throws Exception {
		LOGGER.debug("checkCurrentDate start");
		String branchCode = exchange.getProperty(CBSConstants.HEADER_BRANCH_CODE, String.class);
		String workingDate = exchange.getProperty(CBSConstants.HEADER_WORK_DATE, String.class);

		String sqlQuery = "SELECT WorkingDate FROM REF_SystemTypes WHERE WorkingDate = ?  ";
		try(Connection conn = this.sqlDS.getConnection();PreparedStatement pstm = conn.prepareStatement(sqlQuery);) {

			pstm.setString(1, workingDate);

			try(ResultSet res1 = pstm.executeQuery()){
				if (res1.next()) {
					String sqlQuery2 = "SELECT SystemWorkingDate, UnitCode FROM DAT_WorkingDatesExceptions where UnitCode = ? AND SystemWorkingDate = ? ";
					try(PreparedStatement pstm2 = conn.prepareStatement(sqlQuery2);) {
						pstm2.setString(1, branchCode);
						pstm2.setString(2, workingDate);
						try(ResultSet res2 = pstm2.executeQuery();){
							if (res2.next()) {
								ErrorUtils.throwCBSException(null, String.valueOf(ConstantError_Types._Functional),
										String.valueOf(ConstantError_System_IDs._FUSE), this.getClass().getCanonicalName(),
										String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob),
										String.valueOf(ConstantError_Levels._Error),
										"Η ημερομηνία " + workingDate + " είναι αργία για το κατάστημα " + branchCode, "", "", "");
							}
						}
					}
				} else{
					ErrorUtils.throwCBSException(null,
							String.valueOf(ConstantError_Types._Functional),
							String.valueOf(ConstantError_System_IDs._FUSE),
							this.getClass().getCanonicalName(),
							String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob),
							String.valueOf(ConstantError_Levels._Error),
							"Η ημερομηνία " + workingDate + " δεν ταιριάζει με αυτή του συστήματος!",
							"",
							"",
							"");
				}
			}
		} catch (Exception ex) {
			if (!(ex instanceof CBSException)){
				ErrorUtils.throwCBSException(ex,
						String.valueOf(ConstantError_Types._Functional),
						String.valueOf(ConstantError_System_IDs._FUSE),
						this.getClass().getCanonicalName(),
						String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob),
						String.valueOf(ConstantError_Levels._Error),
						ex.getMessage(),
						"",
						"",
						"");
			}else{
				throw ex;
			}
		}
		LOGGER.debug("checkCurrentDate end");

	}
}
