package gr.alpha.cbs.fuse.ifaces;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface TariffManagerInterface {

    Map<String, List<HashMap<String, String>>> getCommissionsWithMandatoryFieldsOnly(String serviceName, String operationName, String amount) throws Exception;

    Map<String, List<HashMap<String, String>>> getCommissionsFull(String serviceName, String operationName, String amount, String currency, String productCategoryCode, String productCode, String customerCategory, String accountCategory,
                                                                  String commissionCarrierID, int languageIC, String commissionAttributesXML, String multiplier) throws Exception;

    List<Map<String, String>> getCommissionParameters(String serviceName, String operationName, String currency, String language, String commissionAttributesXML) throws Exception;

}
