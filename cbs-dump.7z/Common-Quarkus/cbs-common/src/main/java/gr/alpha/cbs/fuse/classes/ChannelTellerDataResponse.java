package gr.alpha.cbs.fuse.classes;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class ChannelTellerDataResponse {

    private TellerDetails responseData;

    public TellerDetails getResponseData() {
        return responseData;
    }

    public void setResponseData(TellerDetails responseData) {
        this.responseData = responseData;
    }

}
