package gr.alpha.cbs.fuse.bean;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import io.quarkus.agroal.runtime.AgroalDataSourceUtil;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.annotation.PostConstruct;
import org.apache.camel.Exchange;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

import jakarta.transaction.Transactional;
import javax.xml.transform.TransformerException;
import java.sql.*;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;

@Named("kafkaOutboxBean")
@ApplicationScoped
@RegisterForReflection
public class KafkaOutboxBean {
    private static final Logger LOGGER = Logger.getLogger(KafkaOutboxBean.class);

    javax.sql.DataSource sqlKafka;

    @PostConstruct
    protected void init() {
        if (AgroalDataSourceUtil.dataSourceIfActive("kafka_db").isPresent()) {
            LOGGER.info("Found kafka_db datasource");
            sqlKafka = AgroalDataSourceUtil.dataSourceIfActive("kafka_db").get();
        } else {
            LOGGER.warn("kafka_db datasource is not configured.");
            sqlKafka = null;
        }
    }

    @Transactional(Transactional.TxType.REQUIRED)
    public void updateOutboxRecord(Exchange exchange) throws SQLException, TransformerException {
        updateRecordCommon(exchange, 1); // SUCCEEDED
    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public void updateOutboxFailRecord(Exchange exchange) throws SQLException, TransformerException {
        updateRecordCommon(exchange, -1); // FAILED IN ERROR HANDLER IN TEMPLATE
    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public void createOutboxRecord(String kafkaOutboxTable, String kafkaOutgoingTopic, Long kafkaTimestampMillis, String kafkaKey) throws SQLException, TransformerException {
        createRecord(kafkaOutboxTable, kafkaOutgoingTopic, kafkaTimestampMillis, kafkaKey, 0); // PENDING We have
    }

    private void createRecord(String kafkaOutboxTable, String kafkaOutgoingTopic, Long kafkaTimestampMillis, String kafkaKey, int statusCode) throws SQLException, TransformerException {
        LOGGER.debug("createRecordCommon start");
        try {
            String sql = "INSERT INTO " + kafkaOutboxTable + " (kafkaKey, OutgoingTopic, ResponseXML, Status, Created, KafkaTimestamp, Reservation, ReservedAt, ProcessedTimestamp) VALUES(?,?,?,?,?,?,?,?,?)";
            LOGGER.debug("prepareStatement:" + sql);
            try (Connection conn = this.sqlKafka.getConnection();
                 PreparedStatement statement = conn.prepareStatement(sql);) {

                statement.setString(1, kafkaKey); /* kafkaKey */
                statement.setString(2, kafkaOutgoingTopic); /* OutgoingTopic */
                statement.setString(3, ""); /* ResponseXML */
                statement.setInt(4, statusCode); /* Status */
                LocalDateTime ldtEuropeAthens = LocalDateTime.now(ZoneId.of("Europe/Athens"));
                Timestamp timeNow = Timestamp.valueOf(ldtEuropeAthens);
                statement.setTimestamp(5, timeNow); /* Created */
                Instant kafkaTimestamp = Instant.ofEpochMilli(kafkaTimestampMillis);
                ZoneId utc = ZoneId.of("UTC");
                ZoneId europeAthens = ZoneId.of("Europe/Athens");
                LocalDateTime kafkaTimestampUTC = LocalDateTime.ofInstant(kafkaTimestamp, utc);
                LocalDateTime kafkaTimestampEuropeAthens = LocalDateTime.ofInstant(kafkaTimestamp, europeAthens);
                long timeDiff = ChronoUnit.MILLIS.between(kafkaTimestampUTC, kafkaTimestampEuropeAthens);
                statement.setTimestamp(6, new Timestamp(kafkaTimestamp.toEpochMilli() + timeDiff)); /* KafkaTimestamp */
                statement.setInt(7, -1 /* Record Initialization */); /* Reservation */
                statement.setTimestamp(8, timeNow); /* ReservedAt */
                statement.setTimestamp(9, timeNow); /* ProcessedTimestamp */

                statement.execute();
            }

            LOGGER.debug("createRecordCommon end");
        } catch (SQLException e) {
            LOGGER.error("Unable to create kafka outbox record", e);
            throw e;
        }
    }

    private void updateRecordCommon(Exchange exchange, int statusCode) throws SQLException, TransformerException {
        LOGGER.debug("createRecord start");
        try {
            LOGGER.debug("updateRecordCommon end");
            String sql = "UPDATE " + exchange.getProperty(CBSConstants.PROPERTY_KAFKA_OUTBOX_TABLE_NAME) + " SET Status = ?, ResponseXML = ?, Reservation = ? WHERE kafkaKey = ?";
            LOGGER.debug("prepareStatement:" + sql);
            try (Connection conn = this.sqlKafka.getConnection();
                 PreparedStatement statement = conn.prepareStatement(sql);) {

                Document document = exchange.getIn().getBody(Document.class);
                String kafkaKey = exchange.getProperty(CBSConstants.PROPERTY_KAFKA_KEY, String.class);
                String bodyAsString = FormatUtils.nodeToString(document, FormatUtils.OMIT_XML_DECLARATION_YES, FormatUtils.INDENT_NO);

                statement.setInt(1, statusCode); /* Status */
                statement.setString(2, bodyAsString); /* ResponseXML */
                statement.setInt(3, 0); /* Reservation */ /* Ready for kafka outbox publisher */
                statement.setString(4, kafkaKey); /* kafkaKey */

                statement.execute();
            }
        } catch (TransformerException | SQLException e) {
            LOGGER.error("Unable to create kafka outbox record", e);
            throw e;
        }
    }

}
