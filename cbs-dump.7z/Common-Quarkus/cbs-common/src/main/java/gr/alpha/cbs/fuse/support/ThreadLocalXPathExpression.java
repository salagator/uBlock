package gr.alpha.cbs.fuse.support;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;

public class ThreadLocalXPathExpression {
    private XPath xpath;
    private String xpathString;
    private ThreadLocal<XPathExpression> xpathExpression;

    public ThreadLocalXPathExpression(XPath xpath, String xpathString) {
        this.xpath = xpath;
        this.xpathString = xpathString;
        this.xpathExpression = new ThreadLocal<>();
    }

    public XPathExpression get() throws XPathExpressionException {
        if (xpathExpression.get() == null) {
            xpathExpression.set(xpath.compile(xpathString));
        }
        return xpathExpression.get();
    }

    public String getXPathString() {
        return xpathString;
    }
}