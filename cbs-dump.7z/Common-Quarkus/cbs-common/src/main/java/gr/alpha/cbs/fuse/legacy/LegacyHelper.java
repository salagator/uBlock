package gr.alpha.cbs.fuse.legacy;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.common.ifaces.RefDataTranslator;
import gr.alpha.cbs.fuse.tools.XMLGregorianCalendarDeserializer;
import gr.alpha.cbs.fuse.tools.XMLGregorianCalendarSerializer;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.xml.bind.JAXBContext;
import org.apache.camel.Exchange;
import org.apache.hc.core5.http.HttpStatus;
import org.eclipse.microprofile.config.ConfigProvider;
import org.jboss.logging.Logger;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import javax.naming.Context;
import javax.naming.InitialContext;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import java.io.StringWriter;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Named("legacyHelper")
@ApplicationScoped
@RegisterForReflection
public class LegacyHelper {

	private static final Logger LOGGER = Logger.getLogger(LegacyHelper.class);

    private static final String ADORN_HEADERS_ENDPOINT = ConfigProvider.getConfig().getValue("cbs.mw.adorn.headers.endpoint", String.class);
	
	public String getRefDataDescription(String parentName, String value) throws Exception{

		Context ctx = new InitialContext();
		RefDataTranslator translator = (RefDataTranslator) ctx.lookup("java:global/ops-common-ejbs/RefDataTranslatorEjb");
		
		return translator.translateData(CBSConstants.REF_DATA_SYSTEM_UI, CBSConstants.LANGUAGE_GREEK, parentName, value);
	}
	
	public String getPlaceholderValueOrEmptyString(Exchange exchange, String placeholder) throws Exception{
		
		String value = "";
		
		try{
			value = exchange.getContext().resolvePropertyPlaceholders("{{"+placeholder+"}}");		
		} catch(IllegalArgumentException e) {
			LOGGER.debug("Unable to retrieve value for placeholder with name: " + placeholder);
		}
		
		return value;		
	}
	
	public void handleParameterValues(Exchange exchange) throws Exception{
		String parameterValues = exchange.getProperty("legacyDispatcher.common.ErrorParameterValues", String.class);
		String description = exchange.getProperty("legacyDispatcher.common.ErrorDescription", String.class);
		
		List<String> parameters = Stream.of(parameterValues.split("\\|", -1)).collect(Collectors.toList()); 
		for (int i = 0 ; i < parameters.size(); i++){
			description = description.replace("{" + i + "}", parameters.get(i));
		}
		
		exchange.setProperty("legacyDispatcher.common.ErrorDescription", description);
	}
	
    public void getAdornHeaders(Exchange exchange) throws Exception{
    	ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        SimpleModule moduleXMLGregorianCalendarSerializer = new SimpleModule();
        moduleXMLGregorianCalendarSerializer.addSerializer(XMLGregorianCalendar.class, new XMLGregorianCalendarSerializer());
        mapper.registerModule(moduleXMLGregorianCalendarSerializer);
        
        SimpleModule moduleXMLGregorianCalendarDeserializer = new SimpleModule();
        moduleXMLGregorianCalendarDeserializer.addDeserializer(XMLGregorianCalendar.class, new XMLGregorianCalendarDeserializer());
        mapper.registerModule(moduleXMLGregorianCalendarDeserializer);
        
    	JsonNodeFactory jsonNodeFactory = new JsonNodeFactory(false);
        ObjectNode requestToAdornHeaders = new ObjectNode(jsonNodeFactory);        
        
        Map<String,String> loggingInfo = Stream.of(new String [][] {
            {"userId", exchange.getProperty("legacyDispatcher.common.UserId", String.class)}
        }).collect(Collectors.toMap(kv -> kv[0], kv -> kv[1]));
        
        Map<String,String> envParams = Collections.emptyMap();
        requestToAdornHeaders.set("envParams", mapper.convertValue(envParams, ObjectNode.class));
        requestToAdornHeaders.set("loggingInfo", mapper.convertValue(loggingInfo, ObjectNode.class));
        
        LOGGER.info("Endpoint used to call the adron headers micro service " + ADORN_HEADERS_ENDPOINT + "adorn");
        
        try {
            String requestToAdornHeadersAsString = mapper.writeValueAsString(requestToAdornHeaders);
            HttpRequest httpRequest = HttpRequest.newBuilder()
                    .uri(URI.create(ADORN_HEADERS_ENDPOINT + "adorn"))
                    .header("content-type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(requestToAdornHeadersAsString))
                    .build();

            HttpResponse<String> httpResponse = HttpClient.newHttpClient().send(httpRequest, HttpResponse.BodyHandlers.ofString());
//            ClientRequest client = new ClientRequest(System.getProperty("cbs.mw.adorn.headers.endpoint") + "adorn");
//            client.accept(MediaType.APPLICATION_JSON);

            LOGGER.info("Adorn headers micro service called with :" + requestToAdornHeadersAsString);
            
//            ClientResponse<String> clientResponse = client.body(MediaType.APPLICATION_JSON, requestToAdornHeadersAsString).post(String.class);
            LOGGER.info("response status :" + httpResponse.statusCode());
            
            if (httpResponse.statusCode() == HttpStatus.SC_OK) {
                JsonNode responseJSON = mapper.readTree(httpResponse.body());
                JsonParser envParamsParser = mapper.treeAsTokens(responseJSON.get("envParams"));
                JsonParser loggingInfoParser = mapper.treeAsTokens(responseJSON.get("loggingInfo"));
                EnvParamsType envParamsType = envParamsParser.readValueAs(EnvParamsType.class);
                LoggingInfoType loggingInfoType = loggingInfoParser.readValueAs(LoggingInfoType.class);
                
                ObjectFactory objectFactory = new ObjectFactory();
                AdornHeadersResponse response = objectFactory.createAdornHeadersResponse(); 
                response.setEnvParams(envParamsType);
                response.setLoggingInfo(loggingInfoType);
                
                JAXBElement<AdornHeadersResponse> jaxbResponse = new JAXBElement<AdornHeadersResponse>(new QName("AdornHeadersResponse"), AdornHeadersResponse.class, response);
                
                exchange.getIn().setBody(jaxbResponse);
                
            } else {
                throw new Exception("Unable to contact the adorn headers micro service (" + httpResponse.statusCode() + ").");
            }
        } catch (Exception e) {
        	LOGGER.info(e.getMessage());
        	ErrorUtils.throwCBSException(null ,
        			ErrorTypeModel.ERROR_TYPE_TECHNICAL,
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					this.getClass().getCanonicalName(),
					ErrorTypeModel.DEFAULT_ERROR_CODE,
					ErrorTypeModel.SEVERITY_SEVERE,
					e.getMessage(), "", "");
        }
    }

    public void convertBodyToXML(Exchange exchange) throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(AdornHeadersResponse.class);
        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
        JAXBElement<AdornHeadersResponse> root = exchange.getIn().getBody(JAXBElement.class);
        StringWriter stringWriter = new StringWriter();
        jaxbMarshaller.marshal(root, stringWriter);
        exchange.getIn().setBody(stringWriter.toString());
    }
}
