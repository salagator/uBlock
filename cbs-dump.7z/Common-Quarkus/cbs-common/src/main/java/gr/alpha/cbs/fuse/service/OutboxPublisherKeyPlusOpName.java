package gr.alpha.cbs.fuse.service;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.node.ObjectNode;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import gr.alpha.cbs.fuse.support.NonCopyingByteArrayOutputStream;
import io.smallrye.reactive.messaging.kafka.api.OutgoingKafkaRecordMetadata;
import jakarta.annotation.PostConstruct;
import jakarta.xml.bind.JAXBContext;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.common.header.internals.RecordHeaders;
import org.eclipse.microprofile.config.ConfigProvider;
import org.eclipse.microprofile.reactive.messaging.Emitter;
import org.eclipse.microprofile.reactive.messaging.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import javax.sql.DataSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public abstract class OutboxPublisherKeyPlusOpName implements SerializationHelper {
    protected static final Logger logger = LoggerFactory.getLogger(OutboxPublisherKeyPlusOpName.class);

    /**
     * The following could have been set up as follows:
     @Inject
     @io.quarkus.agroal.DataSource("kafkaOutboxDB")
     DataSource kafkaDBDataSource;
     @Inject
     @Channel("kafka-output-topic")
     Emitter<Record<String, String>> kafkaEmitter;
      * However this would mean that only one implementation of AbstractCamelRouteDrivingKafkaConsumer
      * could be used in the same Quarkus application. This is because the @Channel annotation
      * is not a qualifier, so the CDI container would not be able to distinguish between the
      * two implementations of AbstractCamelRouteDrivingKafkaConsumer.
      * So, we are leaving the responsibility of setting up the DataSource and Emitter to the
      * concrete implementations of this class, and we are getting access to them here through
      * the following abstract methods.
     */
    protected abstract DataSource getKafkaDBDataSource();
    protected abstract Emitter<String> getOutboxEmitter();

    protected String getOutboxSchemaName() {
        return "dbo";
    }

    protected abstract String getOutboxTableName();
    protected abstract String getOutboxTableName_History();

    protected abstract String getOutboxTopic();

    protected ObjectMapper objectMapper;
    protected Map<String, JAXBContext> jaxbContextMap;
    protected Map<String, ObjectWriter> objectWriterMap;
    protected Emitter<String> outboxEmitter;
    protected int batchSize;
    protected int batchSizeTop;

    @PostConstruct
    public void afterPropertiesSet() throws Exception {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd"));

        jaxbContextMap = new HashMap<>();
        objectWriterMap = new HashMap<>();

        outboxEmitter = getOutboxEmitter();

        batchSize = ConfigProvider.getConfig().getValue("cbs.mw.outbox.batch.size", String.class) != null ?
                Integer.parseInt(ConfigProvider.getConfig().getValue("cbs.mw.outbox.batch.size", String.class)) : 10;
    }

    public void pollAndPublish() throws SQLException, ExecutionException, InterruptedException,
            TimeoutException {
        logger.debug("POLL STARTED");
        try (Connection conn = getKafkaDBDataSource().getConnection()) {
            conn.setAutoCommit(false);

            try {
                List<Map<String,Object>> dbData = getOutboxUnprocessedRecords(conn);
                for (Map<String,Object> row: dbData) {
                    try {
                        Boolean isSuccessful = !row.getOrDefault("Status", -1).equals(-1);
                        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                        factory.setNamespaceAware(true);

                        if (isXML(row.getOrDefault("ResponseXML", "").toString())) {
                            DocumentBuilder builder = factory.newDocumentBuilder();
                            Document responseXML = builder.parse(new InputSource(new StringReader(row.getOrDefault("ResponseXML", "").toString())));
                            String operation = StringUtils.substringBeforeLast(responseXML.getDocumentElement().getNodeName(), "Response");
                            Document responseDocument = createResponse(responseXML, operation);
                            String bodyAsString = FormatUtils.nodeToString(responseDocument, FormatUtils.OMIT_XML_DECLARATION_YES, FormatUtils.INDENT_NO);
                            row.put("responseXML", bodyAsString);
                            if (row.getOrDefault("OutgoingTopic", "").equals(getOutboxTopic())) {
                                factory.setNamespaceAware(true);
                                NonCopyingByteArrayOutputStream outputStream = new NonCopyingByteArrayOutputStream();
                                writeOutputDocument(outputStream, operation, responseDocument, objectMapper, jaxbContextMap, objectWriterMap);
                                String stringResponse = new String(outputStream.getBuffer(), 0, outputStream.size(), StandardCharsets.UTF_8);
                                // Uniform Response JSON Object on both success and failure
                                JsonNode responseJSON = objectMapper.readTree(stringResponse);
                                ObjectNode outgoingJSON = objectMapper.createObjectNode();
                                outgoingJSON.set("requestId", responseJSON.findPath("requestId"));
                                if(StringUtils.isNotBlank(responseJSON.findPath("cbsunId").asText())){
                                    outgoingJSON.set("transactionId", responseJSON.findPath("cbsunId"));
                                }
                                else{
                                    outgoingJSON.set("transactionId", null);
                                }
                                outgoingJSON.put("success", isSuccessful);
                                if (!isSuccessful) {
                                    outgoingJSON.set("errorCode", responseJSON.findPath("errorCode"));
                                    if(StringUtils.isNotBlank(responseJSON.findPath("errorMessage").findPath("description").asText())){
                                        outgoingJSON.set("errorMessage", responseJSON.findPath("errorMessage").findPath("description"));
                                    }
                                    else{
                                        outgoingJSON.set("errorMessage", null);
                                    }
                                }
                                outgoingJSON.set("transactionData", responseJSON);
                                row.put("OutgoingRecordValue", outgoingJSON.toString());
                                row.put("responseXML", bodyAsString);
                                row.put("operation", operation);
                            } else {//case that you have more than one outgoing kafka topics and XML transformed message
                                row.put("OutgoingRecordValue", row.getOrDefault("ResponseXML", ""));
                            }
                        }
                        else{//case that you want to put non XML transformed message to kafka topic
                            // This should not happen if everything is configured correctly (in the normal case).
                            // There are use cases that need to send the response as is, so we need to handle this case.
                            // Take care that you know what you are doing, though, as this is not the "normal use case".
                            // The "normal use case" is to expose a normal CBS operation as an asynchronous operation
                            // through kafka using the outbox pattern (see
                            // https://microservices.io/patterns/data/transactional-outbox.html).
                            row.put("responseXML", row.getOrDefault("ResponseXML", "").toString());
                            row.put("OutgoingRecordValue", row.getOrDefault("ResponseXML", ""));
                        }
                    } catch (Exception e) {
                        logger.error("Error while processing outgoing record: " + row.getOrDefault("KafkaKey", ""), e);
                        row.put("OutgoingRecordValue", "{\"success\": \"false\", \"errorMessage\": \"Error while converting XML to JSON: " + e.getMessage() + "\"}");
                    }
                }
                if (dbData.isEmpty() ) {
                    conn.commit();
                    return;
                }

                for (Map<String, Object> dbdata : dbData) {
                    logger.info("Processing response for kafka key: " + dbdata.get("KafkaKey").toString() + " and operation: " + dbdata.get("OperationName").toString());
                    boolean sendOperationHeader = dbdata.containsKey("operation");
                    String operationName = dbdata.get("OperationName").toString();
                    CompletableFuture<Void> future = new CompletableFuture<>();
                    Message<String> message = Message.of(dbdata.get("OutgoingRecordValue").toString()).withAck(() -> {
                        future.complete(null);
                        return CompletableFuture.completedFuture(null);
                    }).withNack(t -> {
                        future.completeExceptionally(t);
                        return CompletableFuture.completedFuture(null);
                    });
                    OutgoingKafkaRecordMetadata<String> metadata = OutgoingKafkaRecordMetadata.<String>builder().
                            withKey(dbdata.get("KafkaKey").toString()).
                            withTopic(dbdata.get("OutgoingTopic").toString()).
                            withHeaders(sendOperationHeader ?
                                    new RecordHeaders().add("EventType", dbdata.get("operation").toString().getBytes(StandardCharsets.UTF_8)) : null).
                            build();
                    message.addMetadata(metadata);
                    try (PreparedStatement insert_stm =
                                 conn.prepareStatement("INSERT INTO [" + getOutboxSchemaName() + "].[" + getOutboxTableName_History() + "] (kafkaKey, operationName, OutgoingTopic, ResponseXML, Status, Created, KafkaTimestamp, Reservation, ReservedAt, ProcessedTimestamp) VALUES(?,?,?,?,?,?,?,?,?,?)");
                         PreparedStatement delete_stm =
                                 conn.prepareStatement("DELETE FROM [" + getOutboxSchemaName() + "].[" + getOutboxTableName() + "] WHERE KafkaKey = ?")) {

                        insert_stm.setString(1, metadata.getKey()); /* kafkaKey */
                        insert_stm.setString(2, operationName); /* OperationName */
                        insert_stm.setString(3, metadata.getTopic()); /* OutgoingTopic */
                        insert_stm.setString(4, dbdata.get("responseXML").toString()); /* ResponseXML */
                        insert_stm.setInt(5, Integer.parseInt(dbdata.get("Status").toString())); /* Status */
                        insert_stm.setString(6,  dbdata.get("Created").toString()); /* Created */
                        insert_stm.setString(7,  dbdata.get("KafkaTimestamp").toString()); /* KafkaTimestamp */
                        insert_stm.setInt(8,  2); /* Reservation */
                        insert_stm.setString(9,  dbdata.get("ReservedAt").toString());  /* ReservedAt */
                        LocalDateTime ldtEuropeAthens = LocalDateTime.now(ZoneId.of("Europe/Athens"));
                        Timestamp timestamp = Timestamp.valueOf(ldtEuropeAthens);
                        insert_stm.setTimestamp(10,  timestamp); /* ProcessedTimestamp */
                        insert_stm.execute();

                        delete_stm.setString(1, metadata.getKey());
                        delete_stm.executeUpdate();

                        outboxEmitter.send(message);
                        future.get(1, TimeUnit.SECONDS);
                    }
                }

                conn.commit();
            } catch (Exception e) {
                logger.error("Failure while processing batch", e);
                try { conn.rollback(); } catch (SQLException e1) { logger.error("Failure while rolling back batch" + e1); }
                throw e;
            }
        }
    }

    protected List<Map<String, Object>> getOutboxUnprocessedRecords(Connection conn) throws SQLException {
        List<Map<String, Object>> outboxRecords = new ArrayList<>();

        //timestamp pattern
        String pattern = "yyyy-MM-dd HH:mm:ss.SSS";
        // Create a DateTimeFormatter with the pattern
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);

        // Get the current timestamp
        LocalDateTime currentDateTime = LocalDateTime.now(ZoneId.of("Europe/Athens"));

        // Format the current timestamp using the formatter
        String formattedDateTime = currentDateTime.format(formatter);

        try (PreparedStatement ps1 = conn.prepareStatement(
                "UPDATE TOP(" + batchSize + ") [" + getOutboxSchemaName() + "].[" + getOutboxTableName() + "]\n" +
                        "SET \n" +
                        "[Reservation] = ?, [ReservedAt] = ?\n" +
                        "FROM \n" +
                        "(SELECT TOP(" + batchSize + ")\n" +
                        "KafkaKey, OperationName, KafkaTimestamp, Reservation\n" +
                        "FROM \n" +
                        "[" + getOutboxSchemaName() + "].[" + getOutboxTableName() + "] WITH (UPDLOCK, READPAST)\n" +
                        "WHERE \n" +
                        "Reservation=?\n" +
                        "ORDER BY KafkaTimestamp ASC) AS t1 \n" +
                        "WHERE [" + getOutboxSchemaName() + "].[" + getOutboxTableName() + "].KafkaKey = t1.KafkaKey AND \n" +
                        "[" + getOutboxSchemaName() + "].[" + getOutboxTableName() + "].OperationName = t1.OperationName AND t1.Reservation = ?;"
        )
        ) {
            ps1.setInt(1, 1 /* RESERVED */);
            ps1.setString(2, formattedDateTime);
            ps1.setInt(3, 0 /* ADDED */);
            ps1.setInt(4, 0 /* ADDED */);
            ps1.executeUpdate();

        }
        try(PreparedStatement ps2 = conn.prepareStatement(
                "SELECT TOP(" + batchSize + ") [KafkaKey],[OperationName],[OutgoingTopic],[ResponseXML],[Status],[Created],[KafkaTimestamp],[ReservedAt] \n" +
                        "FROM \n" +
                        "[" + getOutboxSchemaName() + "].[" + getOutboxTableName() + "] WITH (UPDLOCK, READPAST) \n"+
                        "WHERE \n" +
                        "Reservation = ? \n" +
                        "ORDER BY \n" +
                        "KafkaTimestamp ASC"
        )
        ){
            ps2.setInt(1, 1 /* RESERVED */);
            try(ResultSet rs = ps2.executeQuery()) {
                ResultSetMetaData meta = rs.getMetaData();
                int columns = meta.getColumnCount();
                while (rs.next()) {
                    Map<String, Object> recordData = new HashMap<>(columns);
                    for (int i = 1; i <= columns; i++) {
                        recordData.put(meta.getColumnName(i), rs.getObject(i));
                    }
                    outboxRecords.add(recordData);
                }
            }
        }
        logger.debug("Polling found " + outboxRecords.size() + " records.");
        logger.debug("POLL ENDED WITH: " + outboxRecords);
        return outboxRecords;
    }

    protected static boolean isXML(String data) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            InputSource is = new InputSource(new StringReader(data));
            Document doc = builder.parse(is);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    /**
     * Method to get the root element of the request XML.<br>
     * Default behavior is to get the first element child from the root.<br>
     * <p>
     * Override this method for other behavior
     *
     * @param rootElement Initial SOAP request XML
     * @return Root element
     */
    protected Element getXMLRootElement(Element rootElement) {
        Element newRoot = null;

        if (requestWithPayloadOnly()) {
            Node childNode = rootElement.getFirstChild();
            while (childNode != null && childNode.getNodeType() != Node.ELEMENT_NODE) {
                childNode = childNode.getNextSibling();
            }
            newRoot = (Element) childNode;
        } else {
            newRoot = rootElement;
        }

        return newRoot;
    }

    protected Document createResponse(Document response, String operation) throws ParserConfigurationException {
        if (isResponseUnmodified()) {
            return response;
        }

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.newDocument();

        // root element
        Element rootElement = doc.createElementNS(response.getDocumentElement().getNamespaceURI(), operation + "Response");

        doc.appendChild(rootElement);

        Node nNode = null;
        if (keepRootElement() == ResponseLayout.WRAP) {
            nNode = doc.importNode(response.getDocumentElement(), true);
        } else if (keepRootElement() == ResponseLayout.WRAP_UNWRAP) {
            nNode = doc.importNode(getXMLRootElement(response.getDocumentElement()), true);
        } else {
            return response;
        }
        rootElement.appendChild(nNode);

        return doc;
    }

    /**
     * Override in case where the response payload should be wrapped.
     *
     * @return true/false
     */
    protected ResponseLayout keepRootElement() {
        return ResponseLayout.WRAP;
    }

    /**
     * Override in case the initial request will be handled as is.
     *
     * @return
     */
    protected boolean requestWithPayloadOnly() {
        return true;
    }

    /**
     * Override in case the response as written in the table can go back unmodified
     *
     * @return
     */
    protected boolean isResponseUnmodified() {
        return true;
    }

}
