package gr.alpha.cbs.fuse.kafka;

import org.apache.camel.util.StringHelper;

public class KafkaConfig {
	private String processName;
	private KafkaConfigContext contextConfig;
	private KafkaConfigConsumer consumerConfig;
	private KafkaConfigProducer producerConfig;

	private KafkaConfig(String processName, KafkaConfigContext contextConfig, KafkaConfigConsumer consumerConfig, KafkaConfigProducer producerConfig) {
		this.processName = processName;
		this.contextConfig = contextConfig;
		this.consumerConfig = consumerConfig;
		this.producerConfig = producerConfig;
	}

	public String getProcessName() {
		return this.processName;
	}

	public KafkaConfigContext getContextConfig() {
		return this.contextConfig;
	}

	public KafkaConfigConsumer getConsumerConfig() {
		return this.consumerConfig;
	}

	public KafkaConfigProducer getProducerConfig() {
		return this.producerConfig;
	}

	public static class Builder {
		private String processName;
		private KafkaConfigContext contextConfig;
		private KafkaConfigConsumer consumerConfig;
		private KafkaConfigProducer producerConfig;

		public Builder processName(String processName) {
			this.processName = processName;
			return this;
		}

		public Builder contextConfig(KafkaConfigContext contextConfig) {
			this.contextConfig = contextConfig;
			return this;
		}

		public Builder consumerConfig(KafkaConfigConsumer consumerConfig) {
			this.consumerConfig = consumerConfig;
			return this;
		}

		public Builder producerConfig(KafkaConfigProducer producerConfig) {
			this.producerConfig = producerConfig;
			return this;
		}

		public KafkaConfig build() {
			StringHelper.notEmpty(this.processName, "processName");
			return new KafkaConfig(this.processName, this.contextConfig, this.consumerConfig, this.producerConfig);
		}
	}
}
