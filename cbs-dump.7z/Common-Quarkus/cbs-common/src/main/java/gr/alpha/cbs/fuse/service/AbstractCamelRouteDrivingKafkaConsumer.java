package gr.alpha.cbs.fuse.service;

import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import gr.alpha.cbs.fuse.bean.KafkaKeyPlusOpNameOutboxBean;
import gr.alpha.cbs.fuse.bean.KafkaOutboxBean;
import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.common.logging.LoadLoggingHelper;
import gr.alpha.cbs.fuse.common.tools.AlternativePathsFlagHolder;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import gr.alpha.cbs.fuse.exceptions.BadRequestException;
import gr.alpha.cbs.fuse.logging.LoggingMDCInterceptor;
import gr.alpha.cbs.fuse.support.NonCopyingByteArrayOutputStream;
import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import gr.alpha.cbs.fuse.tools.AppMonitoringHelper;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpHeaderValues;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.smallrye.faulttolerance.api.RateLimitException;
import io.smallrye.faulttolerance.api.RateLimitType;
import io.smallrye.faulttolerance.api.TypedGuard;
import io.smallrye.reactive.messaging.kafka.api.OutgoingKafkaRecordMetadata;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.support.DefaultExchange;
import org.apache.commons.collections.IteratorUtils;
import org.apache.commons.io.IOUtils;
import org.apache.hc.core5.http.HttpStatus;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Header;
import org.eclipse.microprofile.config.ConfigProvider;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.faulttolerance.exceptions.BulkheadException;
import org.eclipse.microprofile.faulttolerance.exceptions.CircuitBreakerOpenException;
import org.eclipse.microprofile.faulttolerance.exceptions.TimeoutException;
import org.eclipse.microprofile.reactive.messaging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import jakarta.inject.Inject;
import javax.sql.DataSource;
import javax.xml.XMLConstants;
import jakarta.xml.bind.JAXBContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public abstract class AbstractCamelRouteDrivingKafkaConsumer implements SerializationHelper {
    private static final Logger logger = LoggerFactory.getLogger(AbstractCamelRouteDrivingKafkaConsumer.class);

    private static final int MAX_RESPONSE_SIZE = 10000;
    private static final boolean TRIMMING_RESPONSE = Boolean.parseBoolean(ConfigProvider.getConfig().getOptionalValue("do.not.trim.camel.responses", String.class).orElse("true"));
    private static final String FAULT_TOLERANCE_GUARD_CACHE_NAME = "FaultToleranceGuardCache";

    private RemoteDatagridClientHelper<String, String> datagridHelper;

    private final Map<String, TypedGuard<Void>> typedGuardMap = Collections.synchronizedMap(new HashMap<>());

    private final Map<String, TypedGuard<CompletionStage<Void>>> asynchronousTypedGuardMap = Collections.synchronizedMap(new HashMap<>());

    protected boolean faultToleranceEnabled() {
        return false;
    }

    protected boolean useStandardFaultToleranceSettings() {
        return false;
    }

    /**
     * Override this to set up fault tolerance for various operations.
     * If overridden, make sure to initialize the map only once by setting an
     * instance variable to the return value of this method in the constructor.
     * Otherwise, the fault tolerance logic will not work correctly.
     * Also make sure that the map is synchronized. See the example in this class on how to do this.
     * @return the map from operation name to FaultTolerance instance.
     */
    protected Map<String, TypedGuard<CompletionStage<Void>>> getAsynchronousTypedGuardMap() {
        return asynchronousTypedGuardMap;
    }

    /**
     * Re-initialize the typed guard map. Called from the clearFaultToleranceGuards()
     * method that is used to re-read the fault tolerance settings from the datagrid.
     */
    protected void reinitializeAsynchronousTypedGuardMap() {
    }

    /**
     * Override this to set up fault tolerance for various operations.
     * If overridden, make sure to initialize the map only once by setting an
     * instance variable to the return value of this method in the constructor.
     * Otherwise, the fault tolerance logic will not work correctly.
     * Also make sure that the map is synchronized. See the example in this class on how to do this.
     * @return the map from operation name to FaultTolerance instance.
     */
    protected Map<String, TypedGuard<Void>> getTypedGuardMap() {
        return typedGuardMap;
    }

    /**
     * Re-initialize the typed guard map. Called from the clearFaultToleranceGuards()
     * method that is used to re-read the fault tolerance settings from the datagrid.
     */
    protected void reinitializeTypedGuardMap() {
    }

    /**
     * Override in case where there are operations that should be handled asynchronously.
     * This would be so that @Bulkhead for the operation.
     *
     * @return a set of operation names
     */
    protected Set<String> asynchronousOperations() {
        return Collections.emptySet();
    }

    protected abstract Map<String, Object> getHeaders(String operation, Element requestRootElement);

    // It should be Implemented to Set 3 Important Headers
    // 1 Operation Name map.put(CBSConstants.HEADER_TRANSACTION_NAME,operation)
    // 2 Flow Name hardCoded from EventRegistry map.put(CBSConstants.HEADER_TRANSACTION_FLOW, flow-name )
    // 3 Service Name "hard coded for each service"
    protected abstract void setServiceOperationInfo(String flowName, String operation, Map<String, Object> property);

    protected LoggingMDCInterceptor loggingMDCInterceptor;

    /*
     * The following three member variables are state that is used as a performance optimization.
     * Construction of the Jackson ObjectMapper is expensive and is only done once in the
     * initialization of this object. According to the documentation, keeping and reusing
     * ObjectReader objects is thread-safe and light weight:
     * https://fasterxml.github.io/jackson-databind/javadoc/2.8/com/fasterxml/jackson/databind/ObjectReader.html
     * So we cache them in the respective <code>HashMap</code>, keyed by the class name they
     * "represent".
     *
     * Please note that ObjectWriters are not cached in this class, as the responsibility
     * of converting the response XML to JSON is not part of this class. That responsibility
     * lies to the reader of the outbox table (if (s)he so wishes to perform such a conversion).
     *
     * Similarly, construction of the JAXBContext is also expensive, so we only do it lazily
     * the first time a particular class is marshalled or unmarshalled. We cache such objects
     * in a <code>HashMap</code>, keyed by the class name they "represent".
     */
    private final ObjectMapper objectMapper;
    private final Map<String, JAXBContext> jaxbContextMap;
    private final Map<String, ObjectReader> objectReaderMap;

    private ExecutorService pool;

    protected String kafkaOutboxTableName;
    protected String kafkaOutboxTableName_History;
    protected String kafkaOutputTopic;

    /**
     * Override this method to set the operation name as part of the idempotency check for messages.
     * This means that both the operation name and the kafka message key will be used to uniquely identify a message.
     * Default is false.
     * @return Whether to use the operation name as part of the idempotency check for messages.
     */
    protected boolean useOperationNameAsPartOfIdempotencyCheckForMessages() {
        return false;
    }

    /**
     * The following could have been set up as follows:
     @Inject
     @io.quarkus.agroal.DataSource("kafkaOutboxDB")
     DataSource kafkaDBDataSource;
     @Inject
     @Channel("kafka-output-topic")
     Emitter<Record<String, String>> kafkaEmitter;
     * However this would mean that only one implementation of AbstractCamelRouteDrivingKafkaConsumer
     * could be used in the same Quarkus application. This is because the @Channel annotation
     * is not a qualifier, so the CDI container would not be able to distinguish between the
     * two implementations of AbstractCamelRouteDrivingKafkaConsumer.
     * So, we are leaving the responsibility of setting up the DataSource and Emitter to the
     * concrete implementations of this class, and we are getting access to them here through
     * the following abstract methods.
     */
    protected abstract DataSource getKafkaDBDataSource();
    protected abstract Emitter<String> getKafkaEmitter();
    @Inject
    CamelContext camelContext;

    @Inject
    KafkaOutboxBean kafkaOutboxBean;
    @Inject
    KafkaKeyPlusOpNameOutboxBean kafkaKeyPlusOpNameOutboxBean;

    public AbstractCamelRouteDrivingKafkaConsumer() {
        this.objectMapper= initObjectMapper();

        this.loggingMDCInterceptor = new LoggingMDCInterceptor();
        this.jaxbContextMap = new HashMap<>();
        this.objectReaderMap = new HashMap<>();

        if (isProcessingOnExecutor()) {
            int threadCount = Integer.parseInt(ConfigProvider.getConfig().getOptionalValue("cbs.mw.kafka.pool.size", String.class).orElse("20"));
            logger.info("Setting up executor thread pool with a size of {}", threadCount);
            pool = Executors.newFixedThreadPool(threadCount);
        }
    }

    @PostConstruct
    public void init() {
        datagridHelper = new RemoteDatagridClientHelper<>();
        datagridHelper.initCacheManagerWithMarshaller(null);
        datagridHelper.setCache(FAULT_TOLERANCE_GUARD_CACHE_NAME);
        logger.debug("postConstruct called");
    }

    @PreDestroy
    public void cleanup() {
        if (datagridHelper != null) {
            datagridHelper.stopCacheManager();
        }
        logger.debug("preDestroy called");
    }

    public String getKafkaOutboxTableName() {
        return kafkaOutboxTableName;
    }

    public void setKafkaOutboxTableName(String kafkaOutboxTableName) {
        this.kafkaOutboxTableName = kafkaOutboxTableName;
    }

    public String getKafkaOutboxTableName_History() {
        return kafkaOutboxTableName_History;
    }

    public void setKafkaOutboxTableName_History(String kafkaOutboxTableName_History) {
        this.kafkaOutboxTableName_History = kafkaOutboxTableName_History;
    }

    public String getKafkaOutputTopic() {
        return kafkaOutputTopic;
    }

    public void setKafkaOutputTopic(String kafkaOutputTopic) {
        this.kafkaOutputTopic = kafkaOutputTopic;
    }

    /**
     * By default processing on the same thread as the message listener. Override this method, if there
     * is a need to process on a different thread in order to acknowledge earlier to the kafka topic.
     * If returning true, then the ackMode on the kafka listener must be set to RECORD and the enable.auto.commit
     * must be set to true.
     * @return true iff processing on the executor service threads.
     */
    public boolean isProcessingOnExecutor() {
        return false;
    }

    /**
     * In order to use this you must supply a function in the concrete class:
     * @Incoming("kafka-inbox")
     * @Acknowledgment(Acknowledgment.Strategy.POST_PROCESSING)
     * public void consume(ConsumerRecord<String, String> record) {
     *      super.consumeImpl(record);
     * }
     *
     * Default acknowledgement strategy is Strategy.POST_PROCESSING, which is what we want for the non-executor case.
     */

    public void consumeImpl(ConsumerRecord<String, String> record) {
        logger.info("Kafka message @ offset: {} - received.", record.offset());
        if (logger.isDebugEnabled()) {
            logger.debug("Received Message @ offset: {}, ({}, {}), partition: {}, topic: {}.", record.offset(), record.key(), record.value(), record.partition(), record.topic());
            for (Header header : record.headers()) {
                logger.debug("  Message contains header: ({}, {}).", header.key(), new String(header.value(), StandardCharsets.UTF_8));
            }
        }
        if (isProcessingOnExecutor()) {
            pool.submit(() -> actualProcess(record));
        } else {
            // Process on the same thread
            actualProcess(record);
        }
        logger.info("Kafka key: {} @ offset: {} - onCommit completed.",record.key(), record.offset());
    }

    private void actualProcess(ConsumerRecord<String, String> record) {
        String operationName;
        try {
            operationName = new String(record.headers().lastHeader("Operation").value(), StandardCharsets.UTF_8);
        } catch (NullPointerException e) {
            logger.error("Kafka key: " + record.key() + " @ offset: " + record.offset() + " - No operation name found in the headers. Failing call.", e);
            writeKafkaErrorMessage(record.key(), HttpStatus.SC_BAD_REQUEST, "Bad Request");
            return;
        }
        if (!isRecordProcessed(record)) {
            if (useFaultTolerance(operationName)) {
                processWithFaultToleranceErrorHandling(operationName, record);
            } else {
                process(record);
            }
        } else {
            logger.info("Kafka key: {} operation: {} @ offset: {} - already processed.", record.key(), operationName, record.offset());
        }
        logger.info("Kafka  key: {}  operation: {} @ offset: {} - processing completed.", record.key(), operationName, record.offset());
    }

    protected boolean isRecordProcessed(ConsumerRecord<String, String> record){
        String operationName = new String(record.headers().lastHeader("Operation").value(), StandardCharsets.UTF_8);
        try {
            try (Connection connection = getKafkaDBDataSource().getConnection()) {
                if (useOperationNameAsPartOfIdempotencyCheckForMessages()) {
                    try (PreparedStatement ps = connection.prepareCall("SELECT COUNT(kafkaKey) FROM " + kafkaOutboxTableName + " WHERE kafkaKey=? AND operationName=?")) {
                        ps.setString(1, record.key());
                        ps.setString(2, operationName);
                        try (ResultSet rs = ps.executeQuery()) {
                            if (rs.next() && rs.getInt(1) > 0) {
                                return true;
                            }
                        }
                    }
                } else {
                    try (PreparedStatement ps = connection.prepareCall("SELECT COUNT(kafkaKey) FROM " + kafkaOutboxTableName + " WHERE kafkaKey=?")) {
                        ps.setString(1, record.key());
                        try (ResultSet rs = ps.executeQuery()) {
                            if (rs.next() && rs.getInt(1) > 0) {
                                return true;
                            }
                        }
                    }
                }
                // If we reach this point, then we did not find the record in the outbox table proper.
                // Look at the history table.
                if (useOperationNameAsPartOfIdempotencyCheckForMessages()) {
                    PreparedStatement ps2 = connection.prepareCall("SELECT COUNT(kafkaKey) FROM " + kafkaOutboxTableName_History + " WHERE kafkaKey=? AND operationName=?");
                    ps2.setString(1, record.key());
                    ps2.setString(2, operationName);
                    try (ResultSet rs2 = ps2.executeQuery()) {
                        if (!rs2.next() || rs2.getInt(1) == 0) {
                            logger.debug("Unable to get outbox existence for record with key: " + record.key() + " and operation: " + operationName);
                            return false;
                        } else {
                            return true;
                        }
                    }
                } else {
                    PreparedStatement ps2 = connection.prepareCall("SELECT COUNT(kafkaKey) FROM " + kafkaOutboxTableName_History + " WHERE kafkaKey=?");
                    ps2.setString(1, record.key());
                    try (ResultSet rs2 = ps2.executeQuery()) {
                        if (!rs2.next() || rs2.getInt(1) == 0) {
                            logger.debug("Unable to get outbox existence for record with key: " + record.key() + " and operation: " + operationName);
                            return false;
                        } else {
                            return true;
                        }
                    }
                }
            }
        } catch (SQLException e) {
            logger.error("Cannot execute the select query for record with key: " + record.key() + " and operation: " + operationName, e);
            return false;
        }
    }

    public void clearFaultToleranceGuards() {
        if (useStandardFaultToleranceSettings()) {
            getTypedGuardMap().clear();
            logger.info("Cleared all standard fault tolerance guards.");
        }
        reinitializeTypedGuardMap();
        reinitializeAsynchronousTypedGuardMap();
    }

    protected void processWithFaultToleranceErrorHandling(String operation, ConsumerRecord<String, String> record) {
        try {
            if (asynchronousOperations().contains(operation)) {
                TypedGuard<CompletionStage<Void>> guard = getAsynchronousTypedGuardMap().get(operation);
                if (guard == null) {
                    logger.info("Although we use fault tolerance, no guard is defined for operation {}. Invoking without fault tolerance.", operation);
                    process(record);
                } else {
                    CompletionStage<Void> completionStage = getAsynchronousTypedGuardMap().get(operation).get(() -> CompletableFuture.supplyAsync(() ->
                            process(record)));
                    completionStage.toCompletableFuture().join();
                }
            } else {
                TypedGuard<Void> guard = getTypedGuardMap().get(operation);
                if (guard == null) {
                    logger.info("Although we use fault tolerance, no guard is defined for operation {}. Invoking without fault tolerance.", operation);
                    process(record);
                } else {
                    guard.get(() -> process(record));
                }
            }
        } catch (CompletionException completionException) {
            logger.error("Completion exception while processing request.", completionException);
            throw completionException;
        } catch (ErrorEncounteredException technicalErrorEncounteredException) {
            logger.error("Technical error encountered while processing request: " + technicalErrorEncounteredException.getMessage());
        } catch (CircuitBreakerOpenException circuitBreakerOpenException) {
            logger.error("Circuit breaker is open, cannot process request: " + circuitBreakerOpenException.getMessage());
            handleCircuitBreakerOpenException(operation, record, kafkaOutputTopic, circuitBreakerOpenException);
        } catch (BulkheadException bulkheadException) {
            logger.error("Bulkhead limit reached, cannot process request: " + bulkheadException.getMessage());
            handleBulkheadException(operation, record, kafkaOutputTopic, bulkheadException);
        } catch (TimeoutException timeoutException) {
            logger.error("Request timed out: " + timeoutException.getMessage());
            handleTimeoutException(operation, record, kafkaOutputTopic, timeoutException);
        } catch (RateLimitException rateLimitException) {
            logger.error("Rate limit exceeded, cannot process request: " + rateLimitException.getMessage());
            handleRateLimitException(operation, record, kafkaOutputTopic, rateLimitException);
        }
    }

    protected void handleCircuitBreakerOpenException(String operation, ConsumerRecord<String, String> record, String kafkaOutputTopic, CircuitBreakerOpenException exception) {
        logger.error("Handling Circuit Breaker Open Exception: " + exception.getMessage() + ". " +
                "This method should not be called. Implementors that use circuit breaker functionality " +
                "should override AbstractCamelRouteDrivingKafkaConsumer.handleCircuitBreakerOpenException() " +
                "to provide a custom implementation.");
    }

    protected void handleBulkheadException(String operation, ConsumerRecord<String, String> record, String kafkaOutputTopic, BulkheadException exception) {
        logger.error("Handling Bulkhead Exception: " + exception.getMessage() + ". " +
                "This method should not be called. Implementors that use bulkhead functionality " +
                "should override AbstractCamelRouteDrivingKafkaConsumer.handleBulkheadException() " +
                "to provide a custom implementation.");
    }

    protected void handleTimeoutException(String operation, ConsumerRecord<String, String> record, String kafkaOutputTopic, TimeoutException exception) {
        logger.error("Handling Timeout Exception: " + exception.getMessage() + ". " +
                "This method should not be called. Implementors that use timeout functionality " +
                "should override AbstractCamelRouteDrivingKafkaConsumer.handleTimeoutException() " +
                "to provide a custom implementation.");
    }

    protected void handleRateLimitException(String operation, ConsumerRecord<String, String> record, String kafkaOutputTopic, RateLimitException exception) {
        logger.error("Handling Rate Limit Exception: " + exception.getMessage() + ". " +
                "This method should not be called. Implementors that use rate limiting functionality " +
                "should override AbstractCamelRouteDrivingKafkaConsumer.handleRateLimitException() " +
                "to provide a custom implementation.");
    }

    protected Void process(ConsumerRecord<String, String> record) {
        if (logger.isDebugEnabled()) {
            logger.debug("Operation requested is: {}.", new String(record.headers().lastHeader("Operation").value(), StandardCharsets.UTF_8));
        }

        String operationName = new String(record.headers().lastHeader("Operation").value(), StandardCharsets.UTF_8);

        logger.info("Operation name from the kafka record is: {}", operationName);


        // Move the outbox record creation here, before any processing is done.
        // This is moved here to ensure that we do not write anything to the database
        // if the fault tolerance checks fail (e.g. circuit breaker is open, rate limit exceeded, etc).
        // If we wrote the outbox record after the processing, then we would have a record
        // in the outbox table, but no corresponding processing done, which would be incorrect.
        try {
            if (useOperationNameAsPartOfIdempotencyCheckForMessages()) {
                kafkaKeyPlusOpNameOutboxBean.createOutboxRecord(kafkaOutboxTableName, getKafkaOutputTopic(), record.timestamp(), record.key(), operationName);
            } else {
                kafkaOutboxBean.createOutboxRecord(kafkaOutboxTableName, getKafkaOutputTopic(), record.timestamp(), record.key());
            }
        } catch (Exception e) {
            // Short circuit the execution of the message, as failing to insert the outbox record is a terminal condition.
            logger.error("Kafka key: " + record.key() + " and operation: " + operationName + " @ offset: " + record.offset() + " - Unable to create outbox record. Failing call.", e);
            writeKafkaErrorMessage(record.key(), HttpStatus.SC_INTERNAL_SERVER_ERROR, "Internal Server Error");
            return null;
        }

        long startTime = System.currentTimeMillis();
        try {
            String operation = null;
            String flowName = null;
            Element requestRootElement = null;

            // WORKAROUND FOR EDG MALFORMED REQUEST: IGNORE NON-STANDARD REQUEST FIELDS
            ObjectNode requestJSON = (ObjectNode) objectMapper.readTree(record.value());
            List<String> standardFields = Arrays.asList("loggingInfo", "envParams");
            List<String> requestFields = IteratorUtils.toList(requestJSON.fieldNames());
            List<String> nonStandardFields = requestFields.stream()
                    .skip(1)
                    .filter(item -> !standardFields.contains(item))
                    .collect(Collectors.toList());
            requestJSON.remove(nonStandardFields);

            NonCopyingByteArrayOutputStream servletBodyContents =
                    new NonCopyingByteArrayOutputStream(requestJSON.toString().getBytes(StandardCharsets.UTF_8));
            String servletBodyContentsAsString = new String(
                    servletBodyContents.getBuffer(), 0, servletBodyContents.size(), StandardCharsets.UTF_8);

            if (!servletBodyContentsAsString.contains("envParams")) {
                // EnvParams is missing from the request. It must be a call from an external system, that knows not
                // of CBS intricacies. Call the adorn headers micro service to "tack on" the logging info and
                // env parameters necessary for the Fuse call to work properly. The servletBodyContents object (and
                // most importantly its underlying buffer) is modified in the process accordingly.
                servletBodyContents = adornHeaders(record, objectMapper, servletBodyContents);
            }

            Document requestDocument;
            try {
                requestDocument = getInputDocument(
                        new ByteArrayInputStream(servletBodyContents.getBuffer(), 0, servletBodyContents.size()),
                        operationName, objectMapper, jaxbContextMap, objectReaderMap);
                requestRootElement = requestDocument.getDocumentElement();
                operation = requestRootElement.getLocalName();
            } catch (Exception e) {
                logger.error("Unable to parse request JSON to XML.", e);
                // TODO write to the database for this record or send to the outgoing topic directly?
                writeKafkaErrorMessage(record.key(), HttpStatus.SC_BAD_REQUEST, "Bad Request");
                return null;
            }

            DOMSource inputDOMSource = new DOMSource(requestRootElement);
            loggingMDCInterceptor.processMessageIn(inputDOMSource);

            if (logger.isDebugEnabled()) {
                logger.debug("Operation called: '" + operation + "'.");
            }

            AlternativePathsFlagHolder.setAlternativePathsFlag(
                    ConfigProvider.getConfig().getOptionalValue("cbs.common.tools.formatutils.alternativepaths", Boolean.class).orElse(false)
            );
            Boolean operationSpecificSetting =
                    ConfigProvider.getConfig().getOptionalValue("cbs.common.tools.formatutils." + operation + ".alternativepaths", Boolean.class).orElse(null);
            if (operationSpecificSetting != null) {
                AlternativePathsFlagHolder.setAlternativePathsFlag(operationSpecificSetting);
            }

            // Get the headers from the concrete class
            Map<String, Object> headers = getHeaders(operation, requestRootElement);

            if(headers.containsKey(CBSConstants.HEADER_XSD_PATHS)){
                boolean xsdValidation = validateXMLSchema((String[]) headers.get(CBSConstants.HEADER_XSD_PATHS), requestDocument);
                logger.info("XSD validation result:" + xsdValidation);
                if(!xsdValidation){
                    throw new BadRequestException("XSD validation failed");
                }
            }

            // Lookup the camel context and then the producer template to use.
            ProducerTemplate producerTemplate = camelContext.createProducerTemplate();

            Element payload = getXMLRootElement(requestRootElement);
            flowName = payload.getLocalName();

            // Log the input
            logger.info("Call web service " + flowName + "." + operation + " RequestBody:\n" + formatNodeToString(operation, requestRootElement));

            setServiceOperationInfo(flowName, operation, headers);

            // Perform the call to the camel route (to the template first, which
            // will call the proper route passed in the header above).
            Exchange exchange = new DefaultExchange(camelContext);
            headers.forEach(exchange::setProperty);
            exchange.setProperty(CBSConstants.PROPERTY_KAFKA_ASYNC_CALL, "true");
            exchange.setProperty(CBSConstants.PROPERTY_KAFKA_KEY, record.key());
            exchange.setProperty(CBSConstants.PROPERTY_KAFKA_USE_OPERATION_NAME_AS_IDEMPOTENCY_CHECK, useOperationNameAsPartOfIdempotencyCheckForMessages());
            exchange.setProperty(CBSConstants.PROPERTY_KAFKA_TIMESTAMP, record.timestamp());
            exchange.setProperty(CBSConstants.PROPERTY_KAFKA_OUTBOX_TABLE_NAME, kafkaOutboxTableName);
            exchange.setProperty(CBSConstants.PROPERTY_KAFKA_OUTGOING_TOPIC, kafkaOutputTopic);
            exchange.setProperty(CBSConstants.PROPERTY_KAFKA_OPERATION_NAME, operationName);
            exchange.getIn().setBody(payload);
            Object r = producerTemplate.send(getConsumer(operation),exchange).getIn().getBody();

            // Abnormal condition all exception should be handled by camel routes
            if (exchange.getException() != null){
                throw new RuntimeException(exchange.getException());
            }

            // Capture point of errorCode for Dynatrace monitoring purposes
            AppMonitoringHelper.captureErrorCode(exchange);

            //////////////////////////////////////////////////////////////////////////////
            // Operation really ends here, the following is just here for logging reasons.
            //////////////////////////////////////////////////////////////////////////////

            Document s = camelContext.getTypeConverter().convertTo(Document.class, r);
            Document responseDocument = createResponse(s,operation);
            long duration = System.currentTimeMillis() - startTime;

            // Log the output
            logger.info("Call web service " + flowName + "." + operation +" Took " + duration + "ms. " + "ResponseBody:\n"
                    + formatNodeToString(operation, responseDocument));
            LoadLoggingHelper.createMessage("FUSE", operation, duration);

            if (useFaultTolerance(operation) && errorEncountered(responseDocument)) {
                // This will be short-circuited in processWithFaultToleranceErrorHandling()
                throw new ErrorEncounteredException("Technical error encountered while processing the request.", (DOMSource) null);
            }
        } catch (BadRequestException | JsonMappingException e ) {
            logger.error("XSD Validation failed or something went wrong while adding env params", e);
            // TODO write to the database for this record or send to the outgoing topic directly?
            writeKafkaErrorMessage(record.key(), HttpStatus.SC_BAD_REQUEST, "Bad Request");
        } catch (TransformerFactoryConfigurationError | TransformerException |
                 ParserConfigurationException | CBSException | IOException e) {
            logger.error("Unable to process web service call", e);
            // TODO write to the database for this record or send to the outgoing topic directly?
            writeKafkaErrorMessage(record.key(), HttpStatus.SC_INTERNAL_SERVER_ERROR, "Internal Server Error");
        } catch (ErrorEncounteredException techException) {
            // This is thrown to trigger the fault tolerance logic, so just log it and rethrow.
            logger.error("Technical error encountered while processing request: " + techException.getMessage());
            throw techException;
        } catch (Throwable t) {
            logger.error("Unchecked exception thrown while processing message", t);
            // TODO write to the database for this record or send to the outgoing topic directly?
            writeKafkaErrorMessage(record.key(), HttpStatus.SC_INTERNAL_SERVER_ERROR, "Unchecked error while processing message");
        } finally {
            loggingMDCInterceptor.processMessageOut();
        }
        return null;
    }

    protected boolean useFaultTolerance(String operation) {
        if (faultToleranceEnabled()) {
            // Either the guard is already in the map
            if (getTypedGuardMap().containsKey(operation)) {
                return true;
            }
            // or we use the standard settings
            int standardRateLimitLimit = getIntegerConfigValue(operation, "RateLimitLimit", 100);
            int standardCircuitBreakerRequestVolumeThreshold = getIntegerConfigValue(operation, "CircuitBreakerRequestVolumeThreshold", 5);
            ChronoUnit standardRateLimitWindowUnit = getChronoUnitConfigValue(operation, "RateLimitWindowUnit", ChronoUnit.MINUTES);
            int standardRateLimitWindow = getIntegerConfigValue(operation, "RateLimitWindow", 1);
            int standardRateLimitMinSpacing = getIntegerConfigValue(operation, "RateLimitMinSpacing", 0);
            ChronoUnit standardRateLimitMinSpacingUnit = getChronoUnitConfigValue(operation, "RateLimitMinSpacingUnit", ChronoUnit.SECONDS);
            RateLimitType standardRateLimitType = getRateLimitTypeConfigValue(operation, "RateLimitType", RateLimitType.ROLLING);
            long standardCircuitBreakerDelay = getIntegerConfigValue(operation, "CircuitBreakerDelay", 1);
            ChronoUnit standardCircuitBreakerDelayUnit = getChronoUnitConfigValue(operation, "CircuitBreakerDelayUnit", ChronoUnit.MINUTES);
            double standardCircuitBreakerFailureRatio = getDoubleConfigValue(operation, "CircuitBreakerFailureRatio", 1.0);
            int standardCircuitBreakerSuccessThreshold = getIntegerConfigValue(operation, "CircuitBreakerSuccessThreshold", 3);
            if (useStandardFaultToleranceSettings() &&
                    standardRateLimitLimit > 0 &&
                    standardCircuitBreakerRequestVolumeThreshold > 0)  {
                // Lazily create the standard fault tolerance settings if needed
                FaultToleranceStrategyHelper.Builder<Void> builder =
                        FaultToleranceStrategyHelper.Builder.createSynchronous(Void.class);
                if (standardRateLimitLimit > 0) {
                    builder = builder.addRateLimitStrategy(
                            standardRateLimitLimit,
                            standardRateLimitWindow,
                            standardRateLimitWindowUnit,
                            standardRateLimitMinSpacing,
                            standardRateLimitMinSpacingUnit,
                            standardRateLimitType,
                            null,
                            null
                    );
                }
                if (standardCircuitBreakerRequestVolumeThreshold > 0) {
                    builder = builder.addCircuitBreakerStrategy(
                            standardCircuitBreakerDelay,
                            standardCircuitBreakerDelayUnit,
                            standardCircuitBreakerRequestVolumeThreshold,
                            standardCircuitBreakerFailureRatio,
                            standardCircuitBreakerSuccessThreshold,
                            null,
                            Collections.singletonList(RateLimitException.class),
                            null,
                            null,
                            null,
                            null,
                            null
                    );
                }
                TypedGuard<Void> standardTypedGuard = builder.build();
                // Add the standard guard to the map, so that it is used for this operation
                getTypedGuardMap().put(operation, standardTypedGuard);
                return true;
            }
        }
        // if we reach this point, no fault tolerance is to be used
        return false;
    }

    protected int getIntegerConfigValue(String operation, String configSuffix, int defaultValue) {
        if (datagridHelper != null) {
            String configKey = this.getClass().getSimpleName() + operation + configSuffix;
            logger.info("Looking up config key {} in datagrid.", configKey);
            String cachedValue = datagridHelper.get(configKey);
            if (cachedValue == null) {
                return defaultValue;
            }
            return Integer.parseInt(cachedValue);
        }
        return defaultValue;
    }

    protected double getDoubleConfigValue(String operation, String configSuffix, double defaultValue) {
        if (datagridHelper != null) {
            String configKey = this.getClass().getSimpleName() + operation + configSuffix;
            logger.info("Looking up config key {} in datagrid.", configKey);
            String cachedValue = datagridHelper.get(configKey);
            if (cachedValue == null) {
                return defaultValue;
            }
            return Double.parseDouble(cachedValue);
        }
        return defaultValue;
    }

    protected ChronoUnit getChronoUnitConfigValue(String operation, String configSuffix, ChronoUnit defaultValue) {
        if (datagridHelper != null) {
            String configKey = this.getClass().getSimpleName() + operation + configSuffix;
            logger.info("Looking up config key {} in datagrid.", configKey);
            String cachedValue = datagridHelper.get(configKey);
            if (cachedValue == null) {
                return defaultValue;
            }
            return ChronoUnit.valueOf(cachedValue);
        }
        return defaultValue;
    }

    protected RateLimitType getRateLimitTypeConfigValue(String operation, String configSuffix, RateLimitType defaultValue) {
        if (datagridHelper != null) {
            String configKey = this.getClass().getSimpleName() + operation + configSuffix;
            logger.info("Looking up config key {} in datagrid.", configKey);
            String cachedValue = datagridHelper.get(configKey);
            if (cachedValue == null) {
                return defaultValue;
            }
            return RateLimitType.valueOf(cachedValue);
        }
        return defaultValue;
    }

    protected RemoteDatagridClientHelper<String, String> getDatagridHelper() {
        return datagridHelper;
    }

    protected boolean errorEncountered(Document responseDocument) {
        return !Objects.isNull(FormatUtils.getValue(responseDocument, "//*:ErrorMessage/*:ErrorType")) &&
                !Objects.equals(FormatUtils.getValue(responseDocument, "//*:ErrorMessage/*:SeverityLevel"), ErrorTypeModel.SEVERITY_WARNING);
    }

    private void writeKafkaErrorMessage(String kafkaKey, int status, String message) {
        String result = "{ \"requestId\": \"" + kafkaKey + "\"," +
                " \"transactionId\": \"\"," +
                " \"success\": false," +
                " \"errorCode\": " + status + "," +
                " \"errorMessage\": \"" + message + "\" }";
        Message<String> kafkaMessage = Message.of(result);
        OutgoingKafkaRecordMetadata<String> metadata = OutgoingKafkaRecordMetadata.<String>builder().
                withKey(kafkaKey).
                withTopic(kafkaOutputTopic).
                build();
        kafkaMessage.addMetadata(metadata);
        getKafkaEmitter().send(kafkaMessage);
        if (logger.isDebugEnabled()) {
            logger.debug("Sent Kafka message");
        }
    }

    @SuppressWarnings("unchecked")
    private NonCopyingByteArrayOutputStream adornHeaders(ConsumerRecord<String, String> record, ObjectMapper mapper, NonCopyingByteArrayOutputStream servletBodyContents) throws IOException, BadRequestException, CBSException {
        String flowName;
        JsonNode requestJSON = mapper.readTree(
                new ByteArrayInputStream(servletBodyContents.getBuffer(), 0, servletBodyContents.size()));
        flowName = requestJSON.fieldNames().next();

        JsonNodeFactory jsonNodeFactory = new JsonNodeFactory(false);
        ObjectNode requestToAdornHeaders = new ObjectNode(jsonNodeFactory);

        Header userIdHeader = Optional.ofNullable(record.headers().lastHeader("UserId")).orElseThrow(BadRequestException::new);
        Header requestIdHeader = Optional.ofNullable(record.headers().lastHeader("RequestId")).orElseThrow(BadRequestException::new);
        Header languageHeader = record.headers().lastHeader("language");
        Header channelTypeCodeHeader = record.headers().lastHeader("channelTypeCode");

        Map<String, String> envParams = Collections.emptyMap();
        if (languageHeader != null || channelTypeCodeHeader != null) {
            envParams = new HashMap<>();
            if (languageHeader != null) {
                envParams.put("language", new String(languageHeader.value(), StandardCharsets.UTF_8));
            }
            if (channelTypeCodeHeader != null) {
                envParams.put("channelTypeCode", new String(channelTypeCodeHeader.value(), StandardCharsets.UTF_8));
            }
        }
        requestToAdornHeaders.set("envParams", mapper.convertValue(envParams, ObjectNode.class));

        Map<String, String> loggingInfo = Stream.of(new String[][]{
                {"requestId", new String(requestIdHeader.value(), StandardCharsets.UTF_8)},
                {"userId", new String(userIdHeader.value(), StandardCharsets.UTF_8)}
        }).collect(Collectors.toMap(kv -> kv[0], kv -> kv[1]));
        requestToAdornHeaders.set("loggingInfo", mapper.convertValue(loggingInfo, ObjectNode.class));

        try {
            String adornHeadersEndpoint = ConfigProvider.getConfig().getValue("cbs.mw.adorn.headers.endpoint", String.class);
            logger.info("Using {} as the endpoint to call the adorn headers micro service", adornHeadersEndpoint);
            String requestToAdornHeadersAsString = mapper.writeValueAsString(requestToAdornHeaders);
            if (logger.isDebugEnabled()) {
                logger.debug("Adorn headers micro service called with :" + requestToAdornHeadersAsString);
            }
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .header(HttpHeaderNames.CONTENT_TYPE.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
                    .header(HttpHeaderNames.ACCEPT.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
                    .POST(HttpRequest.BodyPublishers.ofString(requestToAdornHeadersAsString))
                    .uri(new URI(adornHeadersEndpoint + "/adorn"))
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == HttpResponseStatus.OK.code()) {
                JsonNode responseJSON = mapper.readTree(response.body());
                loggingInfo = mapper.convertValue(responseJSON.findPath("loggingInfo"), Map.class);
                envParams = mapper.convertValue(responseJSON.findPath("envParams"), Map.class);
            } else {
                throw new Exception("Unable to contact the adorn headers micro service (" + response.statusCode() + ").");
            }
        } catch (Exception e) {
            throw new CBSException(ErrorTypeModel.createErrorModel(
                    ErrorTypeModel.ERROR_TYPE_TECHNICAL,
                    ErrorTypeModel.ERROR_SYSTEM_ID_BPM,
                    "JSONProvider",
                    ErrorTypeModel.DEFAULT_ERROR_CODE,
                    ErrorTypeModel.SEVERITY_SEVERE,
                    e.getMessage()
            ));
        }

        ObjectNode requestPayload = (ObjectNode) requestJSON.path(flowName);
        requestPayload.set("loggingInfo", mapper.convertValue(loggingInfo, ObjectNode.class));
        requestPayload.set("envParams", mapper.convertValue(envParams, ObjectNode.class));

        logger.debug("Final request JSON: " + requestJSON.toString());

        servletBodyContents = new NonCopyingByteArrayOutputStream();
        IOUtils.copy(new ByteArrayInputStream(
                requestJSON.toString().getBytes(StandardCharsets.UTF_8)), servletBodyContents);
        return servletBodyContents;
    }

    public String getConsumer(String operation) {
        return "direct:start";
    }

    public String formatNodeToString(String operation, Node node) throws TransformerFactoryConfigurationError, TransformerException {
        String returnValue = FormatUtils.nodeToString(node, FormatUtils.OMIT_XML_DECLARATION_YES, FormatUtils.INDENT_NO);
        if (TRIMMING_RESPONSE  && "getListReferenceDataItem".equals(operation) && returnValue.length() > MAX_RESPONSE_SIZE) {
            return returnValue.substring(0, MAX_RESPONSE_SIZE) + "... (trimmed)";
        }
        return returnValue;
    }

    /**
     * Method to get the root element of the request XML.<br>
     * Default behavior is to get the first element child from the root.<br>
     *
     * Override this method for other behavior
     *
     * @param rootElement Initial SOAP request XML
     * @return Root element
     */
    protected Element getXMLRootElement(Element rootElement){
        Element newRoot = null;

        if (requestWithPayloadOnly()) {
            Node childNode = rootElement.getFirstChild();
            while (childNode != null && childNode.getNodeType() != Node.ELEMENT_NODE) {
                childNode = childNode.getNextSibling();
            }
            newRoot = (Element) childNode;
        }else{
            newRoot = rootElement;
        }

        return newRoot;
    }

    private boolean validateXMLSchema(String[] xsdPath, Document doc){
        try {
            SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            final StreamSource[] sources = generateStreamSourcesFromXsdPaths(xsdPath);
            Schema schema = factory.newSchema(sources);
            Validator validator = schema.newValidator();
            validator.validate(new DOMSource(doc));
        } catch (IOException | SAXException e) {
            logger.info("Exception: "+e.getMessage());
            return false;
        }
        return true;
    }


    private static StreamSource[] generateStreamSourcesFromXsdPaths(final String[] xsdFilesPaths) {
        return Arrays.stream(xsdFilesPaths)
                .map((String s) -> new StreamSource(Thread.currentThread().getContextClassLoader().getResource(s).toExternalForm()))
                .collect(Collectors.toList()).toArray(new StreamSource[xsdFilesPaths.length]);
    }

    private Document createResponse(Document response,String operation) throws ParserConfigurationException {

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.newDocument();

        // root element
        Element rootElement = doc.createElementNS(response.getDocumentElement().getNamespaceURI(),  operation+"Response");

        doc.appendChild(rootElement);

        Node nNode = null;
        if(keepRootElement() == ResponseLayout.WRAP){
            nNode = doc.importNode(response.getDocumentElement(), true);
        }else if(keepRootElement() == ResponseLayout.WRAP_UNWRAP){
            nNode = doc.importNode(getXMLRootElement(response.getDocumentElement()), true);
        }
        else{
            return response;
        }
        rootElement.appendChild(nNode);

        return doc;
    }

    /**
     * Override in case where the response payload should be wrapped.
     *
     * @return true/false
     */
    protected ResponseLayout keepRootElement(){
        return ResponseLayout.WRAP;
    }

    /**
     * Override in case the initial request will be handled as is.
     * @return
     */
    protected boolean requestWithPayloadOnly(){
        return true;
    }

}
