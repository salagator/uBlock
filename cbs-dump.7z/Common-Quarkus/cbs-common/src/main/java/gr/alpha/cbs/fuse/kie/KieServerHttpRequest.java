//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

import jakarta.ws.rs.core.MediaType;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLEncoder;
import java.net.Proxy.Type;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.zip.GZIPInputStream;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class KieServerHttpRequest {
    public static final String CHARSET_UTF8 = "UTF-8";
    public static final String HEADER_PROXY_AUTHORIZATION = "Proxy-Authorization";
    public static final String HEADER_REFERER = "Referer";
    public static final String HEADER_SERVER = "Server";
    public static final String PARAM_CHARSET = "charset";
    private static final String[] EMPTY_STRINGS = new String[0];
    private static final String IDENTITY_KEYSTORE_TYPE = "jks";
    private static final int DEFAULT_TIMEOUT_SECS = 5;
    private RequestInfo requestInfo;
    private int bufferSize;
    private boolean ignoreCloseExceptions;
    boolean uncompress;
    private HttpURLConnection connection;
    private RequestOutputStream output;
    boolean followRedirects;
    String httpProxyHost;
    int httpProxyPort;
    private KieServerHttpResponse response;
    private static ConnectionFactory CONNECTION_FACTORY;
    private static SSLSocketFactory TRUSTED_FACTORY;
    private static HostnameVerifier TRUSTED_VERIFIER;

    private RequestInfo getRequestInfo() {
        if (this.requestInfo == null) {
            this.requestInfo = new RequestInfo();
        }

        return this.requestInfo;
    }

    private static String getValidCharset(String charset) {
        return charset != null && charset.length() > 0 ? charset : "UTF-8";
    }

    private static StringBuilder addPathSeparator(String baseUrl, StringBuilder result) {
        if (baseUrl.indexOf(58) + 2 == baseUrl.lastIndexOf(47)) {
            result.append('/');
        }

        return result;
    }

    private static StringBuilder addParamPrefix(String baseUrl, StringBuilder result) {
        int queryStart = baseUrl.indexOf(63);
        int lastChar = result.length() - 1;
        if (queryStart == -1) {
            result.append('?');
        } else if (queryStart < lastChar && baseUrl.charAt(lastChar) != '&') {
            result.append('&');
        }

        return result;
    }

    static String encodeUrlToUTF8(CharSequence url) throws KieServerHttpRequestException {
        URL parsed;
        try {
            parsed = new URL(url.toString());
        } catch (IOException ioe) {
            throw new KieServerHttpRequestException("Unable to encode url '" + url.toString() + "'", ioe);
        }

        String host = parsed.getHost();
        int port = parsed.getPort();
        if (port != -1) {
            host = host + ':' + Integer.toString(port);
        }

        try {
            String encoded = (new URI(parsed.getProtocol(), host, parsed.getPath(), parsed.getQuery(), (String)null)).toASCIIString();
            int paramsStart = encoded.indexOf(63);
            if (paramsStart > 0 && paramsStart + 1 < encoded.length()) {
                encoded = encoded.substring(0, paramsStart + 1) + encoded.substring(paramsStart + 1).replace("+", "%2B");
            }

            return encoded;
        } catch (URISyntaxException e) {
            KieServerHttpRequestException krhre = new KieServerHttpRequestException("Unable to parse parse URI", e);
            throw krhre;
        }
    }

    static String appendQueryParameters(CharSequence url, Map<?, ?> params) {
        String baseUrl = url.toString();
        if (params != null && !params.isEmpty()) {
            StringBuilder result = new StringBuilder(baseUrl);
            addPathSeparator(baseUrl, result);
            addParamPrefix(baseUrl, result);
            Iterator<?> iterator = params.entrySet().iterator();
            Map.Entry<?, ?> entry = (Map.Entry)iterator.next();
            result.append(entry.getKey().toString());
            result.append('=');
            Object value = entry.getValue();
            if (value != null) {
                result.append(value);
            }

            while(iterator.hasNext()) {
                result.append('&');
                entry = (Map.Entry)iterator.next();
                result.append(entry.getKey().toString());
                result.append('=');
                value = entry.getValue();
                if (value != null) {
                    result.append(value);
                }
            }

            return result.toString();
        } else {
            return baseUrl;
        }
    }

    static String appendQueryParameters(CharSequence url, Object... params) {
        String baseUrl = url.toString();
        if (params != null && params.length != 0) {
            if (params.length % 2 != 0) {
                throw new IllegalArgumentException("Must specify an even number of parameter names/values");
            } else {
                StringBuilder result = new StringBuilder(baseUrl);
                addPathSeparator(baseUrl, result);
                addParamPrefix(baseUrl, result);
                result.append(params[0]);
                result.append('=');
                Object value = params[1];
                if (value != null) {
                    result.append(value);
                }

                for(int i = 2; i < params.length; i += 2) {
                    result.append('&');
                    result.append(params[i]);
                    result.append('=');
                    value = params[i + 1];
                    if (value != null) {
                        result.append(value);
                    }
                }

                return result.toString();
            }
        } else {
            return baseUrl;
        }
    }

    public static void setKeepAlive(boolean keepAlive) {
        setProperty("http.keepAlive", Boolean.toString(keepAlive));
    }

    public static void setMaxConnections(int maxConnections) {
        setProperty("http.maxConnections", Integer.toString(maxConnections));
    }

    private static String setProperty(final String name, final String value) {
        if (value != null) {
            return System.setProperty(name, value);
        } else {
            return System.clearProperty(name);
        }
    }

    public static KieServerHttpRequest deleteRequest(URL url) throws KieServerHttpRequestException {
        KieServerHttpRequest request = new KieServerHttpRequest(url);
        request.getRequestInfo().requestMethod = "DELETE";
        return request;
    }

    public static KieServerHttpRequest putRequest(URL url) throws KieServerHttpRequestException {
        KieServerHttpRequest request = new KieServerHttpRequest(url);
        request.getRequestInfo().requestMethod = "PUT";
        return request;
    }

    public static KieServerHttpRequest getRequest(String urlString) throws KieServerHttpRequestException {
        KieServerHttpRequest request = new KieServerHttpRequest(urlString);
        request.getRequestInfo().requestMethod = "GET";
        return request;
    }

    public static KieServerHttpRequest getRequest(URL url) throws KieServerHttpRequestException {
        KieServerHttpRequest request = new KieServerHttpRequest(url);
        request.getRequestInfo().requestMethod = "GET";
        return request;
    }

    public static KieServerHttpRequest postRequest(URL url) throws KieServerHttpRequestException {
        KieServerHttpRequest request = new KieServerHttpRequest(url);
        request.getRequestInfo().requestMethod = "POST";
        return request;
    }

    public static KieServerHttpRequest newRequest(String url) throws KieServerHttpRequestException {
        return new KieServerHttpRequest(url);
    }

    public static KieServerHttpRequest newRequest(URL url) throws KieServerHttpRequestException {
        return new KieServerHttpRequest(url);
    }

    public static KieServerHttpRequest newRequest(String url, String username, String password) throws KieServerHttpRequestException {
        return new KieServerHttpRequest(url, username, password);
    }

    public static KieServerHttpRequest newRequest(URL url, String username, String password) throws KieServerHttpRequestException {
        return new KieServerHttpRequest(url, username, password);
    }

    private KieServerHttpRequest(URL url) throws KieServerHttpRequestException {
        this.bufferSize = 8192;
        this.ignoreCloseExceptions = true;
        this.uncompress = false;
        this.connection = null;
        this.followRedirects = false;
        this.response = null;
        this.getRequestInfo().baseUrl = url;
    }

    private KieServerHttpRequest(String urlString) throws KieServerHttpRequestException {
        this.bufferSize = 8192;
        this.ignoreCloseExceptions = true;
        this.uncompress = false;
        this.connection = null;
        this.followRedirects = false;
        this.response = null;
        this.getRequestInfo().baseUrl = convertStringToUrl(urlString);
    }

    private static URL convertStringToUrl(String urlString) throws KieServerHttpRequestException {
        try {
            return new URL(urlString);
        } catch (MalformedURLException e) {
            throw new KieServerHttpRequestException("Unable to create request with url '" + urlString + "'", e);
        }
    }

    private KieServerHttpRequest(RequestInfo requestInfo) {
        this.bufferSize = 8192;
        this.ignoreCloseExceptions = true;
        this.uncompress = false;
        this.connection = null;
        this.followRedirects = false;
        this.response = null;
        this.requestInfo = requestInfo;
    }

    private KieServerHttpRequest(URL stringUrl, String username, String password) {
        this.bufferSize = 8192;
        this.ignoreCloseExceptions = true;
        this.uncompress = false;
        this.connection = null;
        this.followRedirects = false;
        this.response = null;
        RequestInfo requestInfo = this.getRequestInfo();
        requestInfo.baseUrl = stringUrl;
        requestInfo.user = username;
        requestInfo.password = password;
    }

    private KieServerHttpRequest(String stringUrl, String username, String password) {
        this(stringUrl);
        RequestInfo requestInfo = this.getRequestInfo();
        requestInfo.user = username;
        requestInfo.password = password;
    }

    public KieServerHttpRequest get(String relativeUrl) throws KieServerHttpRequestException {
        this.relativeRequest(relativeUrl, "GET");
        this.responseCode();
        return this;
    }

    public KieServerHttpRequest get() throws KieServerHttpRequestException {
        this.getRequestInfo().requestMethod = "GET";
        this.responseCode();
        return this;
    }

    public KieServerHttpRequest post(String relativeUrl) throws KieServerHttpRequestException {
        this.relativeRequest(relativeUrl, "POST");
        this.responseCode();
        return this;
    }

    public KieServerHttpRequest post() throws KieServerHttpRequestException {
        this.getRequestInfo().requestMethod = "POST";
        this.responseCode();
        return this;
    }

    public KieServerHttpRequest put(String relativeUrl) throws KieServerHttpRequestException {
        this.relativeRequest(relativeUrl, "PUT");
        this.responseCode();
        return this;
    }

    public KieServerHttpRequest put() throws KieServerHttpRequestException {
        this.getRequestInfo().requestMethod = "PUT";
        this.responseCode();
        return this;
    }

    public KieServerHttpRequest delete(String relativeUrl) throws KieServerHttpRequestException {
        this.relativeRequest(relativeUrl, "DELETE");
        this.responseCode();
        return this;
    }

    public KieServerHttpRequest delete() throws KieServerHttpRequestException {
        this.getRequestInfo().requestMethod = "DELETE";
        this.responseCode();
        return this;
    }

    private KieServerHttpRequest copy(final InputStream input, final OutputStream output) throws IOException {
        return (KieServerHttpRequest)(new CloseOperation<KieServerHttpRequest>(input, this.ignoreCloseExceptions) {
            public KieServerHttpRequest run() throws IOException {
                byte[] buffer = new byte[KieServerHttpRequest.this.bufferSize];

                int read;
                while((read = input.read(buffer)) != -1) {
                    output.write(buffer, 0, read);
                }

                return KieServerHttpRequest.this;
            }
        }).call();
    }

    public KieServerHttpRequest ignoreCloseExceptions(boolean ignore) {
        this.ignoreCloseExceptions = ignore;
        return this;
    }

    public boolean ignoreCloseExceptions() {
        return this.ignoreCloseExceptions;
    }

    public KieServerHttpRequest bufferSize(int size) {
        if (size < 1) {
            throw new IllegalArgumentException("Size must be greater than zero");
        } else {
            this.bufferSize = size;
            return this;
        }
    }

    public int bufferSize() {
        return this.bufferSize;
    }

    public KieServerHttpRequest setUncompress(boolean uncompress) {
        this.uncompress = uncompress;
        return this;
    }

    public KieServerHttpRequest followRedirects(boolean followRedirects) {
        this.followRedirects = followRedirects;
        return this;
    }

    public URI getUri() {
        try {
            return this.getRequestInfo().getRequestUrl().toURI();
        } catch (URISyntaxException urise) {
            throw new KieServerHttpRequestException("Invalid request URL", urise);
        }
    }

    public KieServerHttpRequest timeout(long timeoutInMilliseconds) {
        if (this.connection != null) {
            this.connection.setReadTimeout((int)timeoutInMilliseconds);
        } else {
            this.getRequestInfo().timeoutInMilliSecs = (int)timeoutInMilliseconds;
        }

        return this;
    }

    private void setRequestUrl(String urlString) {
        this.getRequestInfo().setRequestUrl(urlString);
    }

    private HttpURLConnection createConnection() {
        String urlString = this.getRequestInfo().getRequestUrl().toString();
        if (this.getRequestInfo().requestMethod == null) {
            throw new KieServerHttpRequestException("Please specify (and execute?) a HTTP method first.");
        } else {
            try {
                HttpURLConnection connection;
                if (this.httpProxyHost != null) {
                    Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress(this.httpProxyHost, this.httpProxyPort));
                    connection = CONNECTION_FACTORY.create(this.getRequestInfo().getRequestUrl(), proxy);
                } else {
                    connection = CONNECTION_FACTORY.create(this.getRequestInfo().getRequestUrl());
                }

                if (this.getRequestInfo().getRequestUrl().getProtocol().equalsIgnoreCase("https") && this.getRequestInfo().getRequestUrl().getHost().equalsIgnoreCase("localhost")) {
                    ((HttpsURLConnection)connection).setHostnameVerifier(new HostnameVerifier() {
                        public boolean verify(String hostname, SSLSession sslSession) {
                            return hostname.equalsIgnoreCase("localhost");
                        }
                    });
                }

                /*
                if (this.getRequestInfo().clientCertificate != null) {
                    ClientCertificate clientCertificate = this.getRequestInfo().clientCertificate;

                    try {
                        KeyStore identityKeyStore = KeyStore.getInstance("jks");
                        identityKeyStore.load(new FileInputStream(clientCertificate.getKeystore()), clientCertificate.getKeystorePassword().toCharArray());
                        SSLContextBuilder contextBuilder = SSLContexts.custom().loadKeyMaterial(identityKeyStore, clientCertificate.getCertPassword().toCharArray(), (map, socket) -> clientCertificate.getCertName());
                        if (clientCertificate.getTruststore() != null) {
                            KeyStore trustStore = KeyStore.getInstance("jks");
                            trustStore.load(new FileInputStream(clientCertificate.getTruststore()), clientCertificate.getTruststorePassword().toCharArray());
                            contextBuilder.loadTrustMaterial(trustStore, (TrustStrategy)null);
                        }

                        SSLSocketFactory socketFactory = contextBuilder.build().getSocketFactory();
                        ((HttpsURLConnection)connection).setSSLSocketFactory(socketFactory);
                    } catch (IOException | GeneralSecurityException e) {
                        throw new RuntimeException("Unable to create SSLSocketFactory", e);
                    }
                }

                 */

                connection.setRequestMethod(this.getRequestInfo().requestMethod);
                return connection;
            } catch (IOException ioe) {
                throw new KieServerHttpRequestException("Unable to create (" + this.getRequestInfo().requestMethod + ") connection to '" + urlString + "'", ioe);
            }
        }
    }

    HttpURLConnection getConnection() {
        if (this.getRequestInfo().requestMethod == null) {
            throw new KieServerHttpRequestException("Please set HTTP request method before opening a connection.");
        } else {
            this.initializeConnection();
            return this.connection;
        }
    }

    private void initializeConnection() {
        if (this.connection == null) {
            this.addQueryParametersToUrl();
            this.connection = this.createConnection();
            this.connection.setReadTimeout(this.getRequestInfo().timeoutInMilliSecs);
            this.connection.setConnectTimeout(this.getRequestInfo().timeoutInMilliSecs);
            RequestInfo requestInfo = this.getRequestInfo();
            int contentLength = 0;
            if (requestInfo.body != null) {
                contentLength = requestInfo.body.toString().getBytes(Charset.forName("UTF-8")).length;
                this.connection.setFixedLengthStreamingMode(contentLength);
                List<String> contentTypeList = requestInfo.getHeader("Accept");
                if (contentTypeList != null && !contentTypeList.isEmpty()) {
                    requestInfo.setHeader("Content-Type", contentTypeList.get(0));
                }
            }

            requestInfo.setHeader("Content-Length", contentLength);
            this.connection.setInstanceFollowRedirects(this.followRedirects);
            if (requestInfo.user != null && requestInfo.password != null) {
                this.basicAuthorization(requestInfo.user, requestInfo.password);
            }

            if (requestInfo.headers != null) {
                for(Map.Entry<String, List<String>> entry : requestInfo.headers.entrySet()) {
                    for(Object val : (List)entry.getValue()) {
                        this.connection.setRequestProperty((String)entry.getKey(), (String) val);
                    }
                }
            }

            this.addFormParametersToConnection();
            if (requestInfo.body != null) {
                try {
                    this.openOutput();
                    this.output.write(requestInfo.body.toString());
                } catch (IOException ioe) {
                    throw new KieServerHttpRequestException("Unable to add char sequence to request body", ioe);
                }
            }
        }

    }

    public KieServerHttpRequest relativeRequest(String relativeUrlString, String httpMethod) {
        this.relativeRequest(relativeUrlString);
        this.getRequestInfo().requestMethod = httpMethod;
        return this;
    }

    public KieServerHttpRequest relativeRequest(String relativeUrlString) {
        String baseUrlString = this.getRequestInfo().baseUrl.toExternalForm();
        boolean urlSlash = baseUrlString.endsWith("/");
        boolean postfixSlash = relativeUrlString.startsWith("/");
        String separator = "";
        if (!urlSlash && !postfixSlash) {
            separator = "/";
        } else if (urlSlash && postfixSlash) {
            relativeUrlString = relativeUrlString.substring(1);
        }

        this.setRequestUrl(baseUrlString + separator + relativeUrlString);
        return this;
    }

    public KieServerHttpRequest disconnect() {
        this.getConnection().disconnect();
        return this;
    }

    public KieServerHttpRequest resetStream() throws IOException {
        this.getConnection().getInputStream().reset();
        return this;
    }

    public KieServerHttpRequest followRedirets(boolean followRedirects) {
        this.followRedirects = followRedirects;
        return this;
    }

    public URL getUrl() {
        return this.getRequestInfo().getRequestUrl();
    }

    public String getMethod() {
        return this.getRequestInfo().requestMethod;
    }

    public String getHeader(String name) {
        List<String> headerVals = this.getRequestInfo().getHeader(name);
        return headerVals != null && !headerVals.isEmpty() ? (String)headerVals.get(0) : null;
    }

    public KieServerHttpRequest header(String name, Object value) {
        this.getRequestInfo().setHeader(name, value);
        return this;
    }

    public KieServerHttpRequest headers(Map<String, String> headers) {
        if (!headers.isEmpty()) {
            for(Map.Entry<String, String> header : headers.entrySet()) {
                this.header((String)header.getKey(), header.getValue());
            }
        }

        return this;
    }

    public List<String> getRequestHeader(String headerName) {
        return this.getRequestInfo().getHeader(headerName);
    }

    public KieServerHttpRequest acceptEncoding(String acceptEncoding) {
        return this.header("Accept-Encoding", acceptEncoding);
    }

    public KieServerHttpRequest acceptCharset(String acceptCharset) {
        return this.header("Accept-Charset", acceptCharset);
    }

    public KieServerHttpRequest basicAuthorization(String name, String password) {
        return this.header("Authorization", "Basic " + Base64Util.encode(name + ':' + password));
    }

    public KieServerHttpRequest tokenAuthorization(String token) {
        return this.header("Authorization", "Bearer " + token);
    }

    /*
    public KieServerHttpRequest clientCertificate(ClientCertificate clientCertificate) {
        this.getRequestInfo().clientCertificate = clientCertificate;
        return this;
    }
     */

    public KieServerHttpRequest contentType(String contentType) {
        return this.contentType(contentType, (String)null);
    }

    public KieServerHttpRequest contentType(String contentType, String charset) {
        if (charset != null && charset.length() > 0) {
            String separator = "; charset=";
            return this.header("Content-Type", contentType + "; charset=" + charset);
        } else {
            return this.header("Content-Type", contentType);
        }
    }

    public KieServerHttpRequest accept(String accept) {
        RequestInfo requestInfo = this.getRequestInfo();
        if (requestInfo.getHeader("Accept").isEmpty()) {
            requestInfo.setHeader("Accept", new ArrayList());
        }

        ((List)requestInfo.headers.get("Accept")).set(0, accept);
        return this;
    }

    private KieServerHttpRequest openOutput() throws IOException {
        if (this.output != null) {
            return this;
        } else {
            this.getConnection().setDoOutput(true);
            String charset = getHeaderParam(this.getConnection().getRequestProperty("Content-Type"), "charset");
            this.output = new RequestOutputStream(this.getConnection().getOutputStream(), charset, this.bufferSize);
            return this;
        }
    }

    private KieServerHttpRequest closeOutput() throws IOException {
        if (this.connection == null) {
            throw new KieServerHttpRequestException("Please execute a HTTP method first on the request.");
        } else if (this.output == null) {
            return this;
        } else {
            if (this.ignoreCloseExceptions) {
                try {
                    this.output.close();
                } catch (IOException var2) {
                }
            } else {
                this.output.close();
            }

            this.output = null;
            return this;
        }
    }

    private KieServerHttpRequest closeOutputQuietly() throws KieServerHttpRequestException {
        try {
            return this.closeOutput();
        } catch (IOException ioe) {
            throw new KieServerHttpRequestException("Unable to close output from response", ioe);
        }
    }

    public KieServerHttpRequest body(CharSequence value) throws KieServerHttpRequestException {
        this.getRequestInfo().addToBody(value);
        return this;
    }

    public OutputStreamWriter writer() throws KieServerHttpRequestException {
        try {
            this.openOutput();
            return new OutputStreamWriter(this.output, this.output.encoder.charset());
        } catch (IOException ioe) {
            throw new KieServerHttpRequestException("Unable to create writer to request output stream", ioe);
        }
    }

    public KieServerHttpRequest query(Object name, Object value) throws KieServerHttpRequestException {
        this.getRequestInfo().setQueryParameter(name.toString(), value != null ? value.toString() : null);
        return this;
    }

    public KieServerHttpRequest query(Map<?, ?> values) throws KieServerHttpRequestException {
        if (!values.isEmpty()) {
            for(Map.Entry<?, ?> entry : values.entrySet()) {
                this.query(entry.getKey(), entry.getValue());
            }
        }

        return this;
    }

    private void addQueryParametersToUrl() {
        RequestInfo requestInfo = this.getRequestInfo();
        Object[] paramList = null;
        if (requestInfo.queryParameters != null) {
            List<String> queryParamList = new ArrayList();

            for(Map.Entry<String, List<String>> paramListEntry : requestInfo.queryParameters.entrySet()) {
                String name = (String)paramListEntry.getKey();

                for(Object val : (List)paramListEntry.getValue()) {
                    queryParamList.add(name);
                    queryParamList.add((String) val);
                }
            }

            paramList = queryParamList.toArray();
        }

        String unencodedUrlString = appendQueryParameters(requestInfo.getRequestUrl().toString(), paramList);
        String urlString = encodeUrlToUTF8(unencodedUrlString);
        requestInfo.setRequestUrl(urlString);
    }

    public KieServerHttpRequest form(Object name, Object value, String charset) throws KieServerHttpRequestException {
        if (!this.getRequestInfo().form) {
            this.contentType("application/x-www-form-urlencoded", charset);
            this.getRequestInfo().form = true;
        }

        charset = getValidCharset(charset);
        RequestInfo requestInfo = this.getRequestInfo();
        requestInfo.form = true;
        requestInfo.charset = charset;
        requestInfo.setFormParameter(name.toString(), value);
        return this;
    }

    public KieServerHttpRequest form(Object name, Object value) throws KieServerHttpRequestException {
        return this.form(name, value, "UTF-8");
    }

    public KieServerHttpRequest form(Map<?, ?> values, String charset) throws KieServerHttpRequestException {
        if (!values.isEmpty()) {
            for(Map.Entry<?, ?> entry : values.entrySet()) {
                this.form(entry.getKey(), entry.getValue(), charset);
            }
        }

        return this;
    }

    public KieServerHttpRequest form(Map<?, ?> values) throws KieServerHttpRequestException {
        return this.form(values, "UTF-8");
    }

    private void addFormParametersToConnection() {
        RequestInfo requestInfo = this.getRequestInfo();
        if (requestInfo.form && requestInfo.formParameters != null) {
            String name = null;
            String value = null;

            try {
                this.openOutput();
                boolean first = true;

                for(Map.Entry<String, List<String>> entry : requestInfo.formParameters.entrySet()) {
                    name = (String)entry.getKey();

                    for(Object formValue : (List)entry.getValue()) {
                        if (!first) {
                            this.output.write(38);
                        }

                        first = false;
                        this.output.write(URLEncoder.encode(name.toString(), requestInfo.charset));
                        this.output.write(61);
                        if (formValue != null) {
                            this.output.write(URLEncoder.encode(formValue.toString(), requestInfo.charset));
                        }
                    }
                }
            } catch (IOException ioe) {
                throw new KieServerHttpRequestException("Unable to add form parameter (" + name + "/" + value + ") to request body", ioe);
            }
        }

    }

    public KieServerHttpResponse response() {
        if (this.response == null) {
            this.response = new KieServerHttpResponse() {
                private String body = null;

                public InputStream stream() throws KieServerHttpRequestException {
                    return KieServerHttpRequest.this.responseStream();
                }

                public String message() throws KieServerHttpRequestException {
                    return KieServerHttpRequest.this.responseMessage();
                }

                public int intHeader(String name) throws KieServerHttpRequestException {
                    return KieServerHttpRequest.this.intResponseHeader(name);
                }

                public String[] headers(String name) {
                    return KieServerHttpRequest.this.responseHeaders(name);
                }

                public Map<String, List<String>> headers() throws KieServerHttpRequestException {
                    return KieServerHttpRequest.this.responseHeaders();
                }

                public Map<String, String> headerParameters(String headerName) {
                    return KieServerHttpRequest.this.responseHeaderParameters(headerName);
                }

                public String headerParameter(String headerName, String paramName) {
                    return KieServerHttpRequest.this.responseHeaderParameter(headerName, paramName);
                }

                public String header(String name) throws KieServerHttpRequestException {
                    return KieServerHttpRequest.this.responseHeader(name);
                }

                public String contentType() {
                    return KieServerHttpRequest.this.responseContentType();
                }

                public int contentLength() {
                    return KieServerHttpRequest.this.responseContentLength();
                }

                public String contentEncoding() {
                    return KieServerHttpRequest.this.responseContentEncoding();
                }

                public int code() throws KieServerHttpRequestException {
                    return KieServerHttpRequest.this.responseCode();
                }

                public String charset() {
                    return KieServerHttpRequest.this.responseCharset();
                }

                public byte[] bytes() throws KieServerHttpRequestException {
                    return KieServerHttpRequest.this.responseBytes();
                }

                public BufferedInputStream buffer() throws KieServerHttpRequestException {
                    return KieServerHttpRequest.this.responseBuffer();
                }

                public String body() throws KieServerHttpRequestException {
                    if (this.body == null) {
                        this.body = KieServerHttpRequest.this.responseBody();
                    }

                    return this.body;
                }
            };
        }

        return this.response;
    }

    private int responseCode() throws KieServerHttpRequestException {
        this.initializeConnection();

        try {
            this.closeOutput();
            return this.getConnection().getResponseCode();
        } catch (IOException ioe) {
            throw new KieServerHttpRequestException("Error occurred when trying to retrieve response code", ioe);
        }
    }

    private String responseMessage() throws KieServerHttpRequestException {
        this.initializeConnection();

        try {
            this.closeOutput();
            return this.getConnection().getResponseMessage();
        } catch (IOException ioe) {
            throw new KieServerHttpRequestException("Error occurred when trying to retrieve response message", ioe);
        }
    }

    private String responseBody() throws KieServerHttpRequestException {
        String charset = this.responseCharset();
        ByteArrayOutputStream output = this.byteStream();

        try {
            this.copy(this.responseBuffer(), output);
            return output.toString(getValidCharset(charset));
        } catch (IOException ioe) {
            throw new KieServerHttpRequestException("Error occurred when retrieving response body", ioe);
        }
    }

    private byte[] responseBytes() throws KieServerHttpRequestException {
        ByteArrayOutputStream output = this.byteStream();

        try {
            this.copy(this.responseBuffer(), output);
        } catch (IOException ioe) {
            throw new KieServerHttpRequestException("Error occurred when retrieving byte content of response", ioe);
        }

        return output.toByteArray();
    }

    private ByteArrayOutputStream byteStream() {
        int size = this.responseContentLength();
        return size > 0 ? new ByteArrayOutputStream(size) : new ByteArrayOutputStream();
    }

    private InputStream responseStream() throws KieServerHttpRequestException {
        InputStream stream;
        if (this.responseCode() < 400) {
            try {
                stream = this.getConnection().getInputStream();
            } catch (IOException ioe) {
                throw new KieServerHttpRequestException("Unable to retrieve input stream of response", ioe);
            }
        } else {
            stream = this.getConnection().getErrorStream();
            if (stream == null) {
                try {
                    stream = this.getConnection().getInputStream();
                } catch (IOException ioe) {
                    if (this.responseContentLength() > 0) {
                        throw new KieServerHttpRequestException("Unable to retrieve input stream of response", ioe);
                    }

                    stream = new ByteArrayInputStream(new byte[0]);
                }
            }
        }

        if (this.uncompress && "gzip".equals(this.responseContentEncoding())) {
            try {
                return new GZIPInputStream(stream);
            } catch (IOException e) {
                throw new KieServerHttpRequestException("Unable to decompress gzipped stream", e);
            }
        } else {
            return stream;
        }
    }

    private BufferedInputStream responseBuffer() throws KieServerHttpRequestException {
        return new BufferedInputStream(this.responseStream(), this.bufferSize);
    }

    private String responseHeader(String name) throws KieServerHttpRequestException {
        this.closeOutputQuietly();
        return this.getConnection().getHeaderField(name);
    }

    private int intResponseHeader(String name) throws KieServerHttpRequestException {
        this.closeOutputQuietly();
        return this.getConnection().getHeaderFieldInt(name, -1);
    }

    private Map<String, List<String>> responseHeaders() throws KieServerHttpRequestException {
        this.closeOutputQuietly();
        return this.getConnection().getHeaderFields();
    }

    private String[] responseHeaders(String name) {
        Map<String, List<String>> headers = this.responseHeaders();
        if (headers != null && !headers.isEmpty()) {
            List<String> values = (List)headers.get(name);
            return values != null && !values.isEmpty() ? (String[])values.toArray(new String[values.size()]) : EMPTY_STRINGS;
        } else {
            return EMPTY_STRINGS;
        }
    }

    private String responseHeaderParameter(String headerName, String paramName) {
        return getHeaderParam(this.responseHeader(headerName), paramName);
    }

    private Map<String, String> responseHeaderParameters(String headerName) {
        return getHeaderParams(this.responseHeader(headerName));
    }

    private static Map<String, String> getHeaderParams(String header) {
        if (header != null && header.length() != 0) {
            int headerLength = header.length();
            int start = header.indexOf(59) + 1;
            if (start != 0 && start != headerLength) {
                int end = header.indexOf(59, start);
                if (end == -1) {
                    end = headerLength;
                }

                Map<String, String> params = new LinkedHashMap();

                while(start < end) {
                    int nameEnd = header.indexOf(61, start);
                    if (nameEnd != -1 && nameEnd < end) {
                        String name = header.substring(start, nameEnd).trim();
                        if (name.length() > 0) {
                            String value = header.substring(nameEnd + 1, end).trim();
                            int length = value.length();
                            if (length != 0) {
                                if (length > 2 && '"' == value.charAt(0) && '"' == value.charAt(length - 1)) {
                                    params.put(name, value.substring(1, length - 1));
                                } else {
                                    params.put(name, value);
                                }
                            }
                        }
                    }

                    start = end + 1;
                    end = header.indexOf(59, start);
                    if (end == -1) {
                        end = headerLength;
                    }
                }

                return params;
            } else {
                return Collections.emptyMap();
            }
        } else {
            return Collections.emptyMap();
        }
    }

    private static String getHeaderParam(String value, String paramName) {
        if (value != null && value.length() != 0) {
            int length = value.length();
            int start = value.indexOf(59) + 1;
            if (start != 0 && start != length) {
                int end = value.indexOf(59, start);
                if (end == -1) {
                    end = length;
                }

                while(start < end) {
                    int nameEnd = value.indexOf(61, start);
                    if (nameEnd != -1 && nameEnd < end && paramName.equals(value.substring(start, nameEnd).trim())) {
                        String paramValue = value.substring(nameEnd + 1, end).trim();
                        int valueLength = paramValue.length();
                        if (valueLength != 0) {
                            if (valueLength > 2 && '"' == paramValue.charAt(0) && '"' == paramValue.charAt(valueLength - 1)) {
                                return paramValue.substring(1, valueLength - 1);
                            }

                            return paramValue;
                        }
                    }

                    start = end + 1;
                    end = value.indexOf(59, start);
                    if (end == -1) {
                        end = length;
                    }
                }

                return null;
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    private String responseContentEncoding() {
        return this.responseHeader("Content-Encoding");
    }

    private String responseContentType() {
        return this.responseHeader("Content-Type");
    }

    private int responseContentLength() {
        this.closeOutputQuietly();
        return this.getConnection().getHeaderFieldInt("Content-Length", -1);
    }

    private String responseCharset() {
        return this.responseHeaderParameter("Content-Type", "charset");
    }

    private static SSLSocketFactory getTrustedFactory() throws KieServerHttpRequestException {
        if (TRUSTED_FACTORY == null) {
            TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }

                public void checkClientTrusted(X509Certificate[] chain, String authType) {
                }

                public void checkServerTrusted(X509Certificate[] chain, String authType) {
                }
            }};

            try {
                SSLContext context = SSLContext.getInstance("TLS");
                context.init((KeyManager[])null, trustAllCerts, new SecureRandom());
                TRUSTED_FACTORY = context.getSocketFactory();
            } catch (GeneralSecurityException e) {
                throw new KieServerHttpRequestException("Security exception configuring SSL context", e);
            }
        }

        return TRUSTED_FACTORY;
    }

    private static HostnameVerifier getTrustedVerifier() {
        if (TRUSTED_VERIFIER == null) {
            TRUSTED_VERIFIER = (hostname, session) -> true;
        }

        return TRUSTED_VERIFIER;
    }

    public KieServerHttpRequest trustAllCerts() throws KieServerHttpRequestException {
        HttpURLConnection connection = this.getConnection();
        if (connection instanceof HttpsURLConnection) {
            ((HttpsURLConnection)connection).setSSLSocketFactory(getTrustedFactory());
        }

        return this;
    }

    public KieServerHttpRequest trustAllHosts() {
        HttpURLConnection connection = this.getConnection();
        if (connection instanceof HttpsURLConnection) {
            ((HttpsURLConnection)connection).setHostnameVerifier(getTrustedVerifier());
        }

        return this;
    }

    public static void setProxyHost(String host) {
        setProperty("http.proxyHost", host);
        setProperty("https.proxyHost", host);
    }

    public static void setProxyPort(int port) {
        String portValue = Integer.toString(port);
        setProperty("http.proxyPort", portValue);
        setProperty("https.proxyPort", portValue);
    }

    public static void setNonProxyHosts(String... hosts) {
        if (hosts != null && hosts.length > 0) {
            StringBuilder separated = new StringBuilder();
            int last = hosts.length - 1;

            for(int i = 0; i < last; ++i) {
                separated.append(hosts[i]).append('|');
            }

            separated.append(hosts[last]);
            setProperty("http.nonProxyHosts", separated.toString());
        } else {
            setProperty("http.nonProxyHosts", (String)null);
        }

    }

    public KieServerHttpRequest useProxy(String proxyHost, int proxyPort) {
        if (this.connection != null) {
            throw new IllegalStateException("The connection has already been created. This method must be called before reading or writing to the request.");
        } else {
            this.httpProxyHost = proxyHost;
            this.httpProxyPort = proxyPort;
            return this;
        }
    }

    public KieServerHttpRequest proxyAuthorization(String proxyAuthorization) {
        return this.header("Proxy-Authorization", proxyAuthorization);
    }

    public KieServerHttpRequest proxyBasic(String name, String password) {
        return this.proxyAuthorization("Basic " + Base64Util.encode(name + ':' + password));
    }

    public String toString() {
        return this.getMethod() + ' ' + this.getUrl();
    }

    public KieServerHttpRequest clone() {
        if (this.connection != null) {
            throw new KieServerHttpRequestException("Unable to clone request with open or completed connection.");
        } else {
            return new KieServerHttpRequest(this.getRequestInfo().clone());
        }
    }

    static {
        CONNECTION_FACTORY = KieServerHttpRequest.ConnectionFactory.DEFAULT;
    }

    private static class RequestInfo {
        URL baseUrl;
        URL requestUrl;
        String user;
        String password;
//        ClientCertificate clientCertificate;
        Integer timeoutInMilliSecs;
        String requestMethod;
        Map<String, List<String>> headers;
        Map<String, List<String>> queryParameters;
        Map<String, List<String>> formParameters;
        boolean form;
        String charset;
        StringBuilder body;
        MediaType bodyContentType;

        private RequestInfo() {
            this.timeoutInMilliSecs = 5000;
            this.form = false;
        }

        public URL getRequestUrl() {
            if (this.requestUrl == null) {
                this.requestUrl = this.baseUrl;
            }

            return this.requestUrl;
        }

        public void setRequestUrl(String urlString) {
            this.requestUrl = KieServerHttpRequest.convertStringToUrl(urlString);
        }

        public List<String> getHeader(String name) {
            if (this.headers == null) {
                this.headers = new LinkedHashMap();
            }

            return this.headers.get(name) == null ? Collections.EMPTY_LIST : (List)this.headers.get(name);
        }

        public void setHeader(String name, Object value) {
            if (this.headers == null) {
                this.headers = new LinkedHashMap();
            }

            if (this.headers.get(name) == null) {
                this.headers.put(name, new ArrayList());
            }

            ((List)this.headers.get(name)).add(value == null ? null : value.toString());
        }

        public void setQueryParameter(String name, Object value) {
            if (this.queryParameters == null) {
                this.queryParameters = new LinkedHashMap();
            }

            if (this.queryParameters.get(name) == null) {
                this.queryParameters.put(name, new ArrayList());
            }

            ((List)this.queryParameters.get(name)).add(value == null ? null : value.toString());
        }

        public void setFormParameter(String name, Object value) {
            if (this.formParameters == null) {
                this.formParameters = new LinkedHashMap();
            }

            if (this.formParameters.get(name) == null) {
                this.formParameters.put(name, new ArrayList());
            }

            ((List)this.formParameters.get(name)).add(value == null ? null : value.toString());
        }

        public void addToBody(CharSequence addToBody) {
            if (this.body == null) {
                this.body = new StringBuilder();
            }

            this.body.append(addToBody);
        }

        public RequestInfo clone() {
            RequestInfo clone = new RequestInfo();
            clone.baseUrl = this.baseUrl;
            clone.body = this.body;
            clone.bodyContentType = this.bodyContentType;
            clone.charset = this.charset;
            clone.form = this.form;
            clone.formParameters = this.formParameters;
            clone.headers = this.headers;
            clone.password = this.password;
            clone.queryParameters = this.queryParameters;
            clone.requestMethod = this.requestMethod;
            clone.requestUrl = this.requestUrl;
            clone.timeoutInMilliSecs = this.timeoutInMilliSecs;
            clone.user = this.user;
//            clone.clientCertificate = this.clientCertificate;
            return clone;
        }
    }

    public interface ConnectionFactory {
        ConnectionFactory DEFAULT = new ConnectionFactory() {
            public HttpURLConnection create(URL url) throws IOException {
                return (HttpURLConnection)url.openConnection();
            }

            public HttpURLConnection create(URL url, Proxy proxy) throws IOException {
                return (HttpURLConnection)url.openConnection(proxy);
            }
        };

        HttpURLConnection create(URL var1) throws IOException;

        HttpURLConnection create(URL var1, Proxy var2) throws IOException;
    }

    private abstract static class Operation<V> implements Callable<V> {
        private Operation() {
        }

        protected abstract V run() throws KieServerHttpRequestException, IOException;

        protected abstract void done() throws IOException;

        public V call() throws KieServerHttpRequestException {
            boolean thrown = false;

            Object var2;
            try {
                var2 = this.run();
            } catch (KieServerHttpRequestException e) {
                thrown = true;
                throw e;
            } catch (IOException ioe) {
                thrown = true;
                throw new KieServerHttpRequestException("Unable to do " + this.getClass().getSimpleName(), ioe);
            } finally {
                try {
                    this.done();
                } catch (IOException ioe) {
                    if (!thrown) {
                        throw new KieServerHttpRequestException("Exception thrown when finishing " + this.getClass().getSimpleName(), ioe);
                    }
                }

            }

            return (V)var2;
        }
    }

    private abstract static class CloseOperation<V> extends Operation<V> {
        private final Closeable closeable;
        private final boolean ignoreCloseExceptions;

        protected CloseOperation(Closeable closeable, boolean ignoreCloseExceptions) {
            this.closeable = closeable;
            this.ignoreCloseExceptions = ignoreCloseExceptions;
        }

        protected void done() throws IOException {
            if (this.closeable instanceof Flushable) {
                ((Flushable)this.closeable).flush();
            }

            if (this.ignoreCloseExceptions) {
                try {
                    this.closeable.close();
                } catch (IOException var2) {
                }
            } else {
                this.closeable.close();
            }

        }
    }

    private abstract static class FlushOperation<V> extends Operation<V> {
        private final Flushable flushable;

        protected FlushOperation(Flushable flushable) {
            this.flushable = flushable;
        }

        protected void done() throws IOException {
            this.flushable.flush();
        }
    }

    public static class RequestOutputStream extends BufferedOutputStream {
        private final CharsetEncoder encoder;

        public RequestOutputStream(OutputStream stream, String charset, int bufferSize) {
            super(stream, bufferSize);
            this.encoder = Charset.forName(KieServerHttpRequest.getValidCharset(charset)).newEncoder();
        }

        public RequestOutputStream write(String value) throws IOException {
            ByteBuffer bytes = this.encoder.encode(CharBuffer.wrap(value));
            super.write(bytes.array(), 0, bytes.limit());
            return this;
        }
    }
}
