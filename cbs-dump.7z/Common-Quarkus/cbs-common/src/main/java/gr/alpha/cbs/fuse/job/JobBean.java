package gr.alpha.cbs.fuse.job;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDateTime;
import java.time.ZoneId;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Any;
import jakarta.enterprise.inject.Instance;
import jakarta.enterprise.inject.literal.NamedLiteral;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.inject.Singleton;
import javax.sql.DataSource;

import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Route;
import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;

@ApplicationScoped
@Named("jobBean")
@RegisterForReflection
public class JobBean {
	private static final Logger LOGGER = Logger.getLogger(JobBean.class);
	private DataSource ds;

	@Inject
	@Any
	Instance<DataSource> dsInstance;

	public void jobStatus(Exchange exchange, String dataSourceRef, String jobName) throws SQLException {
		LOGGER.debug(String.format("Getting job status for %s", jobName));
		String jobStatus = "Unkown";

		ds = dsInstance.select(NamedLiteral.of(dataSourceRef)).get();
		try (Connection connection = ds.getConnection();
				PreparedStatement sp = connection.prepareStatement("exec Job_GetJobStatus ?, ?;");) {
			sp.setString(1, jobName);
			sp.setTimestamp(2, java.sql.Timestamp.valueOf(LocalDateTime.now(ZoneId.of(System.getProperty("cbs.time.zone", "Europe/Athens")))));

			try (ResultSet result = sp.executeQuery();) {
				if (result.next()) {
					jobStatus = result.getString(1);
				}
			}
		}

		LOGGER.debug(String.format("Job status for %s: %s", jobName, jobStatus));
		exchange.getIn().setHeader("jobStatus", jobStatus);
	}

	public void completeJob(String dataSourceRef, String jobName, String status, String nextExecutionDate) throws SQLException {
		LOGGER.debug(String.format("Completing job %s", jobName));

		ds = dsInstance.select(NamedLiteral.of(dataSourceRef)).get();
		
		String completeJobQuery = "exec Job_CompleteJob ?, ?, ?, ?;";
		
		if(status.equals("Waiting")) {
			try (Connection conn = ds.getConnection();
					PreparedStatement stmt = conn.prepareStatement(completeJobQuery);) {
				stmt.setString(1, status);
				
				if(StringUtils.isNotBlank(nextExecutionDate)) {
					stmt.setTimestamp(2, Timestamp.valueOf(nextExecutionDate));
				} else {
					stmt.setNull(2, Types.TIMESTAMP);
				}
				
				stmt.setString(3, jobName);
				stmt.setTimestamp(4, java.sql.Timestamp.valueOf(LocalDateTime.now(ZoneId.of(System.getProperty("cbs.time.zone", "Europe/Athens")))));
				stmt.execute();
			} 
		} else if(status.equals("Failed")) {
			try (Connection conn = ds.getConnection();
					PreparedStatement stmt = conn.prepareStatement(completeJobQuery);) {
				stmt.setString(1, status);
				stmt.setString(2, nextExecutionDate); // This will be ignored in the SP in this case
				stmt.setString(3, jobName);
				stmt.setTimestamp(4, java.sql.Timestamp.valueOf(LocalDateTime.now(ZoneId.of(System.getProperty("cbs.time.zone", "Europe/Athens")))));
				stmt.execute();
			}  catch (Exception e ) {  
				LOGGER.debug("Exception thrown while completing Failed job", e);
		    }
		}
		
		LOGGER.debug(String.format("Completed job %s with status [%s]", jobName, status));
	}

	public void startHeartbit(Exchange exchange, String heartbitRouteId) throws Exception {
		if (routeExists(exchange, heartbitRouteId)) {
			LOGGER.debug(String.format("Starting heartbit %s", heartbitRouteId));
			exchange.getContext().getRouteController().startRoute(heartbitRouteId);
		}
	}

	public void stopHeartbit(Exchange exchange, String heartbitRouteId) {
		Thread t = new Thread() {
			@Override
			public void run() {
				try {
					if (routeExists(exchange, heartbitRouteId)) {
						LOGGER.debug(String.format("Stopping heartbit %s", heartbitRouteId));
						exchange.getContext().getRouteController().stopRoute(heartbitRouteId);
					}
				} catch (Exception e) {
					LOGGER.error(String.format("Cannot stop heartbit %s", heartbitRouteId), e);
				}
			}
		};
		t.start();
	}

	private boolean routeExists(Exchange exchange, String heartbitRouteId) {
		CamelContext context = exchange.getContext();
		Route heartbitRouteDefinition = context.getRoute(heartbitRouteId);
		return (heartbitRouteDefinition != null);
	}
}
