//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;


public interface KieServicesClient {
    <T> T getServicesClient(Class<T> serviceClient);

    ServiceResponse<KieServerInfo> getServerInfo();

    /*
    ServiceResponse<KieContainerResourceList> listContainers();

    ServiceResponse<KieContainerResourceList> listContainers(KieContainerResourceFilter containerFilter);

    ServiceResponse<KieContainerResource> createContainer(String id, KieContainerResource resource);

    ServiceResponse<KieContainerResource> activateContainer(String id);

    ServiceResponse<KieContainerResource> deactivateContainer(String id);

    ServiceResponse<KieContainerResource> getContainerInfo(String id);

    ServiceResponse<Void> disposeContainer(String id);

    ServiceResponsesList executeScript(CommandScript script);

    ServiceResponse<KieScannerResource> getScannerInfo(String id);

    ServiceResponse<KieScannerResource> updateScanner(String id, KieScannerResource resource);

    ServiceResponse<ReleaseId> getReleaseId(String containerId);

    ServiceResponse<ReleaseId> updateReleaseId(String id, ReleaseId releaseId);

    ServiceResponse<ReleaseId> updateReleaseId(String id, ReleaseId releaseId, boolean resetBeforeUpdate);

    ServiceResponse<KieServerStateInfo> getServerState();
    */
    void close();

    /** @deprecated */
/*
    @Deprecated
    ServiceResponse<String> executeCommands(String id, String payload);
*/

    /** @deprecated */
/*
    @Deprecated
    default ServiceResponse<String> executeCommands(String id, Command<?> cmd) {
        return this.executeCommands(id, cmd, Status.OK);
    }
*/

    /** @deprecated */
/*
    @Deprecated
    default ServiceResponse<String> executeCommands(String id, Command<?> cmd, Response.Status response) {
        throw new UnsupportedOperationException();
    }
*/

    void setClassLoader(ClassLoader classLoader);

    ClassLoader getClassLoader();

    String getConversationId();

    void completeConversation();

//    void setResponseHandler(ResponseHandler responseHandler);
}
