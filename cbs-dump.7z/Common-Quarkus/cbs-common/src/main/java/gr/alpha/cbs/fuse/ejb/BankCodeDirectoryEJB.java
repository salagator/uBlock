package gr.alpha.cbs.fuse.ejb;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import gr.alpha.cbs.fuse.ifaces.BankCodeDirectory;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.stream.Collectors;

@Named("BankCodeDirectoryEJB")
@ApplicationScoped
@RegisterForReflection
public class BankCodeDirectoryEJB implements BankCodeDirectory {

    private static final Logger LOGGER = Logger.getLogger(BankCodeDirectoryEJB.class);

    @Inject
    @io.quarkus.agroal.DataSource("hostpsxa")
    DataSource sqlDS;

    @Override
    public int getBankCode(String creditCardNumber) throws CBSException {
        String whereClause = "where NetCode in ('20', '30') and '" + creditCardNumber + "' like BinCode + '%'";
        String sqlStatement = "exec usp_MST_GetMasterData 'BinCodes', ?";
        int bnkCode = -1;

        try (Connection conn = this.sqlDS.getConnection(); PreparedStatement preparedStatement = conn.prepareStatement(sqlStatement)) {
            preparedStatement.setString(1, whereClause);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    bnkCode = resultSet.getInt("BnkCode");
                }
            }
        } catch (SQLException ex) {
            ErrorUtils.throwCBSException(ex, String.valueOf(ConstantError_Types._Functional), String.valueOf(ConstantError_System_IDs._FUSE), this.getClass().getCanonicalName(),
                    String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob), String.valueOf(ConstantError_Levels._Error), ex.getMessage(), "", "");
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("BnkCode :" + bnkCode);
        }

        return bnkCode;
    }

    @Override
    public String getBankCode(String sixFirstDigitsOfCreditCard, String... netCodes) throws CBSException {
        String concatenatedNetCodes = concatenateNetCodes(netCodes);

        String whereClause = "WHERE NetCode IN " + concatenatedNetCodes + " AND BinCode LIKE '" + sixFirstDigitsOfCreditCard + "%'";
        String sqlStatement = "EXEC usp_MST_GetMasterData 'BinCodes', ?";
        String returnedBnkCode = StringUtils.EMPTY;

        try (Connection conn = this.sqlDS.getConnection(); PreparedStatement preparedStatement = conn.prepareStatement(sqlStatement)) {
            preparedStatement.setString(1, whereClause);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    returnedBnkCode = resultSet.getString("BnkCode");
                }
            }
        } catch (SQLException e) {
            ErrorUtils.throwCBSException(
                    e,
                    String.valueOf(ConstantError_Types._Functional),
                    String.valueOf(ConstantError_System_IDs._FUSE),
                    this.getClass().getCanonicalName(),
                    ConstantErrorMessages._UERRMSGS_300001_texniko_prob,
                    String.valueOf(ConstantError_Levels._Error),
                    e.getMessage(),
                    StringUtils.EMPTY,
                    StringUtils.EMPTY);
        }

        return returnedBnkCode;
    }

    private String concatenateNetCodes(String... netCodes) {
        return Arrays.stream(netCodes)
                .map(netCode -> "'" + netCode + "'")
                .collect(Collectors.joining(",", "(", ")"));
    }

}