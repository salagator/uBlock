package gr.alpha.cbs.fuse.support;

import java.sql.Connection;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.camel.Exchange;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public abstract class AbstractCrystalReportGeneratingProcessor {
                
                public Document process(Exchange exchange, Connection connection, List<DB2StoredProcedureExecutor> executorList) throws Exception {
                                Document inputDocument = exchange.getIn().getBody(Document.class);
                                Object parameters = extractParameters(inputDocument);
                                
                                DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        Document newDocument = documentBuilder.newDocument();
        
        Element rootElement = newDocument.createElement("CrystalReportsInfo");
        newDocument.appendChild(rootElement);

                                for (DB2StoredProcedureExecutor executor : executorList) {
                                                executor.executeAndStore(connection, parameters, rootElement);
                                }
                                
                                return newDocument;
                }
                
                /**
                * Implement this in order to extract the input parameters for the stored procedures
                * from the input document in the exchange.
                * @param inputDocument the input document when the processor starts
                * @return an object that contains the information extracted from the input document
                * that can be fed to the stored procedures as input.
                */
                public abstract Object extractParameters(Document inputDocument);

}
