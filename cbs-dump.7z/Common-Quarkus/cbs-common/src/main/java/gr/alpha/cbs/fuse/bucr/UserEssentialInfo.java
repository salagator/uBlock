package gr.alpha.cbs.fuse.bucr;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class UserEssentialInfo {
	private String WorkingDate;
	private String PreviousWorkingDate;
	private String NextWorkingDate;
	private String ValeurDate;
	private String MachineDate;
	private String ResourceID;
	private String ResourceName;
	private String UnitCodeLevel1;
	private String UnitTypeCodeLevel1;
	private String UnitCodeLevel2;
	private String UnitTypeCodeLevel2;
	private String UnitCodeLevel3;
	private String UnitTypeCodeLevel3;
	private String ChannelTypeCode;
	private String ResourceTypeCode;
	private String ReleaseType;
	private String PageKey;
	private String Language;
	private String BaseCurrency;
	
	public String getWorkingDate() {
		return WorkingDate;
	}
	public void setWorkingDate(String workingDate) {
		WorkingDate = workingDate;
	}
	public String getPreviousWorkingDate() {
		return PreviousWorkingDate;
	}
	public void setPreviousWorkingDate(String previousWorkingDate) {
		PreviousWorkingDate = previousWorkingDate;
	}
	public String getNextWorkingDate() {
		return NextWorkingDate;
	}
	public void setNextWorkingDate(String nextWorkingDate) {
		NextWorkingDate = nextWorkingDate;
	}
	public String getValeurDate() {
		return ValeurDate;
	}
	public void setValeurDate(String valeurDate) {
		ValeurDate = valeurDate;
	}
	public String getMachineDate() {
		return MachineDate;
	}
	public void setMachineDate(String machineDate) {
		MachineDate = machineDate;
	}
	public String getResourceID() {
		return ResourceID;
	}
	public void setResourceID(String resourceID) {
		ResourceID = resourceID;
	}
	public String getResourceName() {
		return ResourceName;
	}
	public void setResourceName(String resourceName) {
		ResourceName = resourceName;
	}
	public String getUnitCodeLevel1() {
		return UnitCodeLevel1;
	}
	public void setUnitCodeLevel1(String unitCodeLevel1) {
		UnitCodeLevel1 = unitCodeLevel1;
	}
	public String getUnitTypeCodeLevel1() {
		return UnitTypeCodeLevel1;
	}
	public void setUnitTypeCodeLevel1(String unitTypeCodeLevel1) {
		UnitTypeCodeLevel1 = unitTypeCodeLevel1;
	}
	public String getUnitCodeLevel2() {
		return UnitCodeLevel2;
	}
	public void setUnitCodeLevel2(String unitCodeLevel2) {
		UnitCodeLevel2 = unitCodeLevel2;
	}
	public String getUnitTypeCodeLevel2() {
		return UnitTypeCodeLevel2;
	}
	public void setUnitTypeCodeLevel2(String unitTypeCodeLevel2) {
		UnitTypeCodeLevel2 = unitTypeCodeLevel2;
	}
	public String getUnitCodeLevel3() {
		return UnitCodeLevel3;
	}
	public void setUnitCodeLevel3(String unitCodeLevel3) {
		UnitCodeLevel3 = unitCodeLevel3;
	}
	public String getUnitTypeCodeLevel3() {
		return UnitTypeCodeLevel3;
	}
	public void setUnitTypeCodeLevel3(String unitTypeCodeLevel3) {
		UnitTypeCodeLevel3 = unitTypeCodeLevel3;
	}
	public String getChannelTypeCode() {
		return ChannelTypeCode;
	}
	public void setChannelTypeCode(String channelTypeCode) {
		ChannelTypeCode = channelTypeCode;
	}
	public String getResourceTypeCode() {
		return ResourceTypeCode;
	}
	public void setResourceTypeCode(String resourceTypeCode) {
		ResourceTypeCode = resourceTypeCode;
	}
	public String getReleaseType() {
		return ReleaseType;
	}
	public void setReleaseType(String releaseType) {
		ReleaseType = releaseType;
	}
	public String getPageKey() {
		return PageKey;
	}
	public void setPageKey(String pageKey) {
		PageKey = pageKey;
	}
	public String getLanguage() {
		return Language;
	}
	public void setLanguage(String language) {
		Language = language;
	}
	public String getBaseCurrency() {
		return BaseCurrency;
	}
	public void setBaseCurrency(String baseCurrency) {
		BaseCurrency = baseCurrency;
	}
}
