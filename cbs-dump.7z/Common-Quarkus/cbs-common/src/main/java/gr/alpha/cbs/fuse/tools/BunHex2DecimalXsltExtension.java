package gr.alpha.cbs.fuse.tools;

import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

@Named("bunHex2DecimalXsltExtension")
@ApplicationScoped
@RegisterForReflection
public class BunHex2DecimalXsltExtension extends ExtensionFunctionDefinition {

    /**
     *
     */
    private static final long serialVersionUID = 2060328806406054962L;

    @Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("bhtd", "http://fuse.cbs.alpha.gr/bunHex2Decimal/", "bunHex2Decimal");
    }

    @Override
    public SequenceType[] getArgumentTypes() {
        return new SequenceType[]{SequenceType.SINGLE_STRING};
    }

    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
        return SequenceType.SINGLE_STRING;
    }

    @Override
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {

            /**
             *
             */
            private static final long serialVersionUID = -2058456802203838019L;

            @Override
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
                try {

                    String bunHex = null;
                    //Check BUN
                    if (arguments[0] instanceof LazySequence) {
                        bunHex = ((LazySequence)arguments[0]).head().getStringValue();
                    } else if (arguments[0] instanceof StringValue) {
                        bunHex = ((StringValue)arguments[0]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type for fromIntPart parameter: " + arguments[0].getClass().getCanonicalName());
                    }

                    /*return the Decimal form of the Hexadecimal*/
                    return StringValue.makeStringValue(FormatUtils.bunHex2Decimal(bunHex));

                } catch (Exception e) {
                    throw new XPathException("Unable to get hexaDecimal from BUN", e);
                }
            }

        };
    }
}
