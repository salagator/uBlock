package gr.alpha.cbs.fuse.logging;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import gr.alpha.cbs.fuse.tools.AppMonitoringHelper;
import net.sf.saxon.dom.DocumentBuilderImpl;
import org.eclipse.microprofile.config.ConfigProvider;
import org.jboss.logging.Logger;
import org.slf4j.MDC;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import javax.xml.XMLConstants;
import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.io.ByteArrayInputStream;
import java.util.Iterator;

public abstract class AbstractMDCHelper {
    private static final Logger LOGGER = Logger.getLogger(AbstractMDCHelper.class);

    String xpathRequestIdParam;
    String xpathSessionIdParam;
    String xpathBusinessCaseIdParam;
    String xpathSequenceIdParam;
    String xpathUserIdParam;
    String xpathCBSUnIdParam;
    String prefixWs;
    String namespaceWs;

    protected void setupXPaths() {
        if (namespaceWs == null) {
            // Initialize from the configuration
            xpathRequestIdParam = ConfigProvider.getConfig().getValue("jaxws.logging.RequestId.xpath", String.class);
            xpathSessionIdParam = ConfigProvider.getConfig().getValue("jaxws.logging.SessionId.xpath", String.class);
            xpathBusinessCaseIdParam = ConfigProvider.getConfig().getValue("jaxws.logging.BusinessCaseId.xpath", String.class);
            xpathSequenceIdParam = ConfigProvider.getConfig().getValue("jaxws.logging.SequenceId.xpath", String.class);
            xpathUserIdParam = ConfigProvider.getConfig().getValue("jaxws.logging.UserId.xpath", String.class);
            xpathCBSUnIdParam = ConfigProvider.getConfig().getValue("jaxws.logging.CBSUnId.xpath", String.class);
            prefixWs = ConfigProvider.getConfig().getValue("javaws.logging.prefix", String.class);
            namespaceWs = ConfigProvider.getConfig().getValue("javaws.logging.namespace", String.class);
        }
    }

    protected void setupMDCContext(Source input) {
        if (LOGGER.isDebugEnabled()){
            LOGGER.debug("Setting up MDC context");
        }

        try {
            XPath xpath = FormatUtils.getXPathFactory().newXPath();

            handleParameter(xpath, input, this.xpathRequestIdParam, CBSConstants.MDC_KEY_REQUEST_ID);
            handleParameter(xpath, input, this.xpathSessionIdParam, CBSConstants.MDC_KEY_SESSION_ID);
            handleParameter(xpath, input, this.xpathBusinessCaseIdParam, CBSConstants.MDC_KEY_BUSINESS_CASE_ID);
            handleParameter(xpath, input, this.xpathSequenceIdParam, CBSConstants.MDC_KEY_SEQUENCE_ID);
            handleParameter(xpath, input, this.xpathUserIdParam, CBSConstants.MDC_KEY_USER_ID);
            handleParameter(xpath, input, this.xpathCBSUnIdParam, CBSConstants.MDC_KEY_CBS_UN_ID);
        } catch (Exception e) {
            LOGGER.error("Unable to handle MDC parameters.", e);
        }

        try {
            AppMonitoringHelper.initialize();
        } catch (Exception e) {
            LOGGER.debug("Application Monitoring Info initialization failed!");
        }
    }

    protected void clearMDCContext() {
        MDC.remove(CBSConstants.MDC_KEY_REQUEST_ID);
        MDC.remove(CBSConstants.MDC_KEY_SESSION_ID);
        MDC.remove(CBSConstants.MDC_KEY_BUSINESS_CASE_ID);
        MDC.remove(CBSConstants.MDC_KEY_SEQUENCE_ID);
        MDC.remove(CBSConstants.MDC_KEY_USER_ID);
        MDC.remove(CBSConstants.MDC_KEY_CBS_UN_ID);

        if (LOGGER.isDebugEnabled()){
            LOGGER.debug("MDC context cleared.");
        }
    }

    protected void handleParameter(XPath xpath, Source payload, String param, String logParam)
            throws NumberFormatException, Exception {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("xpath:" + xpath + " param:" + param + " logParam:" + logParam);
        }

        xpath.setNamespaceContext(new NamespaceContext() {
            @Override
            public String getPrefix(String arg0) {
                throw new UnsupportedOperationException();
            }
            @Override
            public String getNamespaceURI(String prefix) {
                if (prefix == null )throw new NullPointerException();
                else if (prefixWs.equals(prefix))
                    return namespaceWs;
                return XMLConstants.NULL_NS_URI;
            }
            @Override
            public Iterator<String> getPrefixes(String namespaceURI) {
                return null;
            }
        });

        XPathExpression xpathExpression = xpath.compile(param);
        NodeList nodeList = (NodeList) xpathExpression.evaluate(((DOMSource)payload).getNode(), XPathConstants.NODESET);

        if (nodeList.getLength() == 1) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Found log parameter value: " + nodeList.item(0).getTextContent());
            }

            if (!param.equals(this.xpathSequenceIdParam)) {
                MDC.put(logParam, nodeList.item(0).getTextContent());
            } else {
                Integer intValue;
                try {
                    intValue = Integer.parseInt(nodeList.item(0).getTextContent());
                } catch (Exception e) {
                    intValue = 0;
                }
                MDC.put(logParam, String.valueOf(++intValue));
            }
        } else {
            //throw new Exception("Cannot find parameter: " + param);
        }
    }

    public static void main(String[] args) {
        try {
            LoggingMDCInterceptor interceptor = new LoggingMDCInterceptor();
            interceptor.prefixWs = "cbsns";
            interceptor.namespaceWs = "http://fuse.ml.cbs.alpha.gr/printing/";
            interceptor.xpathRequestIdParam = "//*:RequestId/text()";
            interceptor.xpathSessionIdParam = "//cbsns:SessionId/text()";
            interceptor.xpathBusinessCaseIdParam = "//*:BusinessCaseId/text()";
            interceptor.xpathSequenceIdParam = "//*:SequenceId/text()";
            interceptor.xpathUserIdParam = "//*:UserId/text()";
            interceptor.xpathCBSUnIdParam = "//*:CBSUnId/text()";

            XPath xpath = FormatUtils.getXPathFactory().newXPath();
            DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document document = documentBuilder.parse(new ByteArrayInputStream("<foo xmlns=\"bar\"><RequestId>123</RequestId><SessionId xmlns=\"http://fuse.ml.cbs.alpha.gr/printing/\">456</SessionId></foo>".getBytes()));
            Source input = new DOMSource(document.getDocumentElement());
            interceptor.handleParameter(xpath, input, interceptor.xpathRequestIdParam, CBSConstants.MDC_KEY_REQUEST_ID);
            interceptor.handleParameter(xpath, input, interceptor.xpathSessionIdParam, CBSConstants.MDC_KEY_SESSION_ID);
            System.out.println("RequestID: " + MDC.get(CBSConstants.MDC_KEY_REQUEST_ID));
            System.out.println("SessionID: " + MDC.get(CBSConstants.MDC_KEY_SESSION_ID));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
