package gr.alpha.cbs.fuse.ifaces;

import java.util.HashMap;

public interface CorporateDividendsInterface {
	  
	 HashMap<String,String> getAllCorporateDividends() throws Exception;
	 
	 HashMap<String,String> getDividend(String key) throws Exception;	 
}