package gr.alpha.cbs.fuse.ejb;

import com.fasterxml.jackson.databind.ObjectMapper;
import gr.alpha.cbs.fuse.bucr.*;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import gr.alpha.cbs.fuse.ifaces.ChannelRestCallerInterface;
import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpHeaderValues;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.inject.Named;
import jakarta.inject.Singleton;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.config.ConfigProvider;
import org.jboss.logging.Logger;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.transaction.Transactional;
import java.io.StringWriter;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

@Named("ChannelBucrCallerEjb")
@Singleton
@RegisterForReflection
@Transactional(Transactional.TxType.NOT_SUPPORTED)
public class ChannelBucrCallerEjb implements ChannelRestCallerInterface {

    private static final Logger LOGGER = Logger.getLogger(ChannelBucrCallerEjb.class);

    private final String channelFuseApi = ConfigProvider.getConfig().getOptionalValue("cbs.channelfuseapi.endpoint", String.class).get();

    private static final String BUCR_GET_GROUPS_CODE_BY_UNIT_CODE = "/api/BUCR/GetGroupsCodesByUnitCode";
    private static final String BUCR_GET_GROUPS_CODES_BY_MASTER_UNIT_CODE_AND_GROUP_TYPE_CODE = "/api/BUCR/GetGroupsCodesByMasterUnitCodeAndGroupTypeCode";
    private static final String BUCR_GET_UNITS_BY_GROUP_CODE = "/api/BUCR/GetUnitsByGroupCode";
    private static final String BUCR_GET_TEAMS_BY_UNIT_CODE_AND_GROUP_CODE = "/api/BUCR/GetTeamsByUnitCodeAndGroupCode";
    private static final String BUCR_GET_GROUPS_CODES_BY_UNIT_CODE_AND_GROUP_TYPE_CODE = "/api/BUCR/GetGroupsCodesByUnitCodeAndGroupTypeCode";

    private static final String NO_DATA_FOUND_FOR_LIST_RESULT = "NO_DATA_FOUND";
    private static final String NO_DATA_FOUND_FOR_MAP_RESULT = "1:NO_DATA_FOUND";

    RemoteDatagridClientHelper<String, Object> datagridHelper;

    @PostConstruct
    void postConstruct() {
        datagridHelper = new RemoteDatagridClientHelper<>();
        datagridHelper.initCacheManager();
        datagridHelper.setCache("channelFuseApi-datalookup");
        LOGGER.debug("postConstruct called");
    }

    @PreDestroy
    void preDestroy() {
        datagridHelper.stopCacheManager();
        LOGGER.debug("preDestroy called");
    }

    public List<String> getGroupsCodesByUnitCode(String unitCode) throws Exception {

        String key = null;
        String cachedValue = null;

        List<String> result = new ArrayList<>();

        //In case that unitCode is empty or null return the empty list
        if (StringUtils.isEmpty(unitCode)) {
            return result;
        }

        if (datagridHelper.getCache() != null) {
            key = "BUCR_GroupsCodesByUnitCode:" + unitCode;
            cachedValue = (String) datagridHelper.get(key);
        } else {
            LOGGER.warn("Will not use datagrid. Channel method GetGroupsCodesByUnitCode will be called.");
        }

        if (cachedValue != null) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Fetched value: " + cachedValue + " from cache (Datagrid) with key:" + key);
            }

            if (NO_DATA_FOUND_FOR_LIST_RESULT.equals(cachedValue)) {
                return result;
            } else {
                result = Arrays.asList(cachedValue.split(","));
            }
        } else {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Get value from channel api GetGroupsCodesByUnitCode for unit code:" + unitCode);
            }

            result = bucrGetGroupsCodesByUnitCode(unitCode);

            if (datagridHelper.getCache() != null) {
                if (!result.isEmpty()) {
                    String resultToBeCached = String.join(",", result);
                    datagridHelper.put(key, resultToBeCached);
                } else {
                    datagridHelper.put(key, NO_DATA_FOUND_FOR_LIST_RESULT);
                }
            }
        }

        return result;
    }

    public List<String> getGroupsCodesByMasterUnitCodeAndGroupTypeCode(String masterUnitCode, String groupTypeCode) throws Exception {

        String key = null;
        String cachedValue = null;

        List<String> result = new ArrayList<>();

        if (datagridHelper.getCache() != null) {
            key = "BUCR_GroupsCodesByMasterUnitCodeAndGroupTypeCode:" + masterUnitCode + "|" + groupTypeCode;
            cachedValue = (String) datagridHelper.get(key);
        } else {
            LOGGER.warn("Will not use datagrid. Channel method GetGroupsCodesByMasterUnitCodeAndGroupTypeCode will be called.");
        }

        if (cachedValue != null) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Fetched value: " + cachedValue + " from cache (Datagrid) with key:" + key);
            }

            if (NO_DATA_FOUND_FOR_LIST_RESULT.equals(cachedValue)) {
                return result;
            } else {
                result = Arrays.asList(cachedValue.split(","));
            }
        } else {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Get value from channel api getGroupsCodesByMasterUnitCodeAndGroupTypeCode for values :" + masterUnitCode + "," + groupTypeCode);
            }

            result = bucrGetGroupsCodesByMasterUnitCodeAndGroupTypeCode(masterUnitCode, groupTypeCode);

            if (datagridHelper.getCache() != null) {
                if (!result.isEmpty()) {
                    String resultToBeCached = String.join(",", result);
                    datagridHelper.put(key, resultToBeCached);
                } else {
                    datagridHelper.put(key, NO_DATA_FOUND_FOR_LIST_RESULT);
                }
            }
        }

        return result;
    }

    public HashMap<Integer, String> getUnitsByGroupCode(String groupCode) throws Exception {

        String key = null;
        String cachedValue = null;

        HashMap<Integer, String> result = new HashMap<>();

        //In case that groupCode is empty or null return the empty map
        if (StringUtils.isEmpty(groupCode)) {
            return result;
        }

        if (datagridHelper.getCache() != null) {
            key = "BUCR_UnitsByGroupCode:" + groupCode;
            cachedValue = (String) datagridHelper.get(key);
        } else {
            LOGGER.warn("Will not use datagrid. Channel method GetUnitsByGroupCode will be called.");
        }

        if (cachedValue != null) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Fetched value: " + cachedValue + " from cache (Datagrid) with key:" + key);
            }

            if (NO_DATA_FOUND_FOR_MAP_RESULT.equals(cachedValue)) {
                return result;
            } else {
                // cachedValue contains comma separated key:value pairs, e.g."1:AA,2:BB"
                // and it is converted into a HashMap<Integer,String>
                result = (HashMap<Integer, String>) Arrays.stream(cachedValue.split(",")).map(elem -> elem.split(":")).collect(Collectors.toMap(e -> Integer.parseInt(e[0]), e -> e[1]));
            }
        } else {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Get value from channel api getUnitsByGroupCode for :" + groupCode);
            }

            result = bucrGetUnitsByGroupCode(groupCode);

            if (datagridHelper.getCache() != null) {
                if (!result.isEmpty()) {
                    // the value that will be cached is a string that contains comma separated key:value pairs
                    // e.g. if the result map is {1=AA , 2=BB} then the cached value will be : "1:AA,2:BB"
                    String resultToBeCached = result.entrySet().stream().map(entry -> entry.getKey() + ":" + entry.getValue()).collect(Collectors.joining(","));
                    datagridHelper.put(key, resultToBeCached);
                } else {
                    datagridHelper.put(key, NO_DATA_FOUND_FOR_MAP_RESULT);
                }
            }
        }

        return result;
    }

    public HashMap<Integer, String> getTeamsByUnitCodeAndGroupCode(String unitCode, String groupCode) throws Exception {

        String key = null;
        String cachedValue = null;

        HashMap<Integer, String> result = new HashMap<>();

        if (datagridHelper.getCache() != null) {
            key = "BUCR_TeamsByUnitCodeAndGroupCode:" + unitCode + "|" + groupCode;
            cachedValue = (String) datagridHelper.get(key);
        } else {
            LOGGER.warn("Will not use datagrid. Channel method GetTeamsByUnitCodeAndGroupCode will be called.");
        }

        if (cachedValue != null) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Fetched value: " + cachedValue + " from cache (Datagrid) with key:" + key);
            }

            if (NO_DATA_FOUND_FOR_MAP_RESULT.equals(cachedValue)) {
                return result;
            } else {
                // cachedValue contains comma separated key:value pairs, e.g."1:AA,2:BB"
                // and it is converted into a HashMap<Integer,String>
                result = (HashMap<Integer, String>) Arrays.stream(cachedValue.split(",")).map(elem -> elem.split(":")).collect(Collectors.toMap(e -> Integer.parseInt(e[0]), e -> e[1]));
            }
        } else {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Get value from channel api getTeamsByUnitCodeAndGroupCode for unit:" + unitCode + " and group:" + groupCode);
            }

            result = bucrGetTeamsByUnitCodeAndGroupCode(unitCode, groupCode);

            if (datagridHelper.getCache() != null) {
                if (!result.isEmpty()) {
                    // the value that will be cached is a string that contains comma separated key:value pairs
                    // e.g. if the result map is {1=AA , 2=BB} then the cached value will be : "1:AA,2:BB"
                    String resultToBeCached = result.entrySet().stream().map(entry -> entry.getKey() + ":" + entry.getValue()).collect(Collectors.joining(","));
                    datagridHelper.put(key, resultToBeCached);
                } else {
                    datagridHelper.put(key, NO_DATA_FOUND_FOR_MAP_RESULT);
                }
            }
        }

        return result;
    }

    public List<String> getGroupsCodesByUnitCodeAndGroupTypeCode(String unitCode, String groupTypeCode) throws Exception {

        String key = null;
        String cachedValue = null;

        List<String> result = new ArrayList<>();

        //In case that unitCode is empty or null return the empty list
        if (StringUtils.isEmpty(unitCode)) {
            return result;
        }

        if (datagridHelper.getCache() != null) {
            key = "BUCR_GroupsCodesByUnitCodeAndGroupTypeCode:" + unitCode + "|" + groupTypeCode;
            cachedValue = (String) datagridHelper.get(key);
        } else {
            LOGGER.warn("Will not use datagrid. Channel method GetGroupsCodesByUnitCodeAndGroupTypeCode will be called.");
        }

        if (cachedValue != null) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Fetched value: " + cachedValue + " from cache (Datagrid) with key:" + key);
            }

            if (NO_DATA_FOUND_FOR_LIST_RESULT.equals(cachedValue)) {
                return result;
            } else {
                result = Arrays.asList(cachedValue.split(","));
            }
        } else {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Get value from channel api GetGroupsCodesByUnitCodeAndGroupTypeCode for values UnitCode:" + unitCode + ", GroupCode = " + groupTypeCode);
            }

            result = bucrGetGroupsCodesByUnitCodeAndGroupTypeCode(unitCode, groupTypeCode);

            if (datagridHelper.getCache() != null) {
                if (!result.isEmpty()) {
                    String resultToBeCached = String.join(",", result);
                    datagridHelper.put(key, resultToBeCached);

                } else {
                    datagridHelper.put(key, NO_DATA_FOUND_FOR_LIST_RESULT);
                }
            }
        }
        return result;
    }

    private List<String> bucrGetGroupsCodesByUnitCode(String unitCode) throws Exception {

        List<String> listOfGroupCodes = new ArrayList<>();

        //create object that will be  used as input for the channel service
        GetGroupsCodesByUnitCodeRequest groupsCodesByUnitCodeRequestObject = new GetGroupsCodesByUnitCodeRequest();
        groupsCodesByUnitCodeRequestObject.setUnitCode(unitCode);

        ObjectMapper mapper = new ObjectMapper();
        StringWriter writer = new StringWriter();

        mapper.writeValue(writer, groupsCodesByUnitCodeRequestObject);

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .header(HttpHeaderNames.CONTENT_TYPE.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
                .header(HttpHeaderNames.ACCEPT.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
                .POST(HttpRequest.BodyPublishers.ofString(writer.toString()))
                .uri(new URI(channelFuseApi + BUCR_GET_GROUPS_CODE_BY_UNIT_CODE))
                .build();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("GetGroupsCodesByUnitCode called with :" + writer.toString());
        }
        HttpResponse<String> clientResponse = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (clientResponse.statusCode() == HttpResponseStatus.OK.code()) {
            GetGroupsCodesByUnitCodeResponse response = mapper.readValue(clientResponse.body().getBytes(), GetGroupsCodesByUnitCodeResponse.class);

            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("GetGroupsCodesByUnitCode channel rest service returned :" + response.getResponseData().getGroupsCodes());
            }

            return response.getResponseData().getGroupsCodes();
        } else {
            ErrorUtils.throwCBSException(null,
                    String.valueOf(ConstantError_Types._Technical),
                    String.valueOf(ConstantError_System_IDs._FUSE),
                    this.getClass().getCanonicalName(),
                    String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob),
                    String.valueOf(ConstantError_Levels._Error),
                    "Service GetGroupsCodesByUnitCode of channel api replied with status:" + clientResponse.statusCode(),
                    "",
                    "");
        }

        return listOfGroupCodes;
    }

    private List<String> bucrGetGroupsCodesByMasterUnitCodeAndGroupTypeCode(String masterUnitCode, String groupTypeCode) throws Exception {

        List<String> listOfGroupCodes = new ArrayList<>();

        GetGroupsByMasterUnitGroupTypeRequest groupsByMasterUnitGroupTypeRequest = new GetGroupsByMasterUnitGroupTypeRequest();
        groupsByMasterUnitGroupTypeRequest.setMasterUnitCode(masterUnitCode);
        groupsByMasterUnitGroupTypeRequest.setGroupTypeCode(groupTypeCode);

        ObjectMapper mapper = new ObjectMapper();
        StringWriter writer = new StringWriter();

        mapper.writeValue(writer, groupsByMasterUnitGroupTypeRequest);

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .header(HttpHeaderNames.CONTENT_TYPE.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
                .header(HttpHeaderNames.ACCEPT.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
                .POST(HttpRequest.BodyPublishers.ofString(writer.toString()))
                .uri(new URI(channelFuseApi + BUCR_GET_GROUPS_CODES_BY_MASTER_UNIT_CODE_AND_GROUP_TYPE_CODE))
                .build();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("GetGroupsCodesByMasterUnitCodeAndGroupTypeCode called with :" + writer.toString());
        }
        HttpResponse<String> clientResponse = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (clientResponse.statusCode() == HttpResponseStatus.OK.code()) {
            GetGroupsByMasterUnitGroupTypeResponse response = mapper.readValue(clientResponse.body().getBytes(), GetGroupsByMasterUnitGroupTypeResponse.class);

            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("GetGroupsCodesByMasterUnitCodeAndGroupTypeCode channel rest service returned :" + response.getResponseData().getGroupsCodes());
            }

            return response.getResponseData().getGroupsCodes();
        } else {
            ErrorUtils.throwCBSException(null,
                    String.valueOf(ConstantError_Types._Technical),
                    String.valueOf(ConstantError_System_IDs._FUSE),
                    this.getClass().getCanonicalName(),
                    String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob),
                    String.valueOf(ConstantError_Levels._Error),
                    "Service GetGroupsCodesByMasterUnitCodeAndGroupTypeCode of channel api replied with status:" + clientResponse.statusCode(),
                    "",
                    "");
        }

        return listOfGroupCodes;

    }

    /**
     * Calls the channelFuseApi rest service GetUnitsByGroupCode, which returns a List of Unit objects.
     * Each Unit object consists of a unitId and a UnitCode.
     * This method returns a HashMap containing as key the unitId and as value the unitCode.
     */
    private HashMap<Integer, String> bucrGetUnitsByGroupCode(String groupCode) throws Exception {

        HashMap<Integer, String> unitPairs = new HashMap<>();

        GetUnitsByGroupCodeRequest getUnitsByGroupCodeRequest = new GetUnitsByGroupCodeRequest();
        getUnitsByGroupCodeRequest.setGroupCode(groupCode);

        ObjectMapper mapper = new ObjectMapper();
        StringWriter writer = new StringWriter();

        mapper.writeValue(writer, getUnitsByGroupCodeRequest);

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .header(HttpHeaderNames.CONTENT_TYPE.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
                .header(HttpHeaderNames.ACCEPT.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
                .POST(HttpRequest.BodyPublishers.ofString(writer.toString()))
                .uri(new URI(channelFuseApi + BUCR_GET_UNITS_BY_GROUP_CODE))
                .build();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("GetUnitsByGroupCode called with :" + writer.toString());
        }
        HttpResponse<String> clientResponse = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (clientResponse.statusCode() == HttpResponseStatus.OK.code()) {
            GetUnitsByGroupCodeResponse response = mapper.readValue(clientResponse.body().getBytes(), GetUnitsByGroupCodeResponse.class);

            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("GetUnitsByGroupCodeResponse channel rest service returned :" + response.getResponseData().getUnits());
            }

            List<Unit> listOfUnits = response.getResponseData().getUnits();

            if (listOfUnits != null) {
                listOfUnits.forEach((unit) -> unitPairs.put(unit.getUnitId(), unit.getUnitCode()));
            }

        } else {
            ErrorUtils.throwCBSException(null,
                    String.valueOf(ConstantError_Types._Technical),
                    String.valueOf(ConstantError_System_IDs._FUSE),
                    this.getClass().getCanonicalName(),
                    String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob),
                    String.valueOf(ConstantError_Levels._Error),
                    "Service GetUnitsByGroupCodeResponse of channel api replied with status:" + clientResponse.statusCode(),
                    "",
                    "");
        }

        return unitPairs;
    }

    /**
     * Calls the channelFuseApi rest service GetTeamsByUnitCodeAndGroupCode, which returns a List of Unit objects.
     * Each Unit object consists of a unitId and a UnitCode.
     * This method returns a HashMap containing as key the unitId and as value the unitCode.
     *
     * @param unitCode
     * @param groupCode
     * @return
     * @throws Exception
     */
    private HashMap<Integer, String> bucrGetTeamsByUnitCodeAndGroupCode(String unitCode, String groupCode) throws Exception {

        HashMap<Integer, String> teamPairs = new HashMap<Integer, String>();

        GetTeamsByUnitCodeAndGroupCodeRequest getTeamsByUnitCodeAndGroupCode = new GetTeamsByUnitCodeAndGroupCodeRequest();
        getTeamsByUnitCodeAndGroupCode.setUnitCode(unitCode);
        getTeamsByUnitCodeAndGroupCode.setGroupCode(groupCode);

        ObjectMapper mapper = new ObjectMapper();
        StringWriter writer = new StringWriter();

        mapper.writeValue(writer, getTeamsByUnitCodeAndGroupCode);

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .header(HttpHeaderNames.CONTENT_TYPE.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
                .header(HttpHeaderNames.ACCEPT.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
                .POST(HttpRequest.BodyPublishers.ofString(writer.toString()))
                .uri(new URI(channelFuseApi + BUCR_GET_TEAMS_BY_UNIT_CODE_AND_GROUP_CODE))
                .build();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("GetTeamsByUnitCodeAndGroupCode called with :" + writer.toString());
        }
        HttpResponse<String> clientResponse = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (clientResponse.statusCode() == HttpResponseStatus.OK.code()) {
            GetTeamsByUnitCodeAndGroupCodeResponse response = mapper.readValue(clientResponse.body().getBytes(), GetTeamsByUnitCodeAndGroupCodeResponse.class);

            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("GetTeamsByUnitCodeAndGroupCodeResponse channel rest service returned :" + response.getResponseData().getUnits());
            }

            List<Unit> listOfUnits = response.getResponseData().getUnits();

            if (listOfUnits != null) {
                listOfUnits.forEach((unit) -> teamPairs.put(unit.getUnitId(), unit.getUnitCode()));
            }

        } else {
            ErrorUtils.throwCBSException(null,
                    String.valueOf(ConstantError_Types._Technical),
                    String.valueOf(ConstantError_System_IDs._FUSE),
                    this.getClass().getCanonicalName(),
                    String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob),
                    String.valueOf(ConstantError_Levels._Error),
                    "Service GetTeamsByUnitCodeAndGroupCode of channel api replied with status:" + clientResponse.statusCode(),
                    "",
                    "");
        }

        return teamPairs;
    }

    private List<String> bucrGetGroupsCodesByUnitCodeAndGroupTypeCode(String unitCode, String groupTypeCode) throws Exception {

        List<String> listOfGroupCodes = new ArrayList<>();

        //create object that will be  used as input for the channel service
        GetGroupsCodesByUnitCodeAndGroupTypeCodeRequest groupsCodesByUnitCodeAndGroupTypeCodeRequest = new GetGroupsCodesByUnitCodeAndGroupTypeCodeRequest();
        groupsCodesByUnitCodeAndGroupTypeCodeRequest.setUnitCode(unitCode);
        groupsCodesByUnitCodeAndGroupTypeCodeRequest.setGroupTypeCode(groupTypeCode);

        ObjectMapper mapper = new ObjectMapper();
        StringWriter writer = new StringWriter();

        mapper.writeValue(writer, groupsCodesByUnitCodeAndGroupTypeCodeRequest);

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .header(HttpHeaderNames.CONTENT_TYPE.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
                .header(HttpHeaderNames.ACCEPT.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
                .POST(HttpRequest.BodyPublishers.ofString(writer.toString()))
                .uri(new URI(channelFuseApi + BUCR_GET_GROUPS_CODES_BY_UNIT_CODE_AND_GROUP_TYPE_CODE))
                .build();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("GetGroupsCodesByUnitCodeAndGroupTypeCode called with :" + writer.toString());
        }
        HttpResponse<String> clientResponse = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (clientResponse.statusCode() == HttpResponseStatus.OK.code()) {
            GetGroupsCodesByUnitCodeAndGroupTypeCodeResponse response = mapper.readValue(clientResponse.body().getBytes(), GetGroupsCodesByUnitCodeAndGroupTypeCodeResponse.class);

            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("GetGroupsCodesByUnitCodeAndGroupTypeCode channel rest service returned :" + response.getResponseData().getGroupsCodes());
            }

            return response.getResponseData().getGroupsCodes();

        } else {
            ErrorUtils.throwCBSException(null,
                    String.valueOf(ConstantError_Types._Technical),
                    String.valueOf(ConstantError_System_IDs._FUSE),
                    this.getClass().getCanonicalName(),
                    ConstantErrorMessages._UERRMSGS_300001_texniko_prob,
                    String.valueOf(ConstantError_Levels._Error),
                    "Service GetGroupsCodesByUnitCodeAndGroupTypeCode of channel api replied with status:" + clientResponse.statusCode(),
                    "",
                    "");
        }
        return listOfGroupCodes;
    }
}