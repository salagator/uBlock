//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

import java.util.List;

public interface QueryServicesClient {
    String QUERY_MAP_PI = "ProcessInstances";
    String QUERY_MAP_PI_WITH_VARS = "ProcessInstancesWithVariables";
    String QUERY_MAP_TASK = "UserTasks";
    String QUERY_MAP_TASK_WITH_VARS = "UserTasksWithVariables";
    String QUERY_MAP_RAW = "RawList";
    String QUERY_MAP_TASK_SUMMARY = "TaskSummaries";
    String QUERY_MAP_PI_WITH_CUSTOM_VARS = "ProcessInstancesWithCustomVariables";
    String QUERY_MAP_TASK_WITH_CUSTOM_VARS = "UserTasksWithCustomVariables";
    String QUERY_MAP_ERROR = "ExecutionErrors";
    String QUERY_MAP_TASK_WITH_MODIF = "UserTasksWithModifications";
    String QUERY_MAP_TASK_WITH_PO = "UserTasksWithPotOwners";
    String QUERY_MAP_PI_CUSTOM = "ProcessInstancesCustom";
    String SORT_BY_NAME = "ProcessName";
    String SORT_BY_VERSION = "ProcessVersion";
    String SORT_BY_PROJECT = "Project";

    List<VariableInstance> findVariablesCurrentState(Long processInstanceId);

}
