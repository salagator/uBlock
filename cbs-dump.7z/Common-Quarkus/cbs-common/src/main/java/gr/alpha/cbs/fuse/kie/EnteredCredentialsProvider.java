package gr.alpha.cbs.fuse.kie;

import org.apache.hc.core5.http.HttpHeaders;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class EnteredCredentialsProvider implements CredentialsProvider {

    private String username;
    private String password;

    public EnteredCredentialsProvider(String username, String password) {
        this.username = username;
        this.password = password;
    }

    @Override
    public String getHeaderName() {
        return HttpHeaders.AUTHORIZATION;
    }

    @Override
    public String getAuthorization() {
        return BASIC_AUTH_PREFIX + Base64.getEncoder().encodeToString((username + ':' + password).getBytes(StandardCharsets.UTF_8));
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

