package gr.alpha.cbs.fuse.bucr;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class GetGroupsCodesByUnitCodeResponse {
	
	private GroupsCodes responseData;
	
	public GroupsCodes getResponseData() {
		return responseData;
	}

	public void setResponseData(GroupsCodes responseData) {
		this.responseData = responseData;
	}

}
