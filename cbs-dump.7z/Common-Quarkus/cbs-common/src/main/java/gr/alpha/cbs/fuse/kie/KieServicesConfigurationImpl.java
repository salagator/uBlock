//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class KieServicesConfigurationImpl implements KieServicesConfiguration {
    public static final String SSL_CONNECTION_FACTORY_NAME = "jms/SslRemoteConnectionFactory";
    public static final String CONNECTION_FACTORY_NAME = "jms/RemoteConnectionFactory";
    public static final String REQUEST_QUEUE_NAME = "jms/queue/KIE.SERVER.REQUEST";
    public static final String RESPONSE_QUEUE_NAME = "jms/queue/KIE.SERVER.RESPONSE";
    private long timeoutInMillisecs;
    private final KieServicesConfiguration.Transport transport;
    private String userName;
    private String password;
    private String serverUrl;
    private List<String> capabilities;
    private boolean useSsl;
    private MarshallingFormat format;
    private Set<Class<?>> extraClasses;
    private CredentialsProvider credentialsProvider;
    private LoadBalancer loadBalancer;
    private Map<String, String> headers;

    public KieServicesConfigurationImpl(String url, String username, String password) {
        this(url, username, password, 5000L);
    }

    public KieServicesConfigurationImpl(String url, String username, String password, long timeout) {
        this.timeoutInMillisecs = 10000L;
        this.useSsl = false;
        this.format = MarshallingFormat.JAXB;
        this.extraClasses = new HashSet();
        this.transport = Transport.REST;
        this.serverUrl = url;
        this.userName = username;
        this.password = password;
        this.timeoutInMillisecs = timeout;
        this.credentialsProvider = new EnteredCredentialsProvider(username, password);
    }

    public KieServicesConfigurationImpl(String url, CredentialsProvider credentialsProvider) {
        this(url, credentialsProvider, 5000L);
    }

    public KieServicesConfigurationImpl(String url, CredentialsProvider credentialsProvider, long timeout) {
        this.timeoutInMillisecs = 10000L;
        this.useSsl = false;
        this.format = MarshallingFormat.JAXB;
        this.extraClasses = new HashSet();
        this.transport = Transport.REST;
        this.serverUrl = url;
        this.timeoutInMillisecs = timeout;
        this.credentialsProvider = credentialsProvider;
    }

    public void dispose() {
        if (this.extraClasses != null) {
            this.extraClasses.clear();
            this.extraClasses = null;
        }

    }

    /*
    public KieServicesConfigurationImpl(ConnectionFactory connectionFactory, Queue requestQueue, Queue responseQueue) {
        this.timeoutInMillisecs = 10000L;
        this.useSsl = false;
        this.format = MarshallingFormat.JAXB;
        this.extraClasses = new HashSet();
        this.transport = Transport.JMS;
        this.credentialsProvider = null;
        checkValidValues(this.connectionFactory, this.requestQueue, this.responseQueue);
    }

    public KieServicesConfigurationImpl(ConnectionFactory connectionFactory, Queue requestQueue, Queue responseQueue, String username, String password) {
        this(connectionFactory, requestQueue, responseQueue);
        this.setAndCheckUserNameAndPassword(username, password);
    }

    public KieServicesConfigurationImpl(InitialContext context, String username, String password) {
        this.timeoutInMillisecs = 10000L;
        this.useSsl = false;
        this.format = MarshallingFormat.JAXB;
        this.extraClasses = new HashSet();
        this.transport = Transport.JMS;
        this.setAndCheckUserNameAndPassword(username, password);
        this.setRemoteInitialContext(context);
        this.credentialsProvider = new EnteredCredentialsProvider(username, password);
    }
     */

    private KieServicesConfiguration setAndCheckUserNameAndPassword(String username, String password) {
        if (username != null && !username.trim().isEmpty()) {
            this.userName = username;
            if (password == null) {
                throw new IllegalArgumentException("The password may not be null.");
            } else {
                this.password = password;
                return this;
            }
        } else {
            throw new IllegalArgumentException("The user name may not be empty or null.");
        }
    }

    public MarshallingFormat getMarshallingFormat() {
        return this.format;
    }

    public KieServicesConfiguration setMarshallingFormat(MarshallingFormat format) {
        this.format = format;
        return this;
    }

    public boolean isJms() {
        return this.transport == Transport.JMS;
    }

    public boolean isRest() {
        return this.transport == Transport.REST;
    }

    public String getServerUrl() {
        return this.serverUrl;
    }

    public String getUserName() {
        return this.userName;
    }

    public String getPassword() {
        return this.password;
    }

    public boolean addExtraClasses(Set<Class<?>> extraClassList) {
        return this.extraClasses.addAll(extraClassList);
    }

    public KieServicesConfiguration clearExtraClasses() {
        this.extraClasses.clear();
        return this;
    }

    public Set<Class<?>> getExtraClasses() {
        return this.extraClasses;
    }

    public KieServicesConfiguration.Transport getTransport() {
        return this.transport;
    }

    public long getTimeout() {
        return this.timeoutInMillisecs;
    }

    public boolean getUseSsl() {
        return this.useSsl;
    }

    public KieServicesConfiguration setTimeout(long timeout) {
        this.timeoutInMillisecs = timeout;
        return this;
    }

    public KieServicesConfiguration setServerUrl(String url) {
        this.serverUrl = url;
        return this;
    }

    public KieServicesConfiguration setUserName(String userName) {
        this.userName = userName;
        if (this.credentialsProvider instanceof EnteredCredentialsProvider) {
            ((EnteredCredentialsProvider)this.credentialsProvider).setUsername(userName);
        }

        return this;
    }

    public KieServicesConfiguration setPassword(String password) {
        this.password = password;
        if (this.credentialsProvider instanceof EnteredCredentialsProvider) {
            ((EnteredCredentialsProvider)this.credentialsProvider).setPassword(password);
        }

        return this;
    }

    public KieServicesConfiguration setExtraClasses(Set<Class<?>> extraJaxbClasses) {
        this.extraClasses.clear();
        if (extraJaxbClasses != null) {
            this.extraClasses.addAll(extraJaxbClasses);
        }

        return this;
    }

    public KieServicesConfiguration setUseSsl(boolean useSsl) {
        this.useSsl = useSsl;
        return this;
    }

    public void setCapabilities(List<String> capabilities) {
        this.capabilities = capabilities;
    }

    public List<String> getCapabilities() {
        return this.capabilities;
    }

    public void setCredentialsProvider(CredentialsProvider credentialsProvider) {
        this.credentialsProvider = credentialsProvider;
    }

    public CredentialsProvider getCredentialsProvider() {
        return this.credentialsProvider;
    }

    public void setLoadBalancer(LoadBalancer loadBalancer) {
        this.loadBalancer = loadBalancer;
    }

    public LoadBalancer getLoadBalancer() {
        return this.loadBalancer;
    }

    public void setHeaders(Map<String, String> headers) {
        this.headers = headers;
    }

    public Map<String, String> getHeaders() {
        return this.headers;
    }

    private KieServicesConfigurationImpl(KieServicesConfigurationImpl config) {
        this.timeoutInMillisecs = 10000L;
        this.useSsl = false;
        this.format = MarshallingFormat.JAXB;
        this.extraClasses = new HashSet();
        this.extraClasses = config.extraClasses;
        this.format = config.format;
        this.password = config.password;
        this.serverUrl = config.serverUrl;
        this.timeoutInMillisecs = config.timeoutInMillisecs;
        this.transport = config.transport;
        this.userName = config.userName;
        this.useSsl = config.useSsl;
        this.capabilities = config.capabilities;
        this.credentialsProvider = config.credentialsProvider;
        this.loadBalancer = config.loadBalancer;
        this.headers = config.headers;
    }

    public KieServicesConfiguration clone() {
        return new KieServicesConfigurationImpl(this);
    }

    public String toString() {
        return "KieServicesConfiguration{transport=" + this.transport + ", serverUrl='" + this.serverUrl + '\'' + '}';
    }

    /** @deprecated */
    @Deprecated
    public Set<Class<?>> getExtraJaxbClasses() {
        return this.getExtraClasses();
    }

    /** @deprecated */
    @Deprecated
    public boolean addJaxbClasses(Set<Class<?>> extraJaxbClassList) {
        return this.addExtraClasses(extraJaxbClassList);
    }

    /** @deprecated */
    @Deprecated
    public KieServicesConfiguration setExtraJaxbClasses(Set<Class<?>> extraJaxbClasses) {
        return this.setExtraClasses(extraJaxbClasses);
    }

    /** @deprecated */
    @Deprecated
    public KieServicesConfiguration clearJaxbClasses() {
        return this.clearExtraClasses();
    }
}
