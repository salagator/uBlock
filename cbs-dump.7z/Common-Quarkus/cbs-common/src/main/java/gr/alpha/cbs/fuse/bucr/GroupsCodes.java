package gr.alpha.cbs.fuse.bucr;

import java.util.List;

public class GroupsCodes {
	
	private List<String> groupsCodes;
	
	public List<String> getGroupsCodes() {
		return groupsCodes;
	}

	public void setGroupsCodes(List<String> groupsCodes) {
		this.groupsCodes = groupsCodes;
	}

}
