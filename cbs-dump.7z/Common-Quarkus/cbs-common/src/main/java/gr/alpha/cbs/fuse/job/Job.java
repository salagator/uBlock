package gr.alpha.cbs.fuse.job;

import org.apache.camel.util.ObjectHelper;
import org.jboss.logging.Logger;
import org.quartz.CronExpression;

import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.text.ParseException;
import java.time.*;
import java.util.HashMap;
import java.util.Map;

public class Job {
	
	private static final Logger LOGGER = Logger.getLogger(Job.class);
	private static final String TIMESTAMP_PATTERN = "yyyy-MM-dd HH:mm:ss";
	
	private final String dataSourceRef;
	private final String contextId;
	private final String jobName;
	private final String routeToExecute;
	private final Long failoverTimeMs;
	private final Long recurringEveryMs;
	private final String cron;
	private final boolean cronDeclaredInUTC;

	private Job(String dataSourceRef, String contexId, String jobName, String routeToExecute, Long failoverTimeMs, Long recurringEveryMs, String cron, boolean cronDeclaredInUTC) {
		this.dataSourceRef = dataSourceRef;
		this.contextId = contexId;
		this.jobName = jobName;
		this.routeToExecute = routeToExecute;
		this.failoverTimeMs = failoverTimeMs;
		this.recurringEveryMs = recurringEveryMs;
		this.cron = cron;
		this.cronDeclaredInUTC = cronDeclaredInUTC;
	}

	public String getDataSourceRef() {
		return this.dataSourceRef;
	}

	public String getContextId() {
		return this.contextId;
	}

	public String getJobName() {
		return this.jobName;
	}

	
	public String getRouteToExecute() {
		return this.routeToExecute;
	}

	public Long getFailoverTimeMs() {
		return this.failoverTimeMs;
	}

	public Long getRecurringEveryMs() {
		return this.recurringEveryMs;
	}

	public String getCron() {
		return this.cron;
	}
	public boolean isCronDeclaredInUTC() {return this.cronDeclaredInUTC;}

	public static Map<String, Method> getBuilderMethods() {
		Method[] jobBuilderMethods = Job.Builder.class.getDeclaredMethods();
		Map<String, Method> jobBuilderMethodsDirectory = new HashMap<>();
        for (Method m : jobBuilderMethods) {
            jobBuilderMethodsDirectory.put(m.getName(), m);
        }
		return jobBuilderMethodsDirectory;
	}


	public java.sql.Timestamp calculateNextCronExecutionDate() throws ParseException{

		Timestamp nextExecutionDateSQL = null;

		if(this.cron != null) {
			CronExpression cronexp = new CronExpression(this.cron);
			LOGGER.debug("CronExpression's description is " + cronexp.getExpressionSummary());

			// Camel cron component uses UTC while the system is in Europe/Athens locale.
			// This creates the implication that cron routes are fired at a later hour that what is specified
			// in the cron expression. For example,  0 */1 17 ? * * * will fire at 20:00+03:00. To mitigate for this
			// cronDeclaredInUTC property has been added. This allows the user to specify a cron expression in UTC time
			// and handles the execution in  Europe/Athens locale by appropriately zoning nextExecutionDate.


			ZoneId timezone = isCronDeclaredInUTC() ? ZoneId.of("UTC") : ZoneId.of(System.getProperty("cbs.time.zone", "Europe/Athens"));

			java.util.Date nowZonedD = java.sql.Timestamp.valueOf(LocalDateTime.now(timezone));
			java.util.Date nextExecutionDate = cronexp.getNextValidTimeAfter(nowZonedD);

			LOGGER.debug("LocalDateTime.now(timezone) is " + LocalDateTime.now(timezone));
			LOGGER.debug("nowZonedD is " + nowZonedD);
			LOGGER.debug("nextExecutionDate is " + nextExecutionDate);

			nextExecutionDateSQL = new Timestamp(nextExecutionDate.getTime());
			LOGGER.debug("nextExecutionDateSQL [java.sql.Timestamp] is " + nextExecutionDateSQL);

			if(isCronDeclaredInUTC()) {

				LocalDateTime nextExecutionDateLD = nextExecutionDateSQL.toLocalDateTime();
				ZonedDateTime z = nextExecutionDateLD.atZone(ZoneId.of("UTC")); // Get nextExcecutionDate in UTC
				LocalDateTime zLocal = LocalDateTime.ofInstant(z.toInstant(), ZoneId.of(System.getProperty("cbs.time.zone", "Europe/Athens"))); // Get nextExcecutionDate in local time zone
				nextExecutionDateSQL = java.sql.Timestamp.valueOf(zLocal); // Transform to timestamp

				LOGGER.debug("z is " + z);
				LOGGER.debug("zLocal is " + zLocal);
				LOGGER.debug("nextExecutionDateSQL [java.sql.Timestamp] with zone offset is " + nextExecutionDateSQL);

			}

		}

		return nextExecutionDateSQL;
	}

	public static class Builder {
		private String dataSourceRef;
		private String contextId;
		private String jobName;
		private String routeToExecute;
		private Long failoverTimeMs;
		private Long recurringEveryMs;
		private String cron;
		private boolean cronDeclaredInUTC;

		public Builder dataSourceRef(String dataSourceRef) {
			this.dataSourceRef = dataSourceRef;
			return this;
		}

		public Builder contextId(String contextId) {
			this.contextId = contextId;
			return this;
		}

		public Builder jobName(String jobName) {
			this.jobName = jobName;
			return this;
		}

		public Builder routeToExecute(String routeToExecute) {
			this.routeToExecute = routeToExecute;
			return this;
		}

		public Builder failoverTimeMs(Long failoverTimeMs) {
			this.failoverTimeMs = failoverTimeMs;
			return this;
		}

		public Builder recurringEveryMs(Long recurringEveryMs) {
			this.recurringEveryMs = recurringEveryMs;
			return this;
		}

		public Builder cron(String cron) {
			this.cron = cron;
			return this;
		}
		public Builder cronDeclaredInUTC(String cronDeclaredInUTC) {
			this.cronDeclaredInUTC =  Boolean.parseBoolean(cronDeclaredInUTC);
			return this;
		}

		public Job build() {
			ObjectHelper.isNotEmpty(contextId);
			ObjectHelper.isNotEmpty(jobName);
			ObjectHelper.isNotEmpty(routeToExecute);
			ObjectHelper.isNotEmpty(failoverTimeMs);

			if (cron == null) {
				ObjectHelper.isNotEmpty(recurringEveryMs);
				if (recurringEveryMs == null) {
					throw new IllegalArgumentException("recurringEveryMs must be specified when cron=null");
				}
			} else {
				ObjectHelper.isNotEmpty(cron);
				if (recurringEveryMs != null) {
					throw new IllegalArgumentException("recurringEveryMs must not be specified when cron is not null");
				}
			}


			return new Job(this.dataSourceRef, this.contextId, this.jobName, this.routeToExecute, this.failoverTimeMs, this.recurringEveryMs, this.cron, this.cronDeclaredInUTC);
		}
		
	}
}
