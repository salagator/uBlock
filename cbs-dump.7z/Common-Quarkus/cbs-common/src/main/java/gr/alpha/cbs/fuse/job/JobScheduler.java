package gr.alpha.cbs.fuse.job;

import java.beans.PropertyEditor;
import java.beans.PropertyEditorManager;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.util.*;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Any;
import jakarta.enterprise.inject.Instance;
import jakarta.enterprise.inject.literal.NamedLiteral;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import javax.sql.DataSource;

import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import org.apache.camel.CamelContext;
import org.apache.camel.LoggingLevel;
import org.apache.camel.Route;
import org.apache.camel.ShutdownRunningTask;
import org.apache.camel.builder.ExpressionBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.spi.CamelEvent;
import org.apache.camel.support.EventNotifierSupport;
import org.jboss.logging.Logger;


@Singleton
public class JobScheduler extends EventNotifierSupport {

	private static final Logger LOGGER = Logger.getLogger(JobScheduler.class);
	private static final String EXCEPTION_STACKTRACE = "${exception.stacktrace}";

	private boolean testMode;
	private DataSource ds;
	private List<Job> jobs;

	@Inject
	@Any
	Instance<DataSource> dsInstance;


	public JobScheduler() {
		this.testMode = false;
	}

	public JobScheduler(DataSource ds, List<Job> jobs) {
		this.testMode = false;
		this.ds = ds;
		this.jobs = jobs;
	}

	public void setTestMode(boolean testMode) {
		this.testMode = testMode;
	}


	@Override
	public void notify(CamelEvent event) throws Exception {
		if (jobs == null) {
			jobs = createJobsRepository();
		}

		if (jobs.isEmpty()) {
			return;
		}

		CamelEvent.CamelContextStartedEvent startedEvent = (CamelEvent.CamelContextStartedEvent) event;
		CamelContext context = startedEvent.getContext();

		if (jobs != null) {
			Iterator<Job> jobsIterator = jobs.iterator();
			while (jobsIterator.hasNext()) {
				Job job = jobsIterator.next();
				registerJob(job);
				createRoutes(context, job);
			}
		}
	}

	@Override
	public boolean isEnabled(CamelEvent event) {
		return (event instanceof CamelEvent.CamelContextStartedEvent);
	}

	public DataSource getDs() {
		return ds;
	}

	public void setDs(DataSource ds) {
		this.ds = ds;
	}

	public void setJobs(List<Job> jobs) {
		this.jobs = jobs;
	}

	public List<Job> getJobs() {
		return this.jobs;
	}

	private List<Job> createJobsRepository() throws IOException, IllegalAccessException, InvocationTargetException {
		InputStream propertiesFile = Thread.currentThread().getContextClassLoader().getResourceAsStream("gr/alpha/cbs/fuse/jobs.properties");

		if (propertiesFile == null) {
			return new ArrayList<>();
		}

		Properties properties = new Properties();
		properties.load(propertiesFile);
		propertiesFile.close();

		Set<String> keySet = new HashSet(properties.stringPropertyNames());
		Optional<String> dataSourceRefProperty = keySet.stream().parallel().filter(s -> s.equals("dataSourceRef")).findAny();
		String dataSourceRef = null;
		if (dataSourceRefProperty.isPresent()) {
			dataSourceRef = properties.getProperty(dataSourceRefProperty.get());
			keySet.remove(dataSourceRefProperty.get());
		}

		Map<String, Method> jobBuilderMethodsDirectory = Job.getBuilderMethods();
		Map<String, Job.Builder> jobsDirectory = new HashMap<>();
		Iterator<String> keys = keySet.iterator();
		while (keys.hasNext()) {
			String key = keys.next();
			Object value = properties.get(key);

			String jobName = key.substring(0, key.indexOf('.'));
			if (!jobsDirectory.containsKey(jobName)) {
				jobsDirectory.put(jobName, new Job.Builder().dataSourceRef(dataSourceRef).jobName(jobName));
			}

			String jobProperty = key.substring(jobName.length() + 1);
			Method m = jobBuilderMethodsDirectory.get(jobProperty);

			PropertyEditor editor = PropertyEditorManager.findEditor(m.getParameterTypes()[0]);
			editor.setAsText(String.valueOf(value));

			m.invoke(jobsDirectory.get(jobName), editor.getValue());
		}

		List<Job> jobsRegistry = new ArrayList<>();
		Iterator<Job.Builder> jobsIterator = jobsDirectory.values().iterator();
		while (jobsIterator.hasNext()) {
			Job job = jobsIterator.next().build();
			jobsRegistry.add(job);
		}

		return jobsRegistry;
	}

	private DataSource getDataSource(Job job){

		if (this.ds == null) {
			String dataSourceRef = job.getDataSourceRef();

			ds = dsInstance.select(NamedLiteral.of(dataSourceRef)).get();

		}
		return ds;
	}

	private void registerJob(Job job) throws SQLException, ParseException, CBSException {

		String jobName = job.getJobName();
		String routeToExecute = job.getRouteToExecute();
		String cron = job.getCron();
		Long recurringEveryMs = job.getRecurringEveryMs();
		Long failoverTimeMs = job.getFailoverTimeMs();
		String checkJobExistsQuery = this.testMode ? "SELECT COUNT(Id) FROM CFG_Job WHERE Name = ?" : "SELECT COUNT(Id) FROM CFG_Job WITH (nolock) WHERE Name = ?";
		String updateJobQuery = this.testMode ? "UPDATE CFG_Job SET RouteToExecute = ?, Cron = ?, RecurringEveryMs = ?, FailoverTimeMs = ?, NextExecutionDate = ?, WHERE Name = ?" : "exec Job_UpdateJob ?, ?, ?, ?, ?, ?;";
		String insertJobQuery = this.testMode ? "INSERT INTO CFG_Job (Name, RouteToExecute, Cron, RecurringEveryMs, FailoverTimeMs, Status, NextExecutionDate) VALUES (?, ?, ?, ?, ?, ?, ?)" : "exec Job_InsertJob ?, ?, ?, ?, ?, ?, ?;";
		
		try (Connection dbConnection = getDataSource(job).getConnection();
				PreparedStatement checkJobExistsStatement = dbConnection.prepareStatement(checkJobExistsQuery);) {
			checkJobExistsStatement.setString(1, jobName);

			try (ResultSet checkJobExistsResults = checkJobExistsStatement.executeQuery();) {
				boolean jobExists = false;

				if (checkJobExistsResults.next()) {
					jobExists = checkJobExistsResults.getInt(1) == 1;
				}

				if (jobExists) {
					try (PreparedStatement updateJobStatement = dbConnection.prepareStatement(updateJobQuery);) {
						updateJobStatement.setString(1, routeToExecute);
						if (cron != null) {
							updateJobStatement.setString(2, cron);
							updateJobStatement.setNull(3, Types.BIGINT);
						} else {
							updateJobStatement.setNull(2, Types.VARCHAR);
							updateJobStatement.setLong(3, recurringEveryMs);
						}
						updateJobStatement.setLong(4, failoverTimeMs);
						
						if (cron != null) {
							updateJobStatement.setTimestamp(5, job.calculateNextCronExecutionDate());
						} else {
							updateJobStatement.setNull(5, Types.TIMESTAMP);
						}
						
						updateJobStatement.setString(6, jobName);
						
						updateJobStatement.execute();
						
					}
				} else {
					try (PreparedStatement registerJobStatement = dbConnection.prepareStatement(insertJobQuery);) {
						registerJobStatement.setString(1, jobName);
						registerJobStatement.setString(2, routeToExecute);
						if (cron != null) {
							registerJobStatement.setString(3, cron);
							registerJobStatement.setNull(4, Types.BIGINT);
						} else {
							registerJobStatement.setNull(3, Types.VARCHAR);
							registerJobStatement.setLong(4, recurringEveryMs);
						}
						registerJobStatement.setLong(5, failoverTimeMs);
						registerJobStatement.setString(6, "Waiting");
						
						if (cron != null) {
							registerJobStatement.setTimestamp(7, job.calculateNextCronExecutionDate());
						} else {
							registerJobStatement.setNull(7, Types.TIMESTAMP);
						}
						
						registerJobStatement.execute();
					}
				}
			}
		}
	}
	
	private void createRoutes(CamelContext context, Job job) throws Exception {

		String jobName = job.getJobName();
		String cron = job.getCron();
		String routeToExecute = job.getRouteToExecute();

		String jobRouteId = String.format("jobRoute-%s", jobName);
		String heartbitRouteId = String.format("heartbitRoute-%s", jobName);

		String jobStatusMethod = String.format("jobStatus(*, %s, %s)", job.getDataSourceRef(), jobName);
		String jobCompleteMethod = String.format("completeJob(%s, %s, ${exchangeProperty.status}, ${exchangeProperty.nextExecutionDate})", job.getDataSourceRef(), jobName);
		String startHeartbitBeanMethod = String.format("startHeartbit(*, %s)", heartbitRouteId);
		String stopHeartbitBeanMethod = String.format("stopHeartbit(*, %s)", heartbitRouteId);

		String compareJobStatusHeaderNotUnknown = "${header.jobStatus} != 'Unknown'";
		String compareJobStatusHeaderEqualsStart = "${header.jobStatus} == 'Start'";
		String compareJobStatusHeaderEqualsCompleted = "${header.jobStatus} == 'Completed'";

		Route routeToExecuteDefinition = context.getRoute(routeToExecute);
		String routeToExecuteEndpoint = routeToExecuteDefinition.getEndpoint().getEndpointUri();

		if (cron != null) {
			context.addRoutes(new RouteBuilder() {

				@Override
				public void configure() throws Exception {
					String from = String.format("quartz://%s?cron=%s", jobRouteId, cron.replaceAll(" ", "+"));
					Job jobBeanIns = job;
					log.debug("Creating route {}", from);
	
					from(from)
						.routeId(jobRouteId)
						.shutdownRunningTask(ShutdownRunningTask.CompleteCurrentTaskOnly)
						.setProperty("cron", constant(cron))
						.setProperty("nextExecutionDate", constant(""))
						.log(LoggingLevel.DEBUG, "Started main quartz route.")
					.doTry()
						.log(LoggingLevel.DEBUG, String.format("Executing %s job", jobName))
						.to("bean:jobBean?method="+jobStatusMethod)
						.choice()
							.when()
								.simple(compareJobStatusHeaderNotUnknown)
								.to("bean:jobBean?method="+startHeartbitBeanMethod)
								.choice()
									.when()
										.simple(compareJobStatusHeaderEqualsStart)
										.toD(routeToExecuteEndpoint)
										.setProperty("status", constant("Waiting"))
										.setProperty("nextExecutionDate", ExpressionBuilder.beanExpression(jobBeanIns, "calculateNextCronExecutionDate"))
										.log(LoggingLevel.DEBUG, "Inside Quartz route. Exchange property nextExecutionDate is: " + simple("${exchangeProperty.nextExecutionDate}"))
										.to("bean:jobBean?method="+jobCompleteMethod)
										.to("bean:jobBean?method="+stopHeartbitBeanMethod)
								.endChoice()
							.endChoice()
						.end()
					.endDoTry()
					.doCatch(SQLException.class)
						.log(LoggingLevel.ERROR, EXCEPTION_STACKTRACE)
					.doCatch(Exception.class)
						.log(LoggingLevel.ERROR, EXCEPTION_STACKTRACE)
						.log(LoggingLevel.DEBUG, "Inside catch clause in main quartz route.")
						.setProperty("status", constant("Failed"))
						.to("bean:jobBean?method="+jobCompleteMethod)
					.end();
				}
			});
		} else {
			context.addRoutes(new RouteBuilder() {

				@Override
				public void configure() throws Exception {
					String from = String.format("timer://%s?fixedRate=true&period=%d", jobRouteId, job.getRecurringEveryMs());
					log.debug("Creating route {}", from);
	
					from(from)
						.routeId(jobRouteId)
						.shutdownRunningTask(ShutdownRunningTask.CompleteCurrentTaskOnly)
						.setProperty("nextExecutionDate", constant(""))
						.log(LoggingLevel.DEBUG, "Started main timer route.")
					.doTry()
						.log(LoggingLevel.DEBUG, String.format("Executing %s job", jobName))
						.to("bean:jobBean?method="+jobStatusMethod)
						.choice()
							.when()
								.simple(compareJobStatusHeaderNotUnknown)
								.to("bean:jobBean?method="+startHeartbitBeanMethod)
								.choice()
									.when()
										.simple(compareJobStatusHeaderEqualsStart)
										.toD(routeToExecuteEndpoint)
										.setProperty("status", constant("Waiting"))
										.to("bean:jobBean?method="+jobCompleteMethod)
										.to("bean:jobBean?method="+stopHeartbitBeanMethod)
									.otherwise()
										.log(LoggingLevel.DEBUG, String.format("%s job is already running.", jobName))
								.endChoice()
							.otherwise()
								.log(LoggingLevel.DEBUG, String.format("%s job status is unknown. Skipping execution.", jobName))
						.endChoice()
					.endDoTry()
					.doCatch(SQLException.class)
						.log(LoggingLevel.ERROR, EXCEPTION_STACKTRACE)
					.doCatch(Exception.class)
						.log(LoggingLevel.ERROR, EXCEPTION_STACKTRACE)
						.log(LoggingLevel.DEBUG, "Inside catch clause in main timer route.")
						.setProperty("status", constant("Failed"))
						.to("bean:jobBean?method="+jobCompleteMethod)
					.end();
				}
			});
		}

		context.addRoutes(new RouteBuilder() {

			@Override
			public void configure() throws Exception {
				String from = String.format("timer://%s?fixedRate=true&period=%d", heartbitRouteId, job.getFailoverTimeMs());
				Job jobBeanIns = job;
				log.debug("Creating hearbit route {}", from);

				from(from)
					.routeId(heartbitRouteId)
					.autoStartup(false)
					.shutdownRunningTask(ShutdownRunningTask.CompleteCurrentTaskOnly)
					.setProperty("cron", constant(cron))
					.setProperty("nextExecutionDate", constant(""))
					.log(LoggingLevel.DEBUG, "Started failover route.")
				.doTry()
					.log(LoggingLevel.DEBUG, String.format("%s heartbit tick", jobName))
					.to("bean:jobBean?method="+jobStatusMethod)
					.choice()
						.when()
							.simple(compareJobStatusHeaderEqualsStart)
							.log(LoggingLevel.DEBUG, String.format("Heartbit starting job %s - Executing route %s", jobName, routeToExecute))
							.toD(routeToExecuteEndpoint)
							.choice()
								.when()
									.simple("${exchangeProperty.cron} != ''")
									.setProperty("nextExecutionDate", ExpressionBuilder.beanExpression(jobBeanIns, "calculateNextCronExecutionDate"))
									.log(LoggingLevel.DEBUG, "Inside failover timer route. Exchange property nextExecutionDate is: " + simple("${exchangeProperty.nextExecutionDate}"))
							.endChoice()
							.setProperty("status", constant("Waiting"))
							.to("bean:jobBean?method="+jobCompleteMethod)
						.when()
							.simple(compareJobStatusHeaderEqualsCompleted)
							.log(LoggingLevel.DEBUG, String.format("%s heartbit stop", jobName))
							.to("bean:jobBean?method="+stopHeartbitBeanMethod)
						.endChoice()
					.end()
				.endDoTry()
				.doCatch(SQLException.class)
					.log(LoggingLevel.ERROR, EXCEPTION_STACKTRACE)
				.doCatch(Exception.class)
					.log(LoggingLevel.ERROR, EXCEPTION_STACKTRACE)
					.log(LoggingLevel.DEBUG, "Inside catch clause in failover route.")
					.setProperty("status", constant("Failed"))
					.to("bean:jobBean?method="+jobCompleteMethod)
				.end();
			}
		});
	}


}
