package gr.alpha.cbs.fuse.support;

import java.io.ByteArrayOutputStream;

/**
 * A specialization of a byte array output stream to avoid doing an array copy
 * every time we want to get the bytes of the underlying byte array. Care
 * should be taken when using this, because the byte array returned from the
 * <code>getBuffer</code> method is the same one used by this class, and so
 * any changes to it, will be applied to this class' buffer as well.
 *
 * See AbstractCamelRouteDrivingJSONServlet for sample use of this.
 */
public class NonCopyingByteArrayOutputStream extends ByteArrayOutputStream {

    public NonCopyingByteArrayOutputStream() {
        super();
    }

    public NonCopyingByteArrayOutputStream(byte[] contents) {
        super();
        this.buf = contents;
        this.count = contents.length;
    }

    public byte[] getBuffer() {
        return buf;
    }
}
