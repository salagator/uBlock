package gr.alpha.cbs.fuse.ifaces;

import java.util.Map;

import org.apache.camel.Body;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangeProperties;

public interface BUNHandlerInterface {

	void getBUNFromTUN(Exchange exchange, String tun) throws Exception;

	void getTUNFromBUN(Exchange exchange, String bun ) throws Exception;

	void getTUNFromBUN(Exchange exchange, String bun, String outputHeader ) throws Exception;

	void getBUNFromSigloTUN(Exchange exchange, String valeurDate, String unitCode, String tun) throws Exception;

	Object completeTransaction (@Body Object body, @ExchangeProperties Map<String,Object> properties) throws Exception;

	Object createBUN(@Body Object body, @ExchangeProperties Map<String,Object> properties) throws Exception;

	Object addTUN(@Body Object body, @ExchangeProperties Map<String,Object> properties) throws Exception;

	void createDUN(Exchange exchange) throws Exception;

	void createDUNv2(Exchange exchange) throws Exception;

	String createBUNnoArgs() throws Exception;
}
