package gr.alpha.cbs.fuse.support;

import io.quarkus.arc.DefaultBean;
import io.quarkus.arc.properties.IfBuildProperty;
import io.quarkus.runtime.StartupEvent;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.event.Observes;
import jakarta.enterprise.inject.Instance;
import jakarta.enterprise.inject.Produces;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

@Singleton
@RegisterForReflection
public class RemoteDataGridHelperConfigurer {

    @Produces
    @IfBuildProperty(name = "remote.datagrid.helper.initializer.noop", stringValue = "true")
    RemoteDataGridHelperInitializer produceNoopRemoteDataGridHelperInitializer() {
        return new NoopRemoteDataGridHelperInitializer();
    }

    @Produces
    @DefaultBean
    RemoteDataGridHelperInitializer produceRealRemoteDataGridHelperInitializer() {
        RemoteDataGridHelperInitializer initializer = new RealRemoteDataGridHelperInitializer();
        initializer.init();
        return initializer;
    }

    @Inject
    Instance<RemoteDataGridHelperInitializer> initializerInstance;

    public void init(@Observes StartupEvent ev) {
        // Intentionally left blank
        if (initializerInstance.isResolvable()) {
            // Force the initialization of the RemoteDataGridHelperInitializer bean
            initializerInstance.get();
        }
    }

}
