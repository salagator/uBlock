package gr.alpha.cbs.fuse.support;

import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;

@Named("transformHostAmountXsltExtension")
@ApplicationScoped
@RegisterForReflection
public class TransformHostAmountXsltExtension extends ExtensionFunctionDefinition {

    /**
     *
     */
    private static final long serialVersionUID = -2060328806406054162L;

    @Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("sb", "http://fuse.cbs.alpha.gr/transformHostAmount/", "transformHostAmount");
    }

    @Override
    public SequenceType[] getArgumentTypes() {
        return new SequenceType[]{SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING,};

    }

    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
        return SequenceType.SINGLE_STRING;
    }

    @Override
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {

            /**
             *
             */
            private static final long serialVersionUID = -2058195000003838019L;

            @Override
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
                try {

                    String number = null;
                    String fromIntPart = null;
                    String fromDecPart = null;
                    String toIntPart = null;
                    String toDecPart = null;

                    //Check the number parameter
                    if (arguments[0] instanceof LazySequence) {
                        number = ((LazySequence)arguments[0]).head().getStringValue();
                    } else if (arguments[0] instanceof StringValue) {
                        number = ((StringValue)arguments[0]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type for number parameter: " + arguments[0].getClass().getCanonicalName());
                    }

                    //Check the fromIntPart
                    if (arguments[1] instanceof LazySequence) {
                        fromIntPart = ((LazySequence)arguments[1]).head().getStringValue();
                    } else if (arguments[1] instanceof StringValue) {
                        fromIntPart = ((StringValue)arguments[1]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type for fromIntPart parameter: " + arguments[1].getClass().getCanonicalName());
                    }

                    //Check the fromDecPart
                    if (arguments[2] instanceof LazySequence) {
                        fromDecPart = ((LazySequence)arguments[2]).head().getStringValue();
                    } else if (arguments[2] instanceof StringValue) {
                        fromDecPart = ((StringValue)arguments[2]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type for fromDecPart parameter: " + arguments[2].getClass().getCanonicalName());
                    }

                    //Check the toIntPart
                    if (arguments[3] instanceof LazySequence) {
                        toIntPart = ((LazySequence)arguments[3]).head().getStringValue();
                    } else if (arguments[3] instanceof StringValue) {
                        toIntPart = ((StringValue)arguments[3]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type for toIntPart parameter: " + arguments[3].getClass().getCanonicalName());
                    }

                    //Check the toDecPart
                    if (arguments[4] instanceof LazySequence) {
                        toDecPart = ((LazySequence)arguments[4]).head().getStringValue();
                    } else if (arguments[4] instanceof StringValue) {
                        toDecPart = ((StringValue)arguments[4]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type for toDecPart parameter: " + arguments[4].getClass().getCanonicalName());
                    }


                    return StringValue.makeStringValue(FormatUtils.transformHostNumbers(number, Integer.parseInt(fromIntPart), Integer.parseInt(fromDecPart), Integer.parseInt(toIntPart), Integer.parseInt(toDecPart))) ;

                } catch (Exception e) {
                    throw new XPathException("Unable to translate value", e);
                }
            }
        };


    }
}