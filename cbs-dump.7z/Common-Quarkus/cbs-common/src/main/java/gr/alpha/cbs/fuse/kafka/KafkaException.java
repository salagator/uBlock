package gr.alpha.cbs.fuse.kafka;

public class KafkaException extends RuntimeException {
	private static final long serialVersionUID = 7139167719323271886L;

	public KafkaException(String message) {
		super(message);
	}

	public KafkaException(String message, Throwable throwable) {
		super(message, throwable);
	}

	public KafkaException(Throwable throwable) {
		super(throwable);
	}
}
