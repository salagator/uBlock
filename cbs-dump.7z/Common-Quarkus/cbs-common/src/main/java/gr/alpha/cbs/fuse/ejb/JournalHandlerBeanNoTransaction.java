package gr.alpha.cbs.fuse.ejb;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.transaction.Transactional;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangeProperty;
import org.jboss.logging.Logger;

import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

@Named("journalHandlerBeanNoTransaction")
@ApplicationScoped
@RegisterForReflection
public class JournalHandlerBeanNoTransaction extends AbstractJournalHandlerBean {

	@Inject
	@io.quarkus.agroal.DataSource("cbsxa")
	DataSource sqlDS;

	@Inject
	@io.quarkus.agroal.DataSource("cbsun")
	DataSource sqlDsCBSUN;

	protected DataSource getDataSource() {
		return sqlDS;
	}

	private static final Logger LOGGER = Logger.getLogger(JournalHandlerBeanNoTransaction.class);

	@Transactional(Transactional.TxType.REQUIRES_NEW)
	public void createJournalFailRecord(@ExchangeProperty("journalMap") Map<String, Object> journalMap) throws Exception {
		LOGGER.debug("createJournalFailRecord");
		try {
			// TODO take null protection away when journal horizontal is fully
			// implemented
			if (journalMap != null)
				writeToDatabase(journalMap, false);
		} catch (Exception e) {
			LOGGER.error("FATAL error in Journal Record");
			throw e;
		}
	}

	@Transactional(Transactional.TxType.REQUIRES_NEW)
	public void checkBUN(Exchange exchange) throws SQLException, CBSException {


		ResultSet res = null;
		String bun = exchange.getProperty("cbs.common.reqBUN", String.class);

		String sql = "select BUN FROM JOU_Data WHERE BUN = ?";
		try (Connection conn = this.sqlDsCBSUN.getConnection();PreparedStatement pstm = conn.prepareStatement(sql)) {

			pstm.setString(1, bun);
			res = pstm.executeQuery();

			if (!res.next()) {
				ErrorUtils.throwCBSException(null,
						String.valueOf(ConstantError_Types._Functional),
						String.valueOf(ConstantError_System_IDs._FUSE),
						this.getClass().getCanonicalName(),
						String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob),
						String.valueOf(ConstantError_Levels._Error),
						"BUN not found in database even though transaction is reversal!",
						"",
						"",
						"");
			}

		} catch (Exception ex) {
			if (!(ex instanceof CBSException)){
				ErrorUtils.throwCBSException(ex,
						String.valueOf(ConstantError_Types._Functional),
						String.valueOf(ConstantError_System_IDs._FUSE),
						this.getClass().getCanonicalName(),
						String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob),
						String.valueOf(ConstantError_Levels._Error),
						ex.getMessage(),
						"",
						"",
						"");
			}else
				throw ex;
		} finally {
			if (res != null) {
				res.close();
			}
		}
	}

}