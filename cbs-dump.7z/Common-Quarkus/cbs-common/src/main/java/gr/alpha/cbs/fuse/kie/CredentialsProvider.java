package gr.alpha.cbs.fuse.kie;

public interface CredentialsProvider {

    String BASIC_AUTH_PREFIX = "Basic ";
    String TOKEN_AUTH_PREFIX = "Bearer ";

    /**
     * Returns name of the HTTP header to be set with given authorization
     * @return
     */
    String getHeaderName();

    /**
     * Returns authorization string that shall be used for setting up
     * "Authorization" header for HTTP communication. It's expected to be completely setup
     * including prefix (such as Basic) and encryption (such as Base64 in case of basic) if needed.
     * @return
     */
    String getAuthorization();
}

