package gr.alpha.cbs.fuse.printing;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;

import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Node;

import gr.alpha.cbs.fuse.printing.siglo.PrintingExtentions;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;

public class LoanPaymentsPrintingLibrary {
	private static final Logger logger = LoggerFactory.getLogger(LoanPaymentsPrintingLibrary.class);

	public static final String EMPTY_STRING = "";

	private LoanPaymentsPrintingLibrary() {
		throw new IllegalStateException("Utility class");
	}

	static boolean isDefCurrency(String currency) {
		return (currency.equals(EMPTY_STRING) || currency.equals("EUR"));
	}
	
	@SuppressWarnings("unused")
	private static class ESlipState {
		ArrayList<TransactionDescription> transactionDescriptionList;
		ArrayList<TransactionDescription> transactionDescriptionList2;
		String transactionDescription;
		String transactionDescription2;
		String multiplePages;
		
		Node loanPrintingInformationResponse;
		Node ai00009Response;
		Node ai00004Response;
		Node ai83007Response;
		Node ct60001Response;

		String gestorLoanOperationCode;
		
		String loanAccountType;
		String loanBranchCode;
		String loanReportsIndicator2;
		String loanProductCode;

		String loanOperationCode;
		String loanCurrency;
		String loanTransactionType;
		String loanSettlementItemCode;
		String loanOpeningValueDate;
		String loanPledgedIndicator;
		Integer loanMaximumPeriodNumber;
		Integer loanAuthorizationNumber;
		String loanComissionCode1;
		String loanComissionCode2;
		String loanComissionCode4;

		Integer ct60001ResponseNumber;

		double loanCommisionAmmountOpeningLoanGuarantee;
		double loanAmortizationAmount;
		double loanInterestAmount;
		double loanDelaysAmount;
		double loanWithdrawnAmount;
		
		//ΗΜΕΡΟΛΟΓΙΑΚΗ ΠΙΣΤΩΣΗ
		int loanRecordValue1;
		
		Integer indSoporte;

		Integer litOperation;
		Integer indBond;
		Integer numCopies;
		Integer printInfoPage;
		Integer comesFromLit;

		Boolean rel541;

		public void calculateValuesPartA(XPath xpath) throws XPathExpressionException {
			loanAccountType = xpath.evaluate(
					"LoanDataRetrieval/LoanAccountKey/LoanAccountRecordData/LoanAccountType", ai00009Response);
			loanBranchCode = xpath.evaluate("LoanDataRetrieval/LoanAccountData/LoanBranchCode", ai00009Response);
			loanReportsIndicator2 = xpath.evaluate("LoanDataRetrieval/LoanAccountData/LoanReportsIndicator2",
					ai00009Response);
			loanProductCode = xpath.evaluate("LoanDataRetrieval/LoanAccountData/LoanProductCode",
					ai00009Response);

			loanOperationCode = xpath.evaluate("LoanVoucherPrintingData/LoanOperationCode",
					loanPrintingInformationResponse);
			loanCurrency = xpath.evaluate("LoanVoucherPrintingData/LoanCurrency0Code",
					loanPrintingInformationResponse);
			loanTransactionType = xpath.evaluate("LoanVoucherPrintingData/LoanTransactionType",
					loanPrintingInformationResponse);
			loanSettlementItemCode = xpath.evaluate(
					"LoanVoucherPrintingSettlementsDataList/LoanVoucherPrintingSettlementsData[1]/LoanSettlementItemCode[1]",
					loanPrintingInformationResponse);
			if (loanSettlementItemCode == null) {
				logger.info("Loan settlement item code is null");
				loanSettlementItemCode = EMPTY_STRING;
				try {
					String returnValue = FormatUtils.nodeToString(loanPrintingInformationResponse, FormatUtils.OMIT_XML_DECLARATION_YES, FormatUtils.INDENT_NO);
					logger.info("loan printing information response is " + returnValue);
				} catch (TransformerFactoryConfigurationError e) {
					logger.error("Unable to convert node to string", e);
				} catch (TransformerException e) {
					logger.error("Unable to convert node to string", e);
				}
			}
			loanOpeningValueDate = xpath.evaluate("LoanVoucherPrintingSALData/LoanOpeningValueDate",
					loanPrintingInformationResponse);
			loanPledgedIndicator = xpath.evaluate("LoanVoucherPrintingSALData/LoanPledgedIndicator",
					loanPrintingInformationResponse);
			loanMaximumPeriodNumber = Integer.parseInt(xpath
					.evaluate("LoanVoucherPrintingSALData/LoanMaximumPeriodNumber", loanPrintingInformationResponse));
			loanAuthorizationNumber = Integer.parseInt(
					xpath.evaluate("LoanVoucherPrintingData/LoanAuthorizationNumber", loanPrintingInformationResponse));
			loanComissionCode1 = xpath.evaluate(
					"LoanVoucherPrintingComissionsDataList/LoanVoucherPrintingComissionsData[1]/LoanComissionCode",
					loanPrintingInformationResponse);
			loanComissionCode2 = xpath.evaluate(
					"LoanVoucherPrintingComissionsDataList/LoanVoucherPrintingComissionsData[2]/LoanComissionCode",
					loanPrintingInformationResponse);
			loanComissionCode4 = xpath.evaluate(
					"LoanVoucherPrintingComissionsDataList/LoanVoucherPrintingComissionsData[4]/LoanComissionCode",
					loanPrintingInformationResponse);

			ct60001ResponseNumber = 0;
			if (ct60001Response != null) {
				ct60001ResponseNumber = Integer.parseInt(xpath.evaluate("RELCTAS/LoanResponseNumber", ct60001Response));
			}

			loanCommisionAmmountOpeningLoanGuarantee = Double
					.parseDouble(xpath.evaluate("LoanVoucherPrintingData/LoanCommisionAmmountOpeningLoanGuarantee",
							loanPrintingInformationResponse));
			loanAmortizationAmount = Double.parseDouble(
					xpath.evaluate("LoanVoucherPrintingData/LoanAmortizationAmount", loanPrintingInformationResponse));
			loanInterestAmount = Double.parseDouble(
					xpath.evaluate("LoanVoucherPrintingData/LoanInterestAmount", loanPrintingInformationResponse));
			loanDelaysAmount = Double.parseDouble(
					xpath.evaluate("LoanVoucherPrintingData/LoanDelaysAmount", loanPrintingInformationResponse));
			loanWithdrawnAmount = 0;
			if (ai00004Response != null) {
				loanWithdrawnAmount = Double
						.parseDouble(xpath.evaluate("LoanAccountData/LoanWithdrawnAmount", ai00004Response));
			}
			
		}
		
		public void calculateValuesPartB(XPath xpath, Map<String, Object> printingMap) throws XPathExpressionException {
			//ΗΜΕΡΟΛΟΓΙΑΚΗ ΠΙΣΤΩΣΗ
			loanRecordValue1 = 0;
			if (printingMap.get("Tai83034_delRegistro") instanceof String) {
				loanRecordValue1 = ((String) printingMap.get("Tai83034_delRegistro")).length();
			} 
			
			indSoporte = 0;
			if (loanBranchCode.length() > 0) {
				indSoporte = Integer.parseInt(loanBranchCode.substring(loanBranchCode.length() - 1));
			}

			litOperation = 0;
			indBond = 0;
			numCopies = 99;
			printInfoPage = 0;
			comesFromLit = 0;

			// Check if the operation refers to transfer to litigation and its
			// annulment or not.
			if (loanOperationCode.equals("11205") || loanOperationCode.equals("31217")
					|| loanOperationCode.equals("51216") || loanOperationCode.equals("71205")
					|| loanOperationCode.equals("71217") || loanOperationCode.equals("71216")) {
				litOperation = 1;
			}

			rel541 = false;
			/* if (!strcmp(Gestor.CodWindow, "DRC14")) rel541 = true; */
			
			if (ai83007Response != null) {
				indBond = Integer.parseInt(xpath.evaluate("LoanOKIndicatorAIS83007", ai83007Response));
			}

			if (isDefCurrency(loanCurrency) && numCopies > 90) {
				printInfoPage = 0;
				numCopies = 3;
			}

			// MultiCurrency Loan
			if (!isDefCurrency(loanCurrency) && numCopies > 90) {
				if (loanOperationCode.equals("10878") || loanOperationCode.equals("50875")
						|| loanOperationCode.equals("30876")) {
					printInfoPage = 1;
				} else {
					printInfoPage = 0;
					numCopies = 3;
				}
			}

		}
		
		public void calculateValuesPartC(Map<String, Object> printingMap) {
			if (loanOperationCode.equals("90760") || loanOperationCode.equals("70760")) {
				numCopies--;
			} else {
				if (loanSettlementItemCode.equals(EMPTY_STRING) && numCopies == 3) {
					numCopies--;
				}
			}

			if (loanCommisionAmmountOpeningLoanGuarantee == 0 && numCopies == 2) {
				numCopies--;
			}

			// Nothing To Print
			if (loanSettlementItemCode.equals(EMPTY_STRING) && loanCommisionAmmountOpeningLoanGuarantee == 0
					&& (loanAmortizationAmount + loanInterestAmount + loanDelaysAmount == 0)) {
				return;
			}

			// The Loan Amortization for partial Convertion not printed
			if (numCopies == 1 && loanOperationCode.equals("50875")) {
				return;
			}

		}
	}

	public static void generateESlip(Map<String, Object> printingMap) {
		try {
			ESlipState eSlipState = new ESlipState();
			XPath xpath = new net.sf.saxon.xpath.XPathFactoryImpl().newXPath();
			eSlipState.transactionDescriptionList = new ArrayList<>();
			eSlipState.transactionDescriptionList2 = new ArrayList<>();
			eSlipState.transactionDescription = "";
			eSlipState.transactionDescription2 = "";
			eSlipState.multiplePages ="";
			
			eSlipState.loanPrintingInformationResponse = ((Node) printingMap.get("TLoanPrintingInformationResponse"));
			eSlipState.ai00009Response = ((Node) printingMap.get("Tdata_ai00009Response"));
			eSlipState.ai00004Response = ((Node) printingMap.get("Tdata_ai00004Response"));
			eSlipState.ai83007Response = ((Node) printingMap.get("Tdata_ai83007Response"));
			eSlipState.ct60001Response = ((Node) printingMap.get("Tdata_ct60001Response"));

			eSlipState.gestorLoanOperationCode = "";

			if (printingMap.get("TGestor_LoanOperationCode") instanceof String) {
				eSlipState.gestorLoanOperationCode = ((String) printingMap.get("TGestor_LoanOperationCode"));
			} else {
				throw new IllegalStateException("Printing properties are missing.");
			}

			if (eSlipState.loanPrintingInformationResponse == null || eSlipState.ai00009Response == null) {
				throw new IllegalStateException("Printing properties are missing.");
			}
			
			eSlipState.calculateValuesPartA(xpath);
			eSlipState.calculateValuesPartB(xpath, printingMap);
			eSlipState.calculateValuesPartC(printingMap);
			
			if (eSlipState.numCopies == 1) {
				evaluateNumCopies1(xpath, eSlipState);
			} // numcopies =1

			if (eSlipState.numCopies == 2) {
				evaluateNumCopies2(eSlipState);
			} // numcopies = 2

			if (eSlipState.numCopies == 3) {
				eSlipState.multiplePages = evaluateNumCopies3(eSlipState);
			} // numCopies==3

			if (eSlipState.loanTransactionType.startsWith("1") && (eSlipState.loanOperationCode.equals("40810")
					|| eSlipState.loanOperationCode.equals("40811") || eSlipState.loanOperationCode.equals("40812"))) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P03C1);

				eSlipState.transactionDescriptionList.remove(LoanPrintingDataSource.P0105);
				eSlipState.transactionDescriptionList.remove(LoanPrintingDataSource.P01C1);
				eSlipState.transactionDescriptionList.remove(LoanPrintingDataSource.P03C0);
			}

			// AI20MULT
			if (!isDefCurrency(eSlipState.loanCurrency) && eSlipState.transactionDescriptionList.contains(LoanPrintingDataSource.P0105)) {
				eSlipState.transactionDescriptionList.remove(LoanPrintingDataSource.P0105);
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.MC01);
			}

			Collections.sort(eSlipState.transactionDescriptionList, new Comparator<TransactionDescription>() {
				public int compare(TransactionDescription o1, TransactionDescription o2) {
					return Integer.compare(o1.getIndex(), o2.getIndex());
				}
			});
			
			//set TransactionDescription
			for (TransactionDescription element : eSlipState.transactionDescriptionList) {
				eSlipState.transactionDescription = eSlipState.transactionDescription.concat(element.getDescription());
			}

			eSlipState.transactionDescription = PrintingExtentions.generatePlaceholders(eSlipState.transactionDescription, printingMap);
			if(eSlipState.transactionDescription.length() > 0){
				eSlipState.transactionDescription = eSlipState.transactionDescription.substring(0, eSlipState.transactionDescription.length() - 1);
			}
			printingMap.put("Tdata_TransactionDescription", eSlipState.transactionDescription);
			
			//set TransactionDescription2
			for (TransactionDescription element : eSlipState.transactionDescriptionList2) {
				eSlipState.transactionDescription2 = eSlipState.transactionDescription2.concat(element.getDescription());
			}

			eSlipState.transactionDescription2 = PrintingExtentions.generatePlaceholders(eSlipState.transactionDescription2, printingMap);
			if(eSlipState.transactionDescription2.length() > 0){
				eSlipState.transactionDescription2 = eSlipState.transactionDescription2.substring(0, eSlipState.transactionDescription2.length() - 1);
			}
			else {
				eSlipState.transactionDescription2 = eSlipState.transactionDescription;
			}
			printingMap.put("Tdata_TransactionDescription2", eSlipState.transactionDescription2);
			printingMap.put("Tdata_MultiplePages", eSlipState.multiplePages);

		} catch (Exception e) {
			throw new IllegalStateException("An error occured while printing.", e);
		}

	}

	private static String evaluateNumCopies3(ESlipState eSlipState) {
		if (eSlipState.loanOperationCode.equals("70872")) {
			if (eSlipState.loanRecordValue1 > 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P27);
				eSlipState.transactionDescriptionList2.add(LoanPrintingDataSource.P26);
			}
			else {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P26);
			}
		}
		if (eSlipState.loanOperationCode.equals("70815")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P31);
			eSlipState.multiplePages = "Y";
		}
		if (eSlipState.loanOperationCode.equals("70822") || eSlipState.loanOperationCode.equals("70852")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P31);
		}
		if (eSlipState.loanOperationCode.equals("70802")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P43);
		}
		if (eSlipState.loanOperationCode.equals("71216") || eSlipState.loanOperationCode.equals("71217") ||
				eSlipState.loanOperationCode.equals("71205")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P26);
		}

		switch (eSlipState.indSoporte) {
		case 2:

			if (eSlipState.loanOperationCode.equals("30822") || eSlipState.loanOperationCode.equals("90760")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P68);
			}
			if (eSlipState.loanOperationCode.equals("70760")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.R68);
			}
			break;
		case 1:
			if (eSlipState.loanOperationCode.equals("30822") || eSlipState.loanOperationCode.equals("90760")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P67);
			}
			if (eSlipState.loanOperationCode.equals("70760")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.R68);
			}
			break;
		case 0:
		default:
			if (eSlipState.loanOperationCode.equals("30822")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P29);
			}
			if (eSlipState.loanOperationCode.equals("90760")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P29N);
			}

			break;
		}
		return eSlipState.multiplePages;
	}

	private static void evaluateNumCopies2(ESlipState eSlipState) {
		if (eSlipState.loanOperationCode.equals("30874")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P53);
		}
		if (eSlipState.loanOperationCode.equals("70874")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P54);
		}
		if (eSlipState.loanOperationCode.equals("30881")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P91);
		}
		if (eSlipState.loanOperationCode.equals("70881")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P92);
		}

		if (!(!eSlipState.loanComissionCode1.startsWith("0") && eSlipState.loanComissionCode2.startsWith("0")
				&& (eSlipState.loanComissionCode4.equals("903") || eSlipState.loanComissionCode4.equals("775")
						|| eSlipState.loanComissionCode4.equals("777") || eSlipState.loanComissionCode4.equals("778")
						|| eSlipState.loanComissionCode4.equals("904")))) {
			if (eSlipState.loanProductCode.equals("1424") || eSlipState.loanProductCode.equals("1438")
					|| eSlipState.loanProductCode.equals("1445") || eSlipState.loanProductCode.equals("1465")
					|| eSlipState.loanProductCode.equals("1466") || eSlipState.loanProductCode.equals("1460")
					|| eSlipState.loanProductCode.equals("1462")) {
				if (eSlipState.loanOperationCode.equals("10800") || eSlipState.loanOperationCode.equals("10879") ||
						eSlipState.loanOperationCode.equals("40810") || eSlipState.loanOperationCode.equals("40811") ||
						eSlipState.loanOperationCode.equals("40812")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P99);
				}
			} else if (eSlipState.loanProductCode.equals("1468")) {
				if (eSlipState.loanOperationCode.equals("10800") || eSlipState.loanOperationCode.equals("10879") ||
						eSlipState.loanOperationCode.equals("40810") || eSlipState.loanOperationCode.equals("40811") ||
						eSlipState.loanOperationCode.equals("40812")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.R99);
				}

			} else {
				if (eSlipState.loanOperationCode.equals("10800") || eSlipState.loanOperationCode.equals("10879") ||
						eSlipState.loanOperationCode.equals("40810") || eSlipState.loanOperationCode.equals("40811") ||
						eSlipState.loanOperationCode.equals("40812")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P14);
				}
			}
		}

		eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P66);

		if (eSlipState.loanOperationCode.equals("50806") || eSlipState.loanOperationCode.equals("30876") ||
				eSlipState.loanOperationCode.equals("30822") || eSlipState.loanOperationCode.equals("90760") ||
				eSlipState.loanOperationCode.equals("50815")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P15);
		}
		if (eSlipState.loanOperationCode.equals("50875")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.M16);
		}
		if (eSlipState.loanOperationCode.equals("50806")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P15C1);
		}
		if (eSlipState.loanOperationCode.equals("90820")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P22);
		}
		if (eSlipState.loanOperationCode.equals("70820")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P23);
		}

		if (eSlipState.loanComissionCode4.equals("778")) {
			if (eSlipState.loanOperationCode.equals("10800")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P97);
			}
			if (eSlipState.loanOperationCode.equals("70800") || eSlipState.loanOperationCode.equals("70810") ||
					eSlipState.loanOperationCode.equals("70811") || eSlipState.loanOperationCode.equals("70812")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P98);
			}
		} else {
			if (eSlipState.loanComissionCode4.equals("777")) {
				if (eSlipState.loanOperationCode.equals("10800")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P95);
				}
				if (eSlipState.loanOperationCode.equals("70800") || eSlipState.loanOperationCode.equals("70810") ||
						eSlipState.loanOperationCode.equals("70811") || eSlipState.loanOperationCode.equals("70812")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P96);
				}
			} else {
				if (eSlipState.loanComissionCode4.equals("775")) {
					if (eSlipState.loanOperationCode.equals("70800") || eSlipState.loanOperationCode.equals("70810") ||
							eSlipState.loanOperationCode.equals("70811") || eSlipState.loanOperationCode.equals("70812")) {
						eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P39C);
					}

				} else {
					if (eSlipState.loanOperationCode.equals("70800") || eSlipState.loanOperationCode.equals("70810") ||
							eSlipState.loanOperationCode.equals("70811") || eSlipState.loanOperationCode.equals("70812")) {
						eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P39);
					}
				}
			}
		}

		if (eSlipState.loanOperationCode.equals("70806")|| eSlipState.loanOperationCode.equals("70822") ||
				eSlipState.loanOperationCode.equals("70815")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P38);
		}
		if (eSlipState.loanOperationCode.equals("61207")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.R01);
		}
		if (eSlipState.loanOperationCode.equals("71207")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.R02);
		}
		if (eSlipState.loanOperationCode.equals("61206")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.R03);
		}
		if (eSlipState.loanOperationCode.equals("71206")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.R04);
		}
	}

	private static void evaluateNumCopies1(XPath xpath, ESlipState eSlipState) throws XPathExpressionException {
		if (!eSlipState.loanTransactionType.startsWith("4")) {
			evaluateNumCopies1ForTransactionType4(eSlipState);
		}

		evaluateNumCopies1ForLoanAccountType(eSlipState);

		evaluateNumCopies1ForIndSoporte(eSlipState);

		evaluateNumCopies1ContinuationA(eSlipState);

		evaluateNumCopies1ContinuationB(xpath, eSlipState);

	}

	private static void evaluateNumCopies1ForTransactionType4(ESlipState eSlipState) {
		if (eSlipState.loanOperationCode.equals("10800") || eSlipState.loanOperationCode.equals("10879")
				|| eSlipState.loanOperationCode.equals("40810") || eSlipState.loanOperationCode.equals("40811")
				|| eSlipState.loanOperationCode.equals("40812")) {

			if (!eSlipState.loanAccountType.equals("28") && !eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.isEmpty() && eSlipState.loanMaximumPeriodNumber > 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P01C1);
			}

			if (!eSlipState.loanAccountType.equals("28") && !eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.isEmpty() && eSlipState.loanMaximumPeriodNumber == 0
					&& !eSlipState.loanReportsIndicator2.startsWith("1")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P01C2);
			}

			if (!eSlipState.loanAccountType.equals("28") && eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.startsWith("H")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P02C1);
			}
			if (!eSlipState.loanAccountType.equals("28") && eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.startsWith("P")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P02C2);
			}
			if (!eSlipState.loanAccountType.equals("28") && eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.startsWith("*")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P02C3);
			}
			if (!eSlipState.loanAccountType.equals("28") && eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.isEmpty()) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P03C0);
			}
			if (!eSlipState.loanAccountType.equals("28") && !eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.startsWith("H") && eSlipState.loanMaximumPeriodNumber > 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P05C1);
			}
			if (!eSlipState.loanAccountType.equals("28") && !eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.startsWith("*") && eSlipState.loanMaximumPeriodNumber > 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P05C5);
			}
			if (!eSlipState.loanAccountType.equals("28") && !eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.startsWith("P") && eSlipState.loanMaximumPeriodNumber > 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P05C2);
			}
			if (!eSlipState.loanAccountType.equals("28") && !eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.startsWith("H") && eSlipState.loanMaximumPeriodNumber == 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P05C3);
			}
			if (!eSlipState.loanAccountType.equals("28") && !eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.startsWith("*") && eSlipState.loanMaximumPeriodNumber == 0
					&& !eSlipState.loanReportsIndicator2.startsWith("1")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P05C6);
			}
			if (!eSlipState.loanAccountType.equals("28") && !eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.startsWith("P") && eSlipState.loanMaximumPeriodNumber == 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P05C4);
			}
			if (eSlipState.loanAccountType.equals("28") && !eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.isEmpty() && eSlipState.loanMaximumPeriodNumber > 0
					&& eSlipState.indBond == 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P06C1);
			}
			if (eSlipState.loanAccountType.equals("28") && !eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.isEmpty() && eSlipState.loanMaximumPeriodNumber == 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P06C2);
			}
			if (eSlipState.loanAccountType.equals("28") && !eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.startsWith("H") && eSlipState.loanMaximumPeriodNumber > 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P07C1);
			}
			if (eSlipState.loanAccountType.equals("28") && !eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.startsWith("*") && eSlipState.loanMaximumPeriodNumber > 0
					&& eSlipState.indBond == 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P07C5);
			}
			if (eSlipState.loanAccountType.equals("28") && !eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.startsWith("P") && eSlipState.loanMaximumPeriodNumber > 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P07C2);
			}
			if (eSlipState.loanAccountType.equals("28") && !eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.startsWith("H") && eSlipState.loanMaximumPeriodNumber == 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P07C3);
			}
			if (eSlipState.loanAccountType.equals("28") && !eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.startsWith("*") && eSlipState.loanMaximumPeriodNumber == 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P07C6);
			}
			if (eSlipState.loanAccountType.equals("28") && !eSlipState.loanOpeningValueDate.equals(EMPTY_STRING)
					&& eSlipState.loanPledgedIndicator.startsWith("P") && eSlipState.loanMaximumPeriodNumber == 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P07C4);
			}

			if (eSlipState.loanAccountType.equals("28") && (eSlipState.indBond == 0)) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P0607);
			} else {
				if (eSlipState.indBond == 0) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P0105);
				} else {
					if (eSlipState.ct60001ResponseNumber > 0 && eSlipState.ct60001Response != null) {
						if (eSlipState.comesFromLit == 0) {
							if (eSlipState.loanWithdrawnAmount > 0 && eSlipState.ai00004Response != null) {
								eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P0609);
							} else {
								// this is not the first
								// disbursment. Perform the same
								// action as was doing
								if (eSlipState.indBond == 1) {
									eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P0608B);
								}
								if (eSlipState.indBond == 2) {
									eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P0608S);
								}
								if (eSlipState.indBond == 3) {
									eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P0608K);
								}
							}
						}
					} else {
						if (eSlipState.indBond == 1) {
							eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P0608B);
						}
						if (eSlipState.indBond == 2) {
							eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P0608S);
						}
						if (eSlipState.indBond == 3) {
							eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P0608K);
						}
					}
				}

			}

		}

		if (eSlipState.loanOperationCode.equals("70800") || eSlipState.loanOperationCode.equals("70810")
				|| eSlipState.loanOperationCode.equals("70811") || eSlipState.loanOperationCode.equals("70812")) {
			if (!eSlipState.loanAccountType.equals("28")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P04C1);
			} else {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P04C2);
			}
		}
	}

	private static void evaluateNumCopies1ForLoanAccountType(ESlipState eSlipState) {
		if (eSlipState.loanAccountType.equals("24")) {
			if (eSlipState.loanOperationCode.equals("50814")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P41);
			}
			if (eSlipState.loanOperationCode.equals("50815") && eSlipState.loanOperationCode.equals("30823")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P63);
			}
			if (eSlipState.loanOperationCode.equals("50815") && eSlipState.loanOperationCode.equals("30854")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P63);
			}
			if (eSlipState.loanOperationCode.equals("50815") && eSlipState.loanOperationCode.equals("30873")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P64);
			}
			if (eSlipState.loanOperationCode.equals("50815") && eSlipState.loanOperationCode.equals("30874")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P65);
			}
			if (eSlipState.loanOperationCode.equals("50815") && eSlipState.loanOperationCode.equals("30881")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P93);
			}
			if (eSlipState.loanOperationCode.equals("50816")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P41);
			}
			if (eSlipState.loanOperationCode.equals("70814")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P42);
			}
			if (eSlipState.loanOperationCode.equals("70816")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P42);
			}
		} else {
			if ((eSlipState.loanOperationCode.equals("50814")) || (eSlipState.loanOperationCode.equals("50816"))) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.PAY);
			}

			switch (eSlipState.indSoporte) {
			case 2:

				if (eSlipState.loanOperationCode.equals("50815")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P68);
				}
				break;
			case 1:
				if (eSlipState.loanOperationCode.equals("50815")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P67);
				}
				break;
			case 0:
			default:
				if (eSlipState.loanOperationCode.equals("50815")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P29);
				}
				break;
			}

			// 2ND SWITCH STATEMENT
			switch (eSlipState.indSoporte) {
			case 2:

				if (eSlipState.loanOperationCode.equals("50814")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P76);
				}
				if (eSlipState.loanOperationCode.equals("50816")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P76);
				}
				if (eSlipState.loanOperationCode.equals("70816")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P78);
				}
				if (eSlipState.loanOperationCode.equals("70814")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P78);
				}
				break;
			case 1:
				if (eSlipState.loanOperationCode.equals("50814")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P75);
				}
				if (eSlipState.loanOperationCode.equals("50816")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P75);
				}
				if (eSlipState.loanOperationCode.equals("70816")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P77);
				}
				if (eSlipState.loanOperationCode.equals("70814")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P77);
				}
				break;
			case 0:
			default:
				if (eSlipState.indBond == 0) // Not Bond eSlipState.loan
				{
					if (eSlipState.loanOperationCode.equals("50814") || eSlipState.loanOperationCode.equals("50816")) {
						eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P32);
					}
					if (eSlipState.loanOperationCode.equals("70814") || eSlipState.loanOperationCode.equals("70816")) {
						eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P33);
					}
				} else // Bond loan
				{
					if (eSlipState.loanOperationCode.equals("50814") || eSlipState.loanOperationCode.equals("50816")) {
						eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P87);
					}
					if (eSlipState.loanOperationCode.equals("70814") || eSlipState.loanOperationCode.equals("70816")) {
						eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P88);
					}
				}

				break;
			}
			if (eSlipState.loanOperationCode.equals("50816")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.PAY);
			}

		}

		if (eSlipState.loanOperationCode.equals("50875")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.M16);
		}
	}

	private static void evaluateNumCopies1ForIndSoporte(ESlipState eSlipState) {
		switch (eSlipState.indSoporte) {
		case 2:

			if (eSlipState.loanOperationCode.equals("50870")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P72);
			}
			if (eSlipState.loanOperationCode.equals("70870")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P74);
			}
			if (eSlipState.loanOperationCode.equals("50871")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P80);
			}
			if (eSlipState.loanOperationCode.equals("70871")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P82);
			}
			if (eSlipState.loanOperationCode.equals("50806")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P84);
			}
			if (eSlipState.loanOperationCode.equals("70806")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P86);
			}
			break;
		case 1:
			if (eSlipState.loanOperationCode.equals("50870")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P71);
			}
			if (eSlipState.loanOperationCode.equals("70870")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P73);
			}
			if (eSlipState.loanOperationCode.equals("50871")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P79);
			}
			if (eSlipState.loanOperationCode.equals("70871")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P81);
			}
			if (eSlipState.loanOperationCode.equals("50806")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P83);
			}
			if (eSlipState.loanOperationCode.equals("70806")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P85);
			}
			break;
		case 0:
		default:
			if (eSlipState.loanOperationCode.equals("50870")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P18);
			}
			if (eSlipState.loanOperationCode.equals("70870")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P19);
			}
			if (eSlipState.loanOperationCode.equals("50871")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P20);
			}
			if (eSlipState.loanOperationCode.equals("70871")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P21);
			}
			if (eSlipState.loanOperationCode.equals("50806")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P16);
			}
			if (eSlipState.loanOperationCode.equals("70806")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P17);
			}
			break;
		}

		if (eSlipState.loanOperationCode.equals("50872")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P25);
		}
		if (eSlipState.loanOperationCode.equals("70872")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P27);
		}

		if (eSlipState.loanOperationCode.equals("11205")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P29R);
		}
		if (eSlipState.loanOperationCode.equals("71216")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P60R);
		}
		if (eSlipState.loanOperationCode.equals("71217")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P60R);
		}
		if (eSlipState.loanOperationCode.equals("71205")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P60R);
		}

		if (eSlipState.loanOperationCode.equals("30824")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P29F);
		}
		if (eSlipState.loanOperationCode.equals("30876")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.M2901);
		}
		if (eSlipState.loanOperationCode.equals("30877")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.M2902);
		}

		// 4TH SWITCH STATEMENT
		switch (eSlipState.indSoporte) {
		case 2:

			if (eSlipState.loanOperationCode.equals("30822") || eSlipState.loanOperationCode.equals("90760") ||
					eSlipState.loanOperationCode.equals("70760") || eSlipState.loanOperationCode.equals("30852")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P68);
			}
			break;
		case 1:
			if (eSlipState.loanOperationCode.equals("30822") || eSlipState.loanOperationCode.equals("90760") ||
					eSlipState.loanOperationCode.equals("30852")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P67);
			}
			if (eSlipState.loanOperationCode.equals("70760")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.R68);
			}
			break;
		case 0:
		default:
			if (eSlipState.loanOperationCode.equals("30822")) {

				if (eSlipState.rel541) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P29SYN);
				} else {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P29);
				}

			}
			if (eSlipState.loanOperationCode.equals("90760")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P29N);
			}
			if (eSlipState.loanOperationCode.equals("70760")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.R68);
			}
			if (eSlipState.loanOperationCode.equals("30852")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P29);
			}
			break;
		}
	}

	private static void evaluateNumCopies1ContinuationA(ESlipState eSlipState) {
		if (!eSlipState.loanAccountType.equals("24")) {

			// 5TH SWITCH STATEMENT
			switch (eSlipState.indSoporte) {
			case 2:

				if (eSlipState.loanOperationCode.equals("70815")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P70);
				}
				break;
			case 1:
				if (eSlipState.loanOperationCode.equals("70815")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P69);
				}
				break;
			case 0:
			default:
				if (eSlipState.loanOperationCode.equals("70815")) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P30);
				}
				break;
			}
		} else // cod_tip_expe = 24 EGGYHTIKH EPISTOLH
		{
			if (eSlipState.loanOperationCode.equals("70815")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P62);
			}
		}

		// 6TH SWITCH STATEMENT
		switch (eSlipState.indSoporte) {
		case 2:

			if (eSlipState.loanOperationCode.equals("70822") || eSlipState.loanOperationCode.equals("70852")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P70);
			}
			break;
		case 1:
			if (eSlipState.loanOperationCode.equals("70822") || eSlipState.loanOperationCode.equals("70852")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P69);
			}
			break;
		case 0:
		default:
			if (eSlipState.loanOperationCode.equals("70822") || eSlipState.loanOperationCode.equals("70852")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P30);
			}
			break;
		}

		if (eSlipState.loanOperationCode.equals("30873")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P47);
		}
		if (eSlipState.loanOperationCode.equals("30874")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P48);
		}
		if (eSlipState.loanOperationCode.equals("70873")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P49);
		}
		if (eSlipState.loanOperationCode.equals("70874")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P50);
		}
		if (eSlipState.loanOperationCode.equals("90842")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P45);
		}
		if (eSlipState.loanOperationCode.equals("70842")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P46);
		}
		if (eSlipState.loanOperationCode.equals("30823")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P51);
		}
		if (eSlipState.loanOperationCode.equals("30854")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P51);
		}
		if (eSlipState.loanOperationCode.equals("70823")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P52);
		}
		if (eSlipState.loanOperationCode.equals("70854")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P52);
		}
		if (eSlipState.loanOperationCode.equals("30881")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P91);
		}
		if (eSlipState.loanOperationCode.equals("70881")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P92);
		}
		if (eSlipState.loanOperationCode.equals("90845")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P89);
		}
		if (eSlipState.loanOperationCode.equals("70845")) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P90);
		}

		if (eSlipState.loanTransactionType.startsWith("4")) {
			if (eSlipState.loanOperationCode.equals("10800") || eSlipState.loanOperationCode.equals("40810")
					|| eSlipState.loanOperationCode.equals("40811") || eSlipState.loanOperationCode.equals("40812")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P44);
			}
			if (eSlipState.loanOperationCode.equals("70800") || eSlipState.loanOperationCode.equals("70810")
					|| eSlipState.loanOperationCode.equals("70811") || eSlipState.loanOperationCode.equals("70812")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P13);
			}
		}

		if (eSlipState.loanOperationCode.equals("90890") || eSlipState.loanOperationCode.equals("70890")) {
			if (eSlipState.loanOperationCode.equals("90890")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P55);
			}
			if (eSlipState.loanOperationCode.equals("70890")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P56);
			}
		}

		if (eSlipState.transactionDescriptionList.contains(LoanPrintingDataSource.P29)
				&& (eSlipState.loanAmortizationAmount + eSlipState.loanInterestAmount + eSlipState.loanDelaysAmount > 1)) {
			if (eSlipState.loanAmortizationAmount > 0 && ! eSlipState.rel541) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P29K);
			}
			if (eSlipState.loanInterestAmount > 0 && ! eSlipState.rel541) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P29T);
			}
			if (eSlipState.loanDelaysAmount > 0 && ! eSlipState.rel541 && !eSlipState.loanOperationCode.equals("30822")) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P29Y);
			}
		}
	}


	private static void evaluateNumCopies1ContinuationB(XPath xpath, ESlipState eSlipState)
			throws XPathExpressionException {
		Integer counter = Integer.parseInt(xpath.evaluate(
				"count(eSlipState.loanVoucherPrintingSettlementsDataList/eSlipState.loanVoucherPrintingSettlementsData)",
				eSlipState.loanPrintingInformationResponse));

		String xpathLoanSettlementItemCodeI = "LoanVoucherPrintingSettlementsDataList/LoanVoucherPrintingSettlementsData[1]/LoanSettlementItemCode";
		String loanSettlementItemCodeI = xpath.evaluate(xpathLoanSettlementItemCodeI,
				eSlipState.loanPrintingInformationResponse); // CodConcLiq

		String xpathLoanSettlementItemAmountI = "LoanVoucherPrintingSettlementsDataList/LoanVoucherPrintingSettlementsData[1]/LoanSettlementItemAmount";
		double loanSettlementItemAmountI = Double
				.parseDouble(xpath.evaluate(xpathLoanSettlementItemAmountI, eSlipState.loanPrintingInformationResponse)); // impConcLiquid

		if (eSlipState.transactionDescriptionList.contains(LoanPrintingDataSource.P29N)) {
			double impDelAmount = 0;
			double impCurAmount = 0;

			for (Integer i = 1; !loanSettlementItemCodeI.startsWith("0")
					&& !loanSettlementItemCodeI.startsWith(" ") && !loanSettlementItemCodeI.equals(EMPTY_STRING)
					&& i <= counter; i++) {

				if (loanSettlementItemCodeI.startsWith("2")) {
					impDelAmount += loanSettlementItemAmountI;
				}
				if (loanSettlementItemCodeI.startsWith("1")) {
					impCurAmount += loanSettlementItemAmountI;
				}

				// calculate next amounts
				Integer nextI = i + 1;
				xpathLoanSettlementItemCodeI = "LoanVoucherPrintingSettlementsDataList/LoanVoucherPrintingSettlementsData["
						+ nextI + "]/LoanSettlementItemCode";
				loanSettlementItemCodeI = xpath.evaluate(xpathLoanSettlementItemCodeI,
						 eSlipState.loanPrintingInformationResponse); // CodConcLiq

				xpathLoanSettlementItemAmountI = "LoanVoucherPrintingSettlementsDataList/LoanVoucherPrintingSettlementsData["
						+ nextI + "]/LoanSettlementItemAmount";
				loanSettlementItemAmountI = Double.parseDouble(
						xpath.evaluate(xpathLoanSettlementItemAmountI,  eSlipState.loanPrintingInformationResponse)); // impConcLiquid
			}

			if (impCurAmount > 0 && impDelAmount > 0) {
				if (impCurAmount > 0 && !eSlipState.rel541) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P29L);
				}
				if (impDelAmount > 0 && !eSlipState.rel541) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P29M);
				}
			}
		}

		if (eSlipState.transactionDescriptionList.contains(LoanPrintingDataSource.PAY) &&
				(eSlipState.loanAmortizationAmount > 0 || eSlipState.loanInterestAmount > 0)) {
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.PAYS);
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.PAYK);
		}

		// If Amount is negative change the titles
		if ( eSlipState.loanOperationCode.equals("30822")) {
			// 7TH SWITCH STATEMENT
			switch (eSlipState.indSoporte) {
			case 2:

				if (eSlipState.loanAmortizationAmount < 0) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P68);
				}
				break;
			case 1:
				if (eSlipState.loanAmortizationAmount < 0) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P67);
				}
				break;
			case 0:
			default:
				if (eSlipState.loanAmortizationAmount < 0) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P29);
				}
				break;
			}
			if (eSlipState.loanAmortizationAmount < 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P25);
			}
		}

		// If Amount is negative change the titles
		if (eSlipState.loanOperationCode.equals("90760")) {

			// 7TH SWITCH STATEMENT
			switch (eSlipState.indSoporte) {
			case 2:

				if (eSlipState.loanAmortizationAmount < 0) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P68);
				}
				break;
			case 1:
				if (eSlipState.loanAmortizationAmount < 0) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P67);
				}
				break;
			case 0:
			default:
				if (eSlipState.loanAmortizationAmount < 0) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P29N);
				}
				break;
			}
			if (eSlipState.loanAmortizationAmount < 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P25);
			}
		}

		if (eSlipState.loanOperationCode.equals("70822")) {
			// 8TH SWITCH STATEMENT
			switch (eSlipState.indSoporte) {
			case 2:

				if (eSlipState.loanAmortizationAmount > 0) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P70);
				}
				break;
			case 1:
				if (eSlipState.loanAmortizationAmount > 0) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P69);
				}
				break;
			case 0:
			default:
				if (eSlipState.loanAmortizationAmount > 0) {
					eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P30);
				}
				break;
			}
			if (eSlipState.loanAmortizationAmount > 0) {
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.P27);
			}
		}

		// Print ruthmismena Loans
		if ((eSlipState.loanOperationCode.equals("10800") || eSlipState.loanOperationCode.equals("10879")
				|| eSlipState.loanOperationCode.equals("40810") || eSlipState.loanOperationCode.equals("40811")
				|| eSlipState.loanOperationCode.equals("40812")) && !eSlipState.loanAccountType.equals("24")
				&& eSlipState.loanAuthorizationNumber > 0)
			eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.RYT);
	}

	public static void generateRiskESlip(Map<String, Object> printingMap) throws IllegalStateException {
		try {
			XPath xpath = new net.sf.saxon.xpath.XPathFactoryImpl().newXPath();
			ArrayList<TransactionDescription> transactionDescriptionList = new ArrayList<>();
			String transactionDescription = "";

			Node loanPrintingInformationResponse = ((Node) printingMap.get("TLoanRiskPrintingInformationResponse"));
			Node ai83034Response = ((Node) printingMap.get("Tdata_ai83034Response"));

			if (loanPrintingInformationResponse == null || ai83034Response == null) {
				throw new Exception("Printing properties are missing.");
			}

			String loanOperationCode = xpath.evaluate("LoanVoucherPrintingData/LoanOperationCode",
					loanPrintingInformationResponse);
			String txtComment1 = xpath.evaluate("LoanComment/LoanComment1", ai83034Response);
			String txtComment2 = xpath.evaluate("LoanComment/LoanComment2", ai83034Response);
			String txtComment3 = xpath.evaluate("LoanComment/LoanComment3", ai83034Response);

			String cause = EMPTY_STRING; // cause is empty from aic89 -
											// Αντιλογισμοί

			if (loanOperationCode.equals("51260")) {
				transactionDescriptionList.add(LoanPrintingRiskDataSource.P01);
			}
			if (loanOperationCode.equals("71260")) {
				transactionDescriptionList.add(LoanPrintingRiskDataSource.P02);
			}
			if (loanOperationCode.equals("61206")) {
				transactionDescriptionList.add(LoanPrintingRiskDataSource.P03);
			}
			if (loanOperationCode.equals("71206")) {
				transactionDescriptionList.add(LoanPrintingRiskDataSource.P04);
			}
			if (loanOperationCode.equals("61207")) {
				transactionDescriptionList.add(LoanPrintingRiskDataSource.P05);
			}
			if (loanOperationCode.equals("71207")) {
				transactionDescriptionList.add(LoanPrintingRiskDataSource.P06);
			}
			if (loanOperationCode.equals("61201")) {
				transactionDescriptionList.add(LoanPrintingRiskDataSource.P10);
			}
			if (loanOperationCode.equals("71201")) {
				transactionDescriptionList.add(LoanPrintingRiskDataSource.P09);
			}
			if (loanOperationCode.equals("61202")) {
				transactionDescriptionList.add(LoanPrintingRiskDataSource.P11);
			}
			if (loanOperationCode.equals("71202")) {
				transactionDescriptionList.add(LoanPrintingRiskDataSource.P12);
			}
			if ((loanOperationCode.equals("61210")) || (loanOperationCode.equals("61212"))
					|| (loanOperationCode.equals("61211")) || (loanOperationCode.equals("61213"))) {
				transactionDescriptionList.add(LoanPrintingRiskDataSource.P13);
			}
			if ((loanOperationCode.equals("61214")) || (loanOperationCode.equals("61215"))) {
				transactionDescriptionList.add(LoanPrintingRiskDataSource.P15);
			}
			if ((loanOperationCode.equals("71210")) || (loanOperationCode.equals("71212"))
					|| (loanOperationCode.equals("71211")) || (loanOperationCode.equals("71213"))) {
				transactionDescriptionList.add(LoanPrintingRiskDataSource.P14);
			}
			if ((loanOperationCode.equals("71214")) || (loanOperationCode.equals("71215"))) {
				transactionDescriptionList.add(LoanPrintingRiskDataSource.P16);
			}
			if ((loanOperationCode.equals("61218")) || (loanOperationCode.equals("61219"))) {
				transactionDescriptionList.add(LoanPrintingRiskDataSource.P17);
			}
			if ((loanOperationCode.equals("71218")) || (loanOperationCode.equals("71219"))) {
				transactionDescriptionList.add(LoanPrintingRiskDataSource.P18);
			}

			if ((loanOperationCode.equals("61214")) || (loanOperationCode.equals("61215"))
					|| (loanOperationCode.equals("71214")) || (loanOperationCode.equals("71215"))) {
				if (cause.equals("71")) {
					transactionDescriptionList.add(LoanPrintingRiskDataSource.C01);
				} else if (cause.equals("72")) {
					transactionDescriptionList.add(LoanPrintingRiskDataSource.C02);
				} else if (cause.equals("73")) {
					transactionDescriptionList.add(LoanPrintingRiskDataSource.C03);
				} else if (cause.equals("74")) {
					transactionDescriptionList.add(LoanPrintingRiskDataSource.C04);
				}
			}

			if (!txtComment1.equals(EMPTY_STRING) && !loanOperationCode.equals("51260") && !loanOperationCode.equals("71260")) {
				transactionDescriptionList.add(LoanPrintingRiskDataSource.COM01);
				if (!txtComment2.equals(EMPTY_STRING)) {
					transactionDescriptionList.add(LoanPrintingRiskDataSource.COM02);
				}
				if (!txtComment3.equals(EMPTY_STRING)) {
					transactionDescriptionList.add(LoanPrintingRiskDataSource.COM03);
				}
			}

			Collections.sort(transactionDescriptionList, new Comparator<TransactionDescription>() {
				public int compare(TransactionDescription o1, TransactionDescription o2) {
					return Integer.compare(o1.getIndex(), o2.getIndex());
				}
			});

			for (TransactionDescription element : transactionDescriptionList) {
				transactionDescription = transactionDescription.concat(element.getDescription());
			}

			transactionDescription = PrintingExtentions.generatePlaceholders(transactionDescription, printingMap);
			if(transactionDescription.length() > 0){
				transactionDescription = transactionDescription.substring(0, transactionDescription.length() - 1);
			}
			printingMap.put("Tdata_TransactionDescription", transactionDescription);

		} catch (Exception e) {
			throw new IllegalStateException("An error occured while printing.", e);
		}

	}
	
		public static void generateKASM2ESlip(Map<String, Object> printingMap) {
		try {
			ESlipState eSlipState = new ESlipState();
			XPath xpath = new net.sf.saxon.xpath.XPathFactoryImpl().newXPath();
			eSlipState.transactionDescriptionList = new ArrayList<>();
			eSlipState.transactionDescriptionList2 = new ArrayList<>();
			eSlipState.transactionDescription = "";
			eSlipState.transactionDescription2 = "";
			eSlipState.multiplePages ="";
			
			eSlipState.loanPrintingInformationResponse = ((Node) printingMap.get("TLoanPrintingInformationResponseM2"));
			eSlipState.ai00009Response = ((Node) printingMap.get("Tdata_ai00009ResponseM2"));
			eSlipState.ai00004Response = ((Node) printingMap.get("Tdata_ai00004ResponseM2"));
			eSlipState.ai83007Response = ((Node) printingMap.get("Tdata_ai83007ResponseM2"));
			eSlipState.ct60001Response = ((Node) printingMap.get("Tdata_ct60001ResponseM2"));

			eSlipState.gestorLoanOperationCode = "";

			if (printingMap.get("TGestor_LoanOperationCode") instanceof String) {
				eSlipState.gestorLoanOperationCode = ((String) printingMap.get("TGestor_LoanOperationCode"));
			} else {
				throw new IllegalStateException("Printing properties are missing.");
			}

			if (eSlipState.loanPrintingInformationResponse == null || eSlipState.ai00009Response == null) {
				throw new IllegalStateException("Printing properties are missing.");
			}
			
			eSlipState.calculateValuesPartA(xpath);
			eSlipState.calculateValuesPartB(xpath, printingMap);
			eSlipState.calculateValuesPartC(printingMap);
			
			if (eSlipState.numCopies == 1) {
				evaluateNumCopies1(xpath, eSlipState);
			} // numcopies =1

			if (eSlipState.numCopies == 2) {
				evaluateNumCopies2(eSlipState);
			} // numcopies = 2

			if (eSlipState.numCopies == 3) {
				eSlipState.multiplePages = evaluateNumCopies3(eSlipState);
			} // numCopies==3

			
			// AI20MULT
			if (!isDefCurrency(eSlipState.loanCurrency) && eSlipState.transactionDescriptionList.contains(LoanPrintingDataSource.P0105)) {
				eSlipState.transactionDescriptionList.remove(LoanPrintingDataSource.P0105);
				eSlipState.transactionDescriptionList.add(LoanPrintingDataSource.MC01);
			}

			Collections.sort(eSlipState.transactionDescriptionList, new Comparator<TransactionDescription>() {
				public int compare(TransactionDescription o1, TransactionDescription o2) {
					return Integer.compare(o1.getIndex(), o2.getIndex());
				}
			});
			
			//set TransactionDescription
			for (TransactionDescription element : eSlipState.transactionDescriptionList) {
				eSlipState.transactionDescription = eSlipState.transactionDescription.concat(element.getDescription());
			}

			eSlipState.transactionDescription = PrintingExtentions.generatePlaceholders(eSlipState.transactionDescription, printingMap);
			if(eSlipState.transactionDescription.length() > 0){
				eSlipState.transactionDescription = eSlipState.transactionDescription.substring(0, eSlipState.transactionDescription.length() - 1);
			}
			printingMap.put("Tdata_TransactionDescriptionM2", eSlipState.transactionDescription);
			
			//set TransactionDescription2
			for (TransactionDescription element : eSlipState.transactionDescriptionList2) {
				eSlipState.transactionDescription2 = eSlipState.transactionDescription2.concat(element.getDescription());
			}

			eSlipState.transactionDescription2 = PrintingExtentions.generatePlaceholders(eSlipState.transactionDescription2, printingMap);
			if(eSlipState.transactionDescription2.length() > 0){
				eSlipState.transactionDescription2 = eSlipState.transactionDescription2.substring(0, eSlipState.transactionDescription2.length() - 1);
			}
			else {
				eSlipState.transactionDescription2 = eSlipState.transactionDescription;
			}
			printingMap.put("Tdata_TransactionDescription2M2", eSlipState.transactionDescription2);
			printingMap.put("Tdata_MultiplePagesM2", eSlipState.multiplePages);

		} catch (Exception e) {
			throw new IllegalStateException("An error occured while printing.", e);
		}

	}

}
