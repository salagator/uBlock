/*
 * Copyright 2015 Red Hat, Inc. and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package gr.alpha.cbs.fuse.kie;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import jakarta.xml.bind.annotation.*;

@XmlRootElement(name = "list-type")
@XmlAccessorType(XmlAccessType.FIELD)
public class JaxbList implements Wrapped<List<?>> {

    @XmlElementWrapper(name = "items")
    private Object[] items;

    public JaxbList() {
    }

    public JaxbList(List<Object> items) {
        this.items = items.toArray();
        int index = 0;
        for (Object o : this.items) {
            this.items[index] = ModelWrapper.wrapSkipPrimitives(o);
            index++;
        }
    }

    public List<Object> getItems() {
        return Arrays.asList(items);
    }

    public void setItems(List<Object> items) {
        this.items = items.toArray();
    }

    @Override
    public List<?> unwrap() {
        List<Object> unwrapped = new ArrayList<Object>();

        if (items != null) {
            for (Object o : items) {
                Object item = o;
                if (o instanceof Wrapped) {
                    item = ((Wrapped) o).unwrap();
                }
                unwrapped.add(item);
            }
        }
        return unwrapped;
    }
}
