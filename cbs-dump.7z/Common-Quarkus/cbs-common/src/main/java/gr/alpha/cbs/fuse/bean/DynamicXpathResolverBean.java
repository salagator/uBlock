package gr.alpha.cbs.fuse.bean;

import java.util.Iterator;
import java.util.NoSuchElementException;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;

import org.apache.camel.Exchange;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Named;
import io.quarkus.runtime.annotations.RegisterForReflection;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
/**
 * The methods of this class are used only in spring camel context
 * @author x89099
 *
 */
@Named("dynamicXpathResolverBean")
@Dependent
@RegisterForReflection
public class DynamicXpathResolverBean  {
	private static final Logger LOGGER = Logger.getLogger(DynamicXpathResolverBean.class);
	
	/**
	 * Sets a header on each iteration to get the corresponding value 
	 * from the component (for tags like tagname_1,tagname_2...)
	 * 
	 * e.g. set the Header cbs.customerInfo.memberCustNumber on each iteration 
	 * with the value of the xpath expression //customerSmallSearchResponse/memberCustomerNumber_i  , i=0,1...
	 * @param exchange
	 * @param xpath   
	 * @param headerName 
	 * @throws Exception
	 */
	public void setDynamicHeaderForLoop(Exchange exchange, String xpath, String headerName) throws Exception {
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("Started");
		}
		Document  doc = exchange.getIn().getBody(Document.class);
		
		//CamelLoopIndex property : zero based 
		int loopIndex = exchange.getProperty("CamelLoopIndex", Integer.class) + 1 ;
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("loopIndex:" + loopIndex);
		}
		
		
		//setHeader the value of element defined with xpath for each iteration
		 exchange.getIn().setHeader(headerName,	 FormatUtils.getValue(doc, xpath + String.valueOf(loopIndex)));
		if (LOGGER.isDebugEnabled()){
				LOGGER.debug("Completed");
		}
	}
	
	public void setDynamicHeaderForLoopList(Exchange exchange, String xpath, String headerName) throws Exception {
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("Started");
		}
		
		Document  doc = exchange.getIn().getBody(Document.class);
		
		XPath xPath = new net.sf.saxon.xpath.XPathFactoryImpl().newXPath();
		XPathExpression expr;
		expr = xPath.compile(xpath); 
		Object result = expr.evaluate(doc, XPathConstants.NODESET);
		NodeList allNodes = (NodeList) result;
		//CamelLoopIndex property : zero based 
		int loopIndex = exchange.getProperty("CamelLoopIndex", Integer.class);
		//Node el = (Node) allNodes.item(loopIndex);	
		NodeList childNodes = null;
		int size = 0;
		for (Node node : iterable(allNodes)) {
			boolean hasChild = node.hasChildNodes();
			if (hasChild) {
				childNodes = node.getChildNodes();
				for (Node newNode : iterable(childNodes)) {
					String localName = newNode.getLocalName();
					if (localName != null && localName.equalsIgnoreCase("CustomerNumber") && loopIndex == size) {
						String value = (String) newNode.getTextContent();
						value = value.replaceAll("\\s|\\r|\\n", "");
						//setHeader the value of element defined with xpath for each iteration
						exchange.getIn().setHeader(headerName, value);	
						return;
					} else if (localName != null && localName.equalsIgnoreCase("CustomerNumber")) size++;
				}
			}
		}
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("Completed");
		}
		
	}
	
	public void calculateDynamicHeaderForListSize(Exchange exchange, String xpath, String headerName) throws Exception {
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("Started");
		}
		
		Document  doc = (Document) exchange.getIn().getBody(Document.class);
		
		XPath xPath = new net.sf.saxon.xpath.XPathFactoryImpl().newXPath();
		XPathExpression expr;
		expr = xPath.compile(xpath); 
		Object result = expr.evaluate(doc, XPathConstants.NODESET);
		NodeList allNodes = (NodeList) result;
		
		NodeList childNodes = null;
		int size = 0;
		for (Node node : iterable(allNodes)) {
			boolean hasChild = node.hasChildNodes();
			if (hasChild) {
				childNodes = node.getChildNodes();
				for (Node newNode : iterable(childNodes)) {
					String localName = newNode.getLocalName();
					if (localName != null && localName.equalsIgnoreCase("CustomerNumber")) {
						size++;
					}
				}
			}
		}
		//setHeader the value of element defined with xpath for each iteration
		exchange.getIn().setHeader(headerName, Integer.valueOf(size));
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("Completed");
		}
		
	}
	
	
	public void setDynamicHeaderForLoopTrimmedValue(Exchange exchange, String xpath, String headerName) throws Exception {
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("Started");
		}
		
		Document  doc = exchange.getIn().getBody(Document.class);
		//CamelLoopIndex property : zero based 
		int loopIndex = exchange.getProperty("CamelLoopIndex", Integer.class) + 1 ;
		//setHeader the value of element defined with xpath for each iteration
		 exchange.getIn().setHeader(headerName + loopIndex,	 FormatUtils.parseEmpty(FormatUtils.getValue(doc, xpath + String.valueOf(loopIndex))));
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("Completed");
		}
		 
	}

	
	private static Iterable<Node> iterable(final NodeList n) {
		return new Iterable<Node>() {
			@Override
			public Iterator<Node> iterator() {
				return new Iterator<Node>() {
					int index = 0;
					@Override
					public boolean hasNext() {
						return index < n.getLength();
					}
					@Override
					public Node next() {
						if (hasNext()) {
							return n.item(index++);
						} else {
							throw new NoSuchElementException();
						}
					}
					@Override
					public void remove() {
						throw new UnsupportedOperationException();
					}
				};
			}
		};
	}
	
}

