package gr.alpha.cbs.fuse.ifaces;

import org.apache.camel.Exchange;

public interface IHorizontalProcessor {
	void process(Exchange exchange, String phase) throws Exception;
}
