package gr.alpha.cbs.fuse.ifaces;

import java.util.HashMap;
import java.util.List;

public interface ChannelRestCallerInterface {
	
	 List<String> getGroupsCodesByUnitCode(String unitCode) throws Exception;
	 
	 List<String> getGroupsCodesByMasterUnitCodeAndGroupTypeCode(String masterUnitCode, String groupTypeCode) throws Exception;
	  
	 HashMap<Integer,String> getUnitsByGroupCode(String groupCode) throws Exception;
	 
	 HashMap<Integer,String> getTeamsByUnitCodeAndGroupCode(String unitCode, String groupCode) throws Exception;
	 
	 List<String> getGroupsCodesByUnitCodeAndGroupTypeCode(String unitCode, String groupTypeCode) throws Exception;
}