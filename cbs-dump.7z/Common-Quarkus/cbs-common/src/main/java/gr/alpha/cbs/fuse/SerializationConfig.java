package gr.alpha.cbs.fuse;

import gr.alpha.cbs.fuse.common.support.TransactionConfig;
import io.quarkus.runtime.annotations.RegisterForReflection;

import java.util.ArrayList;
import java.util.HashMap;

/*
 * This configuration file is here because it is needed for the native build for serialization purposes that
 * is used in the communications between our applications and the datagrid (i.e. TransactionConfig caches for
 * the registry configuration, etc.)
 */
@RegisterForReflection(targets = {
        String.class,
        HashMap.class,
        ArrayList.class,
        TransactionConfig.class
}, serialization = true)
public class SerializationConfig {
}
