package gr.alpha.cbs.fuse.processors;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Named;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import io.quarkiverse.cxf.annotation.CXFClient;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import gr.alpha.cbs.fuse.support.HostInformationHelper;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import peesupport.PeeWS;
import peesupport.beans.LoanApplication;
import peesupport.beans.Response;

@Named("peeWSCaller")
@Dependent
@RegisterForReflection
public class PeeWSCaller implements Processor {
    private static final Logger logger = LoggerFactory.getLogger(PeeWSCaller.class);

    @CXFClient("myPeeWS")
    PeeWS client;


    @Override
    public void process(Exchange exchange) throws Exception {

        /* This is the CDI (customer number) */
        String customerNumber = exchange.getProperty("cbs.fuse.pee.ws.customer.number", String.class);
        Response response = null;
        if (customerNumber != null && customerNumber.trim().length() != 0) {
            logger.info("The customer number is specified ({}), making the call to the PeeWS service.", customerNumber);

            try {
                response = client.result(customerNumber);
            } catch (Exception e) {
                logger.error("Unable to call the PeeWS web service.", e);
            }

            if (response != null && response.getErrorCode() != null &&
                    response.getErrorCode().length() > 0 && !response.getErrorCode().equals("0")) {
                logger.warn("Error code returned by PeeWS system: {}.", response.getErrorCode());
                // TODO: Assume there was an error calling PeeWS. We have not been
                // given the explicit list of errorCodes that mean there was actually
                // an error, so assume that empty or zero mean everything went OK. In
                // any other case, throw an exception including the error code and
                // error description.
                ErrorUtils.throwCBSException(null,
                        ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
                        ErrorTypeModel.ERROR_SYSTEM_ID_PEE,
                        "PeeWSCaller",
                        "301260",
                        ErrorTypeModel.SEVERITY_ERROR,
                        response.getErrorDescription(),
                        "",
                        HostInformationHelper.getHostname());
            }
        }

        Document document = exchange.getIn().getBody(Document.class);
        // Use the first child element of the document to get the namespace URI.
        Element firstElement = getFirstElementNode(document);
        if (firstElement == null) {
            throw new IllegalStateException("No element contained in the document passed in the body of the camel exchange.");
        }
        String namespaceURI = firstElement.getNamespaceURI();
        Element rootElement = document.getDocumentElement();
        Element peeWSResponseElement = document.createElementNS(namespaceURI, "peeWSResponse");
        rootElement.appendChild(peeWSResponseElement);
        if (response != null) {
            for (LoanApplication loanApplication : response.getLoanApplications().getLoanApplication()) {
                Element loanApplicationElement = document.createElementNS(namespaceURI, "LoanPeeWSOutput");
                createChildElement(document, loanApplicationElement, namespaceURI, "LoanAppplicationId", loanApplication.getLoanAppplicationId());
                createChildElement(document, loanApplicationElement, namespaceURI, "LoanRequestCode", loanApplication.getLoanRequestCode());
                createChildElement(document, loanApplicationElement, namespaceURI, "Title", loanApplication.getTitle());
                createChildElement(document, loanApplicationElement, namespaceURI, "LimitSequencial", loanApplication.getLimitSequencial());
                createChildElement(document, loanApplicationElement, namespaceURI, "ProductCode", loanApplication.getProductCode());
                createChildElement(document, loanApplicationElement, namespaceURI, "LoanRequestPurpose", loanApplication.getLoanRequestPurpose());
                peeWSResponseElement.appendChild(loanApplicationElement);
            }
        }

        // Make sure that we have modified the exchange.
        exchange.getIn().setBody(document);
    }

    private Element getFirstElementNode(Document document) {
        for (int i = 0; i < document.getChildNodes().getLength(); i++) {
            Node childNode = document.getChildNodes().item(i);
            if (childNode instanceof Element) {
                return (Element) childNode;
            }
        }
        return null;
    }

    private void createChildElement(Document document, Element parentElement, String namespaceURI, String tagName, String value) {
        Element childElement = document.createElementNS(namespaceURI, tagName);
        childElement.setTextContent(value);
        parentElement.appendChild(childElement);
    }

}
