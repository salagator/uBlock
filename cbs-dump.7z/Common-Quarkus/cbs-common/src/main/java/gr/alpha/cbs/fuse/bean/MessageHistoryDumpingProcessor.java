package gr.alpha.cbs.fuse.bean;

import java.util.List;

import gr.alpha.cbs.fuse.common.CBSConstants;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.support.MessageHelper;
import org.apache.camel.support.processor.DefaultExchangeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Named;

/**
 * This processor can be used to turn on dumping of message history in order to see the timing
 * of the various stages of the camel route.
 * 
 * This is placed at the end of the camel template that we use. Normally it is turned off. To
 * turn it on, one must place the following bean in the camel context of the routes that need
 * to be dumped:
 * 
 * 	<bean id="dumpMessageHistory" class="java.util.ArrayList">
 * 	    <constructor-arg>
 * 	        <list>
 * 	        	<value>LoanSearchRequestPayload</value>
 * 	        	<value>LoanDisbursementExecutionRequestPayload</value>
 * 	        </list>
 * 	    </constructor-arg>
 * 	</bean>
 * 
 * Note that each route that we want dumped has its flow operation name listed in the
 * dumpMessageHistory bean.
 */
@Named("messageHistoryDumper")
@Dependent
@RegisterForReflection
public class MessageHistoryDumpingProcessor implements Processor {
	private static final Logger logger = LoggerFactory.getLogger(MessageHistoryDumpingProcessor.class);
	private static final Logger loggerTemplate = LoggerFactory.getLogger("transactionTemplate");
	
	private static final String gatewayBeanName = "dumpMessageHistory";

	@Override
	public void process(Exchange exchange) throws Exception {
		if (exchange.getContext().getRegistry().lookupByName(gatewayBeanName) != null) {
			String opeartion = (String) exchange.getProperty(CBSConstants.HEADER_TRANSACTION_FLOW);
			@SuppressWarnings("rawtypes")
			List operationNames = (List) exchange.getContext().getRegistry().lookupByName(gatewayBeanName);
			if (logger.isInfoEnabled() && operationNames.contains(opeartion)) {
				logger.info(MessageHelper.dumpMessageHistoryStacktrace(exchange, new DefaultExchangeFormatter(), false));
			}
		}
		if (loggerTemplate.isTraceEnabled()){
			loggerTemplate.trace("MessageHistoryDumpingProcessor:" + MessageHelper.dumpMessageHistoryStacktrace(exchange, new DefaultExchangeFormatter(), false));
		}
	}

}
