package gr.alpha.cbs.fuse.kie;

public enum Severity {
    INFO,
    WARN,
    ERROR
}
