package gr.alpha.cbs.fuse.support;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import gr.alpha.cbs.fuse.ejb.BUNHandlerBean;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.support.DefaultExchange;
import org.jboss.logging.Logger;

import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;

@Named("functionGetBun")
@ApplicationScoped
@RegisterForReflection
public class GetBUNfromTUNExtension extends ExtensionFunctionDefinition {
    private static final Logger LOGGER = Logger.getLogger(GetBUNfromTUNExtension.class);

    @Inject
    BUNHandlerBean bunHandlerBean;

    @Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("gb", "http://fuse.cbs.alpha.gr/getbun/", "getbun");
    }

    @Override
    public SequenceType[] getArgumentTypes() {
        return new SequenceType[] { SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING };

    }

    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
        return SequenceType.SINGLE_STRING;
    }

    @Override
    @SuppressWarnings("rawtypes")
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {
            private static final long serialVersionUID = 5090616615262067008L;

            @Override
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
                Long timer = 0L;
                String bun = null;

                try {
//					Get valeurdate
                    String valeurdate = null;
                    if (arguments[0] instanceof LazySequence) {
                        Item it = ((LazySequence) arguments[0]).head();
                        if (it == null) {
                            throw new Exception(
                                    "Unrecognized argument type: " + arguments[0].getClass().getCanonicalName());
                        } else {
                            valeurdate = it.getStringValue();
                        }
                    } else if (arguments[1] instanceof StringValue) {
                        valeurdate = ((StringValue) arguments[0]).getStringValue();
                    } else {
                        throw new Exception(
                                "Unrecognized argument type: " + arguments[0].getClass().getCanonicalName());
                    }

//					Get branchcode
                    String branchcode = null;
                    if (arguments[1] instanceof LazySequence) {
                        Item it = ((LazySequence) arguments[1]).head();
                        if (it == null) {
                            throw new Exception(
                                    "Unrecognized argument type: " + arguments[1].getClass().getCanonicalName());
                        } else {
                            branchcode = it.getStringValue();
                        }
                    } else if (arguments[1] instanceof StringValue) {
                        branchcode = ((StringValue) arguments[1]).getStringValue();
                    } else {
                        throw new Exception(
                                "Unrecognized argument type: " + arguments[1].getClass().getCanonicalName());
                    }

//					Get tun
                    String tun = null;
                    if (arguments[2] instanceof LazySequence) {
                        Item it = ((LazySequence) arguments[2]).head();
                        if (it == null) {
                            throw new Exception(
                                    "Unrecognized argument type: " + arguments[2].getClass().getCanonicalName());
                        } else {
                            tun = it.getStringValue();
                        }
                    } else if (arguments[2] instanceof StringValue) {
                        tun = ((StringValue) arguments[2]).getStringValue();
                    } else {
                        throw new Exception(
                                "Unrecognized argument type: " + arguments[2].getClass().getCanonicalName());
                    }

                    if (LOGGER.isTraceEnabled()){
                        timer = System.nanoTime();
                    }

                    CamelContext ctxc = new DefaultCamelContext();
                    Exchange exchange = new DefaultExchange(ctxc);

                    long initcontext = System.nanoTime() - timer;
                    bunHandlerBean.getBUNFromSigloTUN(exchange, valeurdate, branchcode, tun);
                    if ((Boolean)exchange.getIn().getHeader("cbs.commons.tun.not.from.cbs")==false){
                        bun = exchange.getIn().getHeader("cbs.commons.bun.from.tun", String.class);
                    }

                    if (LOGGER.isTraceEnabled()){
                        timer = System.nanoTime() - timer;
                        LOGGER.trace("XSL call completed " + timer / 1000 + ",init:"  + initcontext / 1000 + " microseconds");
                    }

                    return StringValue.makeStringValue(bun);
                } catch (Exception e) {
                    throw new XPathException("Unable to retrieve bun", e);
                }
            }
        };
    }

}
