package gr.alpha.cbs.fuse.ifaces;

import org.apache.camel.Exchange;

public interface IPrintingExtension {
	void addExtraPrintingInformation(Exchange exchange) throws Exception;
}
