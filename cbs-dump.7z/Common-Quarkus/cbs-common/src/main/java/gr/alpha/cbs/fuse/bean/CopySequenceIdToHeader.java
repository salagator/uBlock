package gr.alpha.cbs.fuse.bean;

import gr.alpha.cbs.fuse.common.CBSConstants;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.jboss.logging.MDC;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Named;

@Named("copySequenceIdToHeader")
@Dependent
@RegisterForReflection
public class CopySequenceIdToHeader implements Processor {

	@Override
	public void process(Exchange exchange) throws Exception {
		exchange.getIn().setHeader("sequenceId", MDC.get(CBSConstants.MDC_KEY_SEQUENCE_ID));
	}

}
