//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

import java.io.IOException;

public class KieServerHttpRequestException extends RuntimeException {
    private static final long serialVersionUID = 8703710246151287879L;

    public KieServerHttpRequestException(String msg, Throwable cause) {
        super(msg, cause);
    }

    public KieServerHttpRequestException(String msg) {
        super(msg);
    }

    public IOException getCause() {
        return (IOException)super.getCause();
    }
}
