
package gr.alpha.cbs.fuse.legacy;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlSchemaType;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ServeResult" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Reply" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CommitStatus" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "serveResult",
    "reply",
    "commitStatus"
})
@XmlRootElement(name = "ServeResponse", namespace = "http://alpha.gr/odissy/dispatcher")
public class ServeResponse {

    @XmlElement(name = "ServeResult", namespace = "http://alpha.gr/odissy/dispatcher")
    protected String serveResult;
    @XmlElement(name = "Reply", namespace = "http://alpha.gr/odissy/dispatcher")
    protected String reply;
    @XmlElement(name = "CommitStatus", namespace = "http://alpha.gr/odissy/dispatcher")
    @XmlSchemaType(name = "unsignedByte")
    protected short commitStatus;

    /**
     * Gets the value of the serveResult property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServeResult() {
        return serveResult;
    }

    /**
     * Sets the value of the serveResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServeResult(String value) {
        this.serveResult = value;
    }

    /**
     * Gets the value of the reply property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReply() {
        return reply;
    }

    /**
     * Sets the value of the reply property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReply(String value) {
        this.reply = value;
    }

    /**
     * Gets the value of the commitStatus property.
     * 
     */
    public short getCommitStatus() {
        return commitStatus;
    }

    /**
     * Sets the value of the commitStatus property.
     * 
     */
    public void setCommitStatus(short value) {
        this.commitStatus = value;
    }

}
