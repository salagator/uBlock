package gr.alpha.cbs.fuse.strategies;

import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;
import org.apache.camel.component.xslt.XsltAggregationStrategy;
import org.apache.camel.component.xslt.XsltOutput;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import java.util.Map;

@Named("enrichCDATARequestXMLAggregationStrategy")
@ApplicationScoped
@RegisterForReflection
public class EnrichCDATARequestXMLAggregationStrategy extends XsltAggregationStrategy {

    private static final Logger logger = LoggerFactory.getLogger(EnrichCDATARequestXMLAggregationStrategy.class);
    public EnrichCDATARequestXMLAggregationStrategy() {
        super("xslt/enrichCDATARequestXML.xsl");
        setOutput(XsltOutput.DOM);
    }

    @Override
    public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
        Exchange exchangeToReturn = super.aggregate(oldExchange, newExchange);
        if (newExchange != null && oldExchange != null) {
            for(Map.Entry<String, Object> entry : newExchange.getProperties().entrySet()) {
                String key = entry.getKey();
                Object value = entry.getValue();
                if (exchangeToReturn.getProperty(key) == null) {
                    logger.info("Adding non existing property {} with value {}.", key, value);
                    exchangeToReturn.setProperty(key, value);
                }
            }
        }
        return exchangeToReturn;
    }
}
