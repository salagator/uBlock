package gr.alpha.cbs.fuse.support;

import gr.alpha.cbs.fuse.common.ifaces.RefDataTranslator;
import io.quarkus.runtime.annotations.RegisterForReflection;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;

@Named("functionReverseTranslator")
@ApplicationScoped
@RegisterForReflection
public class ReverseTranslatorXsltExtension extends ExtensionFunctionDefinition {
    private static final long serialVersionUID = 1862024181840326214L;

    @Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("rvtr", "http://fuse.cbs.alpha.gr/translator/", "reversetranslator");
    }

    @Override
    public SequenceType[] getArgumentTypes() {
        return new SequenceType[]{SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING};

    }

    @Inject
    @Named("refDataTranslatorEjb")
    RefDataTranslator translator;

    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
        return SequenceType.SINGLE_STRING;
    }

    @Override
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {

            @Override
            @SuppressWarnings("rawtypes")
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
                try {
                    String fromSystem = ((StringValue)arguments[0]).getStringValue();
                    String toSystem = ((StringValue)arguments[1]).getStringValue();
                    String table = ((StringValue)arguments[2]).getStringValue();
                    String description = null;
                    if (arguments[3] instanceof LazySequence) {
                        description = ((LazySequence)arguments[3]).head().getStringValue();
                    } else if (arguments[3] instanceof StringValue) {
                        description = ((StringValue)arguments[3]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type: " + arguments[3].getClass().getCanonicalName());
                    }
                    if (description == null || description.isEmpty())
                        return StringValue.makeStringValue("");
                    String result = translator.reverseTranslateData(fromSystem, toSystem, table, description.trim());

                    return StringValue.makeStringValue(result);
                } catch (Exception e) {
                    throw new XPathException("Unable to translate value", e);
                }
            }
        };
    }
}
