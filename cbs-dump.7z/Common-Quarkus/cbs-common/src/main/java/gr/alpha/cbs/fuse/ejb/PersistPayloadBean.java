package gr.alpha.cbs.fuse.ejb;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.support.PersistedPayload;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;
import org.eclipse.microprofile.config.ConfigProvider;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;
import jakarta.transaction.Transactional;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Named("persistPayloadBean")
@Dependent
@RegisterForReflection
@Transactional(Transactional.TxType.NOT_SUPPORTED)
public class PersistPayloadBean {
	private static final Logger LOGGER = Logger.getLogger(PersistPayloadBean.class);

	@Inject
	@io.quarkus.agroal.DataSource("cbsxa")
	DataSource sqlDS;

	private static final String PERSIST_PAYLOAD = "INSERT INTO TRN_PersistedRequestPayloads (PayloadTimestamp, PayloadRequestId, ServiceName, OperationName, Payload) VALUES (?,?,?,?,?)";
	private static final String GET_PAYLOAD_BY_OPERATION_AND_REQUEST_ID = "SELECT Payload FROM TRN_PersistedRequestPayloads WHERE OperationName = ? AND PayloadRequestId = ?";
	private static final String GET_PAYLOADS_BY_TIMESTAMP_RANGE = "SELECT PayloadTimestamp, PayloadRequestId, ServiceName, OperationName, Payload FROM TRN_PersistedRequestPayloads WHERE PayloadTimestamp BETWEEN ? AND ?";

	public void createPersistedRequestPayload(Exchange exchange) throws SQLException, TransformerException {
		try (Connection conn = sqlDS.getConnection(); PreparedStatement stmt = conn.prepareStatement(PERSIST_PAYLOAD);) {
			LocalDateTime ldtEuropeAthens = LocalDateTime.now(ZoneId.of(ConfigProvider.getConfig().getOptionalValue("cbs.time.zone", String.class).orElse("Europe/Athens")));
			Timestamp timestamp = Timestamp.valueOf(ldtEuropeAthens);
			Document body = exchange.getIn().getBody(Document.class);
			SQLXML sqlxml = documentToSQLXML(conn, body);
			String requestId = exchange.getProperty(CBSConstants.HEADER_REQUEST_ID, String.class);
			String serviceName = exchange.getProperty(CBSConstants.HEADER_TRANSACTION_SERVICE, String.class);
			String operationName = exchange.getProperty(CBSConstants.HEADER_TRANSACTION_NAME, String.class);

			stmt.setTimestamp(1, timestamp);
			stmt.setString(2, requestId);
			stmt.setString(3, serviceName);
			stmt.setString(4, operationName);
			stmt.setSQLXML(5, sqlxml);

			String payloadTimestamp = ldtEuropeAthens.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
			LOGGER.debug(String.format("Persisting request payload [payloadTimestamp=%s, payloadRequestId=%s, operationName=%s]", payloadTimestamp, requestId, operationName));

			stmt.execute();
		}
	}

	public Document getPersistedRequestPayload(String operationName, String requestId) throws SQLException, ParserConfigurationException, SAXException, IOException {
		Document doc = null;
		try (Connection conn = sqlDS.getConnection(); PreparedStatement stmt = conn.prepareStatement(GET_PAYLOAD_BY_OPERATION_AND_REQUEST_ID);) {
			stmt.setString(1, operationName);
			stmt.setString(2, requestId);

			try (ResultSet resultSet = stmt.executeQuery();) {
				if (resultSet.next()) {
					SQLXML sqlxml = resultSet.getSQLXML(1);
					InputStream binaryStream = sqlxml.getBinaryStream();
					DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
					doc = parser.parse(binaryStream);
					binaryStream.close();
				}
			}
		}
		return doc;
	}

	public List<PersistedPayload> getPersistedRequestPayloadsByTimestampRange(Timestamp from, Timestamp to) throws SQLException, ParserConfigurationException, SAXException, IOException {
		List<PersistedPayload> persistedPayloads = new ArrayList<>();
		try (Connection conn = sqlDS.getConnection(); PreparedStatement stmt = conn.prepareStatement(GET_PAYLOADS_BY_TIMESTAMP_RANGE);) {
			stmt.setTimestamp(1, from);
			stmt.setTimestamp(2, to);

			DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			SQLXML sqlxml;
			InputStream binaryStream;

			try (ResultSet resultSet = stmt.executeQuery();) {
				while (resultSet.next()) {
					sqlxml = resultSet.getSQLXML(5);
					binaryStream = sqlxml.getBinaryStream();
					persistedPayloads.add(new PersistedPayload(resultSet.getTimestamp(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), parser.parse(binaryStream)));
					binaryStream.close();
				}
			}
		}
		return persistedPayloads;
	}

	SQLXML documentToSQLXML(Connection conn, Document document) throws SQLException, TransformerException {
		SQLXML sqlxml = conn.createSQLXML();
		SAXResult sax = sqlxml.setResult(SAXResult.class);
		Transformer transformer = TransformerFactory.newInstance().newTransformer();
		transformer.transform(new DOMSource(document), sax);
		return sqlxml;
	}
}
