/*
 * Copyright 2015 Red Hat, Inc. and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package gr.alpha.cbs.fuse.kie;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "variable-instance-list")
public class VariableInstanceList implements ItemList<VariableInstance> {

    @XmlElement(name = "variable-instance")
    @JsonProperty(value = "variable-instance")
    private VariableInstance[] variableInstances;

    public VariableInstanceList() {
    }

    public VariableInstanceList(VariableInstance[] variableInstances) {
        this.variableInstances = variableInstances;
    }

    public VariableInstanceList(List<VariableInstance> variableInstances) {
        this.variableInstances = variableInstances.toArray(new VariableInstance[variableInstances.size()]);
    }

    public VariableInstance[] getVariableInstances() {
        return variableInstances;
    }

    public void setVariableInstances(VariableInstance[] variableInstances) {
        this.variableInstances = variableInstances;
    }

    @Override
    public List<VariableInstance> getItems() {
        if (variableInstances == null) {
            return Collections.emptyList();
        }
        return Arrays.asList(variableInstances);
    }
}
