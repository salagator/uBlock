package gr.alpha.cbs.fuse.tools;

import com.fasterxml.jackson.annotation.JsonProperty;

public abstract class LoggingInfoMixIn {
    @JsonProperty("cbsUnId")
    public String cbsUnId;
}
