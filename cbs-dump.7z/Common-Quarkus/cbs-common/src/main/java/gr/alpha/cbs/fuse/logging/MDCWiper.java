package gr.alpha.cbs.fuse.logging;

import io.quarkus.runtime.annotations.RegisterForReflection;
import org.jboss.logging.Logger;
import org.slf4j.MDC;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

@Named("mdcWiper")
@ApplicationScoped
@RegisterForReflection
public class MDCWiper {

	private static final Logger LOGGER = Logger.getLogger(MDCHandler.class);
	public static final String MDC_KEY_REQUEST_ID = "cbs.RequestId";
	public static final String MDC_KEY_SESSION_ID = "cbs.SessionId";
	public static final String MDC_KEY_BUSINESS_CASE_ID = "cbs.BusinessCaseId";
	public static final String MDC_KEY_SEQUENCE_ID = "cbs.SequenceId";
	public static final String MDC_KEY_USER_ID = "cbs.UserId";
	public static final String MDC_KEY_CBS_UN_ID = "cbs.CBSUnId";

	public void wipe(){
	    if(LOGGER.isDebugEnabled()) {
			LOGGER.debug("Before MDC WIPE: MDC set. requestId:" + MDC.get(MDC_KEY_REQUEST_ID) + " sequenceId:" + MDC.get(MDC_KEY_SEQUENCE_ID) +
					" sessionId:" + MDC.get(MDC_KEY_SESSION_ID) + " businessCaseId:" + MDC.get(MDC_KEY_BUSINESS_CASE_ID) + " userId:" + MDC.get(MDC_KEY_USER_ID));
		}
		MDC.remove(MDC_KEY_REQUEST_ID);
		MDC.remove(MDC_KEY_SEQUENCE_ID);
		MDC.remove(MDC_KEY_SESSION_ID);
		MDC.remove(MDC_KEY_BUSINESS_CASE_ID);
		MDC.remove(MDC_KEY_USER_ID);
		MDC.remove(MDC_KEY_CBS_UN_ID);		
	}
}
