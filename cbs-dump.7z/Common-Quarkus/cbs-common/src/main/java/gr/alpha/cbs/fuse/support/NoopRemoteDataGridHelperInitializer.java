package gr.alpha.cbs.fuse.support;

public class NoopRemoteDataGridHelperInitializer implements RemoteDataGridHelperInitializer {
    public void init() {
        // No operation performed
    }
}
