package gr.alpha.cbs.fuse.ejb;

import gr.alpha.cbs.fuse.common.ifaces.RefDataTranslator;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantTransactionLanguages;
import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.inject.Singleton;
import org.apache.commons.lang3.math.NumberUtils;
import org.jboss.logging.Logger;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;
import jakarta.transaction.Transactional;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Named("refDataTranslatorEjb")
@Singleton
@RegisterForReflection
@Transactional(Transactional.TxType.NOT_SUPPORTED)
public class RefDataTranslatorEjb implements RefDataTranslator {
    private static final int DEFAULT_ZERO = 0;


    // Constant for storing NOT FOUND ELEMENTS IN CACHE. Otherwise lookups in DB upon next request
    private static 	String NOT_FOUND_REF_DATA = "_NOT_FOUND_REF_DATA_";
    private static final String GREEK="Greek";
    private static final String ENGLISH="English";
    private static final String PRODUCT_STUDIO="ProductStudio";



    private static final Logger LOGGER = Logger.getLogger(RefDataTranslatorEjb.class);
    @Inject
    @io.quarkus.agroal.DataSource("hostcbsparams")
    DataSource sqlDS;

    RemoteDatagridClientHelper<String, String> datagridHelper;


    private static final String REVERSE_TRANSLATION_SQL = "SELECT SystemMap.Value FROM REF_MembersSystemsMapping as SystemMap "
            + "JOIN REF_SystemTypes AS Systems ON Systems.Id = SystemMap.SystemsId "
            + "JOIN REF_MembersUI AS Literal ON Literal.MembersId = SystemMap.MembersId "
            + "JOIN UFE_Languages AS Languages ON Languages.Id = Literal.LanguageId "
            + "JOIN REF_Members AS Member ON Member.Id = SystemMap.MembersId "
            + "JOIN REF_Members AS ParentMember ON ParentMember.id = Member.ParentMemberId "
            + "WHERE Languages.LanguageName = ? AND Systems.SystemName = ?  "
            + "AND LTRIM(RTRIM(Literal.UserDisplay)) = ? AND ParentMember.Name = ? ";

    /**
     *
     * @param fromSystem
     *            UFE, OS2200 or Siglo
     * @param toSystem
     *            UFE, OS2200, Siglo, Greek or English
     * @param parentName
     *            Parent name of values e.g. Address_Types
     * @param value
     *            The actual value
     * @return the translated value to the system specified or the initial value
     *         if not found
     * @throws Exception
     */
    public String translateDataOrReturnNull(String fromSystem, String toSystem, String parentName, String value) throws Exception {

        //override parameter toSystem: Greek or English with el or en
        if(GREEK.equals(toSystem)){
            toSystem = ConstantTransactionLanguages._ELLINIKA;
        }else if(ENGLISH.equals(toSystem)){
            toSystem = ConstantTransactionLanguages._AGGLIKA;
        }

        Long l = System.currentTimeMillis();
        String queryResult = "";
        String key = null;
        String cachedValue = null;
        if (datagridHelper.getCache() != null) {
            key = "REF_DT:" + fromSystem + "|" + toSystem + "|" + parentName + "|" + value;
            cachedValue = datagridHelper.get(key);
        }
        if (cachedValue != null) {
            if (NOT_FOUND_REF_DATA.equals(cachedValue)){
                queryResult = null;
            } else {
                queryResult = cachedValue;
            }
            LOGGER.debug("Got from cache:" + queryResult);
        } else {
            queryResult = getFromDB(fromSystem, toSystem, parentName, value, queryResult);
            if (datagridHelper.getCache() != null) {
                if (queryResult == null){
                    datagridHelper.put(key, NOT_FOUND_REF_DATA);
                } else {
                    datagridHelper.put(key, queryResult);
                }

            }

        }
        if (LOGGER.isTraceEnabled()) {
            l = System.currentTimeMillis() - l;
            LOGGER.trace("Executed in " + l + "ms,fromSystem:" + fromSystem + ",toSystem:" + toSystem + ",parentName:"
                    + parentName + ",value:" + value);
        }

        return queryResult;
    }

    String getFromDB(String fromSystem, String toSystem, String parentName, String value, String queryResult) throws Exception {
        Connection conn = null;
        PreparedStatement pstm = null;
        ResultSet res = null;

        try {
            LOGGER.debug("query db");
            conn = this.sqlDS.getConnection();

            pstm = getPreparedStatement(conn, fromSystem, toSystem, parentName, value);

            res = pstm.executeQuery();


            if (res.next()) {
                queryResult = res.getString(1); //returns Value for refdata , Member column value for productstudio data
            } else {

                LOGGER.warn(ConstantErrorMessages._No_parameters_found_related_to_Ref_Data
                        + " - Δεν βϝέθηκε reference data για την κατηγοϝία (" + parentName + ") με τιμή (" + value
                        + ")");
                if (ConstantTransactionLanguages._ELLINIKA.equals(toSystem) || ConstantTransactionLanguages._AGGLIKA.equals(toSystem)) {
                    queryResult = "";
                } else {
                    queryResult = null;
                }
            }

        } catch (Exception ex) {
            LOGGER.error("Exception when translating data", ex);
            throw ex;
        } finally {
            if (res != null) {
                res.close();
            }

            if (pstm != null) {
                pstm.close();
            }

            if (conn != null) {
                conn.close();
            }
        }
        return queryResult;
    }


    public String reverseTranslateData(String fromSystem, String toSystem, String parentName, String description)
            throws Exception {

        ResultSet res = null;

        try (Connection conn = this.sqlDS.getConnection();PreparedStatement pstm = conn.prepareStatement(REVERSE_TRANSLATION_SQL)) {

            pstm.setString(1, fromSystem);
            pstm.setString(2, toSystem);
            pstm.setString(3, description);
            pstm.setString(4, parentName);


            res = pstm.executeQuery();

            if (res.next()) {
                return res.getString("Value");
            } else
                return description;
        } catch (Exception ex) {
            LOGGER.error("Exception when translating data", ex);
            throw ex;
        } finally {
            if (res != null) {
                res.close();
            }
        }
    }
    @SuppressWarnings("squid:S2695")

    PreparedStatement getPreparedStatement(Connection conn, String fromSystem, String toSystem,
                                                   String parentName, String value) throws SQLException {
        String sql = null;

        String whereStr = " AND  fs.system_value = ? ";
        String whereNum = " AND ( fs.system_value = ?   OR fs.system_value = CONVERT(NVARCHAR(max), CONVERT(INT, ?))) ";
        boolean userDisplayFlag =  (ConstantTransactionLanguages._ELLINIKA.equals(toSystem) || ConstantTransactionLanguages._AGGLIKA.equals(toSystem));
        if (userDisplayFlag) {
            if (PRODUCT_STUDIO.equals(fromSystem)){
                StringBuffer  varname1 = new StringBuffer();
                //ParentName, LanguageID (1: Greek), System (0: Product Studio), Value (specific value to be returned)
                varname1.append("{call usp_PRD_RefData_Total_NonXML(?,?,?,?)}");
                sql=varname1.toString();
            }else{

                StringBuffer  varname1 = new StringBuffer();
                varname1.append("SELECT ui.userdisplay AS Value ");
                varname1.append("FROM   ref_membersui ui, ");
                varname1.append("       ref_translate_refdata_indexed_view s (noexpand), ");
                varname1.append("       ref_members rm ");
                varname1.append("WHERE  ui.languageid = ? ");
                varname1.append("       AND ui.membersid = s.member_id ");
                varname1.append("       AND rm.name = ? ");
                varname1.append("       AND rm.parentmemberid IS NULL ");
                varname1.append("       AND rm.id = s.root_member_id ");
                varname1.append("       AND s.system_value = ? ");
                varname1.append("       AND s.system_name = ? ");
                sql=varname1.toString();
            }

        } else {
            // First level is the Reference Data Category e.g "Currencies"
            // Second level are the actual currencies e.g EUR, USD etc
            // Third level are the systems specific codes for the second level element e.g. OS2200 EUR Code = 0, UFE EUR Code = 2 etc
            // The ref_translate_refdata_indexed_view is a indexed view that joins all the above to denormilize the schema and put indexes.
            // There are two indexes defined in ref_translate_refdata_indexed_view the first for searching system code e.g OS2000 EUR and returns the second level ID and the other that given the second level ID and systems returns the code.

            StringBuilder  varname1 = new StringBuilder();
            varname1.append("SELECT ts.system_value  AS Value ");
            varname1.append("FROM   ref_translate_refdata_indexed_view fs (noexpand), ");
            varname1.append("       ref_members fm1, ");
            varname1.append("       ref_translate_refdata_indexed_view ts (noexpand) ");
            varname1.append("WHERE   ts.system_name = ? ");
            varname1.append("		AND fm1.name = ? ");
            varname1.append("       AND fm1.id = fs.root_member_id ");
            varname1.append("       AND fs.system_name = ? ");
            varname1.append("       AND fs.member_id = ts.member_id ");
            sql = varname1.toString();

            if (NumberUtils.isDigits(value)) {
                sql += whereNum;
            } else {
                sql += whereStr;
            }
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("SQL:" + sql + " fromSystem:" + fromSystem + " toSystem:" + toSystem + " parentName:" + parentName + " value:" + value);
        }
        @SuppressWarnings("squid:S2095")
        PreparedStatement pstm = conn.prepareStatement(sql);

        if (ConstantTransactionLanguages._ELLINIKA.equals(toSystem)) {
            if (PRODUCT_STUDIO.equals(fromSystem)){
                pstm.setString(1, parentName);
                pstm.setInt(2, 1); //Greek
                pstm.setInt(3, 0); //ProductStudio
                pstm.setString(4, value);
            }else{
                pstm.setInt(1, 1); // Greek
                pstm.setString(2, parentName);
                pstm.setString(3, value);
                pstm.setString(4, fromSystem);
            }

        } else if (ConstantTransactionLanguages._AGGLIKA.equals(toSystem) ) {
            if (PRODUCT_STUDIO.equals(fromSystem)){
                pstm.setString(1, parentName);
                pstm.setInt(2, 2); //English
                pstm.setInt(3, 0); //ProductStudio
                pstm.setString(4, value);
            }else{
                pstm.setInt(1, 2); // English
                pstm.setString(2, parentName);
                pstm.setString(3, value);
                pstm.setString(4, fromSystem);
            }
        } else {
            pstm.setString(1, toSystem);
            pstm.setString(2, parentName);
            pstm.setString(3, fromSystem);

            if (NumberUtils.isDigits(value)) {
                pstm.setString(4, value);
                pstm.setString(5, value);
            } else {
                pstm.setString(4, value);
            }
        }

        return pstm;

    }


    @PostConstruct
    void postConstruct() {
        datagridHelper = new RemoteDatagridClientHelper<>();
        datagridHelper.initCacheManager();
        datagridHelper.setCache("refData-translations");
        LOGGER.debug("postConstruct called");
    }

    @PreDestroy
    void preDestroy() {
        datagridHelper.stopCacheManager();
    }


    @Override
    public String translateData(String fromSystem, String toSystem, String parentName, String value) throws Exception {
        Long timer = System.nanoTime();
        String queryResult = translateDataOrReturnNull(fromSystem, toSystem, parentName, value);

        if (queryResult == null)
            queryResult = value;


        if (LOGGER.isDebugEnabled()){
            timer = System.nanoTime() - timer;
            LOGGER.debug("Executed in " + timer /1000 + "micro,fromSystem:" + fromSystem + ",toSystem:" + toSystem + ",parentName:"	+ parentName + ",value:" + value);
        }
        return queryResult;

    }

    @Override
    public List<String> reverseTranslateAll(String fromSystem, String toSystem, String parentName, String description) throws Exception {
        List<String> translations = new ArrayList<>();

        try (Connection conn = this.sqlDS.getConnection();
             PreparedStatement pstm = conn.prepareStatement(REVERSE_TRANSLATION_SQL)) {
            pstm.setString(1, fromSystem);
            pstm.setString(2, toSystem);
            pstm.setString(3, description);
            pstm.setString(4, parentName);

            try (ResultSet res = pstm.executeQuery();) {
                while (res.next()) {
                    translations.add(res.getString("Value"));
                }
            }
        } catch (Exception ex) {
            LOGGER.error("Exception when translating data", ex);
            throw ex;
        }

        return translations;
    }
}
