package gr.alpha.cbs.fuse.helpers;

import java.io.StringWriter;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpHeaderValues;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.hc.core5.http.HttpStatus;
import org.eclipse.microprofile.config.ConfigProvider;
import org.jboss.logging.Logger;
import com.fasterxml.jackson.databind.ObjectMapper;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.classes.ChannelTellerDataRequest;
import gr.alpha.cbs.fuse.classes.ChannelTellerDataResponse;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.w3c.dom.Document;

@Named("channelTellerDataHelper")
@ApplicationScoped
@RegisterForReflection
public class ChannelTellerDataHelper {
    private static final Logger LOGGER = Logger.getLogger(ChannelTellerDataHelper.class);
    private static final String API_PATH = "/api/BUCR/GetUserDetailsByUsername";
    private static final String CHANNEL_FUSE_API = ConfigProvider.getConfig().getValue("cbs.channelfuseapi.endpoint",String.class);

    public String getTellerFirstNameSureNameFromChannel(Exchange ex) throws Exception{

        String firstLastNameConcatenated = "";
        String username = "";
        username = ex.getProperty("tellerID", String.class);
        if (!username.equals("") && !username.isEmpty() && !username.equals(" ") && username != null){
            firstLastNameConcatenated = fetchData(username);
        }

        if(LOGGER.isDebugEnabled()){
            LOGGER.debug("Now printing the NAME : "+firstLastNameConcatenated);
        }
        return firstLastNameConcatenated;
    }

    public String getUserNameFirstNameLastName(Exchange ex) throws Exception{
        String userIdClean = "", username = "", firstLastNameConcatenated = "", domain = "", userFull = "";
        Document doc = (Document) ex.getIn().getBody(Document.class);

        //gets the domain from the environment userID
        userFull = FormatUtils.getValue(doc, "//*:LoggingInfo/*:UserId");
        domain = userFull.substring(0, userFull.indexOf("\\"));
        username = ex.getProperty("tellerID", String.class);
        //for cases that the username contains the domain, we remove it for printing purposes.
        if (username.contains(domain)){
            userIdClean = username.substring(username.indexOf("\\")+1);
            if(LOGGER.isDebugEnabled()){
                LOGGER.debug("userIdClean from ChannelTellerDataHelper for printing purposes: "+userIdClean);
            }
        }else{
            //for cases that the username does not include domain we add it, to call the ChannelApi.
            username = domain+"\\"+username;
            userIdClean = ex.getProperty("tellerID", String.class);
            if(LOGGER.isDebugEnabled()){
                LOGGER.debug("username concatenated: "+username);
            }
        }
        if (!username.equals("") && !username.isEmpty() && !username.equals(" ") && username != null){
            firstLastNameConcatenated = fetchData(username);
        }
        return userIdClean+" - "+firstLastNameConcatenated;
    }

    private String fetchData(String username) throws Exception{

        String firstLastNameConcatenated = "";
        ChannelTellerDataRequest request = new ChannelTellerDataRequest();
        request.setUsername(username);

        ObjectMapper mapper = new ObjectMapper();
        StringWriter writer = new StringWriter();

        mapper.writeValue(writer, request);
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest clientRequest = HttpRequest.newBuilder()
                .header(HttpHeaderNames.CONTENT_TYPE.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
                .header("Accept", "application/json; charset=utf-8")
                .POST(HttpRequest.BodyPublishers.ofString(writer.toString()))
                .uri(new URI(CHANNEL_FUSE_API+API_PATH))
                .build();

        if(LOGGER.isDebugEnabled()){
            LOGGER.debug("ChannelTellerDataRequest called with :"+writer.toString());
        }

        HttpResponse<String> clientResponse = client.send(clientRequest, HttpResponse.BodyHandlers.ofString());

        if (clientResponse.statusCode() == HttpStatus.SC_OK){

            ChannelTellerDataResponse response = mapper.readValue(clientResponse.body().getBytes(StandardCharsets.UTF_8), ChannelTellerDataResponse.class);

            String firstName = response.getResponseData().getFirstName();
            String lastName = response.getResponseData().getLastName();
            firstLastNameConcatenated = firstName+" "+lastName;
            if(LOGGER.isDebugEnabled()){
                LOGGER.debug("Now printing the NAME : "+firstLastNameConcatenated);
            }

            return firstLastNameConcatenated;

        }else{
            ErrorUtils.throwCBSException(null,
                    String.valueOf(ConstantError_Types._Technical),
                    String.valueOf(ConstantError_System_IDs._FUSE),
                    this.getClass().getCanonicalName(),
                    String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob),
                    String.valueOf(ConstantError_Levels._Error),
                    "Service GetTellerDataFromChannel of channel api replied with status:"+String.valueOf(clientResponse.statusCode()),
                    "",
                    "");
        }

        return firstLastNameConcatenated;
    }
}