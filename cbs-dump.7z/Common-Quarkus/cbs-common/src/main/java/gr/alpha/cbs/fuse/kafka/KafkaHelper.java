package gr.alpha.cbs.fuse.kafka;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

public class KafkaHelper {
	private KafkaHelper() {
	}

	public static Map<String, String> loadPropertiesFile() throws IOException {
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		InputStream propertiesFile = classLoader.getResourceAsStream("gr/alpha/cbs/fuse/kafka.properties");
		if (propertiesFile == null) {
			return new HashMap<>();
		}

		/*
		 * Load kafka.properties in an Properties object
		 * Properties object has to be parsed into KafkaConfig objects
		 */
		Properties properties = new Properties();
		properties.load(propertiesFile);
		propertiesFile.close();

		return properties.entrySet().stream().collect(Collectors.toMap(e -> (String) e.getKey(), e -> (String) e.getValue()));
	}
}
