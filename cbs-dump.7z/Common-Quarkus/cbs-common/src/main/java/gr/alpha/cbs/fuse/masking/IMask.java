package gr.alpha.cbs.fuse.masking;

import org.jboss.logging.Logger;


public interface IMask {
	
	static final Logger LOGGER = Logger.getLogger(IMask.class);
	
	public String mask(String value, int length);
	
}
