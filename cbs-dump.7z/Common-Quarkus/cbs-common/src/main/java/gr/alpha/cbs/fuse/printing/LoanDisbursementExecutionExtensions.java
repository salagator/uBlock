package gr.alpha.cbs.fuse.printing;

import gr.alpha.cbs.fuse.printing.siglo.PrintingExtentions;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

public class LoanDisbursementExecutionExtensions {

    private static final String EMPTY_STRING = "";
    private static final String SPACE = " ";
    private static final String DOUBLE_SLASH ="//";

    private LoanDisbursementExecutionExtensions() {
        throw new IllegalStateException("Utility class");
    }

    public static String generateTransactionDescription(Map<String, Object> printingMap) throws Exception{
        int   numCopies     = 3;
        String resultString;

        Map<String, String> localMap = PrintingExtentions.readPrintingMap(printingMap);

        StringBuilder finalDescription = new StringBuilder();

        if ( (EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSettlementsData_LoanSettlementItemCode")) && numCopies==3) numCopies--;

        if ( ("0.00").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingData_LoanCommisionAmmountOpeningLoanGuarantee")) && numCopies==2) numCopies--;

        if (numCopies==1)
        {
            if (!(("4").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingData_LoanTransactionType"))))
            {
                Boolean checkLoanReportsIndicator2= false;

                if (localMap.get("LoanSearchTransitionData_LoanAccountData_LoanReportsIndicator2").startsWith("1"))
                {

                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P03C1).append(SPACE);
                    checkLoanReportsIndicator2 = true;
                }

                if ((CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType"))&& (Integer.parseInt(localMap.get("bondIndicator")) == 0) )         //Not Bond Loan
                    finalDescription.append( CBSLoanDisbursementExecutionConstants.P0607 + SPACE);
                else
                {
                    if ((Integer.parseInt(localMap.get("bondIndicator")) == 0))        //Not Bond Loan
                    {
                        if ((("EUR").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingData_LoanCurrencyCode")) || ("GRD").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingData_LoanCurrencyCode"))) && !checkLoanReportsIndicator2)
                        {
                            finalDescription.append(CBSLoanDisbursementExecutionConstants.P0105 + SPACE);
                        }
                        else
                        if (!checkLoanReportsIndicator2)
                            finalDescription.append(CBSLoanDisbursementExecutionConstants.MC01 + SPACE);

                    }
                    else                     //Bond Loan
                    {
                        if ((Integer.parseInt(localMap.get("bondIndicator")) == 1))        //Not Bond Loan
                            finalDescription.append(CBSLoanDisbursementExecutionConstants.P0608B).append(SPACE);
                        else if ((Integer.parseInt(localMap.get("bondIndicator")) == 2))        //Not Bond Loan
                            finalDescription.append(CBSLoanDisbursementExecutionConstants.P0608S).append(SPACE);
                        else if ((Integer.parseInt(localMap.get("bondIndicator")) == 3))        //Not Bond Loan
                            finalDescription.append(CBSLoanDisbursementExecutionConstants.P0608K).append(SPACE);
                    }
                }
                if (!(CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && (!(EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) && localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")!=null)  && (EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator"))  &&
                        Integer.parseInt(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanMaximumPeriodNumber")) >   0 && (!checkLoanReportsIndicator2))
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P01C1).append(SPACE);

                if (!(CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && (!(EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) && localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")!=null)  && (EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator")) &&
                        Integer.parseInt(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanMaximumPeriodNumber")) ==  0  && !(localMap.get("LoanSearchTransitionData_LoanAccountData_LoanReportsIndicator2").startsWith("1")))
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P01C2).append(SPACE);

                if (!(CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && ((EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) || localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")==null)  && ("H").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator")))
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P02C1).append(SPACE);
                if (!(CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && ((EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) || localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")==null)  && ("P").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator")))
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P02C2).append(SPACE);
                if (!(CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && ((EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) || localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")==null)  && ("*").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator")))
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P02C3).append(SPACE);

                if (!(CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && ((EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) || localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")==null)  && (EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator")) && (!checkLoanReportsIndicator2))
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P03C0).append(SPACE);

                if (!(CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && (!(EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) && localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")!=null)  && ("H").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator")) &&
                        Integer.parseInt(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanMaximumPeriodNumber")) >   0)
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P05C1).append(SPACE);

                if (!(CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && (!(EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) && localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")!=null)  && ("*").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator")) &&
                        Integer.parseInt(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanMaximumPeriodNumber")) >   0)
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P05C5).append(SPACE);

                if (!(CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && (!(EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) && localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")!=null)  && ("P").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator")) &&
                        Integer.parseInt(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanMaximumPeriodNumber")) >   0)
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P05C2).append(SPACE);

                if (!(CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && (!(EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) && localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")!=null)  && ("H").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator")) &&
                        Integer.parseInt(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanMaximumPeriodNumber")) ==  0)
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P05C3).append(SPACE);

                if (!(CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && (!(EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) && localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")!=null)  && ("*").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator")) &&
                        Integer.parseInt(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanMaximumPeriodNumber")) ==  0  && !("1").equals(localMap.get("LoanSearchTransitionData_LoanAccountData_LoanReportsIndicator2")))
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P05C6).append(SPACE);

                if (!(CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && (!(EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) && localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")!=null)  && ("P").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator")) &&
                        Integer.parseInt(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanMaximumPeriodNumber")) ==  0)
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P05C4).append(SPACE);

                if ((CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && (!(EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) && localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")!=null)  && (EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator"))  &&
                        Integer.parseInt(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanMaximumPeriodNumber")) >   0 && (Integer.parseInt(localMap.get("bondIndicator")) == 0))        //Not Bond Loan
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P06C1).append(SPACE);

                if ((CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && (!(EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) && localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")!=null)  && (EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator"))  &&
                        Integer.parseInt(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanMaximumPeriodNumber")) ==  0)
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P06C2).append(SPACE);

                if ((CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && (!(EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) && localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")!=null)  && ("H").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator")) &&
                        Integer.parseInt(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanMaximumPeriodNumber")) >   0)
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P07C1).append(SPACE);

                if ((CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && (!(EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) && localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")!=null)  && ("*").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator")) &&
                        Integer.parseInt(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanMaximumPeriodNumber")) >   0 && (Integer.parseInt(localMap.get("bondIndicator")) == 0 ))
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P07C5).append(SPACE);

                if ((CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && (!(EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) && localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")!=null)  && ("P").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator")) &&
                        Integer.parseInt(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanMaximumPeriodNumber")) >   0)
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P07C2).append(SPACE);

                if ((CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && (!(EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) && localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")!=null)  && ("H").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator")) &&
                        Integer.parseInt(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanMaximumPeriodNumber")) ==  0)
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P07C3).append(SPACE);

                if ((CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && (!(EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) && localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")!=null)  && ("*").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator")) &&
                        Integer.parseInt(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanMaximumPeriodNumber")) ==  0)
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P07C6).append(SPACE);

                if ((CBSLoanDisbursementExecutionConstants.WORKING_CAPITAL).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && (!(EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")) && localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanOpeningValueDate")!=null)  && ("P").equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanPledgedIndicator")) &&
                        Integer.parseInt(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanMaximumPeriodNumber")) ==  0)
                    finalDescription.append(CBSLoanDisbursementExecutionConstants.P07C4).append(SPACE);



            }



            // Print ruthmismena Loans
            if (!(CBSLoanDisbursementExecutionConstants.LETTER_OF_GUARANTEE).equals(localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")) && (Integer.parseInt(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingGuaranteesData_LoanAuthorizationNumber")) > 0))
            {
                finalDescription.append(CBSLoanDisbursementExecutionConstants.RYT).append(SPACE);
            }

        }

        if((DOUBLE_SLASH).equals(localMap.get("&&SALDATE1[10]&&"))){
            localMap.put("&&SALDATE1[10]&&", EMPTY_STRING);
        }
        if ((DOUBLE_SLASH).equals(localMap.get("&&SALDATE[10]&&"))){
            localMap.put("&&SALDATE[10]&&", EMPTY_STRING);
        }
        if ((DOUBLE_SLASH).equals(localMap.get("&&COURTDATE&&"))){
            localMap.put("&&COURTDATE&&", EMPTY_STRING);
        }
        if ((DOUBLE_SLASH).equals(localMap.get("LoanSearchTransitionData_LoanAccountData_LoanOpeningValueDate"))){
            localMap.put("LoanSearchTransitionData_LoanAccountData_LoanOpeningValueDate", EMPTY_STRING);
        }

        resultString = finalDescription.toString();

        for (Map.Entry<String, String> entry : localMap.entrySet())
        {
            if (entry.getKey().startsWith("&&CONTRACT")) {
                if ( (EMPTY_STRING).equals(localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanRelationshipDescription") ))
                    resultString = resultString.replaceAll(Pattern.quote(entry.getKey()), (localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountNumber") +localMap.get("LoanSearchTransitionData_LoanDataRetrieval_LoanAccountKey_LoanAccountRecordData_LoanAccountType")+" από "+localMap.get("LoanSearchTransitionData_LoanAccountData_LoanOpeningValueDate") ));
                else
                    resultString = resultString.replaceAll(Pattern.quote(entry.getKey()), localMap.get("LoanPrintingInformationResponse_LoanVoucherPrintingSALData_LoanRelationshipDescription"));
            } else if (entry.getKey().startsWith("&&SALLIMIT")) {
                DecimalFormatSymbols otherSymbols = new DecimalFormatSymbols(new Locale("el","GR"));
                otherSymbols.setDecimalSeparator(',');
                otherSymbols.setGroupingSeparator('.');
                DecimalFormat df = new DecimalFormat("###,###,###,###,###,###,###,##0.00", otherSymbols);
                resultString = resultString.replaceAll(Pattern.quote(entry.getKey()), (("EUR").equals(localMap.get("&&SAL_currency")) ? "ΕΥΡΩ " : localMap.get("&&SAL_currency"))+ SPACE + String.valueOf(df.format(Double.valueOf(entry.getValue()))));
            }

            else if (entry.getKey().startsWith("&&")) {
                resultString = resultString.replaceAll(Pattern.quote(entry.getKey()), entry.getValue());
            }

        }

        return resultString;

    }


}
