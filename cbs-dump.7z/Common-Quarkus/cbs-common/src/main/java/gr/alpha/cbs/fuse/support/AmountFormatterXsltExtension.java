package gr.alpha.cbs.fuse.support;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;

@Named("functionAmountFormatter")
@ApplicationScoped
@RegisterForReflection
public class AmountFormatterXsltExtension extends ExtensionFunctionDefinition {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -521757729150770000L;

	/**
	 * 
	 */
	
	

	@Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("sb", "http://fuse.cbs.alpha.gr/amountFormatter/", "amountFormatter");
    }
    
    @Override
    public SequenceType[] getArgumentTypes() {
    	return new SequenceType[]{SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING};

    }
    
    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
    	return SequenceType.SINGLE_STRING;
    }
    
    @Override
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {
			
			/**
			 * 
			 */
			private static final long serialVersionUID = -2058195000003838019L;

			@Override
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
				try {
					
					String fromSystem = null;
	                String toSystem = null;
	                String amount = null;

	                
	                
	                if (arguments[0] instanceof LazySequence) {
	                	fromSystem = ((LazySequence)arguments[0]).head().getStringValue();
	                } else if (arguments[0] instanceof StringValue) {
	                	fromSystem = ((StringValue)arguments[0]).getStringValue();
	                } else {
	                	throw new Exception("Unrecognized argument type: " + arguments[1].getClass().getCanonicalName());
	                }
	                
	                if (arguments[1] instanceof LazySequence) {
	                	toSystem = ((LazySequence)arguments[1]).head().getStringValue();
	                } else if (arguments[1] instanceof StringValue) {
	                	toSystem = ((StringValue)arguments[1]).getStringValue();
	                } else {
	                	throw new Exception("Unrecognized argument type: " + arguments[1].getClass().getCanonicalName());
	                }
	                
	                if (arguments[2] instanceof LazySequence) {
	                	amount = ((LazySequence)arguments[2]).head().getStringValue();
	                } else if (arguments[2] instanceof StringValue) {
	                	amount = ((StringValue)arguments[2]).getStringValue();
	                } else {
	                	throw new Exception("Unrecognized argument type: " + arguments[1].getClass().getCanonicalName());
	                }
	                
	                
	                
	                amount = formatAmountForPrinting(amount);
	                	return StringValue.makeStringValue(amount) ;
	                
				} catch (Exception e) {
					throw new XPathException("Unable to translate value", e);
				}
            }
        };
        
        
    }
    
	private String formatAmountForPrinting(String amount){
	    if(amount!=null){
		if(amount.length() == 0) amount = "0";
	    } else amount = "0";
        double amnt = Double.parseDouble(amount);
        NumberFormat nf = NumberFormat.getNumberInstance(Locale.ITALIAN);
        DecimalFormat formatter = (DecimalFormat)nf;
        nf.setMinimumFractionDigits(2);
        nf.setMaximumFractionDigits(2);
        return formatter.format(amnt);
	}

}
