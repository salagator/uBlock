package gr.alpha.cbs.fuse.outgoing.helpers;

import io.quarkus.rest.client.reactive.QuarkusRestClientBuilder;
import org.apache.hc.client5.http.auth.AuthScope;
import org.apache.hc.client5.http.auth.CredentialsProvider;
import org.apache.hc.client5.http.auth.StandardAuthScheme;
import org.apache.hc.client5.http.auth.UsernamePasswordCredentials;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.auth.BasicCredentialsProvider;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.core5.http.HttpHost;
import org.eclipse.microprofile.config.ConfigProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.Collections;

public class WebProxyHelper {
	private static final Logger logger = LoggerFactory.getLogger(WebProxyHelper.class);
	
	private static String webproxyHost;
	private static int webproxyPort;
	private static String webproxyUsername;
	private static String webproxyPassword;
	static {
		webproxyHost = ConfigProvider.getConfig().getOptionalValue("cbs.https.proxyHost", String.class).orElse("193.193.185.201" /* "webproxy.bank.root.alpha.gr" */);
		webproxyPort = Integer.parseInt(ConfigProvider.getConfig().getOptionalValue("cbs.https.proxyPort", String.class).orElse("8080"));
		webproxyUsername = ConfigProvider.getConfig().getOptionalValue("cbs.https.proxyUser", String.class).orElse("CENTRALTEST\\cbsesbuat");
		webproxyPassword = ConfigProvider.getConfig().getOptionalValue("cbs.https.proxyPassword", String.class).orElse("C8$3#Bu9!5j");
		logger.info("Using: webProxyHost: {},\n" +
				"\t\twebProxyPort: {}\n" +
				"\t\twebProxyUsername: {}\n\" +\n" +
				"\t\twebProxyPassword: {}\n",
                webproxyHost,
                webproxyPort,
				webproxyUsername,
				webproxyPassword);
	}

	public static QuarkusRestClientBuilder registerWebProxy(QuarkusRestClientBuilder builder) {
		return builder.
				proxyAddress(webproxyHost, webproxyPort).
				proxyUser(webproxyUsername).
				proxyPassword(webproxyPassword);
	}

	public static void setupProxy(HttpClientBuilder clientBuilder) {
		BasicCredentialsProvider credentialsProvider = new BasicCredentialsProvider();
		credentialsProvider.setCredentials(new AuthScope(webproxyHost, webproxyPort),
				new UsernamePasswordCredentials(webproxyUsername, webproxyPassword.toCharArray()));

		clientBuilder.setDefaultCredentialsProvider(credentialsProvider);
	}

	public static RequestConfig getRequestConfig() {
		HttpHost proxy = new HttpHost(webproxyHost, webproxyPort);
		return RequestConfig.custom().
				setProxyPreferredAuthSchemes(Collections.unmodifiableList(Arrays.asList(
						StandardAuthScheme.DIGEST,
						StandardAuthScheme.BASIC))).
				setProxy(proxy).build();
	}


}
