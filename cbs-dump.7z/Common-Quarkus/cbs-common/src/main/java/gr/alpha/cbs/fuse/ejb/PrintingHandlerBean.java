package gr.alpha.cbs.fuse.ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.Map.Entry;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;

import jakarta.transaction.TransactionScoped;
import jakarta.transaction.Transactional;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import gr.alpha.cbs.fuse.ifaces.IPrintingExtension;
import gr.alpha.cbs.fuse.support.TransactionOrigin;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.eclipse.microprofile.config.ConfigProvider;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Named("printingHandlerBean")
@TransactionScoped
@RegisterForReflection
public class PrintingHandlerBean {
	private static final Logger LOGGER = Logger.getLogger(PrintingHandlerBean.class);

	@Inject
	@io.quarkus.agroal.DataSource("cbsxa")
	DataSource sqlDS;

	private static final String insertStatementToPRTDataTable = "INSERT INTO PRT_Data "
			+ "(BUN, Data, Language) "
			+ "VALUES (?,?,?)";

	private static final String insertStatementToPRTLinkage = "INSERT INTO PRT_Linkage "
			+ "(FK_PRT_Data_Id, SlipType, Mode, Counter, Status, TemplateName, Version) " + "VALUES (?,?,?,?,?,?,?)";

	private static final String selectLatestVersionStatementTest = "SELECT MAX(Version) FROM PRT_TemplateInfo WHERE TemplateName=? AND Language=?";

	@Transactional(Transactional.TxType.REQUIRED)
	public void updatePrintingData(Exchange exchange) throws Exception {
		IPrintingExtension printingExtension = (IPrintingExtension) exchange.getContext().getRegistry().lookupByName("printingExtension");
		if (printingExtension != null) {
			printingExtension.addExtraPrintingInformation(exchange);
		}
	}

	@Transactional(Transactional.TxType.REQUIRED)
	public void updatePrintingDataBRMS(@Body Document body,
									   @ExchangeProperty(value = CBSConstants.HEADER_TRANSACTION_NAME) String operation,
									   @ExchangeProperty(value = "printingMap") Map<String, Object> printingMap, Exchange exchange)
			throws Exception {
		if (exchange.getContext().getRegistry().lookupByName("BRMSPrintingExtensionProcessor") != null)
			((Processor) exchange.getContext().getRegistry().lookupByName("BRMSPrintingExtensionProcessor"))
					.process(exchange);

	}

	private boolean operationIsRunFromBatch (Map<String, Object> properties) {
		NodeList loanTransactionOriginIndicatorNL = (NodeList) properties.get("LoanTransactionOriginIndicator");
		String loanTransactionOriginIndicator = null;

		if (loanTransactionOriginIndicatorNL != null) {
			loanTransactionOriginIndicator = loanTransactionOriginIndicatorNL.item(0).getTextContent();
		}

		return ((loanTransactionOriginIndicator != null) && (Integer.parseInt(loanTransactionOriginIndicator) != TransactionOrigin.Online.getValue()));
	}

	private boolean printingOverrideFlagIsSet(Map<String, Object> properties) {
		Object printingOverrideFlagObject = properties.get("printingOverrideFlag");
		if (printingOverrideFlagObject == null) {
			return false;
		}
		boolean printingOverrideFlag = false;
		if (printingOverrideFlagObject instanceof String) {
			printingOverrideFlag = "true".equals((String) printingOverrideFlagObject);
		} else if (printingOverrideFlagObject instanceof Boolean) {
			printingOverrideFlag = (Boolean) printingOverrideFlagObject;
		} else {
			LOGGER.warn("Printing override flag is set, but is neither a String nor a Boolean. Ignoring.");
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("printingOverrideFlag:" + printingOverrideFlag);
		}
		return printingOverrideFlag;
	}

	@SuppressWarnings("unchecked")
	@Transactional(Transactional.TxType.REQUIRED)
	public void createPrintingRecord(@ExchangeProperties Map<String, Object> properties) throws Exception {

		// This is for reverting operations initially run from batch so that they don't print.
		// Additionally short-circuit the printing facility when the printingOverrideFlag is
		// set on the route properties. This is used (for example) when the AsIs code for SIGLO
		// is short circuiting printing not on a per-operation, but on a condition that depends
		// on input data. One example of this is the LoanAccountingJournalDebitReversalExecution
		// operation, which does not print when the LoanOperationCode (an input value) has a
		// specific value.
		if (operationIsRunFromBatch(properties) || printingOverrideFlagIsSet(properties)) {
			return;
		}

		List<String> templateList = (List<String>) properties.get(CBSConstants.HEADER_PRINTING_TEMPLATE_CODE);
		List<String> slipTypeList = (List<String>) properties.get(CBSConstants.HEADER_PRINTING_SLIP_TYPE);
		List<String> statusList = (List<String>) properties.get(CBSConstants.HEADER_PRINTING_STATUS);
		List<String> modeList = (List<String>) properties.get(CBSConstants.HEADER_PRINTING_MODE);
		String language = (String) properties.get(CBSConstants.HEADER_LANGUAGE);
		if(StringUtils.isEmpty(language)){
			language = "el";
			LOGGER.warn("Language is not specified for operation:"+ (String) properties.get(CBSConstants.HEADER_TRANSACTION_NAME));
		}
		Map<String, Object> printingMap = (Map<String, Object>) properties.get("printingMap");
		String BUN = (String) properties.get(CBSConstants.HEADER_BUN);
		int genKey = writeToPRTDataTable(BUN, printingMap, language);
		for (int i = 0; i < slipTypeList.size(); i++) {
			String templateName = templateList.get(i);
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("getLatestTemplateVersion templateName:" + templateName + ",language:" + language);
			}
			int templateVersion = getLatestTemplateVersion(templateName, language);
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("templateVersion:" + templateVersion);
			}

			writeToPRTLinkageTable(genKey, slipTypeList.get(i), Integer.parseInt(modeList.get(i)), templateName, templateVersion, statusList.get(i));

			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("writeToDatabase");
			}
		}
	}

	@SuppressWarnings("rawtypes")
	private String generateXMLFromData(Map<String, Object> printingMap) {
		LocalDateTime ldt = LocalDateTime.now(ZoneId.of(ConfigProvider.getConfig().getOptionalValue("cbs.time.zone", String.class).orElse("Europe/Athens")));
		LOGGER.debug("Start generating XML record!!");
		StringBuilder sb = new StringBuilder();
		sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		sb.append("<").append(printingMap.get("Tdata_transaction")).append(">");
		sb.append("<LanguageIndicator>1</LanguageIndicator>");
		sb.append("<Time>").append(ldt.format(DateTimeFormatter.ofPattern("HH:mm:ss"))).append("</Time>");
		printingMap.entrySet().stream().filter(mapping -> mapping.getKey().substring(1).startsWith("data_"))
				.forEach(mapping -> processMapping(sb, mapping));
		sb.append("</").append(printingMap.get("Tdata_transaction")).append(">");
		if (LOGGER.isTraceEnabled()) {
			LOGGER.trace("Printing xml: " + sb.toString());
		}
		return sb.toString();
	}

	private void processMapping(StringBuilder sb, Entry<String, Object> mapping)
			throws TransformerFactoryConfigurationError {
		String key = mapping.getKey().substring(6);
		if (mapping.getValue() instanceof String) {
			processStringValue(sb, mapping, key);
		} else if (mapping.getValue() instanceof ArrayList) {
			processArrayListValue(sb, mapping, key);
		} else if (mapping.getValue() instanceof Element) {
			processElementValue(sb, mapping, key);
		} else if (mapping.getValue() instanceof NodeList) {
			processNodeListValue(sb, mapping, key);
		} else {
			throw new IllegalArgumentException(
					"Expecting either String or NodeList or Element or ArrayList<String> from horizontal properties for " + key + ".");
		}
	}

	private void processNodeListValue(StringBuilder sb, Entry<String, Object> mapping, String key)
			throws TransformerFactoryConfigurationError {
		String nodeString2;
		LOGGER.debug("Value of : " + key + " is instance of NodeList");
		NodeList nodeList = (NodeList) mapping.getValue();
		LOGGER.debug("Value of NodeList is: " + mapping.getValue() + " has length : "
				+ nodeList.getLength());
		if (nodeList.getLength() >= 1) {

			/**
			 * In case that the parentNode of the processing
			 * nodeList is of type Document, then the key will
			 * be used in order to construct the eSlip element.
			 * With this way we prevent the append of the non
			 * xml element <#document> in our eSlip
			 */
			if (nodeList.item(0).getParentNode() instanceof Document) {
				sb.append("<" + key + ">");
			} else {
				nodeString2 = ((Element) nodeList.item(0).getParentNode()).getLocalName();
				sb.append("<" + nodeString2 + ">");
			}
		}
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node node = nodeList.item(i);
			try {
				if (node instanceof Element) {
					Element element = (Element) node;
					node = removeNamespaces(element);
				} else {
					removeNameSpace(node, null);
				}
				String nodeString = FormatUtils.nodeToString(node, FormatUtils.OMIT_XML_DECLARATION_YES,
						FormatUtils.INDENT_NO);
				sb.append(nodeString);
			} catch (Exception e) {
				throw new IllegalArgumentException("Unable to serialize node to string", e);
			}
		}
		if (nodeList.getLength() >= 1) {
			if (nodeList.item(0).getParentNode() instanceof Document) {
				sb.append("</" + key + ">");
			} else {
				nodeString2 = ((Element) nodeList.item(0).getParentNode()).getLocalName();
				sb.append("</" + nodeString2 + ">");
			}
		}
	}

	private void processElementValue(StringBuilder sb, Entry<String, Object> mapping, String key)
			throws TransformerFactoryConfigurationError {
		LOGGER.debug("Value of : " + key + " is instance of Element");
		Element element = (Element) mapping.getValue();
		try {
			element = removeNamespaces(element);
			String nodeString = FormatUtils.nodeToString(element, FormatUtils.OMIT_XML_DECLARATION_YES,
					FormatUtils.INDENT_NO);
			sb.append(nodeString);
		} catch (Exception e) {
			throw new IllegalArgumentException("Unable to serialize node to string", e);
		}
	}

	private void processArrayListValue(StringBuilder sb, Entry<String, Object> mapping, String key) {
		LOGGER.debug("Value of : " + key + " is instance of ArrayList");
		if (key.equals("Date")) {
			sb.append("<").append(key).append("List>");
			for (Object element : ((ArrayList) mapping.getValue())) {
				if (!(element instanceof String)) {
					throw new IllegalArgumentException(
							"Expecting Strings as elements in the ArrayList from horizontal properties.");
				}
				sb.append("<").append(key).append("Struct>");
				sb.append("<").append(key).append(">")
						.append(((String) element).replace('.', '/')).append("</").append(key)
						.append(">");
				sb.append("</").append(key).append("Struct>");
			}
			sb.append("</").append(key).append("List>");

		} else {
			sb.append("<").append(key).append("List>");
			for (Object element : ((ArrayList) mapping.getValue())) {
				if (!(element instanceof String)) {
					throw new IllegalArgumentException(
							"Expecting Strings as elements in the ArrayList from horizontal properties.");
				}
				sb.append("<").append(key).append("Struct>");
				sb.append("<").append(key).append(">")
						.append(StringEscapeUtils.escapeXml10((String) element)).append("</")
						.append(key).append(">");
				sb.append("</").append(key).append("Struct>");
			}
			sb.append("</").append(key).append("List>");
		}
	}

	private void processStringValue(StringBuilder sb, Entry<String, Object> mapping, String key) {
		LOGGER.debug("Value of : " + key + " is instance of String");
		if (key.equals("Date")) {
			sb.append("<").append(key).append(">")
					.append(((String) mapping.getValue()).replace('.', '/')).append("</").append(key)
					.append(">");
		} else {
			sb.append("<").append(key).append(">")
					.append(StringEscapeUtils.escapeXml10((String) mapping.getValue())).append("</")
					.append(key).append(">");
		}
	}

	private void removeNameSpace(Node node, String nameSpaceURI) {

		if (node.getNodeType() == Node.ELEMENT_NODE) {
			Document ownerDoc = node.getOwnerDocument();
			NamedNodeMap map = node.getAttributes();
			Node n;
			while (0 != map.getLength()) {
				n = map.item(0);
				map.removeNamedItemNS(n.getNamespaceURI(), n.getLocalName());
			}
			if (node.getLocalName() == null) {
				ownerDoc.renameNode(node, nameSpaceURI, node.getNodeName());
			} else {
				ownerDoc.renameNode(node, nameSpaceURI, node.getLocalName());
			}
		}
		NodeList list = node.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			removeNameSpace(list.item(i), nameSpaceURI);
		}
	}

	private Element removeNamespaces(Element element) throws ParserConfigurationException {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(false);
		DocumentBuilder builder = dbf.newDocumentBuilder();
		Document document = builder.newDocument();

		String name = element.getLocalName();
		if (name == null) {
			name = element.getNodeName();
		}
		Element rootElement = document.createElement(name);
		document.appendChild(rootElement);

		NodeList list = element.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			Node child = list.item(i);
			if (child instanceof Element) {
				rootElement.appendChild(removeNamespacesFromChildren(document, (Element) child));
			} else {
				rootElement.appendChild(document.importNode(child, true));
			}
		}

		return document.getDocumentElement();
	}

	private Element removeNamespacesFromChildren(Document newDocument, Element element) {
		String name = element.getLocalName();
		if (name == null) {
			name = element.getNodeName();
		}
		Element newElement = newDocument.createElement(name);

		NodeList list = element.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			Node child = list.item(i);
			if (child instanceof Element) {
				newElement.appendChild(removeNamespacesFromChildren(newDocument, (Element) child));
			} else {
				newElement.appendChild(newDocument.importNode(child, false));
			}
		}

		return newElement;
	}

	private int writeToPRTDataTable(String BUN, Map<String, Object> printingMap, String language) throws Exception {

		try (Connection conn = sqlDS.getConnection();
			 PreparedStatement stmt1 = conn.prepareStatement(insertStatementToPRTDataTable,
					 Statement.RETURN_GENERATED_KEYS);) {

			stmt1.setString(1, BUN);
			stmt1.setString(2, generateXMLFromData(printingMap));
			stmt1.setString(3, language);

			stmt1.execute();
			try (ResultSet rs = stmt1.getGeneratedKeys()) {
				if (!rs.next()) {
					throw new IllegalStateException("No rows affected from insert statement.");
				}
				return rs.getInt(1);
			}

		} catch (Exception e) {
			LOGGER.error("Exception on Writing Printing Data", e);
			throw e;
		}

	}

	private void writeToPRTLinkageTable(int foreignKey, String slipType, int mode, String templateName, int templateVersion, String status) throws Exception {
		try (Connection conn = sqlDS.getConnection();
			 PreparedStatement stmt = conn.prepareStatement(insertStatementToPRTLinkage);) {
			stmt.setInt(1, foreignKey);
			stmt.setString(2, slipType);
			stmt.setInt(3, mode);
			stmt.setInt(4, 1);
			stmt.setString(5, status);
			stmt.setString(6, templateName);
			stmt.setInt(7, templateVersion);
			stmt.execute();
		} catch (Exception e) {
			LOGGER.error("Exception on Writing Printing Data", e);
			throw e;
		}

	}

	private int getLatestTemplateVersion(String templateName, String language) throws Exception {
		try (Connection conn = sqlDS.getConnection();
			 PreparedStatement stmt = conn.prepareStatement(selectLatestVersionStatementTest);) {
			stmt.setString(1, templateName);
			stmt.setString(2, language);
			try (ResultSet rs = stmt.executeQuery();) {
				if (rs.next()) {//selectLatestVersionStatementTest query always returns results
					if(rs.getString(1) == null){
						LOGGER.warn("No rows returned while querying for the latest version of template:[" + templateName
								+ "] for language:[" + language + "]");
					}
				}
				return rs.getInt(1);
			}
		} catch (Exception e) {
			LOGGER.error("Exception on querying latest template version", e);
			throw e;
		}
	}

}
