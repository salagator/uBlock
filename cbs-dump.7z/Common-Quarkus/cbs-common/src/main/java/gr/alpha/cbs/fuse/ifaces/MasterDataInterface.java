package gr.alpha.cbs.fuse.ifaces;

import java.util.HashMap;

public interface MasterDataInterface {
	
	String getMasterDetailsXML( String masterName) throws Exception;
	
	HashMap<String, String> getMasterDetailsByItemNameLists (String masterName, String itemName) throws Exception;
	
	HashMap<String, HashMap<String,String>> getMasterDetailsLists (String masterName) throws Exception;
	
	String getMasterDataDetailsByItemAndAttributeName (String masterName, String itemName, String attributeName) throws Exception;

}
