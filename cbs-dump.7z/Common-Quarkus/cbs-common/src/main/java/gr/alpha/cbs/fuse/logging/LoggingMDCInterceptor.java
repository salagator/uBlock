package gr.alpha.cbs.fuse.logging;

import io.quarkus.runtime.annotations.RegisterForReflection;

import jakarta.enterprise.context.ApplicationScoped;
import javax.xml.transform.dom.DOMSource;

@ApplicationScoped
@RegisterForReflection
public  class LoggingMDCInterceptor extends AbstractMDCHelper {
    public void processMessageOut() {
        clearMDCContext();
    }

    public void processMessageIn(DOMSource input) {
        synchronized (this) {
            setupXPaths();
        }

        setupMDCContext(input);
    }

}
