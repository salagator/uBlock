package gr.alpha.cbs.fuse.service;

import io.quarkus.runtime.annotations.RegisterForReflection;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@RegisterForReflection
public class DateConverter {
    private static DateTimeFormatter dateFormatter = DateTimeFormatter.ISO_LOCAL_DATE;
    private static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    public static LocalDate parseDate(String s) {
        return LocalDate.parse(s, dateFormatter);
    }

    public static String printDate(LocalDate d) {
        return dateFormatter.format(d);
    }

    public static LocalDateTime parseDateTime(String s) {
        return LocalDateTime.parse(s, dateTimeFormatter);
    }

    public static String printDateTime(LocalDateTime dt) {
        return dateTimeFormatter.format(dt);
    }
}
