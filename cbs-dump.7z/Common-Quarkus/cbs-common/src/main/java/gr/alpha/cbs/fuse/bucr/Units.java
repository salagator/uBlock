package gr.alpha.cbs.fuse.bucr;

import java.util.List;

public class Units {
	
	private List<Unit> units;

	public List<Unit> getUnits() {
		return units;
	}

	public void setUnits(List<Unit> units) {
		this.units = units;
	}
	
	

}
