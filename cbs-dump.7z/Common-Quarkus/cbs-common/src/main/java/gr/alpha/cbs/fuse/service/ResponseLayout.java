package gr.alpha.cbs.fuse.service;

public enum ResponseLayout {


    /** This Enum is used for the response of AbstractCamelRouteDrivingProvider
     *
     * 1. KEEP_UNCHANGED is used to keep the xml at the end of the route unchanged
     * ex. -> <root><payload>payload</payload></root>
     *
     * 2. WRAP is used to wrap the xml at the end of the route with an element of the
     * operation name.
     * ex. -> if <payload>payload</payload> the xml at the end of route
     *	     then the produced is <operation><payload>payload</payload></operation>
     *
     * 3. WRAP_UNWRAP is used to remove the root Element of the xml at the end of the route
     * 	  and Wrap it again with an element of the  operation name.
     * ex. -> if    <root><payload>payload</payload></root>
     *        then  <operation><payload>payload</payload></operation>
     * */

    KEEP_UNCHANGED, WRAP, WRAP_UNWRAP



}
