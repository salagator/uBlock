package gr.alpha.cbs.fuse.support;

public interface ProcessorLifecycle {

	void doStop();

}
