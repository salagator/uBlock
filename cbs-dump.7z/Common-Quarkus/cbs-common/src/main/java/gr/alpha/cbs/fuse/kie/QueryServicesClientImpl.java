//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

import jakarta.ws.rs.core.Response;
import org.apache.commons.validator.Var;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QueryServicesClientImpl extends AbstractKieServicesClientImpl implements QueryServicesClient {
    public QueryServicesClientImpl(KieServicesConfiguration config) {
        super(config);
    }

    public QueryServicesClientImpl(KieServicesConfiguration config, ClassLoader classLoader) {
        super(config, classLoader);
    }

    /*
    public List<ProcessDefinition> findProcessesById(String processId) {
        ProcessDefinitionList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("processId", processId);
            result = (ProcessDefinitionList)this.makeHttpGetRequestAndCreateCustomResponseWithHandleNotFound(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/definitions/{processId}", valuesMap), ProcessDefinitionList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessesById", new Object[]{processId})));
            ServiceResponse<ProcessDefinitionList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessDefinitionList)response.getResult();
        }

        return result != null && result.getProcesses() != null ? Arrays.asList(result.getProcesses()) : Collections.emptyList();
    }

    public List<ProcessDefinition> findProcesses(Integer page, Integer pageSize) {
        return this.findProcesses(page, pageSize, "", true);
    }

    public List<ProcessDefinition> findProcesses(String filter, Integer page, Integer pageSize) {
        return this.findProcesses(filter, page, pageSize, "", true);
    }

    public List<ProcessDefinition> findProcessesByContainerId(String containerId, Integer page, Integer pageSize) {
        return this.findProcessesByContainerId(containerId, page, pageSize, "", true);
    }

    public ProcessDefinition findProcessByContainerIdProcessId(String containerId, String processId) {
        ProcessDefinition result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("containerId", containerId);
            valuesMap.put("processId", processId);
            result = (ProcessDefinition)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/containers/{containerId}/processes/definitions/{processId}", valuesMap), ProcessDefinition.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessesByDeploymentIdProcessId", new Object[]{containerId, processId})));
            ServiceResponse<ProcessDefinition> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessDefinition)response.getResult();
        }

        return result;
    }

    public List<ProcessDefinition> findProcesses(Integer page, Integer pageSize, String sort, boolean sortOrder) {
        ProcessDefinitionList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            String queryString = this.getPagingQueryString("?sort=" + sort + "&sortOrder=" + sortOrder, page, pageSize);
            result = (ProcessDefinitionList)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/definitions", valuesMap) + queryString, ProcessDefinitionList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessesByFilter", new Object[]{"", page, pageSize, sort, sortOrder})));
            ServiceResponse<ProcessDefinitionList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessDefinitionList)response.getResult();
        }

        return result != null && result.getProcesses() != null ? Arrays.asList(result.getProcesses()) : Collections.emptyList();
    }

    public List<ProcessDefinition> findProcesses(String filter, Integer page, Integer pageSize, String sort, boolean sortOrder) {
        ProcessDefinitionList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            String queryString = this.getPagingQueryString("?filter=" + filter + "&sort=" + sort + "&sortOrder=" + sortOrder, page, pageSize);
            result = (ProcessDefinitionList)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/definitions", valuesMap) + queryString, ProcessDefinitionList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessesByFilter", new Object[]{filter, page, pageSize, sort, sortOrder})));
            ServiceResponse<ProcessDefinitionList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessDefinitionList)response.getResult();
        }

        return result != null && result.getProcesses() != null ? Arrays.asList(result.getProcesses()) : Collections.emptyList();
    }

    public List<ProcessDefinition> findProcessesByContainerId(String containerId, Integer page, Integer pageSize, String sort, boolean sortOrder) {
        ProcessDefinitionList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("containerId", containerId);
            String queryString = this.getPagingQueryString("?sort=" + sort + "&sortOrder=" + sortOrder, page, pageSize);
            result = (ProcessDefinitionList)this.makeHttpGetRequestAndCreateCustomResponseWithHandleNotFound(RestURI.build(this.loadBalancer.getUrl(), "queries/containers/{containerId}/processes/definitions", valuesMap) + queryString, ProcessDefinitionList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessesByDeploymentId", new Object[]{containerId, page, pageSize, sort, sortOrder})));
            ServiceResponse<ProcessDefinitionList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessDefinitionList)response.getResult();
        }

        return result != null && result.getProcesses() != null ? Arrays.asList(result.getProcesses()) : Collections.emptyList();
    }

    public List<ProcessInstance> findProcessInstances(Integer page, Integer pageSize) {
        return this.findProcessInstances(page, pageSize, "", true);
    }

    public List<ProcessInstance> findProcessInstancesByCorrelationKey(CorrelationKey correlationKey, Integer page, Integer pageSize) {
        return this.findProcessInstancesByCorrelationKey(correlationKey, page, pageSize, "", true);
    }

    public List<ProcessInstance> findProcessInstancesByProcessId(String processId, List<Integer> status, Integer page, Integer pageSize) {
        return this.findProcessInstancesByProcessId(processId, status, page, pageSize, "", true);
    }

    public List<ProcessInstance> findProcessInstancesByProcessIdAndInitiator(String processId, String initiator, List<Integer> status, Integer page, Integer pageSize) {
        return this.findProcessInstancesByProcessIdAndInitiator(processId, initiator, status, page, pageSize, "", true);
    }

    public List<ProcessInstance> findProcessInstancesByProcessName(String processName, List<Integer> status, Integer page, Integer pageSize) {
        return this.findProcessInstancesByProcessName(processName, status, page, pageSize, "", true);
    }

    public List<ProcessInstance> findProcessInstancesByContainerId(String containerId, List<Integer> status, Integer page, Integer pageSize) {
        return this.findProcessInstancesByContainerId(containerId, status, page, pageSize, "", true);
    }

    public List<ProcessInstance> findProcessInstancesByStatus(List<Integer> status, Integer page, Integer pageSize) {
        return this.findProcessInstancesByStatus(status, page, pageSize, "", true);
    }

    public List<ProcessInstance> findProcessInstancesByInitiator(String initiator, List<Integer> status, Integer page, Integer pageSize) {
        return this.findProcessInstancesByInitiator(initiator, status, page, pageSize, "", true);
    }

    public List<ProcessInstance> findProcessInstancesByVariable(String variableName, List<Integer> status, Integer page, Integer pageSize) {
        return this.findProcessInstancesByVariable(variableName, status, page, pageSize, "", true);
    }

    public List<ProcessInstance> findProcessInstancesByVariableAndValue(String variableName, String variableValue, List<Integer> status, Integer page, Integer pageSize) {
        return this.findProcessInstancesByVariableAndValue(variableName, variableValue, status, page, pageSize, "", true);
    }

    public List<ProcessInstance> findProcessInstances(Integer page, Integer pageSize, String sort, boolean sortOrder) {
        ProcessInstanceList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            String queryString = this.getPagingQueryString("?sort=" + sort + "&sortOrder=" + sortOrder, page, pageSize);
            result = (ProcessInstanceList)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/instances", valuesMap) + queryString, ProcessInstanceList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessInstances", new Object[]{new ArrayList(), "", "", page, pageSize, sort, sortOrder})));
            ServiceResponse<ProcessInstanceList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessInstanceList)response.getResult();
        }

        return result != null && result.getProcessInstances() != null ? Arrays.asList(result.getProcessInstances()) : Collections.emptyList();
    }

    public List<ProcessInstance> findProcessInstancesByCorrelationKey(CorrelationKey correlationKey, Integer page, Integer pageSize, String sort, boolean sortOrder) {
        ProcessInstanceList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("correlationKey", correlationKey.toExternalForm());
            String queryString = this.getPagingQueryString("?sort=" + sort + "&sortOrder=" + sortOrder, page, pageSize);
            result = (ProcessInstanceList)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/instances/correlation/{correlationKey}", valuesMap) + queryString, ProcessInstanceList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessInstancesByCorrelationKey", new Object[]{correlationKey.toExternalForm(), page, pageSize, sort, sortOrder})));
            ServiceResponse<ProcessInstanceList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessInstanceList)response.getResult();
        }

        return result != null && result.getProcessInstances() != null ? Arrays.asList(result.getProcessInstances()) : Collections.emptyList();
    }

    public List<ProcessInstance> findProcessInstancesByProcessId(String processId, List<Integer> status, Integer page, Integer pageSize, String sort, boolean sortOrder) {
        ProcessInstanceList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("processId", processId);
            String statusQueryString = this.getAdditionalParams("?sort=" + sort + "&sortOrder=" + sortOrder, "status", status);
            String queryString = this.getPagingQueryString(statusQueryString, page, pageSize);
            result = (ProcessInstanceList)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/{processId}/instances", valuesMap) + queryString, ProcessInstanceList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessInstancesByProcessId", new Object[]{processId, this.safeList(status), "", page, pageSize, sort, sortOrder})));
            ServiceResponse<ProcessInstanceList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessInstanceList)response.getResult();
        }

        return result != null && result.getProcessInstances() != null ? Arrays.asList(result.getProcessInstances()) : Collections.emptyList();
    }

    public List<ProcessInstance> findProcessInstancesByProcessIdAndInitiator(String processId, String initiator, List<Integer> status, Integer page, Integer pageSize, String sort, boolean sortOrder) {
        ProcessInstanceList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("processId", processId);
            String statusQueryString = this.getAdditionalParams("?initiator=" + initiator + "&sort=" + sort + "&sortOrder=" + sortOrder, "status", status);
            String queryString = this.getPagingQueryString(statusQueryString, page, pageSize);
            result = (ProcessInstanceList)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/{processId}/instances", valuesMap) + queryString, ProcessInstanceList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessInstancesByProcessId", new Object[]{processId, this.safeList(status), initiator, page, pageSize, sort, sortOrder})));
            ServiceResponse<ProcessInstanceList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessInstanceList)response.getResult();
        }

        return result != null && result.getProcessInstances() != null ? Arrays.asList(result.getProcessInstances()) : Collections.emptyList();
    }

    public List<ProcessInstance> findProcessInstancesByProcessName(String processName, List<Integer> status, Integer page, Integer pageSize, String sort, boolean sortOrder) {
        ProcessInstanceList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            String statusQueryString = this.getAdditionalParams("?processName=" + processName + "&sort=" + sort + "&sortOrder=" + sortOrder, "status", status);
            String queryString = this.getPagingQueryString(statusQueryString, page, pageSize);
            result = (ProcessInstanceList)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/instances", valuesMap) + queryString, ProcessInstanceList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessInstances", new Object[]{this.safeList(status), "", processName, page, pageSize, sort, sortOrder})));
            ServiceResponse<ProcessInstanceList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessInstanceList)response.getResult();
        }

        return result != null && result.getProcessInstances() != null ? Arrays.asList(result.getProcessInstances()) : Collections.emptyList();
    }

    public List<ProcessInstance> findProcessInstancesByContainerId(String containerId, List<Integer> status, Integer page, Integer pageSize, String sort, boolean sortOrder) {
        ProcessInstanceList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("containerId", containerId);
            String statusQueryString = this.getAdditionalParams("?sort=" + sort + "&sortOrder=" + sortOrder, "status", status);
            String queryString = this.getPagingQueryString(statusQueryString, page, pageSize);
            result = (ProcessInstanceList)this.makeHttpGetRequestAndCreateCustomResponseWithHandleNotFound(RestURI.build(this.loadBalancer.getUrl(), "queries/containers/{containerId}/process/instances", valuesMap) + queryString, ProcessInstanceList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessInstancesByDeploymentId", new Object[]{containerId, this.safeList(status), page, pageSize, sort, sortOrder})));
            ServiceResponse<ProcessInstanceList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessInstanceList)response.getResult();
        }

        return result != null && result.getProcessInstances() != null ? Arrays.asList(result.getProcessInstances()) : Collections.emptyList();
    }

    public Long countProcessInstancesByContainerId(String containerId, List<Integer> status) {
        CountDefinition result;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("containerId", containerId);
            String queryString = this.getAdditionalParams("", "status", status);
            result = (CountDefinition)this.makeHttpGetRequestAndCreateCustomResponseWithHandleNotFound(RestURI.build(this.loadBalancer.getUrl(), "queries/containers/{containerId}/process/instances/count", valuesMap) + queryString, CountDefinition.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "countProcessInstancesByDeploymentId", new Object[]{containerId, this.safeList(status)})));
            ServiceResponse<CountDefinition> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (CountDefinition)response.getResult();
        }

        return result != null ? result.getCount() : null;
    }

    public List<ProcessInstance> findProcessInstancesByStatus(List<Integer> status, Integer page, Integer pageSize, String sort, boolean sortOrder) {
        ProcessInstanceList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            String statusQueryString = this.getAdditionalParams("?sort=" + sort + "&sortOrder=" + sortOrder, "status", status);
            String queryString = this.getPagingQueryString(statusQueryString, page, pageSize);
            result = (ProcessInstanceList)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/instances", valuesMap) + queryString, ProcessInstanceList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessInstances", new Object[]{this.safeList(status), "", "", page, pageSize, sort, sortOrder})));
            ServiceResponse<ProcessInstanceList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessInstanceList)response.getResult();
        }

        return result != null && result.getProcessInstances() != null ? Arrays.asList(result.getProcessInstances()) : Collections.emptyList();
    }

    public List<ProcessInstance> findProcessInstancesByInitiator(String initiator, List<Integer> status, Integer page, Integer pageSize, String sort, boolean sortOrder) {
        ProcessInstanceList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            String statusQueryString = this.getAdditionalParams("?initiator=" + initiator + "&sort=" + sort + "&sortOrder=" + sortOrder, "status", status);
            String queryString = this.getPagingQueryString(statusQueryString, page, pageSize);
            result = (ProcessInstanceList)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/instances", valuesMap) + queryString, ProcessInstanceList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessInstances", new Object[]{this.safeList(status), initiator, "", page, pageSize, sort, sortOrder})));
            ServiceResponse<ProcessInstanceList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessInstanceList)response.getResult();
        }

        return result != null && result.getProcessInstances() != null ? Arrays.asList(result.getProcessInstances()) : Collections.emptyList();
    }

    public List<ProcessInstance> findProcessInstancesByVariable(String variableName, List<Integer> status, Integer page, Integer pageSize, String sort, boolean sortOrder) {
        ProcessInstanceList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("varName", variableName);
            String statusQueryString = this.getAdditionalParams("?sort=" + sort + "&sortOrder=" + sortOrder, "status", status);
            String queryString = this.getPagingQueryString(statusQueryString, page, pageSize);
            result = (ProcessInstanceList)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/instances/variables/{varName}", valuesMap) + queryString, ProcessInstanceList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessInstanceByVariables", new Object[]{variableName, "", this.safeList(status), page, pageSize, sort, sortOrder})));
            ServiceResponse<ProcessInstanceList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessInstanceList)response.getResult();
        }

        return result != null && result.getProcessInstances() != null ? Arrays.asList(result.getProcessInstances()) : Collections.emptyList();
    }

    public List<ProcessInstance> findProcessInstancesByVariableAndValue(String variableName, String variableValue, List<Integer> status, Integer page, Integer pageSize, String sort, boolean sortOrder) {
        ProcessInstanceList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("varName", variableName);
            String statusQueryString = this.getAdditionalParams("?varValue=" + variableValue + "&sort=" + sort + "&sortOrder=" + sortOrder, "status", status);
            String queryString = this.getPagingQueryString(statusQueryString, page, pageSize);
            result = (ProcessInstanceList)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/instances/variables/{varName}", valuesMap) + queryString, ProcessInstanceList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessInstanceByVariables", new Object[]{variableName, variableValue, this.safeList(status), page, pageSize, sort, sortOrder})));
            ServiceResponse<ProcessInstanceList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessInstanceList)response.getResult();
        }

        return result != null && result.getProcessInstances() != null ? Arrays.asList(result.getProcessInstances()) : Collections.emptyList();
    }

    public ProcessInstance findProcessInstanceById(Long processInstanceId) {
        ProcessInstance result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("processInstanceId", processInstanceId);
            result = (ProcessInstance)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/instances/{processInstanceId}", valuesMap), ProcessInstance.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessInstanceById", new Object[]{processInstanceId})));
            ServiceResponse<ProcessInstance> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessInstance)response.getResult();
        }

        return result;
    }

    public ProcessInstance findProcessInstanceById(Long processInstanceId, boolean withVars) {
        ProcessInstance result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("processInstanceId", processInstanceId);
            result = (ProcessInstance)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/instances/{processInstanceId}", valuesMap) + "?withVars=" + withVars, ProcessInstance.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessInstanceById", new Object[]{processInstanceId, withVars})));
            ServiceResponse<ProcessInstance> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessInstance)response.getResult();
        }

        return result;
    }

    public ProcessInstance findProcessInstanceByCorrelationKey(CorrelationKey correlationKey) {
        ProcessInstance result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("correlationKey", correlationKey.toExternalForm());
            result = (ProcessInstance)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/instance/correlation/{correlationKey}", valuesMap), ProcessInstance.class);
            return result;
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessInstanceByCorrelationKey", new Object[]{correlationKey.toExternalForm()})));
            ServiceResponse<ProcessInstance> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            return this.shouldReturnWithNullResponse(response) ? null : (ProcessInstance)response.getResult();
        }
    }

    public NodeInstance findNodeInstanceByWorkItemId(Long processInstanceId, Long workItemId) {
        NodeInstance result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("processInstanceId", processInstanceId);
            valuesMap.put("workItemId", workItemId);
            result = (NodeInstance)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/instances/{processInstanceId}/wi-nodes/instances/{workItemId}", valuesMap), NodeInstance.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getNodeInstanceForWorkItem", new Object[]{processInstanceId, workItemId})));
            ServiceResponse<NodeInstance> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (NodeInstance)response.getResult();
        }

        return result;
    }

    public List<NodeInstance> findActiveNodeInstances(Long processInstanceId, Integer page, Integer pageSize) {
        NodeInstanceList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("processInstanceId", processInstanceId);
            String queryString = this.getPagingQueryString("?activeOnly=true", page, pageSize);
            result = (NodeInstanceList)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/instances/{processInstanceId}/nodes/instances", valuesMap) + queryString, NodeInstanceList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessInstanceHistory", new Object[]{processInstanceId, true, false, page, pageSize})));
            ServiceResponse<NodeInstanceList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (NodeInstanceList)response.getResult();
        }

        return result != null && result.getNodeInstances() != null ? Arrays.asList(result.getNodeInstances()) : Collections.emptyList();
    }

    public List<NodeInstance> findCompletedNodeInstances(Long processInstanceId, Integer page, Integer pageSize) {
        NodeInstanceList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("processInstanceId", processInstanceId);
            String queryString = this.getPagingQueryString("?completedOnly=true", page, pageSize);
            result = (NodeInstanceList)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/instances/{processInstanceId}/nodes/instances", valuesMap) + queryString, NodeInstanceList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessInstanceHistory", new Object[]{processInstanceId, false, true, page, pageSize})));
            ServiceResponse<NodeInstanceList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (NodeInstanceList)response.getResult();
        }

        return result != null && result.getNodeInstances() != null ? Arrays.asList(result.getNodeInstances()) : Collections.emptyList();
    }

    public List<NodeInstance> findNodeInstances(Long processInstanceId, Integer page, Integer pageSize) {
        NodeInstanceList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("processInstanceId", processInstanceId);
            String queryString = this.getPagingQueryString("", page, pageSize);
            result = (NodeInstanceList)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/instances/{processInstanceId}/nodes/instances", valuesMap) + queryString, NodeInstanceList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getProcessInstanceHistory", new Object[]{processInstanceId, true, true, page, pageSize})));
            ServiceResponse<NodeInstanceList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (NodeInstanceList)response.getResult();
        }

        return result != null && result.getNodeInstances() != null ? Arrays.asList(result.getNodeInstances()) : Collections.emptyList();
    }
    */

    private static final Logger logger = LoggerFactory.getLogger(QueryServicesClientImpl.class);

    private String modifiedMakeHttpGetRequestAndCreateCustomResponse(String uri) {
        KieServerHttpRequest request = this.invoke(uri, new RemoteHttpOperation() {
            public KieServerHttpRequest doOperation(String url) {
                logger.debug("About to send GET request to '{}'", url);
                return newRequest(url).get();
            }
        });
        KieServerHttpResponse response = request.response();
        this.owner.setConversationId(response.header("X-KIE-ConversationId"));
        if (response.code() == Response.Status.OK.getStatusCode()) {
            return response.body();
        } else {
            throw this.createExceptionForUnexpectedResponseCode(request, response);
        }
    }

    public List<VariableInstance> findVariablesCurrentState(Long processInstanceId) {
        VariableInstanceList result = null;
        Map<String, Object> valuesMap = new HashMap();
        valuesMap.put("processInstanceId", processInstanceId);

        String resultAsString = this.modifiedMakeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/instances/{processInstanceId}/variables/instances", valuesMap));
        logger.debug("Received response for findVariablesCurrentState: {}", resultAsString);
        result = this.deserialize(resultAsString, VariableInstanceList.class);

        return result != null && result.getVariableInstances() != null ? Arrays.asList(result.getVariableInstances()) : Collections.emptyList();
    }

    /*
     * Used for testing purposes
    public static void main(String[] args) {
        String jsonResponse = "{  \"variable-instance\" : [ {    \"name\" : \"logBUN\",    \"old-value\" : \"\",    \"value\" : \"\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218480}  }, {    \"name\" : \"envUnitCodeLevel3\",    \"old-value\" : \"\",    \"value\" : \"sr0950\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218480}  }, {    \"name\" : \"envUnitCodeLevel2\",    \"old-value\" : \"\",    \"value\" : \"0950\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218483}  }, {    \"name\" : \"transactionPayloadSummary\",    \"old-value\" : \"\",    \"value\" : \"Î†Î½Î¿Î¹Î³Î¼Î± Î›Î¿Î³Î±Ï\u0081Î¹Î±ÏƒÎ¼Î¿Ï\u008D \",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218487}  }, {    \"name\" : \"notifyMakerForCheckerDetailView\",    \"old-value\" : \"\",    \"value\" : \"true\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218487}  }, {    \"name\" : \"makerFullName\",    \"old-value\" : \"\",    \"value\" : \"Î£Ï€Ï…Ï\u0081Î¹Î´Î¿Ï\u008DÎ»Î± Î”Î·Î¼Î·Ï„Ï\u0081Î¿ÎºÎ¬Î»Î»Î· Î’ Î¥Ï€Î¿Î³Ï\u0081Î±Ï†Î®\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218490}  }, {    \"name\" : \"logRequestId\",    \"old-value\" : \"\",    \"value\" : \"6639344b-fd5f-40cb-98bf-280cdfee7e15\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218490}  }, {    \"name\" : \"transactionPayloadDetails\",    \"old-value\" : \"\",    \"value\" : \"{\\\"transactionData\\\":[{\\\"name\\\":\\\"Î‘Ï\u0081Î¹Î¸Î¼ÏŒÏ‚ Î ÎµÎ»Î¬Ï„Î·:\\\",\\\"value\\\":\\\"0020595656\\\",\\\"status\\\":\\\"DEFAULT\\\"},{\\\"name\\\":\\\"Î•Ï€Ï‰Î½Ï…Î¼Î¯Î±/ÎŸÎ½Î¿Î¼Î±Ï„ÎµÏ€ÏŽÎ½Ï…Î¼Î¿:\\\",\\\"value\\\":\\\"Î”Î¦ÎšÎ›Î”ÎžÎ›Î“ÎžÎ¦Î”Î›Î“Î—Îš Î”ÎšÎ›Î¦Î›ÎšÎ”ÎžÎ“Î›Î£Î¦Î”Î“ÎžÎ›Î”Î¦Î“ÎžÎš\\\",\\\"status\\\":\\\"DEFAULT\\\"},{\\\"name\\\":\\\"Î Ï\u0081Î¿ÏŠÏŒÎ½ :\\\",\\\"value\\\":\\\"100013 - Alpha Î Ï\u0081Î¿Î½Î¿Î¼Î¹Î±ÎºÏŒÏ‚\\\",\\\"status\\\":\\\"CRITICAL\\\"},{\\\"name\\\":\\\"Î\u009DÏŒÎ¼Î¹ÏƒÎ¼Î± :\\\",\\\"value\\\":\\\"EUR\\\",\\\"status\\\":\\\"DEFAULT\\\"}]}\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218493}  }, {    \"name\" : \"envWorkingDate\",    \"old-value\" : \"\",    \"value\" : \"03/11/2025\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218497}  }, {    \"name\" : \"envChannelTypeCode\",    \"old-value\" : \"\",    \"value\" : \"01\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218497}  }, {    \"name\" : \"logUserId\",    \"old-value\" : \"\",    \"value\" : \"BANKTEST\\\\q30005\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218497}  }, {    \"name\" : \"envUnitCode1\",    \"old-value\" : \"\",    \"value\" : \"014\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218503}  }, {    \"name\" : \"envUnitTypeCodeLevel3\",    \"old-value\" : \"\",    \"value\" : \"06\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218503}  }, {    \"name\" : \"envPreviousWorkingDate\",    \"old-value\" : \"\",    \"value\" : \"31/10/2025\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218507}  }, {    \"name\" : \"envUnitTypeCodeLevel2\",    \"old-value\" : \"\",    \"value\" : \"02\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218507}  }, {    \"name\" : \"envResourceTypeCode\",    \"old-value\" : \"\",    \"value\" : \"01\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218510}  }, {    \"name\" : \"maker\",    \"old-value\" : \"\",    \"value\" : \"BANKTEST\\\\q30005\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218510}  }, {    \"name\" : \"envUnitTypeCode1\",    \"old-value\" : \"\",    \"value\" : \"01\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218513}  }, {    \"name\" : \"checkerGroup\",    \"old-value\" : \"\",    \"value\" : \"[{BANKTEST\\\\Q30004|FIN - Î‘ Î¥Ï€Î¿Î³Ï\u0081Î±Ï†Î®|3|Î”Î·Î¼Î·Ï„Ï\u0081Î¿ÎºÎ¬Î»Î»Î· Î‘  Î¥Ï€Î¿Î³Ï\u0081Î±Ï†Î® Î£Ï€Ï…Ï\u0081Î¹Î´Î¿Ï\u008DÎ»Î±}]\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218513}  }, {    \"name\" : \"notifyMakerForCheckerNotification\",    \"old-value\" : \"\",    \"value\" : \"true\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218517}  }, {    \"name\" : \"envValeurDate\",    \"old-value\" : \"\",    \"value\" : \"03/11/2025\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218520}  }, {    \"name\" : \"logBusinessCaseId\",    \"old-value\" : \"\",    \"value\" : \"6859e962-39ee-4382-a4c5-14e2868dcc88\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218520}  }, {    \"name\" : \"logSequenceId\",    \"old-value\" : \"\",    \"value\" : \"6\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218523}  }, {    \"name\" : \"executionTimer\",    \"old-value\" : \"\",    \"value\" : \"500\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218527}  }, {    \"name\" : \"envMachineDate\",    \"old-value\" : \"\",    \"value\" : \"03/11/2025\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218530}  }, {    \"name\" : \"logSessionId\",    \"old-value\" : \"\",    \"value\" : \"3dfd907e-2bea-44\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218530}  }, {    \"name\" : \"detailsMandatory\",    \"old-value\" : \"\",    \"value\" : \"false\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218533}  }, {    \"name\" : \"envResourceID\",    \"old-value\" : \"\",    \"value\" : \"1675\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218533}  }, {    \"name\" : \"envNextWorkingDate\",    \"old-value\" : \"\",    \"value\" : \"04/11/2025\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218537}  }, {    \"name\" : \"initiator\",    \"old-value\" : \"\",    \"value\" : \"admin\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218543}  }, {    \"name\" : \"timerToNextChecker\",    \"old-value\" : \"30\",    \"value\" : \"32s\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218573}  }, {    \"name\" : \"timerToViewDetails\",    \"old-value\" : \"999\",    \"value\" : \"1001s\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218573}  }, {    \"name\" : \"approvalRequestTime\",    \"old-value\" : \"\",    \"value\" : \"2025-11-03T14:33:38.575+0200\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218577}  }, {    \"name\" : \"selectedUser\",    \"old-value\" : \"\",    \"value\" : \"BANKTEST\\\\Q30004\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218980}  }, {    \"name\" : \"checkerFullName\",    \"old-value\" : \"\",    \"value\" : \"Î”Î·Î¼Î·Ï„Ï\u0081Î¿ÎºÎ¬Î»Î»Î· Î‘  Î¥Ï€Î¿Î³Ï\u0081Î±Ï†Î® Î£Ï€Ï…Ï\u0081Î¹Î´Î¿Ï\u008DÎ»Î±\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218983}  }, {    \"name\" : \"remainingCheckers\",    \"old-value\" : \"[{BANKTEST\\\\Q30004|FIN - Î‘ Î¥Ï€Î¿Î³Ï\u0081Î±Ï†Î®|3|Î”Î·Î¼Î·Ï„Ï\u0081Î¿ÎºÎ¬Î»Î»Î· Î‘  Î¥Ï€Î¿Î³Ï\u0081Î±Ï†Î® Î£Ï€Ï…Ï\u0081Î¹Î´Î¿Ï\u008DÎ»Î±}]\",    \"value\" : \"[]\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173218983}  }, {    \"name\" : \"skipToNextChecker\",    \"old-value\" : \"false\",    \"value\" : \"false\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173226070}  }, {    \"name\" : \"checkerThatCanSignalUs\",    \"old-value\" : \"pending\",    \"value\" : \"BANKTEST\\\\Q30004\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173228873}  }, {    \"name\" : \"checkerComments\",    \"old-value\" : \"\",    \"value\" : \"\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173230083}  }, {    \"name\" : \"notificationStatus\",    \"old-value\" : \"AUTO_APPROVED\",    \"value\" : \"AutoApproved\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173230373}  }, {    \"name\" : \"intResult\",    \"old-value\" : \"0\",    \"value\" : \"2\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173230373}  }, {    \"name\" : \"approvalDecisionTimestamp\",    \"old-value\" : \"\",    \"value\" : \"2025-11-03T12:33:50.376+0000\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173230377}  }, {    \"name\" : \"userToAcknowledge\",    \"old-value\" : \"BANKTEST\\\\q30005\",    \"value\" : \"BANKTEST\\\\q30005\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173230393}  }, {    \"name\" : \"eventTypeToAcknowledge\",    \"old-value\" : \"4\",    \"value\" : \"2\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173230393}  }, {    \"name\" : \"acknowledge_user\",    \"old-value\" : \"BANKTEST\\\\q30005\",    \"value\" : \"BANKTEST\\\\q30005\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173232080}  }, {    \"name\" : \"makerNotificationFailed\",    \"old-value\" : \"false\",    \"value\" : \"false\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173232223}  }, {    \"name\" : \"terminator\",    \"old-value\" : \"\",    \"value\" : \"unknown\",    \"process-instance-id\" : 80199546,    \"modification-date\" : {  \"java.util.Date\" : 1762173232270}  } ]}";
        KieServicesConfiguration config = new KieServicesConfigurationImpl("http://localhost:8080/kie-server/services/rest/server", "kieserver", "kieserver1!");
        config.setMarshallingFormat(MarshallingFormat.JSON);
        config.setCapabilities(List.of("BPM"));
        config.setTimeout(60 * 1000L);
//        Object resultAsObject = new QueryServicesClientImpl(config).deserialize(jsonResponse, Object.class);
//        VariableInstanceList result = (VariableInstanceList) (resultAsObject instanceof Wrapped ? ((Wrapped<?>) resultAsObject).unwrap() : resultAsObject);
        VariableInstanceList result = new QueryServicesClientImpl(config).deserialize(jsonResponse, VariableInstanceList.class);
        List<VariableInstance> variables = result != null && result.getVariableInstances() != null ? Arrays.asList(result.getVariableInstances()) : Collections.emptyList();
        for (VariableInstance var : variables) {
            System.out.println("Variable Name: " + var.getVariableName() + ", Value: " + var.getValue());
        }
    }
     */

    /*
    public List<VariableInstance> findVariableHistory(Long processInstanceId, String variableName, Integer page, Integer pageSize) {
        VariableInstanceList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("processInstanceId", processInstanceId);
            valuesMap.put("varName", variableName);
            String queryString = this.getPagingQueryString("", page, pageSize);
            result = (VariableInstanceList)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/processes/instances/{processInstanceId}/variables/instances/{varName}", valuesMap) + queryString, VariableInstanceList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryService", "getVariableHistory", new Object[]{processInstanceId, variableName, page, pageSize})));
            ServiceResponse<VariableInstanceList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (VariableInstanceList)response.getResult();
        }

        return result != null && result.getVariableInstances() != null ? Arrays.asList(result.getVariableInstances()) : Collections.emptyList();
    }

    public QueryDefinition registerQuery(QueryDefinition queryDefinition) {
        QueryDefinition result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("queryName", queryDefinition.getName());
            result = (QueryDefinition)this.makeHttpPostRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/definitions/{queryName}", valuesMap), queryDefinition, QueryDefinition.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryDataService", "registerQuery", this.serialize(queryDefinition), this.marshaller.getFormat().getType(), new Object[]{queryDefinition.getName()})));
            ServiceResponse<QueryDefinition> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (QueryDefinition)response.getResult();
        }

        return result;
    }

    public QueryDefinition replaceQuery(QueryDefinition queryDefinition) {
        QueryDefinition result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("queryName", queryDefinition.getName());
            result = (QueryDefinition)this.makeHttpPutRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/definitions/{queryName}", valuesMap), queryDefinition, QueryDefinition.class, new HashMap());
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryDataService", "replaceQuery", this.serialize(queryDefinition), this.marshaller.getFormat().getType(), new Object[]{queryDefinition.getName()})));
            ServiceResponse<QueryDefinition> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (QueryDefinition)response.getResult();
        }

        return result;
    }

    public void unregisterQuery(String queryName) {
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("queryName", queryName);
            this.makeHttpDeleteRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/definitions/{queryName}", valuesMap), (Class)null);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryDataService", "unregisterQuery", new Object[]{queryName})));
            ServiceResponse<?> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
        }

    }

    public QueryDefinition getQuery(String queryName) {
        QueryDefinition result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("queryName", queryName);
            result = (QueryDefinition)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/definitions/{queryName}", valuesMap), QueryDefinition.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryDataService", "getQuery", new Object[]{queryName})));
            ServiceResponse<QueryDefinition> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (QueryDefinition)response.getResult();
        }

        return result;
    }

    public List<QueryDefinition> getQueries(Integer page, Integer pageSize) {
        QueryDefinitionList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            String queryString = this.getPagingQueryString("", page, pageSize);
            result = (QueryDefinitionList)this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/definitions", valuesMap) + queryString, QueryDefinitionList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryDataService", "getQueries", new Object[]{page, pageSize})));
            ServiceResponse<QueryDefinitionList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (QueryDefinitionList)response.getResult();
        }

        return result != null && result.getQueries() != null ? Arrays.asList(result.getQueries()) : Collections.emptyList();
    }

    public <T> List<T> query(String queryName, String mapper, String orderBy, Integer page, Integer pageSize, Class<T> resultType) {
        Object result = null;
        Class<?> resultTypeList = this.getResultTypeList(resultType);
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("queryName", queryName);
            String queryString = this.getPagingQueryString("?mapper=" + mapper + "&orderBy=" + orderBy, page, pageSize);
            result = this.makeHttpGetRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/definitions/{queryName}/data", valuesMap) + queryString, resultTypeList);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryDataService", "query", new Object[]{queryName, mapper, orderBy, page, pageSize})));
            ServiceResponse<Object> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = response.getResult();
        }

        if (result != null) {
            if (result instanceof ItemList) {
                return ((ItemList)result).getItems();
            }

            if (result instanceof List) {
                return (List)result;
            }

            if (result instanceof Wrapped) {
                return (List)((Wrapped)result).unwrap();
            }
        }

        return null;
    }

    public <T> List<T> query(String queryName, String mapper, Integer page, Integer pageSize, Class<T> resultType) {
        return this.query(queryName, mapper, "", page, pageSize, resultType);
    }

    public <T> List<T> query(String queryName, String mapper, QueryFilterSpec filterSpec, Integer page, Integer pageSize, Class<T> resultType) {
        Object result = null;
        Class<?> resultTypeList = this.getResultTypeList(resultType);
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("queryName", queryName);
            String queryString = this.getPagingQueryString("?mapper=" + mapper, page, pageSize);
            result = this.makeHttpPostRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/definitions/{queryName}/filtered-data", valuesMap) + queryString, filterSpec, resultTypeList);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryDataService", "queryFiltered", this.serialize(filterSpec), this.marshaller.getFormat().getType(), new Object[]{queryName, mapper, page, pageSize})));
            ServiceResponse<Object> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = response.getResult();
        }

        if (result != null) {
            if (result instanceof ItemList) {
                return ((ItemList)result).getItems();
            }

            if (result instanceof List) {
                return (List)result;
            }

            if (result instanceof Wrapped) {
                return (List)((Wrapped)result).unwrap();
            }
        }

        return Collections.emptyList();
    }

    public <T> List<T> query(String queryName, String mapper, String builder, Map<String, Object> parameters, Integer page, Integer pageSize, Class<T> resultType) {
        Object result = null;
        Class<?> resultTypeList = this.getResultTypeList(resultType);
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("queryName", queryName);
            String queryString = this.getPagingQueryString("?mapper=" + mapper + "&builder=" + builder, page, pageSize);
            result = this.makeHttpPostRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/definitions/{queryName}/filtered-data", valuesMap) + queryString, parameters, resultTypeList);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryDataService", "queryFilteredWithBuilder", this.serialize(this.safeMap(parameters)), this.marshaller.getFormat().getType(), new Object[]{queryName, mapper, builder, page, pageSize})));
            ServiceResponse<Object> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = response.getResult();
        }

        if (result != null) {
            if (result instanceof ItemList) {
                return ((ItemList)result).getItems();
            }

            if (result instanceof List) {
                return (List)result;
            }

            if (result instanceof Wrapped) {
                return (List)((Wrapped)result).unwrap();
            }
        }

        return Collections.emptyList();
    }

    public <T> List<T> query(String containerId, String queryName, String mapper, String builder, Map<String, Object> parameters, Integer page, Integer pageSize, Class<T> resultType) {
        Object result = null;
        Class<?> resultTypeList = this.getResultTypeList(resultType);
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("containerId", containerId);
            valuesMap.put("queryName", queryName);
            String queryString = this.getPagingQueryString("?mapper=" + mapper + "&builder=" + builder, page, pageSize);
            result = this.makeHttpPostRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/definitions/containers/{containerId}/query/{queryName}/filtered-data", valuesMap) + queryString, parameters, resultTypeList);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryDataService", "queryFilteredWithBuilder", this.serialize(this.safeMap(parameters)), this.marshaller.getFormat().getType(), new Object[]{containerId, queryName, mapper, builder, page, pageSize})));
            ServiceResponse<Object> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = response.getResult();
        }

        if (result != null) {
            if (result instanceof ItemList) {
                return ((ItemList)result).getItems();
            }

            if (result instanceof List) {
                return (List)result;
            }

            if (result instanceof Wrapped) {
                return (List)((Wrapped)result).unwrap();
            }
        }

        return Collections.emptyList();
    }

    public List<ProcessInstance> findProcessInstancesWithFilters(String queryName, ProcessInstanceQueryFilterSpec filterSpec, Integer page, Integer pageSize) {
        String mapper = "ProcessInstances";
        ProcessInstanceList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("queryName", queryName);
            String queryString = this.getPagingQueryString("?mapper=" + mapper, page, pageSize);
            result = (ProcessInstanceList)this.makeHttpPostRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/definitions/{queryName}/filtered-data", valuesMap) + queryString, filterSpec, ProcessInstanceList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryDataService", "queryFiltered", this.serialize(filterSpec), this.marshaller.getFormat().getType(), new Object[]{queryName, mapper, page, pageSize})));
            ServiceResponse<ProcessInstanceList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (ProcessInstanceList)response.getResult();
        }

        return result != null ? result.getItems() : Collections.emptyList();
    }

    public List<TaskInstance> findHumanTasksWithFilters(String queryName, TaskQueryFilterSpec filterSpec, Integer page, Integer pageSize) {
        String mapper = "UserTasks";
        TaskInstanceList result = null;
        if (this.config.isRest()) {
            Map<String, Object> valuesMap = new HashMap();
            valuesMap.put("queryName", queryName);
            String queryString = this.getPagingQueryString("?mapper=" + mapper, page, pageSize);
            result = (TaskInstanceList)this.makeHttpPostRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/definitions/{queryName}/filtered-data", valuesMap) + queryString, filterSpec, TaskInstanceList.class);
        } else {
            CommandScript script = new CommandScript(Collections.singletonList(new DescriptorCommand("QueryDataService", "queryFiltered", this.serialize(filterSpec), this.marshaller.getFormat().getType(), new Object[]{queryName, mapper, page, pageSize})));
            ServiceResponse<TaskInstanceList> response = (ServiceResponse)this.executeJmsCommand(script, DescriptorCommand.class.getName(), "BPM").getResponses().get(0);
            this.throwExceptionOnFailure(response);
            if (this.shouldReturnWithNullResponse(response)) {
                return null;
            }

            result = (TaskInstanceList)response.getResult();
        }

        return result != null ? result.getItems() : Collections.emptyList();
    }

    protected Class<?> getResultTypeList(Class<?> resultType) {
        if (TaskSummary.class.isAssignableFrom(resultType)) {
            return TaskSummaryList.class;
        } else if (ProcessInstance.class.isAssignableFrom(resultType)) {
            return ProcessInstanceList.class;
        } else if (ProcessInstanceCustomVars.class.isAssignableFrom(resultType)) {
            return ProcessInstanceCustomVarsList.class;
        } else if (TaskInstance.class.isAssignableFrom(resultType)) {
            return TaskInstanceList.class;
        } else if (TaskWithProcessDescription.class.isAssignableFrom(resultType)) {
            return TaskWithProcessDescriptionList.class;
        } else {
            return ExecutionErrorInstance.class.isAssignableFrom(resultType) ? ExecutionErrorInstanceList.class : Object.class;
        }
    }

    public List<ProcessInstanceCustomVars> queryProcessesByVariables(SearchQueryFilterSpec spec, Integer page, Integer pageSize, String orderBy, boolean asc) {
        if (this.config.isRest()) {
            String queryString = this.getPagingQueryString("", page, pageSize);
            queryString = this.getSortingQueryString(queryString, orderBy, asc);
            return ((ProcessInstanceCustomVarsList)this.makeHttpPostRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/variables/processes" + queryString, Collections.emptyMap()), spec, ProcessInstanceCustomVarsList.class)).getItems();
        } else {
            throw new UnsupportedOperationException("JMS Not supported for this operation");
        }
    }

    public List<ProcessInstanceUserTaskWithVariables> queryUserTaskByVariables(SearchQueryFilterSpec spec, Integer page, Integer pageSize, String orderBy, boolean asc) {
        if (this.config.isRest()) {
            String queryString = this.getPagingQueryString("", page, pageSize);
            queryString = this.getSortingQueryString(queryString, orderBy, asc);
            return ((ProcessInstanceUserTaskWithVariablesList)this.makeHttpPostRequestAndCreateCustomResponse(RestURI.build(this.loadBalancer.getUrl(), "queries/variables/processes/tasks" + queryString, Collections.emptyMap()), spec, ProcessInstanceUserTaskWithVariablesList.class)).getItems();
        } else {
            throw new UnsupportedOperationException("JMS Not supported for this operation");
        }
    }

    public List<ProcessInstanceCustomVars> queryProcessesByVariables(SearchQueryFilterSpec spec, Integer page, Integer pageSize) {
        return this.queryProcessesByVariables(spec, page, pageSize, (String)null, false);
    }

    public List<ProcessInstanceUserTaskWithVariables> queryUserTaskByVariables(SearchQueryFilterSpec spec, Integer page, Integer pageSize) {
        return this.queryUserTaskByVariables(spec, page, pageSize, (String)null, false);
    }
     */
}
