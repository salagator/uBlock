package gr.alpha.cbs.fuse.ejb;

import java.io.StringReader;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;

import jakarta.inject.Singleton;
import jakarta.transaction.Transactional;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import gr.alpha.cbs.fuse.ifaces.ProductStudioInterface;
import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import gr.alpha.cbs.fuse.tools.CodeValue;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;

@Named("productStudioEjb")
@Singleton
@RegisterForReflection
@Transactional(Transactional.TxType.NOT_SUPPORTED)
public class ProductStudioEjb implements ProductStudioInterface {

	private static final Logger LOGGER = Logger.getLogger(ProductStudioEjb.class);

	RemoteDatagridClientHelper<String, String> datagridHelper;

	private static final String ps105 = "<Attribute><AttributeCode>105</AttributeCode><AttributeName>ΔΥΝΑΤΟΤΗΤΑ ΣΥΝΔΕΣΗΣ ΜΕ ΕΠΕΝΔΥΣΗ</AttributeName><AttributeValues><AttributeValue>0</AttributeValue></AttributeValues></Attribute>";

	private static final String checkExistenceOf105 = "<AttributeCode>105</AttributeCode>";

	private static final String CREDIT = "Credit";
	private static final String DEBIT = "Debit";
	private static final String INQUIRY = "Inquiry";
	private static final String MANAGERIAL = "Managerial";


	@Inject
	@io.quarkus.agroal.DataSource("hostps")
	DataSource sqlDS;

	public String getProductDetailsXML(Integer productId, Integer productVersion, Integer productAttributeCode, Integer languageId) throws Exception {

		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String queryResult = null;
		long startTime = System.currentTimeMillis();
		long endTime = 0;
		
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Starting getProductDetailsXML");
		}
		
		try {

			String key = null;
			String cachedValue = null;


			if (datagridHelper.getCache() != null){
				key = "PRD_DTL:" +productId + "|" + productVersion + "|" + (productAttributeCode!=null?productAttributeCode:"-") + "|" + (languageId!=null?languageId:"-");
				cachedValue = datagridHelper.get(key);
			}else{
				LOGGER.warn("Will not use datagrid. Stored procedure usp_PRD_GetProductAttributesByVersion_XML will be called.");
			}
			if (cachedValue != null) {
				queryResult = cachedValue;				
				endTime = System.currentTimeMillis() - startTime;
				if(LOGGER.isTraceEnabled()){
					LOGGER.trace("fetched product attributes from cache (Datagrid) with key:" + key);
					LOGGER.trace("Cache time:" + endTime + "ms");
				}
			} else {
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("fetching from database key:" + key);
				}

				if(productVersion==null) {
					ErrorUtils.throwCBSException(
							null, 
							String.valueOf(ConstantError_Types._Functional), 
							String.valueOf(ConstantError_System_IDs._FUSE), 
							this.getClass().getCanonicalName(), 
							String.valueOf("300802"), 
							String.valueOf(ConstantError_Levels._Error), 
							"Invalid Search Criteria", 
							"", 
							"");
				}

				conn = this.sqlDS.getConnection();
				pstm = conn.prepareStatement("EXEC usp_PRD_GetProductAttributesByVersion_XML ?, ?, ?, ? ");				
				pstm.setInt(1, productId);			
				pstm.setInt(2, productVersion);

				if(productAttributeCode==null) {
					pstm.setNull(3, Types.INTEGER);				
				} else { 
					pstm.setInt(3, productAttributeCode);
				}

				if(languageId==null) {
					pstm.setNull(4, Types.INTEGER);
				} else {
					pstm.setInt(4, languageId);
				}

				rs = pstm.executeQuery();

				if(rs.next()) {

					queryResult = rs.getString("XMLRESULT");

					// if statement has been added in order to resolve bugs 38851 - 38854 (dummy solution)
					if (queryResult != null && !queryResult.contains(checkExistenceOf105)){
						if(productAttributeCode == null||(productAttributeCode != null && productAttributeCode != 0)){
							StringBuilder sb = new StringBuilder();
							
							sb.append(queryResult.substring(0,queryResult.indexOf("</Attributes>")));
							sb.append(ps105);
							sb.append(queryResult.substring(queryResult.indexOf("</Attributes>"), queryResult.length()));
							
							queryResult = sb.toString();
						}
					}	

				} 

				endTime = System.currentTimeMillis() - startTime;
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("database time:" + endTime +"ms");
				}

				if (datagridHelper.getCache() !=null){
					datagridHelper.put(key, queryResult);	
					
					endTime = System.currentTimeMillis() - startTime;
					if(LOGGER.isTraceEnabled()){
						LOGGER.trace("Storing to datagrid time:" + endTime +"ms");
					}
				}

			}

		} catch (SQLException se) {

			ErrorUtils.throwCBSException(se,
					String.valueOf(ConstantError_Types._Technical), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					this.getClass().getCanonicalName(), 
					String.valueOf(300051), 
					String.valueOf(ConstantError_Levels._Error), 
					"Λάθος κατά την εκτέλεση Product Studio SP (usp_PRD_GetProductAttributesByVersion_XML)", 
					"", 
					"");

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Error In Product Studio query");
			throw e;
		} finally {

			if(rs!=null)
				rs.close();

			if(pstm!=null) {
				pstm.close();
			}
			if(conn!=null) {
				conn.close();
			}
		}
		
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Ending getProductDetailsXML");
		}

		return  queryResult;
	}


	public String getProductDetailsByDateXML(Integer productId, String productDate, Integer productAttributeCode, Integer languageId) throws Exception {

		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String queryResult = null;
		long startTime = System.currentTimeMillis();
		long endTime = 0;

		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Starting getProductDetailsByDateXML");
		}
		try {

			String key = null;
			String cachedValue = null;


			if (datagridHelper.getCache() != null){
				key = "PRD_DTL_DT:" +productId + "|" + productDate + "|" + (productAttributeCode!=null?productAttributeCode:"-") + "|" + (languageId!=null?languageId:"-");
				cachedValue = datagridHelper.get(key);			
			}else{
				LOGGER.warn("Will not use datagrid. Stored procedure usp_PRD_GetProductAttributesByDate_XML will be called.");
			}
			if (cachedValue != null) {
				queryResult = cachedValue;
				endTime = System.currentTimeMillis() - startTime;
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("fetched product attributes from cache (Datagrid) with key:" + key + ":-> Cache time:" + endTime + "ms");
					if(LOGGER.isTraceEnabled()){
						LOGGER.trace("Query result:"+queryResult);
					}
				}
			} else {
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("fetching from database key:" + key);
				}

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Date inputDate = null;

				inputDate = sdf.parse(productDate);

				conn = this.sqlDS.getConnection();
				pstm = conn.prepareStatement("EXEC usp_PRD_GetProductAttributesByDate_XML ?, ?, ?, ? ");				
				pstm.setInt(1, productId);			
				pstm.setDate(2, new java.sql.Date(inputDate.getTime()));

				if(productAttributeCode==null) {
					pstm.setNull(3, Types.INTEGER);				
				} else { 
					pstm.setInt(3, productAttributeCode);
				}

				if(languageId==null) {
					pstm.setNull(4, Types.INTEGER);
				} else {
					pstm.setInt(4, languageId);
				}

				rs = pstm.executeQuery();

				if(rs.next()) {
					queryResult = rs.getString("XMLRESULT");

					// if statement has been added in order to resolve bugs 38851 - 38854 (dummy solution)
					if (queryResult != null && !queryResult.contains(checkExistenceOf105)){
						StringBuilder sb = new StringBuilder();

						sb.append(queryResult.substring(0,queryResult.indexOf("</Attributes>")));
						sb.append(ps105);
						sb.append(queryResult.substring(queryResult.indexOf("</Attributes>"), queryResult.length()));

						queryResult = sb.toString();
					}	
				} 

				endTime = System.currentTimeMillis() - startTime;
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("database time:" + endTime +"ms");
				}
				if (datagridHelper.getCache() !=null){
					datagridHelper.put(key, queryResult);
					
					endTime = System.currentTimeMillis() - startTime;
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("Storing to datagrid time:" + endTime +"ms");
					}
				}

			}

		} catch(ParseException e) {
			ErrorUtils.throwCBSException(
					null, 
					String.valueOf(ConstantError_Types._Functional), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					this.getClass().getCanonicalName(), 
					String.valueOf("300802"), 
					String.valueOf(ConstantError_Levels._Error), 
					"Invalid Search Criteria", 
					"", 
					"");
		} catch (SQLException se) {
			ErrorUtils.throwCBSException(se,
					String.valueOf(ConstantError_Types._Technical), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					this.getClass().getCanonicalName(), 
					String.valueOf(300051), 
					String.valueOf(ConstantError_Levels._Error), 
					"Λάθος κατά την εκτέλεση Product Studio SP (usp_PRD_GetProductAttributesByDate_XML)", 
					"", 
					"");
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Error In Product Studio query");
			throw e;

		} finally {

			if(rs!=null)
				rs.close();

			if(pstm!=null) {
				pstm.close();
			}
			if(conn!=null) {
				conn.close();
			}
		}

		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Ending getProductDetailsByDateXML");
		}
		return  queryResult;
	}


	public String getProductListWithFiltersXML(String workingDate, Integer languageId,  List<CodeValue> filteringAttributes) throws Exception {

		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String queryResult = null;
		long startTime = System.currentTimeMillis();
		long endTime = 0;

		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Starting getProductListWithFiltersXML");
		}

		try {
			String attributesKey = filteringAttributes.stream().map(cv->cv.toString()).reduce(",", String::concat);

			String key = null;
			String cachedValue = null;

			if (datagridHelper.getCache() != null){
				key = "PRD_LST_FIL:" +workingDate + "|" + attributesKey + "|" + (languageId!=null?languageId:"-");
				cachedValue = datagridHelper.get(key);			
			}else{
				LOGGER.warn("Will not use datagrid. Stored procedure usp_PRD_GetProductsWithAttributes_XML will be called.");
			}
			if (cachedValue != null) {
				queryResult = cachedValue;
				endTime = System.currentTimeMillis() - startTime;
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("fetched product attributes from cache (Datagrid) with key:" + key+ ":-> Cache time:" + endTime + "ms");
					
					if(LOGGER.isTraceEnabled()){
						LOGGER.trace("Query result:"+queryResult);
					}
				}
			} else {
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("fetching from database key:" + key);
				}

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				conn = this.sqlDS.getConnection();
				pstm = conn.prepareStatement("EXEC usp_PRD_GetProductsWithAttributes_XML ?, ?, ?, ?,  ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ");

				if(StringUtils.isEmpty(workingDate)){
					pstm.setNull(1, Types.DATE);
				}
				else{
					pstm.setDate(1, new java.sql.Date(sdf.parse(workingDate).getTime()));
				}


				if(languageId==null) {
					pstm.setNull(2, Types.INTEGER);
				} else {
					pstm.setInt(2, languageId);
				}

				int i=0;
				if(filteringAttributes!=null) {
					for(CodeValue filter : filteringAttributes) {

						if(i<6) {
							pstm.setInt(2+ (2*i) + 1, filter.getCode());
							pstm.setInt(2+ (2*i) + 2, filter.getValue());
						}

						i++;
					}
				}

				for(;i<6;i++) {
					pstm.setNull(2+ (2*i) + 1, Types.INTEGER);
					pstm.setNull(2+ (2*i) + 2, Types.INTEGER);

				}

				rs = pstm.executeQuery();

				if(rs.next()) {					
					queryResult = rs.getString("XMLRESULT");
				} 

				endTime = System.currentTimeMillis() - startTime;
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("database time:" + endTime +"ms");
				}
				if (datagridHelper.getCache() !=null){
					datagridHelper.put(key, queryResult);
					
					endTime = System.currentTimeMillis() - startTime;
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("Storing to datagrid time:" + endTime +"ms");
					}

				}

			}


		} catch (Exception e) {
			LOGGER.error("Error In Product Studio query");
			throw e;
		} finally {

			if(rs!=null)
				rs.close();

			if(pstm!=null) {
				pstm.close();
			}
			if(conn!=null) {
				conn.close();
			}
		}

		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Ending getProductListWithFiltersXML");
		}
		return  queryResult;
	}

	public HashMap<String, Boolean> getAccountProfile(String transactionID, Integer profileID, Integer productID, Integer carrierID) throws Exception{
		HashMap<String, Boolean> response = new HashMap<>();
		HashMap<String, Boolean> profileBehav = new HashMap<>();
		HashMap<String, Boolean> parameterizationResponse = new HashMap<>(); 
		
		response.put(CREDIT, true);
		response.put(DEBIT, true);
		response.put(INQUIRY, true);
		response.put(MANAGERIAL, true);
		
		String queryResult = null;
		String key = null;
		String cachedValue = null;
		long startTime = System.currentTimeMillis();
		long endTime = 0;
		
		if (datagridHelper.getCache() != null){
			key = "PRD_ACC:|" + transactionID + "|" + profileID + "|" + productID + "|" +carrierID;
			cachedValue = datagridHelper.get(key);		
		}else{
			LOGGER.warn("Will not use datagrid. Calling Account profiling queries.");
		}
		if (cachedValue != null) {
			
			String cachedValues[] = cachedValue.split(":");

			response.replace(CREDIT, Boolean.valueOf(cachedValues[0]));
			response.replace(DEBIT, Boolean.valueOf(cachedValues[1]));
			response.replace(INQUIRY, Boolean.valueOf(cachedValues[2]));
			response.replace(MANAGERIAL, Boolean.valueOf(cachedValues[3]));
			
			endTime = System.currentTimeMillis() - startTime;
			
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("fetched product attributes from cache (Datagrid) with key:" + key +":-> Cache time:" + endTime + "ms");
			}
			
		}
		else{
			profileBehav = getAccountProfilePRF(transactionID, profileID, carrierID);
			
			parameterizationResponse = (profileBehav!=null)?profileBehav:getAccountProfilePRB(transactionID, productID, carrierID);
			response = (parameterizationResponse!=null)?parameterizationResponse:response;
			
			queryResult = addResponseValues(response);
			if (datagridHelper.getCache() != null){
				datagridHelper.put(key, queryResult);
			}
			
		}
		
		return response;
	}
		
		
	public HashMap<String, Boolean> getAccountProfilePRF(String transactionID, Integer profileID, Integer carrierID) throws Exception{

		HashMap<String, Boolean> response = null;		
		ResultSet rs = null;

		long startTime = System.currentTimeMillis();
		long endTime = 0;

		LOGGER.info("Starting getAccountProfilePRF");

		StringBuilder sqlBuilder = new StringBuilder("SELECT top 1 Credit, Debit, Inquiry, Managerial"
				+ "              FROM"
				+ "              PRD_AccountProfile WITH (NOLOCK)"
				+ "       		 WHERE ProfileID = ?"
				+ "				 and (TransactionID = ? or TransactionID = 'zzzzzzzzzz')"
				+ "              and (CarrierID = ? or CarrierID = 999)"
				+ "              order by TransactionID, CarrierID ASC");

		try (Connection conn = this.sqlDS.getConnection();
				PreparedStatement pstm = conn.prepareStatement(sqlBuilder.toString())) {

			pstm.setInt(1, profileID);
			pstm.setString(2, transactionID);
			pstm.setInt(3, carrierID);

			rs = pstm.executeQuery();

			if (rs.next()) {
				response = new HashMap<>();
				response.put(CREDIT, rs.getBoolean(CREDIT));
				response.put(DEBIT, rs.getBoolean(DEBIT));
				response.put(INQUIRY, rs.getBoolean(INQUIRY));
				response.put(MANAGERIAL, rs.getBoolean(MANAGERIAL));
			}
			
			endTime = System.currentTimeMillis() - startTime;
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("database time:" + endTime +"ms");
			}

		} catch (SQLException se) {
			LOGGER.error("Error in SQL while retrieving profile behavior");
		} catch (Exception e) {
			LOGGER.error("Error In Product Studio query");
			throw e;
		}
		finally {
			if (rs != null){
				rs.close();
			}
		}

		LOGGER.info("Ending getAccountProfilePRF");

		return response;
	}

	public HashMap<String, Boolean> getAccountProfilePRB(String transactionID, Integer productID, Integer carrierID) throws Exception{

		HashMap<String, Boolean> response = null;
		ResultSet rs = null;

		long startTime = System.currentTimeMillis();
		long endTime = 0;

		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Starting getAccountProfilePRB");
		}
		
		StringBuilder sqlBuilder = new StringBuilder("SELECT top 1 Credit, Debit, Inquiry, Managerial"
				+ "              FROM"
				+ "              PRD_ProductBehavior"
				+ "       		 WHERE (ProductID = ? or ProductID = 999999)"
				+ "				 and (TransactionID = ? or TransactionID = 'zzzzzzzzzz')"
				+ "              and (CarrierID = ? or CarrierID = 999)"
				+ "              order by TransactionID, CarrierID, ProductID ASC");
		
		try (Connection conn = this.sqlDS.getConnection();
				PreparedStatement pstm = conn.prepareStatement(sqlBuilder.toString())) {

			pstm.setInt(1, productID);
			pstm.setString(2, transactionID);
			pstm.setInt(3, carrierID);

			rs = pstm.executeQuery();

			if (rs.next()) {
				response = new HashMap<>();
				response.put(CREDIT, rs.getBoolean(CREDIT));
				response.put(DEBIT, rs.getBoolean(DEBIT));
				response.put(INQUIRY, rs.getBoolean(INQUIRY));
				response.put(MANAGERIAL, rs.getBoolean(MANAGERIAL));
			}
			
			endTime = System.currentTimeMillis() - startTime;
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("database time:" + endTime +"ms");
			}
		} catch (SQLException se) {
			LOGGER.error("Error in SQL while retrieving product behavior");
		} catch (Exception e) {
			LOGGER.error("Error In Product Studio query");
			throw e;
		}
		finally {
			if (rs != null){
				rs.close();
			}
		}

		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Ending getAccountProfilePRB");
		}

		return response;
	}

	String addResponseValues(HashMap<String, Boolean> response){
		StringBuilder sb = new StringBuilder();

		sb.append(response.get(CREDIT));
		sb.append(":");
		sb.append(response.get(DEBIT));
		sb.append(":");
		sb.append(response.get(INQUIRY));
		sb.append(":");
		sb.append(response.get(MANAGERIAL));

		return sb.toString();
	}

	@PostConstruct
	void postConstruct() {
		datagridHelper = new RemoteDatagridClientHelper<>();
		datagridHelper.initCacheManager();
		datagridHelper.setCache("ref-datalookup");

		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("postConstruct called");
		}
	}

	@PreDestroy
	void preDestroy() {
		datagridHelper.stopCacheManager();

		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("preDestroy called");
		}
	}

	HashMap <String,List<Integer>> getProductAttributeValuesLists(String productDetailsXml,  List<Integer> productAttributeCodes) throws Exception {
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Starting getProductAttributeValuesLists");
		}

		if(productDetailsXml==null)
			return null;

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
		DocumentBuilder builder;  
		HashMap <String,List<Integer>> response = null;


		builder = factory.newDocumentBuilder();  
		Document doc = builder.parse( new InputSource( new StringReader( productDetailsXml ))); 
		NodeList attributeNodes = doc.getElementsByTagName("Attribute");

		if(attributeNodes!=null) {

			response = new HashMap<>();

			for(int i=0;i<attributeNodes.getLength();i++) {
				Element attributeElement = (Element) attributeNodes.item(i);
				Integer attributeCode = Integer.valueOf(attributeElement.getElementsByTagName("AttributeCode").item(0).getFirstChild().getTextContent());
				if(productAttributeCodes==null || productAttributeCodes.contains(attributeCode)) {
					List<Integer> attributeValues = new ArrayList<>();
					NodeList attributeValuesNodes = attributeElement.getElementsByTagName("AttributeValue");
					for(int j=0;j<attributeValuesNodes.getLength();j++) {

						Element attributeValueElement = (Element) attributeValuesNodes.item(j);
						attributeValues.add(Integer.valueOf(attributeValueElement.getTextContent()));

					}
					response.put(attributeCode.toString(), attributeValues);

				}
			}

			NodeList productModeNodes = doc.getElementsByTagName("ProductMode");
			if(productModeNodes!=null && productModeNodes.getLength()>0) {
				response.put("ProductMode", Arrays.asList(Integer.valueOf(productModeNodes.item(0).getTextContent())));
			}

			NodeList productStatusNodes = doc.getElementsByTagName("ProductStatus");
			if(productStatusNodes!=null && productStatusNodes.getLength()>0) {
				response.put("ProductStatus", Arrays.asList(Integer.valueOf(productStatusNodes.item(0).getTextContent())));
			}

			NodeList productCategoryCodeNodes = doc.getElementsByTagName("ProductCategoryCode");
			if(productCategoryCodeNodes!=null && productCategoryCodeNodes.getLength()>0) {
				response.put("ProductCategoryCode", Arrays.asList(Integer.valueOf(productCategoryCodeNodes.item(0).getTextContent())));
			}

			NodeList masterProductCodeNodes = doc.getElementsByTagName("MasterProductCode");
			if(masterProductCodeNodes!=null && masterProductCodeNodes.getLength()>0) {
				response.put("MasterProductCode", Arrays.asList(Integer.valueOf(masterProductCodeNodes.item(0).getTextContent())));
			}

			NodeList productStartDateNodes = doc.getElementsByTagName("ProductStartDate");
			if(productStartDateNodes!=null && productStartDateNodes.getLength()>0) {
				response.put("ProductStartDateHostFormat", Arrays.asList(Integer.valueOf(productStartDateNodes.item(0).getTextContent().replace("-", ""))));
			}

			NodeList productExpiryDateNodes = doc.getElementsByTagName("ProductExpiryDate");
			if(productExpiryDateNodes!=null && productExpiryDateNodes.getLength()>0) {
				response.put("ProductExpiryDateHostFormat", Arrays.asList(Integer.valueOf(productExpiryDateNodes.item(0).getTextContent().replace("-", ""))));
			}

		}

		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Ending getProductAttributeValuesLists");
		}

		return response;

	}
	
	@Override
	public HashMap <String,List<Integer>> getProductAttributeValuesLists(Integer productId, Integer productVersion,  List<Integer> productAttributeCodes) throws Exception {
		String productDetailsXml = getProductDetailsXML(productId, productVersion,  getProductAttributeCodeOrNull(productAttributeCodes), 0);
		return getProductAttributeValuesLists(productDetailsXml, productAttributeCodes);
	}

	@Override
	public HashMap <String,List<Integer>> getProductAttributeValuesLists(Integer productId, Integer productVersion,  List<Integer> productAttributeCodes, Integer languageId) throws Exception {
		String productDetailsXml = getProductDetailsXML(productId, productVersion, getProductAttributeCodeOrNull(productAttributeCodes), languageId);
		return getProductAttributeValuesLists(productDetailsXml, productAttributeCodes);
	}
	
	@Override
	public HashMap<String, List<Integer>> getProductAttributeValuesListsByDate(Integer productId, String productDate, List<Integer> productAttributeCodes) throws Exception {
		String productDetailsXml = getProductDetailsByDateXML(productId, productDate, getProductAttributeCodeOrNull(productAttributeCodes), 0);
		return getProductAttributeValuesLists(productDetailsXml, productAttributeCodes);
	}
	
	@Override
	public HashMap<String, List<Integer>> getProductAttributeValuesListsByDate(Integer productId, String productDate, List<Integer> productAttributeCodes, Integer languageId) throws Exception {
		String productDetailsXml = getProductDetailsByDateXML(productId, productDate, getProductAttributeCodeOrNull(productAttributeCodes), languageId);
		return getProductAttributeValuesLists(productDetailsXml, productAttributeCodes);
	}
	
	HashMap <String,List<String>> getProductAttributeRealValuesLists(String productDetailsXml,  List<Integer> productAttributeCodes) throws Exception {
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Starting getProductAttributeRealValuesLists");
		}

		if(productDetailsXml==null)
			return null;

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
		DocumentBuilder builder;  
		HashMap <String,List<String>> response = null;


		builder = factory.newDocumentBuilder();  
		Document doc = builder.parse( new InputSource( new StringReader( productDetailsXml ))); 
		NodeList attributeNodes = doc.getElementsByTagName("Attribute");

		if(attributeNodes!=null) {

			response = new HashMap<>();

			for(int i=0;i<attributeNodes.getLength();i++) {
				Element attributeElement = (Element) attributeNodes.item(i);
				Integer attributeCode = Integer.valueOf(attributeElement.getElementsByTagName("AttributeCode").item(0).getFirstChild().getTextContent());
				if(productAttributeCodes==null || productAttributeCodes.contains(attributeCode)) {
					List<String> attributeValues = new ArrayList<>();
					NodeList attributeValuesNodes = attributeElement.getElementsByTagName("AttributeValue");
					for(int j=0;j<attributeValuesNodes.getLength();j++) {

						Element attributeValueElement = (Element) attributeValuesNodes.item(j);
						attributeValues.add(attributeValueElement.getAttribute("AttributeRealValue"));

					}
					response.put(attributeCode.toString(), attributeValues);

				}
			}

			NodeList productModeNodes = doc.getElementsByTagName("ProductMode");
			if(productModeNodes!=null && productModeNodes.getLength()>0) {
				response.put("ProductMode", Arrays.asList(productModeNodes.item(0).getTextContent()));
			}

			NodeList productStatusNodes = doc.getElementsByTagName("ProductStatus");
			if(productStatusNodes!=null && productStatusNodes.getLength()>0) {
				response.put("ProductStatus", Arrays.asList(productStatusNodes.item(0).getTextContent()));
			}

			NodeList productCategoryCodeNodes = doc.getElementsByTagName("ProductCategoryCode");
			if(productCategoryCodeNodes!=null && productCategoryCodeNodes.getLength()>0) {
				response.put("ProductCategoryCode", Arrays.asList(productCategoryCodeNodes.item(0).getTextContent()));
			}

			NodeList masterProductCodeNodes = doc.getElementsByTagName("MasterProductCode");
			if(masterProductCodeNodes!=null && masterProductCodeNodes.getLength()>0) {
				response.put("MasterProductCode", Arrays.asList(masterProductCodeNodes.item(0).getTextContent()));
			}

			NodeList productStartDateNodes = doc.getElementsByTagName("ProductStartDate");
			if(productStartDateNodes!=null && productStartDateNodes.getLength()>0) {
				response.put("ProductStartDateHostFormat", Arrays.asList(productStartDateNodes.item(0).getTextContent().replace("-", "")));
			}

			NodeList productExpiryDateNodes = doc.getElementsByTagName("ProductExpiryDate");
			if(productExpiryDateNodes!=null && productExpiryDateNodes.getLength()>0) {
				response.put("ProductExpiryDateHostFormat", Arrays.asList(productExpiryDateNodes.item(0).getTextContent().replace("-", "")));
			}

			NodeList productNameNodes = doc.getElementsByTagName("ProductName");
			if(productNameNodes!=null && productNameNodes.getLength()>0) {
				response.put("ProductName", Arrays.asList(productNameNodes.item(0).getTextContent().replace("-", " ")));
			}

			NodeList productCategoryNameNodes = doc.getElementsByTagName("ProductCategoryDescription");
			if(productCategoryNameNodes!=null && productCategoryNameNodes.getLength()>0) {
				response.put("ProductCategory", Arrays.asList(productCategoryNameNodes.item(0).getTextContent()));
			}

			NodeList productMasterProductNameNodes = doc.getElementsByTagName("MasterProductDecription");
			if(productMasterProductNameNodes!=null && productMasterProductNameNodes.getLength()>0) {
				response.put("MasterProduct", Arrays.asList(productMasterProductNameNodes.item(0).getTextContent()));
			}
		}

		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Ending getProductAttributeRealValuesLists");
		}

		return response;

	}
    
	@Override
	public HashMap <String,List<String>> getProductAttributeRealValuesLists(Integer productId, Integer productVersion,  List<Integer> productAttributeCodes) throws Exception {
		String productDetailsXml = getProductDetailsXML(productId, productVersion, getProductAttributeCodeOrNull(productAttributeCodes), 0);
		return getProductAttributeRealValuesLists(productDetailsXml, productAttributeCodes);
	}
	
	@Override
	public HashMap <String,List<String>> getProductAttributeRealValuesLists(Integer productId, Integer productVersion,  List<Integer> productAttributeCodes, Integer languageId) throws Exception {
		String productDetailsXml = getProductDetailsXML(productId, productVersion, getProductAttributeCodeOrNull(productAttributeCodes), languageId);
		return getProductAttributeRealValuesLists(productDetailsXml, productAttributeCodes);
	}

	@Override
	public HashMap<String, List<String>> getProductAttributeRealValuesListsByDate(Integer productId, String productDate, List<Integer> productAttributeCodes) throws Exception {
		String productDetailsXml = getProductDetailsByDateXML(productId, productDate, getProductAttributeCodeOrNull(productAttributeCodes), 0);
		return getProductAttributeRealValuesLists(productDetailsXml, productAttributeCodes);
	}
	
	@Override
	public HashMap<String, List<String>> getProductAttributeRealValuesListsByDate(Integer productId, String productDate, List<Integer> productAttributeCodes, Integer languageId) throws Exception {
		String productDetailsXml = getProductDetailsByDateXML(productId, productDate, getProductAttributeCodeOrNull(productAttributeCodes), languageId);
		return getProductAttributeRealValuesLists(productDetailsXml, productAttributeCodes);
	}

	HashMap<String, String> getProductAttributeNamesLists(String productDetailsXml, List<Integer> productAttributeCodes) {
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Starting getProductAttributeNamesLists");
		}

		if(productDetailsXml==null)
			return null;

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
		DocumentBuilder builder;  
		HashMap <String,String> response = null;

		try  
		{  
			builder = factory.newDocumentBuilder();  
			Document doc = builder.parse( new InputSource( new StringReader( productDetailsXml ))); 
			NodeList attributeNodes = doc.getElementsByTagName("Attribute");

			if(attributeNodes!=null) {

				response = new HashMap<>();

				for(int i=0;i<attributeNodes.getLength();i++) {
					Element attributeElement = (Element) attributeNodes.item(i);
					Integer attributeCode = Integer.valueOf(attributeElement.getElementsByTagName("AttributeCode").item(0).getFirstChild().getTextContent());
					if(productAttributeCodes==null || productAttributeCodes.contains(attributeCode)) {

						NodeList attributeNamesNodes = attributeElement.getElementsByTagName("AttributeName");
						if(attributeNamesNodes!=null && attributeNamesNodes.getLength()>0) {
							Element attributeNameElement = (Element) attributeNamesNodes.item(0);
							response.put(attributeCode.toString(), attributeNameElement.getTextContent());
						}

					}
				}

				NodeList productNameNodes = doc.getElementsByTagName("ProductName");
				if(productNameNodes!=null && productNameNodes.getLength()>0) {
					response.put("ProductName", productNameNodes.item(0).getTextContent());
				}

				NodeList productCategoryNameNodes = doc.getElementsByTagName("ProductCategoryDescription");
				if(productCategoryNameNodes!=null && productCategoryNameNodes.getLength()>0) {
					response.put("ProductCategory", productCategoryNameNodes.item(0).getTextContent());
				}
				
				NodeList productCategoryCodeNodes = doc.getElementsByTagName("ProductCategoryCode");
				if(productCategoryCodeNodes!=null && productCategoryCodeNodes.getLength()>0) {
					response.put("ProductCategoryCode", productCategoryCodeNodes.item(0).getTextContent());
				}

				NodeList productMasterProductNameNodes = doc.getElementsByTagName("MasterProductDecription");
				if(productMasterProductNameNodes!=null && productMasterProductNameNodes.getLength()>0) {
					response.put("MasterProduct", productMasterProductNameNodes.item(0).getTextContent());
				}
				
				NodeList productShortDescriptionNameNodes = doc.getElementsByTagName("ShortDescription");
				if(productShortDescriptionNameNodes!=null && productShortDescriptionNameNodes.getLength()>0) {
					response.put("ShortDescription", productShortDescriptionNameNodes.item(0).getTextContent());
				}
			}

		} catch (Exception e) {  
			e.printStackTrace();  
		} 
		
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Ending getProductAttributeNamesLists");
		}

		return response;

	}
    
	@Override
	public HashMap<String, String> getProductAttributeNamesListsByDate(Integer productId, String productDate, List<Integer> productAttributeCodes) throws Exception {
		String productDetailsXml = getProductDetailsByDateXML(productId, productDate, getProductAttributeCodeOrNull(productAttributeCodes), 0);
		return getProductAttributeNamesLists(productDetailsXml, productAttributeCodes);
	}
	
	@Override
	public HashMap<String, String> getProductAttributeNamesListsByVersion(Integer productId, Integer productVersion,  List<Integer> productAttributeCodes, Integer languageId) throws Exception {
		String productDetailsXml = getProductDetailsXML(productId, productVersion, getProductAttributeCodeOrNull(productAttributeCodes), languageId);
		return getProductAttributeNamesLists(productDetailsXml, null);
	}

	@Override
	public HashMap<String, String> getProductAttributeNamesListsByDate(Integer productId, String productDate,  List<Integer> productAttributeCodes, Integer languageId) throws Exception {
		String productDetailsXml = getProductDetailsByDateXML(productId, productDate, getProductAttributeCodeOrNull(productAttributeCodes), languageId);
		return getProductAttributeNamesLists(productDetailsXml, null);
	}

	@SuppressWarnings("unchecked")
	public Map<String, HashMap<String,String>> getProductAttributeMetadata(String productAttributeCode, String glCode) throws Exception{

		ResultSet rs = null;
		String queryResult = null;	
		HashMap<String, HashMap<String,String>> map = null;
		long startTime = System.currentTimeMillis();
		long endTime = 0;

		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Starting getProductAttributeMetadata");
		}

		try {

			String key = null;
			String cachedValue = null;

			if (datagridHelper.getCache() != null){
				key = "PRD_ATR_META:" +productAttributeCode + "|" + (glCode!=null?glCode:"-");
				cachedValue = datagridHelper.get(key);			
			}else{
				LOGGER.warn("Will not use datagrid. Stored procedure usp_PRD_GetEntityUDF will be called.");
			}
			if (cachedValue != null) {
				queryResult = cachedValue;
				//Deserialize cached data from String to HashMap
				map = (HashMap<String, HashMap<String,String>>)FormatUtils.deserialize(queryResult);
				
				endTime = System.currentTimeMillis() - startTime;
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("fetched product attributes from cache (Datagrid) with key:" + key +":-> Cache time:" + endTime + "ms");
					if(LOGGER.isTraceEnabled()){
						LOGGER.trace("Query result:"+queryResult);
					}
				}
			} else {

				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("fetching from database key:" + key);
				}

				if(productAttributeCode == null) {
					ErrorUtils.throwCBSException(
							null, 
							String.valueOf(ConstantError_Types._Functional), 
							String.valueOf(ConstantError_System_IDs._FUSE), 
							this.getClass().getCanonicalName(), 
							String.valueOf("300802"), 
							String.valueOf(ConstantError_Levels._Error), 
							"Invalid Search Criteria", 
							"", 
							"");
				}

				
				try(Connection conn = this.sqlDS.getConnection(); PreparedStatement pstm = conn.prepareStatement("EXEC usp_PRD_GetEntityUDF ?,?")) {
					pstm.setString(1, productAttributeCode);
					if(glCode!=null) {
						pstm.setString(2, glCode);
					}else
						pstm.setString(2, "");
				
					rs = pstm.executeQuery();
				
					map = new HashMap<String, HashMap<String,String>>();
					while(rs.next()) {
						String subAttrValue = rs.getString("SubAttributeValue");
						HashMap<String,String> mtdMap = new HashMap<>();
						int i = 1;
						while(i<=9){
							if (rs.getString("UDFDescriptionF" + i) != null){
								mtdMap.put(rs.getString("UDFDescriptionF" + i), rs.getString("UDField"+i));
							}
							i++;
						}
						map.put(subAttrValue, mtdMap);
					}
					
					queryResult = FormatUtils.serialize(map);
					
					endTime = System.currentTimeMillis() - startTime;
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("database time:" + endTime +"ms");
					}
					if (datagridHelper.getCache() !=null){
						datagridHelper.put(key, queryResult);	

						endTime = System.currentTimeMillis() - startTime;
						if(LOGGER.isDebugEnabled()){
							LOGGER.debug("Storing to datagrid time:" + endTime +"ms");
						}
					}
				
				}
			}

		} catch (SQLException se) {

			ErrorUtils.throwCBSException(se, 
					String.valueOf(ConstantError_Types._Technical), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					this.getClass().getCanonicalName(), 
					String.valueOf(300051), 
					String.valueOf(ConstantError_Levels._Error), 
					"Λάθος κατά την εκτέλεση Product Studio SP (usp_PRD_GetEntityUDF)", 
					"", 
					"");

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Error In Product Studio SP");
			throw e;
		} finally {
			if(rs!=null)
				rs.close();
		}
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Ending getProductAttributeMetadata");
		}
		return map;

	}

	@Override
	@SuppressWarnings("unchecked")
	public Map<String, List<String>> getInterestRateCategoriesByProductId(Integer productId, Integer productVersion, Integer isNormalDebitSpread, Integer languageId, Integer currencyCode) throws Exception {

		HashMap<String, List<String>> respMap = new HashMap<String, List<String>>();
		List<String> values = null;
		ResultSet rs = null;
		String queryResult = null;
		long startTime = System.currentTimeMillis();
		long endTime = 0;
		
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Starting getInterestRateCategoriesByProductId");
		}

		String key = null;
		String cachedValue = null;

		if (datagridHelper.getCache() != null){
			key = "PRD_INTR_CATEG:" + productId + "|" + productVersion + "|" + (languageId!=null?languageId:"-") +"|" + currencyCode;
			cachedValue = datagridHelper.get(key);		
		}else{
			LOGGER.warn("Will not use datagrid. Stored procedure usp_GetInterestRateCategoriesByProductId will be called.");
		}
		if (cachedValue != null) {
			queryResult = cachedValue;
			
			respMap = (HashMap<String, List<String>>)FormatUtils.deserialize(queryResult);
					
			endTime = System.currentTimeMillis() - startTime;
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("fetched product attributes from cache (Datagrid) with key:" + key +":-> Cache time:" + endTime + "ms");
				if(LOGGER.isTraceEnabled()){
					LOGGER.trace("Query result:"+queryResult);
				}
			}
		} else {
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("fetching from database key:" + key);
			}
			String qry = "exec usp_GetInterestRateCategoriesByProductId ?,?,?,?,?";	
			
			try (Connection conn = this.sqlDS.getConnection(); PreparedStatement pstm = conn.prepareStatement(qry)) {
				pstm.setInt(1, productId);
				pstm.setInt(2, productVersion);
				pstm.setInt(3, isNormalDebitSpread);
				if(languageId==null) {
					pstm.setNull(4, Types.INTEGER);
				} else {
					pstm.setInt(4, languageId);
				}
				pstm.setInt(5, currencyCode);

				rs = pstm.executeQuery();

				while (rs.next()) {
					values = new ArrayList<>();
					values.add(rs.getString("InterestPlanDescription"));
					values.add(rs.getString("CRTieredRateFlag"));
					values.add(rs.getString("DBTieredRateFlag"));
					values.add(rs.getString("CRBaseRate"));
					values.add(rs.getString("DBBaseRate"));
					values.add(rs.getString("AbsoluteMinDebitSpread"));
					values.add(rs.getString("AbsoluteMaxDebitSpread"));
					values.add(rs.getString("AbsoluteMinCreditSpread"));
					values.add(rs.getString("AbsoluteMaxCreditSpread"));
					values.add(rs.getString("RelativeMinDebitSpread"));
					values.add(rs.getString("RelativeMaxDebitSpread"));
					values.add(rs.getString("RelativeMinCreditSpread"));
					values.add(rs.getString("RelativeMaxCreditSpread"));
					
					respMap.put(rs.getString("InterestPlanCode"), values);
				}

				queryResult = FormatUtils.serialize(respMap);
				
				endTime = System.currentTimeMillis() - startTime;
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("database time:" + endTime +"ms");
				}
				if (datagridHelper.getCache() != null){
					datagridHelper.put(key, queryResult);
					
					endTime = System.currentTimeMillis() - startTime;
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("Storing to datagrid time:" + endTime +"ms");
					}
				}
			} catch (SQLException se) {
				ErrorUtils.throwCBSException(se, 
						String.valueOf(ConstantError_Types._Technical), 
						String.valueOf(ConstantError_System_IDs._FUSE), 
						this.getClass().getCanonicalName(), 
						String.valueOf(300051), 
						String.valueOf(ConstantError_Levels._Error), 
						"Λάθος κατά την εκτέλεση της sp usp_GetInterestRateCategoriesByProductId", 
						"", 
						"");
			} catch (Exception e) {
				LOGGER.error("Error In Product Studio usp_GetInterestRateCategoriesByProductId query");
				throw e;
			}
			finally {
				if (rs != null){
					rs.close();
				}
			}
		} 
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Ending getInterestRateCategoriesByProductId");
		}
		return respMap;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public Map<String, String> getInterestRatesByProductIDandCategoryID(Integer productId, Integer productVersion, String interestCategory, BigDecimal debitSpread, BigDecimal creditSpread, Integer unitsOrPercentageCR, Integer unitsOrPercentageDB, Integer isNormalDebitSpread, Integer languageId, Integer currencyCode) throws Exception{

		ResultSet rs = null;
		String queryResult = null;	
		HashMap<String, String> responseMap = new HashMap<String, String>();
		long startTime = System.currentTimeMillis();
		long endTime = 0;

		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Starting getInterestRatesByProductIDandCategoryID");
		}
		try {

			String key = null;
			String cachedValue = null;

			if (datagridHelper.getCache() != null){
				key = "PRD_INT_RATES:" +productId + "|" + productVersion + "|" + interestCategory + "|" + debitSpread + "|" +  creditSpread+ "|" + (unitsOrPercentageCR!=null?unitsOrPercentageCR:"-") + "|" + (unitsOrPercentageDB!=null?unitsOrPercentageDB:"-") +"|" + isNormalDebitSpread + "|" + (languageId!=null?languageId:"-")+ "|" + (currencyCode!=null?currencyCode:"-");
				cachedValue = datagridHelper.get(key);			
			}else{
				LOGGER.warn("Will not use datagrid. Stored procedure usp_GetInterestRatesByProductIDandCategoryID will be called.");
			}
			if (cachedValue != null) {
				queryResult = cachedValue;
				
				responseMap = (HashMap<String, String>)FormatUtils.deserialize(queryResult);
				endTime = System.currentTimeMillis() - startTime;
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("fetched product attributes from cache (Datagrid) with key:" + key +":-> Cache time:" + endTime + "ms");
					if(LOGGER.isTraceEnabled()){
						LOGGER.trace("Query result:"+queryResult);
					}
				}
			} else {

				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("fetching from database key:" + key);
				}

				String qry = "EXEC usp_GetInterestRatesByProductIDandCategoryID ?,?,?,?,?,?,?,?,?,?";	
				try(Connection conn = this.sqlDS.getConnection(); PreparedStatement pstm = conn.prepareStatement(qry)) {
					pstm.setInt(1, productId);
					pstm.setInt(2, productVersion);
					pstm.setString(3, interestCategory);
					pstm.setBigDecimal(4, debitSpread);
					pstm.setBigDecimal(5, creditSpread);

					if (unitsOrPercentageCR != null){
						pstm.setInt(6, unitsOrPercentageCR);
					}else{
						pstm.setNull(6, Types.INTEGER);
					}
					
					if (unitsOrPercentageDB != null){
						pstm.setInt(7, unitsOrPercentageDB);
					} else {
						pstm.setNull(7, Types.INTEGER);
					}		
					
					pstm.setInt(8, isNormalDebitSpread);

					if (languageId != null){
						pstm.setInt(9, languageId);
					} else {
						pstm.setNull(9, Types.INTEGER);
					}
					
					if (currencyCode != null){
						pstm.setInt(10, currencyCode);
					} else {
						pstm.setNull(10, Types.INTEGER);
					}
					
					rs = pstm.executeQuery();
					
					if(rs.next()) {
						responseMap.put("InterestPlanCode" , rs.getString("InterestPlanCode"));
						responseMap.put("InterestPlanDescription" , rs.getString("InterestPlanDescription"));
						responseMap.put("CRTieredRateFlag" , rs.getString("CRTieredRateFlag"));
						responseMap.put("DBTieredRateFlag" , rs.getString("DBTieredRateFlag"));
						responseMap.put("CRRate" , rs.getString("CRRate"));
						responseMap.put("DBRate" , rs.getString("DBRate"));
						responseMap.put("CRBaseRate" , rs.getString("CRBaseRate"));
						responseMap.put("DBBaseRate" , rs.getString("DBBaseRate"));
						responseMap.put("OldInterestCategory" , rs.getString("Old_Interest_Category"));
					}
			
					queryResult = FormatUtils.serialize(responseMap);
					endTime = System.currentTimeMillis() - startTime;
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("database time:" + endTime +"ms");
					}
					if (datagridHelper.getCache() !=null){
						datagridHelper.put(key, queryResult);	

						endTime = System.currentTimeMillis() - startTime;
						if(LOGGER.isDebugEnabled()){
							LOGGER.debug("Storing to datagrid time:" + endTime +"ms");
						}
					}
				
				}
			}

		} catch (SQLException se) {

			ErrorUtils.throwCBSException(se, 
					String.valueOf(ConstantError_Types._Technical), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					this.getClass().getCanonicalName(), 
					String.valueOf(300051), 
					String.valueOf(ConstantError_Levels._Error), 
					"Λάθος κατά την εκτέλεση Product Studio SP (usp_GetInterestRatesByProductIDandCategoryID)", 
					"", 
					"");

		} catch (Exception e) {
			LOGGER.error("Error In Product Studio usp_GetInterestRatesByProductIDandCategoryID query");
			throw e;
		}
		finally {
			if (rs != null){
				rs.close();
			}
		}
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Ending getProductDetailsXML");
		}
		return responseMap;

	}

	@Override
	public HashMap<String, String> getProductDetailsByVersion(Integer productId, Integer productVersion, Integer languageId) throws Exception {
		String productDetailsXml = getProductDetailsXML(productId, productVersion, 0, languageId);

		return getProductDetailMap(productDetailsXml);
	}

	HashMap<String, String> getProductDetailMap(String productDetailsXml){
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Starting getProductDetailMap");
		}

		if(productDetailsXml==null)
			return null;

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
		DocumentBuilder builder;  
		HashMap <String,String> response = null;

		try {  
			builder = factory.newDocumentBuilder();  
			Document doc = builder.parse( new InputSource( new StringReader( productDetailsXml ))); 
			response = new HashMap<>();
			
			NodeList productNameNodes = doc.getElementsByTagName("ProductName");
			if(productNameNodes!=null && productNameNodes.getLength()>0) {
				response.put("ProductName", productNameNodes.item(0).getTextContent());
			}
			
			NodeList productCategoryDescriptionNodes = doc.getElementsByTagName("ProductCategoryDescription");
			if(productCategoryDescriptionNodes!=null && productCategoryDescriptionNodes.getLength()>0) {
				response.put("ProductCategory", productCategoryDescriptionNodes.item(0).getTextContent());
			}
			
			NodeList productCategoryCodeNodes = doc.getElementsByTagName("ProductCategoryCode");
			if(productCategoryCodeNodes!=null && productCategoryCodeNodes.getLength()>0) {
				response.put("ProductCategoryCode", productCategoryCodeNodes.item(0).getTextContent());
			}
			
			NodeList productMasterProductDescriptionNodes = doc.getElementsByTagName("MasterProductDecription");
			if(productMasterProductDescriptionNodes!=null && productMasterProductDescriptionNodes.getLength()>0) {
				response.put("MasterProduct", productMasterProductDescriptionNodes.item(0).getTextContent());
			}
			
			NodeList productShortDescriptionNodes = doc.getElementsByTagName("ShortDescription");
			if(productShortDescriptionNodes!=null && productShortDescriptionNodes.getLength()>0) {
				response.put("ShortDescription", productShortDescriptionNodes.item(0).getTextContent());
			}

			NodeList productStatusNodes = doc.getElementsByTagName("ProductStatus");
			if(productStatusNodes!=null && productStatusNodes.getLength()>0) {
				response.put("ProductStatus", productStatusNodes.item(0).getTextContent());
			}

			NodeList productModeNodes = doc.getElementsByTagName("ProductMode");
			if(productModeNodes!=null && productModeNodes.getLength()>0) {
				response.put("ProductMode", productModeNodes.item(0).getTextContent());
			}

			NodeList productStartDateNodes = doc.getElementsByTagName("ProductStartDate");
			if(productStartDateNodes!=null && productStartDateNodes.getLength()>0) {
				response.put("ProductStartDate", productStartDateNodes.item(0).getTextContent());
			}

			NodeList productExpiryDateNodes = doc.getElementsByTagName("ProductExpiryDate");
			if(productExpiryDateNodes!=null && productExpiryDateNodes.getLength()>0) {
				response.put("ProductExpiryDate", productExpiryDateNodes.item(0).getTextContent());
			}

			NodeList masterProductCodeNodes = doc.getElementsByTagName("MasterProductCode");
			if(masterProductCodeNodes!=null && masterProductCodeNodes.getLength()>0) {
				response.put("MasterProductCode", masterProductCodeNodes.item(0).getTextContent());
			}
			
		} catch (Exception e) {  
			e.printStackTrace();  
		} 
		
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Ending getProductDetailMap");
		}

		return response;
	}
	
	@SuppressWarnings("unchecked")
	public HashMap<String, List<String>> getInterestRatesAuthorizationsByInterestCategory(Integer productCode, Integer productVersion, String productCategory, Integer carrierID, Integer currencyCode) throws Exception {
		ResultSet rs = null;
		String queryResult = null;
		HashMap<String, List<String>> responseMap = new HashMap<>();
		long startTime = System.currentTimeMillis();
		long endTime = 0;

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Starting getInterestRatesAuthorizationsByInterestCategory");
		}
		
		try {
			String key = null;
			String cachedValue = null;

			if (datagridHelper.getCache() != null) {
				key = "INT_RATES_AUTH_BY_CAT:" + productCode + "|" + productVersion + "|" + productCategory + "|" + (carrierID != null ? carrierID : "-") + "|" + (currencyCode != null ? currencyCode : "-");
				cachedValue = datagridHelper.get(key);
			} else {
				LOGGER.warn("Will not use datagrid. Stored procedure usp_GetInterestRatesAuthorizationsByInterestCategory will be called.");
			}
			
			if (cachedValue != null) {
				queryResult = cachedValue;

				responseMap = (HashMap<String, List<String>>) FormatUtils.deserialize(queryResult);
				endTime = System.currentTimeMillis() - startTime;
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("Fetched interest rates authorizations from cache (Datagrid) with key:" + key + ":-> Cache time:" + endTime + "ms");
					if (LOGGER.isTraceEnabled()) {
						LOGGER.trace("Query result:" + queryResult);
					}
				}
			} else {
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("Fetching from database key:" + key);
				}

				String qry = "EXEC usp_GetInterestRatesAuthorizationsByInterestCategory ?,?,?,?,?";
				try (Connection conn = this.sqlDS.getConnection(); PreparedStatement pstm = conn.prepareStatement(qry)) {
					pstm.setInt(1, productCode);
					pstm.setInt(2, productVersion);
					pstm.setString(3, productCategory);
					
					if (carrierID != null) {
						pstm.setInt(4, carrierID);
					} else {
						pstm.setNull(4, Types.INTEGER);
					}

					if (currencyCode != null) {
						pstm.setInt(5, currencyCode);
					} else {
						pstm.setNull(5, Types.INTEGER);
					}

					rs = pstm.executeQuery();
					List<String> values = null;
					if (rs.next()) { //expecting one row as result
						values = new ArrayList<>();
						values.add(rs.getString("CarrierID"));
						values.add(rs.getString("ModifyInterestPlan"));
						values.add(rs.getString("ModifyDebitSpread"));
						values.add(rs.getString("ModifyCreditSpread"));
						values.add(rs.getString("ModifyLimit"));
						responseMap.put(rs.getString("InterestPlanCode"), values);
					}

					queryResult = FormatUtils.serialize(responseMap);
					endTime = System.currentTimeMillis() - startTime;
					if (LOGGER.isDebugEnabled()) {
						LOGGER.debug("Database time:" + endTime + "ms");
					}
					if (datagridHelper.getCache() != null) {
						datagridHelper.put(key, queryResult);

						endTime = System.currentTimeMillis() - startTime;
						if (LOGGER.isDebugEnabled()) {
							LOGGER.debug("Storing to datagrid time:" + endTime + "ms");
						}
					}
				}
			}
		} catch (SQLException se) {
			ErrorUtils.throwCBSException(se, 
					String.valueOf(ConstantError_Types._Technical), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					this.getClass().getCanonicalName(), 
					String.valueOf(300051),
					String.valueOf(ConstantError_Levels._Error), 
					"Λάθος κατά την εκτέλεση Product Studio SP (usp_GetInterestRatesAuthorizationsByInterestCategory)", "", "");
		} catch (Exception e) {
			LOGGER.error("Error In Product Studio usp_GetInterestRatesAuthorizationsByInterestCategory query");
			throw e;
		} finally {
			if (rs != null) {
				rs.close();
			}
		}
		
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Ending getInterestRatesAuthorizationsByInterestCategory");
		}
		
		return responseMap;
	}
	
	@SuppressWarnings("unchecked")
	public HashMap<String, HashMap<String,String>> getInterestRateAuthorizationsList(Integer productCode, Integer productVersion, Integer carrierID, Integer currencyCode) throws Exception {
		ResultSet rs = null;
		String queryResult = null;
		HashMap<String, HashMap<String,String>> responseMap = new HashMap<>();
		long startTime = System.currentTimeMillis();
		long endTime = 0;

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Starting getInterestRateAuthorizationsList");
		}
		
		try {
			String key = null;
			String cachedValue = null;

			if (datagridHelper.getCache() != null) {
				key = "INT_RATES_AUTH_LIST:" + productCode + "|" + productVersion + "|" + (carrierID != null ? carrierID : "-") + "|" + (currencyCode != null ? currencyCode : "-");
				cachedValue = datagridHelper.get(key);
			} else {
				LOGGER.warn("Will not use datagrid. Stored procedure getInterestRateAuthorizationsList will be called.");
			}
			
			if (cachedValue != null) {
				queryResult = cachedValue;

				responseMap = (HashMap<String, HashMap<String,String>>) FormatUtils.deserialize(queryResult);
				endTime = System.currentTimeMillis() - startTime;
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("Fetched interest rates authorizations from cache (Datagrid) with key:" + key + ":-> Cache time:" + endTime + "ms");
					if (LOGGER.isTraceEnabled()) {
						LOGGER.trace("Query result:" + queryResult);
					}
				}
			} else {
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("Fetching from database key:" + key);
				}

				String qry = "EXEC usp_GetInterestRateAuthorizationsList ?,?,?,?";
				try (Connection conn = this.sqlDS.getConnection(); PreparedStatement pstm = conn.prepareStatement(qry)) {
					pstm.setInt(1, productCode);
					pstm.setInt(2, productVersion);
					
					if (carrierID != null) {
						pstm.setInt(3, carrierID);
					} else {
						pstm.setNull(3, Types.INTEGER);
					}

					if (currencyCode != null) {
						pstm.setInt(4, currencyCode);
					} else {
						pstm.setNull(4, Types.INTEGER);
					}

					rs = pstm.executeQuery();
					HashMap<String,String> values = null;
					while (rs.next()) { //expecting one or more rows as result
						values = new HashMap<>();
						values.put("CarrierID", rs.getString("CarrierID"));
						values.put("ModifyInterestPlan", rs.getString("ModifyInterestPlan"));
						values.put("ModifyDebitSpread", rs.getString("ModifyDebitSpread"));
						values.put("ModifyCreditSpread", rs.getString("ModifyCreditSpread"));
						values.put("ModifyLimit", rs.getString("ModifyLimit"));
						responseMap.put(rs.getString("InterestPlanCode"), values);
					}

					queryResult = FormatUtils.serialize(responseMap);
					endTime = System.currentTimeMillis() - startTime;
					if (LOGGER.isDebugEnabled()) {
						LOGGER.debug("Database time:" + endTime + "ms");
					}
					if (datagridHelper.getCache() != null) {
						datagridHelper.put(key, queryResult);

						endTime = System.currentTimeMillis() - startTime;
						if (LOGGER.isDebugEnabled()) {
							LOGGER.debug("Storing to datagrid time:" + endTime + "ms");
						}
					}
				}
			}
		} catch (SQLException se) {
			ErrorUtils.throwCBSException(se, 
					String.valueOf(ConstantError_Types._Technical), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					this.getClass().getCanonicalName(), 
					String.valueOf(300051),
					String.valueOf(ConstantError_Levels._Error), 
					"Λάθος κατά την εκτέλεση Product Studio SP (usp_GetInterestRateAuthorizationsList)", "", "");
		} catch (Exception e) {
			LOGGER.error("Error In Product Studio usp_GetInterestRateAuthorizationsList query");
			throw e;
		} finally {
			if (rs != null) {
				rs.close();
			}
		}
		
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Ending getInterestRateAuthorizationsList");
		}
		
		return responseMap;
	}
	
	Integer getProductAttributeCodeOrNull(List<Integer> productAttributeCodes) {
		Integer productAttributeCode = null;
		if(productAttributeCodes!=null && productAttributeCodes.size()==1 ) {
			productAttributeCode = productAttributeCodes.get(0);
		}
		return productAttributeCode;
	}

}
