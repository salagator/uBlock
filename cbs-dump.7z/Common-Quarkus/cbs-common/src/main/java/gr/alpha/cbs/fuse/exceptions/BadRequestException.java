package gr.alpha.cbs.fuse.exceptions;

import jakarta.servlet.ServletException;

// this is a temporary workaround for jakarta.ws.rs.BadRequestException conflict on provided eap jaxrs apis
public class BadRequestException extends ServletException {

	private static final long serialVersionUID = 1L;

	public BadRequestException() {super();}
	
	public BadRequestException(String s) {super(s);}

	public BadRequestException(Throwable throwable) {super(throwable);}

	public BadRequestException(String s, Throwable throwable) {super(s, throwable);}
}
