package gr.alpha.cbs.fuse.masking;

public class GenericCardMask implements IMask {
	
	@Override
	public String mask(String value , int length) {
		return value.substring(0,6)+"******"+value.substring(value.length()-4);
	
	}

}
