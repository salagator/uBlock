package gr.alpha.cbs.fuse.bean;

import io.quarkus.runtime.annotations.RegisterForReflection;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.transaction.TransactionManager;

@Named("txManagerVerySlow")
@Dependent
@RegisterForReflection
public class TXManagerVerySlow extends TxManagerBase {
    @Inject
    TransactionManager transactionManager;

    @ConfigProperty(name = "tx.manager.timeout.very.slow")
    int timeout;

    @Override
    public void run(Runnable runnable) throws Throwable {
        transactionManager.setTransactionTimeout(timeout);
        runWithTransaction(runnable, !hasActiveTransaction());
    }
}
