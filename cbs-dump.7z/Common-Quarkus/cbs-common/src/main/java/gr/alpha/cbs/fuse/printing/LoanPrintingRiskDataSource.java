package gr.alpha.cbs.fuse.printing;

public class LoanPrintingRiskDataSource {
	
	private LoanPrintingRiskDataSource() {
		// Intentionally empty
	}
	
	public static final TransactionDescription P01 = new TransactionDescription(1, "ΠΙΣΤΩΣΗ ΕΝΑΝΤΙ ΛΟΓΑΡΙΑΣΜΟΥ &&CodCurrency&&  &&Amount&&\n");
	public static final TransactionDescription P02 = new TransactionDescription(2, "Αντιλογισμός Πίστωσης έναντι λογαριασμού Νο &&NumOper2&& &&CodDom2&& &&NumNod2&&\n");
	public static final TransactionDescription P03 = new TransactionDescription(3, "Πληρωμή Επιδίκων Εξόδων &&CodCurrency&& &&liexAm&&\n");
	public static final TransactionDescription P04 = new TransactionDescription(4, "Αντιλογισμός πληρωμής επιδ.εξοδων Γρ. Εισπρ. Νο.&&NumOper2&& &&CodDom2&& &&NumNod2&&\n");
	public static final TransactionDescription P05 = new TransactionDescription(5, "Επίδικα έξοδα &&CodCurrency&& &&liexAm2&&\n");
	public static final TransactionDescription P06 = new TransactionDescription(6, "Αντιλογισμός ποσου επίδικων εξόδων\n");
	public static final TransactionDescription P07 = new TransactionDescription(7, "Tόκοι καθυστέρησης &&CodCurrency&&  &&DelPartInterest&&&&Amount&& πλέον ΕΦΤΕ &&CodCurrency&& &&EfteAm2t&& Aπό  &&lastsetldate&& (τελευταίος εκτοκισμός) μέχρι &&transdate&& (valeur μεταφοράς λόγω μεταφοράς σt ις ανεπίδεκτες είσπραξης)\n");
	public static final TransactionDescription P08 = new TransactionDescription(8, "Αντιλογισμός  παραστατικού χρέωσης/Πίστωσης Νο &&RevTransID&& Λόγω αντιλογισμού μεταφοράς στις ανεπίδεκτες είσπραξης\n");
	public static final TransactionDescription P09 = new TransactionDescription(9, "Πίστωση εξόδων στην επισφάλεια\n");
	public static final TransactionDescription P10 = new TransactionDescription(10, "Χρέωση εξόδων στην επισφάλεια\n");
	public static final TransactionDescription P11 = new TransactionDescription(11, "Καταβολή πληρωμής εξόδων στην επισφάλεια &&CodCurrency&& &&liexAm&&\n");
	public static final TransactionDescription P12 = new TransactionDescription(12, "Αντιλογισμός καταβολής πληρωμής εξόδων στην επισφάλεια Γρ. Εισπρ. Νο.&&NumOper2&& &&CodDom2&& &&NumNod2&&\n");
	public static final TransactionDescription P13 = new TransactionDescription(13, "Μεταφορά Αποσβεσμένων Οφειλών από &&ALPHALOANDOSSIER&& σε λογαριασμό Συγκέντρωσης Αποσβεσμένων Οφειλών – 3115\n");
	public static final TransactionDescription P14 = new TransactionDescription(14, "Αντιλογισμός Μεταφοράς Αποσβεσμένων Οφειλών Νο.&&NumOper2&& &&CodDom&& &&NumNod&&\n");
	public static final TransactionDescription P15 = new TransactionDescription(15, "Οριστική Διαγραφή Αποσβεσμένων Οφειλών &&ALPHALOANDOSSIER&&\n");
	public static final TransactionDescription P16 = new TransactionDescription(16, "Αντιλογισμός Οριστικής Διαγραφής Αποσβεσμένων Οφειλών Νο.&&NumOper2&& &&CodDom&& &&NumNod&&\n");
	public static final TransactionDescription P17 = new TransactionDescription(17, "Χρέωση Αποσβεσμένων Οφειλών &&ALPHALOANDOSSIER&&\n");
	public static final TransactionDescription P18 = new TransactionDescription(18, "Αντιλογισμός Χρέωσης Αποσβεσμένων Οφειλών Νο.&&NumOper2&& &&CodDom&& &&NumNod&&\n");
	public static final TransactionDescription COM01 = new TransactionDescription(19, "&&TxtComment01&&\n");
	public static final TransactionDescription COM02 = new TransactionDescription(20, "&&TxtComment02&&\n");
	public static final TransactionDescription COM03 = new TransactionDescription(21, "&&TxtComment03&&\n");
	public static final TransactionDescription C01 = new TransactionDescription(22, "Ανταλλαγή χρέους με μετοχικό κεφάλαιο\n");
	public static final TransactionDescription C02 = new TransactionDescription(23, "Ανταλλαγή χρέους με Ακίνητο\n");
	public static final TransactionDescription C03 = new TransactionDescription(24, "Πώληση Δανείου\n");
	public static final TransactionDescription C04 = new TransactionDescription(25, "Λοιπές Διαγραφές\n");
	
}
