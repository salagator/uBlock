package gr.alpha.cbs.fuse.bean;

import com.microsoft.sqlserver.jdbc.SQLServerConnectionPoolDataSource;
import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.microsoft.sqlserver.jdbc.SQLServerXADataSource;
import gr.alpha.cbs.fuse.logging.LogicalLoggingHandler;
import io.quarkus.runtime.annotations.RegisterForReflection;
import net.sf.saxon.Configuration;
import net.sf.saxon.TransformerFactoryImpl;
import net.sf.saxon.functions.*;
import net.sf.saxon.serialize.MessageWarner;
import net.sf.saxon.xpath.XPathFactoryImpl;
import org.apache.camel.CamelExecutionException;
import org.apache.camel.component.xslt.XsltBuilder;
import org.apache.camel.component.xslt.saxon.XsltSaxonBuilder;
import org.apache.cxf.jaxws.handler.types.*;

import jakarta.xml.bind.annotation.adapters.CollapsedStringAdapter;
import java.net.Socket;
import java.net.SocketAddress;

@RegisterForReflection(targets = {
        // Needed for cxf web service provider
        XsdStringType.class,
        DescriptionType.class,
        CString.class,
        DisplayNameType.class,
        IconType.class,
        ParamValueType.class,
        XsdQNameType.class,
        PortComponentHandlerType.class,
        CollapsedStringAdapter.class,
        FullyQualifiedClassType.class,
        LogicalLoggingHandler.class,

        // Needed for camel context
        XsltSaxonBuilder.class,
        Configuration.class,
        String_1.class,
        StringLength_1.class,
        Tokenize_1.class,
        BooleanFn.class,
        StringJoin.class,
        Substring.class,
        Concat.class,
        PositionAndLast.class,
        PositionAndLast.Position.class,
        NormalizeSpace_1.class,
        LocalName_1.class,
        Count.class,
        Exists.class,
        ContextItemAccessorFunction.class,
        XPathFactoryImpl.class,
        XsltBuilder.class,
        TransformerFactoryImpl.class,
        Exception.class,
        CamelExecutionException.class,

        SQLServerXADataSource.class,
        SQLServerConnectionPoolDataSource.class,
        SQLServerDataSource.class,

        SocketAddress.class,
        Socket.class,

        // Apparently needed for Woodstox StAX
        MessageWarner.class
})
public class ReflectionConfiguration {
}
