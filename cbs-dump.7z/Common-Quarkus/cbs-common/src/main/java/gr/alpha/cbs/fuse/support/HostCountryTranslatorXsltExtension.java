package gr.alpha.cbs.fuse.support;

import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;
import org.jboss.logging.Logger;

@Named("hostCountryTranslatorXsltExtension")
@ApplicationScoped
@RegisterForReflection
public class HostCountryTranslatorXsltExtension extends ExtensionFunctionDefinition {
    private static final Logger LOGGER = Logger.getLogger(HostCountryTranslatorXsltExtension.class);
    private static final long serialVersionUID = 1862024181840326214L;

    @Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("hctr", "http://fuse.cbs.alpha.gr/hostcountrytranslator/", "host-country-translator");
    }

    @Override
    public SequenceType[] getArgumentTypes() {
        return new SequenceType[] { SequenceType.SINGLE_STRING };
    }

    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
        return SequenceType.SINGLE_STRING;
    }

    @Override
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {
            private static final long serialVersionUID = 5090616615262067008L;

            @Override
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
                Long timer = 0L;

                try {
                    String country = null;

                    if (arguments[0] instanceof LazySequence) {
                        country = ((LazySequence) arguments[0]).head().getStringValue();
                    } else if (arguments[0] instanceof StringValue) {
                        country = ((StringValue) arguments[0]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type: " + arguments[0].getClass().getCanonicalName());
                    }

                    if (country == null || country.isEmpty()) {
                        return StringValue.makeStringValue("");
                    }

                    if (LOGGER.isTraceEnabled()) {
                        timer = System.nanoTime();
                    }

                    String result = country.trim();
                    long lookup = System.nanoTime() - timer;
                    result = FormatUtils.translateGreek(country.trim());

                    if (LOGGER.isTraceEnabled()) {
                        timer = System.nanoTime() - timer;
                        LOGGER.trace("XSL call completed " + timer / 1000 + ",lookup:" + lookup / 1000 + " microseconds");
                    }

                    return StringValue.makeStringValue(result);
                } catch (Exception e) {
                    throw new XPathException("Unable to translate value", e);
                }
            }
        };
    }
}