package gr.alpha.cbs.fuse.kafka;

import org.apache.camel.util.StringHelper;
import org.eclipse.microprofile.config.ConfigProvider;

public class KafkaConfigContext {
	private String brokerSystemProperty;
	private String topicSystemProperty;
	private String saslKerberosServiceName;
	private String securityProtocol;
	private String contextId;
	private String saslJaasConfigSystemProperty;

	private KafkaConfigContext(String brokerSystemProperty, String topicSystemProperty, String saslKerberosServiceName, String securityProtocol, String contexId, String saslJaasConfigSystemProperty) {
		this.brokerSystemProperty = brokerSystemProperty;
		this.topicSystemProperty = topicSystemProperty;
		this.saslKerberosServiceName = saslKerberosServiceName;
		this.securityProtocol = securityProtocol;
		this.contextId = contexId;
		this.saslJaasConfigSystemProperty = saslJaasConfigSystemProperty;
	}

	public String getBrokerSystemProperty() {
		return this.brokerSystemProperty;
	}

	public String getTopicSystemProperty() {
		return this.topicSystemProperty;
	}

	public String getSaslKerberosServiceName() {
		return this.saslKerberosServiceName;
	}

	public String getSecurityProtocol() {
		return this.securityProtocol;
	}

	public String getContextId() {
		return this.contextId;
	}

	public String getSaslJaasConfigSystemProperty() { return this.saslJaasConfigSystemProperty; }

	public static class Builder {
		private String brokerSystemProperty;
		private String topicSystemProperty;
		private String saslKerberosServiceName;
		private String securityProtocol;
		private String contextId;
		private String saslJaasConfigSystemProperty;

		public Builder brokerSystemProperty(String brokerSystemProperty) {
			this.brokerSystemProperty = brokerSystemProperty;
			return this;
		}

		public Builder topicSystemProperty(String topicSystemProperty) {
			this.topicSystemProperty = topicSystemProperty;
			return this;
		}

		public Builder saslKerberosServiceName(String saslKerberosServiceName) {
			this.saslKerberosServiceName = saslKerberosServiceName;
			return this;
		}

		public Builder securityProtocol(String securityProtocol) {
			this.securityProtocol = securityProtocol;
			return this;
		}

		public Builder contextId(String contextId) {
			this.contextId = contextId;
			return this;
		}

		public Builder saslJaasConfigSystemProperty(String saslJaasConfigSystemProperty) {
			this.saslJaasConfigSystemProperty = saslJaasConfigSystemProperty;
			return this;
		}

		public KafkaConfigContext build() {
			StringHelper.notEmpty(this.brokerSystemProperty, "brokerSystemProperty");
			if (ConfigProvider.getConfig().getValue(this.brokerSystemProperty, String.class) == null) {
				throw new IllegalArgumentException("Invalid Kafka configuration [broker]. " + this.brokerSystemProperty + " cannot be found in system properties.");
			}
			StringHelper.notEmpty(this.topicSystemProperty, "topicSystemProperty");
			if (ConfigProvider.getConfig().getValue(this.topicSystemProperty, String.class) == null) {
				throw new IllegalArgumentException("Invalid Kafka configuration [topic]. " + this.topicSystemProperty + " cannot be found in system properties.");
			}
			StringHelper.notEmpty(this.saslKerberosServiceName, "saslKerberosServiceName");
			StringHelper.notEmpty(this.securityProtocol, "securityProtocol");
			StringHelper.notEmpty(this.contextId, "contextId");
			StringHelper.notEmpty(this.saslJaasConfigSystemProperty, "saslJaasConfigSystemProperty");
			
			return new KafkaConfigContext(this.brokerSystemProperty, this.topicSystemProperty, this.saslKerberosServiceName, this.securityProtocol, this.contextId, this.saslJaasConfigSystemProperty);
		}
	}
}
