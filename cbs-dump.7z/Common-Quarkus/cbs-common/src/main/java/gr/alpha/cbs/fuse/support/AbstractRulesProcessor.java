package gr.alpha.cbs.fuse.support;

import java.util.Collection;

import org.apache.camel.Processor;
import org.jboss.logging.Logger;
// import org.kie.api.KieServices;
// import org.kie.api.builder.KieScanner;
// import org.kie.api.builder.ReleaseId;
// import org.kie.api.builder.Results;
// import org.kie.api.runtime.KieContainer;

/**
 * Abstract rules processor which is responsible for KieContainer LCM.
 * <p/>
 * Sub-classes need to implement the logic that retrieves a KieSession from the
 * KieContainer, firing the rules and disposing the session.
 * 
 * @author <a href="mailto:duncan.doyle@redhat.com">Duncan Doyle</a>
 */
public abstract class AbstractRulesProcessor implements Processor, ProcessorLifecycle {

	private static final Logger LOGGER = Logger.getLogger(AbstractRulesProcessor.class);

	private final String kjarGroupId;
	private final String kjarArtifactId;
	private final String kjarVersion;
	private final String kieProcessName;

	//private static final long KIE_SCANNER_SCAN_INTERVAL = 5000L;

	// private final KieContainer kieContainer;
	// private final KieScanner scanner;




	public AbstractRulesProcessor() {
		this.kjarGroupId = null;
		this.kjarArtifactId = null;
		this.kjarVersion = null;
		//this.scanner = null;
		this.kieProcessName = null;

		// KieServices kieServices = KieServices.Factory.get();

		// kieContainer = kieServices == null ? null : kieServices.newKieClasspathContainer();

		// if (kieContainer != null) {
		// 	// Let's verify that all the resources are loaded correctly
		// 	Results results = kieContainer.verify();
		// 	// We can iterate the results
		// 	if (LOGGER.isDebugEnabled()) {
		// 		results.getMessages().stream().forEach(message -> LOGGER.debug(">> Message ( " + message.getLevel() + " ): " + message.getText()));
		// 	}
		// }
	}

	public AbstractRulesProcessor(String kjarGroupId, String kjarArtifactId, String kjarVersion, String kieProcessName) {
		this.kjarGroupId = kjarGroupId;
		this.kjarArtifactId = kjarArtifactId;
		this.kjarVersion = kjarVersion;
		this.kieProcessName = kieProcessName;

		// KieServices kieServices = KieServices.Factory.get();

		// ReleaseId releaseId = kieServices.newReleaseId(kjarGroupId, kjarArtifactId, kjarVersion);
		
		// LOGGER.debug("Creating JBoss BRMS KieContainer for KJAR: " + releaseId.toString());

		// kieContainer = kieServices.newKieContainer(releaseId);
		
		// LOGGER.debug("---------------------KIECONTAINER---------------------------------");
	

		// if (kieContainer == null) {
		// 	LOGGER.debug("No, KieContainer is null.");
		// } else {
		// 	LOGGER.info("KieContainer ReleaseId:" + kieContainer.getReleaseId() );
		// 	Results results = kieContainer.verify();
		// 	// We can iterate the results
		// 	if (LOGGER.isDebugEnabled()){
		// 		results.getMessages().stream().forEach(message -> LOGGER.debug(">> Message ( " + message.getLevel() + " ): " + message.getText()));
		// 	}
	
		// 	Collection<String> kieBaseNames = kieContainer.getKieBaseNames();
	
		// 	LOGGER.debug("Loaded KieContainer with KieBases: ");
		// 	for (String nextKieBaseName : kieBaseNames) {
		// 		LOGGER.debug("- " + nextKieBaseName);
		// 	}
		// }

		// Attach a KieScanner to the KieContainer so we can dynamically update
		// rules.
		//scanner = kieServices.newKieScanner(kieContainer);
		//scanner.start(KIE_SCANNER_SCAN_INTERVAL);
		//TODO finillize if we use scanner
		//scanner = null;
	}

	@Override
	public void doStop() {
		LOGGER.debug("Stopping the processor.");
		// Shutdown the scanner
		// if (scanner != null) {
		// 	scanner.shutdown();
		// }

	}

	// protected synchronized KieContainer getKieContainer() {

	// 	return kieContainer;
	// }

	public String getKjarGroupId() {
		return kjarGroupId;
	}

	public String getKjarArtifactId() {
		return kjarArtifactId;
	}

	public String getKjarVersion() {
		return kjarVersion;
	}

	public String getProcessName() {
		return kieProcessName;
	}
	
	

}
