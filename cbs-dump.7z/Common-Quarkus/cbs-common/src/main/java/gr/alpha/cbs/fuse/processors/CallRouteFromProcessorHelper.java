package gr.alpha.cbs.fuse.processors;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.w3c.dom.Document;

@Named("callRouteFromProcessorHelper")
@ApplicationScoped
@RegisterForReflection
public class CallRouteFromProcessorHelper {

	public static Document callRouteInChildExchange(ProducerTemplate producerTemplate,
			String endpointIdentifier, Object requestObject,
			Exchange exchange) throws Exception {
		Exchange childExchange = producerTemplate.getCamelContext().getEndpoint(endpointIdentifier).createExchange();
		childExchange.getIn().setBody(requestObject);
		childExchange.getIn().setHeaders(exchange.getIn().getHeaders());
		for (String key : exchange.getProperties().keySet()) {
			Object value = exchange.getProperty(key);
			childExchange.setProperty(key, value);
		}
		producerTemplate.send(endpointIdentifier, childExchange);
		if (childExchange.getException() != null) {
			throw childExchange.getException();
		}
		for (String key : childExchange.getProperties().keySet()) {
			if (!exchange.getProperties().containsKey(key))	{
				Object value = childExchange.getProperty(key);
				exchange.setProperty(key, value);
			}
		}
		return childExchange.getIn().getBody(Document.class);
	}
}
