package gr.alpha.cbs.fuse.tools;

import java.util.Map;

public class ProblemDetails {

    private final String type;
    private final Integer status;
    private final String title;
    private final String detail;
    private final String instance;
    private final Map<String,String> loggingInfo;
    private final Map<String,String> errorMessage;

    private ProblemDetails(String type, Integer status, String title, String detail, String instance, Map<String,String> loggingInfo, Map<String,String> errorMessage) {
        this.type = type;
        this.status = status;
        this.title = title;
        this.detail = detail;
        this.instance = instance;
        this.loggingInfo = loggingInfo;
        this.errorMessage = errorMessage;
    }

    public String  getType() {return type;}
    public Integer getStatus() {return status;}
    public String  getTitle() {return title;}
    public String  getInstance() {return instance;}
    public String  getDetail() {return detail;}
    public Map<String,String>  getLoggingInfo() {return loggingInfo;}
    public Map<String,String>  getErrorMessage() {return errorMessage;}

    public static ProblemDetailsBuilder  getBuilder() {return new ProblemDetailsBuilder();}

    public static class ProblemDetailsBuilder {
        private String  type;
        private Integer status;
        private String  title;
        private String  detail;
        private String  instance;
        private Map<String,String> loggingInfo;
        private Map<String,String> errorMessage;

        public ProblemDetailsBuilder setErrorMessage(Map<String,String> errorMessage) {
            this.errorMessage = errorMessage;
            return this;
        }
        public ProblemDetailsBuilder setLoggingInfo(Map<String,String> loggingInfo) {
            this.loggingInfo = loggingInfo;
            return this;
        }
        public ProblemDetailsBuilder setInstance(String instance) {
            this.instance = instance;
            return this;
        }
        public ProblemDetailsBuilder setDetail(String detail) {
            this.detail = detail;
            return this;
        }
        public ProblemDetailsBuilder setTitle(String title) {
            this.title = title;
            return this;
        }
        public ProblemDetailsBuilder setStatus(Integer status) {
            this.status = status;
            return this;
        }
        public ProblemDetailsBuilder setType(String type) {
            this.type = type;
            return this;
        }
        public ProblemDetails build() {
            return new ProblemDetails(type, status, title, detail, instance, loggingInfo, errorMessage);
        }

    }

}
