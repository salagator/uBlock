package gr.alpha.cbs.fuse.kie;

import org.apache.hc.client5.http.async.methods.SimpleHttpResponse;
import org.apache.hc.client5.http.async.methods.SimpleResponseConsumer;
import org.apache.hc.client5.http.impl.async.CloseableHttpAsyncClient;
import org.apache.hc.core5.concurrent.FutureCallback;
import org.apache.hc.core5.http.Method;
import org.apache.hc.core5.http.nio.AsyncRequestProducer;
import org.apache.hc.core5.http.nio.AsyncResponseConsumer;
import org.apache.hc.core5.http.nio.support.AsyncRequestBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.Future;

public class KieRequestHelper {
    private static final Logger logger = LoggerFactory.getLogger(KieRequestHelper.class);

    private static final String KIE_CONTENT_TYPE_HEADER = "X-KIE-ContentType";

    private static final String PROCESS_URI = "containers/{containerId}/processes";
    private static final String START_PROCESS_POST_URI = "{processId}/instances";
    private static final String SIGNAL_PROCESS_INST_POST_URI = "instances/{processInstanceId}/signal/{signalName}";
    private static final String GET_INSTANCE_VARIABLE_GET_URI = "instances/{processInstanceId}/variable/{varName}";
    private static final String SET_INSTANCE_VARIABLE_PUT_URI = "instances/{processInstanceId}/variable/{varName}";
    private static final String FIND_VARIABLES_CURRENT_STATE_GET_URI = "queries/processes/instances/{processInstanceId}/variables/instances";

    private String baseUrl;
    private CredentialsProvider credentialsProvider;

    public KieRequestHelper(String baseUrl, String username, String password) {
        this.baseUrl = baseUrl;
        this.credentialsProvider = new EnteredCredentialsProvider(username, password);
    }

    public String createStartProcessUrl(String containerId, String processId) {
        return baseUrl + PROCESS_URI.replace("{containerId}", containerId) + "/" + START_PROCESS_POST_URI.replace("{processId}", processId);
    }

    public String createSignalProcessUrl(String containerId, String processInstanceId, String signalName) {
        return baseUrl + PROCESS_URI.replace("{containerId}", containerId) + "/" + SIGNAL_PROCESS_INST_POST_URI.replace("{processInstanceId}", processInstanceId).replace("{signalName}", signalName);
    }

    public String createGetInstanceVariableUrl(String containerId, String processInstanceId, String varName) {
        return baseUrl + PROCESS_URI.replace("{containerId}", containerId) + "/" + GET_INSTANCE_VARIABLE_GET_URI.replace("{processInstanceId}", processInstanceId).replace("{varName}", varName);
    }

    public String createSetInstanceVariableUrl(String containerId, String processInstanceId, String varName) {
        return baseUrl + PROCESS_URI.replace("{containerId}", containerId) + "/" + SET_INSTANCE_VARIABLE_PUT_URI.replace("{processInstanceId}", processInstanceId).replace("{varName}", varName);
    }

    public String createFindVariablesCurrentStateUrl(String containerId, String processInstanceId) {
        return baseUrl + FIND_VARIABLES_CURRENT_STATE_GET_URI.replace("{processInstanceId}", processInstanceId);
    }

    // Normally one should use the sendToKieServer method to send requests, but this method is provided for convenience
    public AsyncRequestProducer createProducer(String url, Method method, String body) {
        AsyncRequestBuilder builder = AsyncRequestBuilder.
                create(method.name()).
                setUri(url).
                addHeader("Accept", "application/json").
                addHeader("Content-Type", "application/json").
                addHeader(KIE_CONTENT_TYPE_HEADER, "json").
                addHeader(credentialsProvider.getHeaderName(), credentialsProvider.getAuthorization());
        if (body != null) {
            builder = builder.
                    addHeader("Content-Length", String.valueOf(body.getBytes(StandardCharsets.UTF_8).length)).
                    setEntity(body);
        }
        return builder.build();
    }

    public Future<SimpleHttpResponse> sendToKieServer(CloseableHttpAsyncClient client, String url, Method method, String body, String interactionDescription) {
        AsyncRequestProducer producer = createProducer(url, method, null);
        AsyncResponseConsumer<SimpleHttpResponse> consumer = SimpleResponseConsumer.create();
        return client.execute(producer, consumer, new FutureCallback<>() {
            @Override
            public void completed(SimpleHttpResponse simpleHttpResponse) {
                logger.info("Response code:" + simpleHttpResponse.getCode());
                logger.info("Response body" + simpleHttpResponse.getBody());
            }

            @Override
            public void failed(Exception e) {
                logger.error("Unable " + interactionDescription, e);
            }

            @Override
            public void cancelled() {
                logger.warn("Request " + interactionDescription + " cancelled");
            }
        });
    }

}
