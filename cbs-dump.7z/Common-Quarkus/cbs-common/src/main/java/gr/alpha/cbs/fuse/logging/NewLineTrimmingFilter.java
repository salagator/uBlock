package gr.alpha.cbs.fuse.logging;

import io.quarkus.logging.LoggingFilter;
import org.jboss.logmanager.ExtLogRecord;

import java.util.logging.Filter;
import java.util.logging.LogRecord;

@LoggingFilter(name = "newLineTrimmingFilter")
public final class NewLineTrimmingFilter implements Filter {
    @Override
    public boolean isLoggable(LogRecord record) {
        if (record.getMessage() == null) {
            record.setMessage("PrintingHandlerBean::isLoggable::record.getMessage() is null");
            return true;
        }
        if (record instanceof ExtLogRecord) {
            ExtLogRecord extLogRecord = (ExtLogRecord) record;
            extLogRecord.setMessage(
                    extLogRecord.getMessage().
                            replace("\r\n", "").
                            replace("\n", ""),
                    extLogRecord.getFormatStyle());
        } else {
            record.setMessage(
                    record.getMessage().
                            replace("\r\n", "").
                            replace("\n", ""));
        }
        return true;
    }
}
