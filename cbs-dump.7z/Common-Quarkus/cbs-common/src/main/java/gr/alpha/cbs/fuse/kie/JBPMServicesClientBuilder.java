//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

import java.util.HashMap;
import java.util.Map;

public class JBPMServicesClientBuilder implements KieServicesClientBuilder {
    public String getImplementedCapability() {
        return "BPM";
    }

    public Map<Class<?>, Object> build(KieServicesConfiguration configuration, ClassLoader classLoader) {
        Map<Class<?>, Object> services = new HashMap();
        services.put(ProcessServicesClient.class, new ProcessServicesClientImpl(configuration, classLoader));
        services.put(QueryServicesClient.class, new QueryServicesClientImpl(configuration, classLoader));
        return services;
    }
}
