
package gr.alpha.cbs.fuse.legacy;

import jakarta.xml.bind.annotation.XmlEnum;
import jakarta.xml.bind.annotation.XmlEnumValue;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TransactionMode.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TransactionMode">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="TransactionDisabled"/>
 *     &lt;enumeration value="TransactionSupported"/>
 *     &lt;enumeration value="TransactionRequired"/>
 *     &lt;enumeration value="TransactionRequiresNew"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "TransactionMode")
@XmlEnum
public enum TransactionMode {

    @XmlEnumValue("TransactionDisabled")
    TRANSACTION_DISABLED("TransactionDisabled"),
    @XmlEnumValue("TransactionSupported")
    TRANSACTION_SUPPORTED("TransactionSupported"),
    @XmlEnumValue("TransactionRequired")
    TRANSACTION_REQUIRED("TransactionRequired"),
    @XmlEnumValue("TransactionRequiresNew")
    TRANSACTION_REQUIRES_NEW("TransactionRequiresNew");
    private final String value;

    TransactionMode(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TransactionMode fromValue(String v) {
        for (TransactionMode c: TransactionMode.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
