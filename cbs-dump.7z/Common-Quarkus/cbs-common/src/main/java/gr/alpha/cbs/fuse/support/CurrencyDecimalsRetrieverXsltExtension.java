package gr.alpha.cbs.fuse.support;

import gr.alpha.cbs.fuse.ejb.MasterDataEjb;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;

import java.util.Map;

@Named("functionCurrencyDecimalsRetriever")
@ApplicationScoped
@RegisterForReflection
public class CurrencyDecimalsRetrieverXsltExtension extends ExtensionFunctionDefinition {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2060328806415157862L;

	@Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("cdr", "http://fuse.cbs.alpha.gr/currencyDecimalsRetriever/", "currencyDecimalsRetriever");
    }

	 @Override
	 public SequenceType[] getArgumentTypes() {
	    return new SequenceType[]{SequenceType.SINGLE_STRING};
	 }
    
    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
    	return SequenceType.SINGLE_STRING;
    }

	@Inject
	@Named("masterDataInterface")
	MasterDataEjb masterStudio;

    @Override
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {
			
			/**
			 * 
			 */
			private static final long serialVersionUID = -2058456802203838019L;

			@Override
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
				try {
					
	                String currency = null;
	                //Check currency - Required field
	                if (arguments[0] instanceof LazySequence) {
	                	currency = ((LazySequence)arguments[0]).head().getStringValue();
	                } else if (arguments[0] instanceof StringValue) {
	                	currency = ((StringValue)arguments[0]).getStringValue();
	                } else {
	                	throw new Exception("Unrecognized argument type for fromIntPart parameter: " + arguments[0].getClass().getCanonicalName());
	                }

	        		Map<String, String> map = masterStudio.getMasterDetailsByItemNameLists("Currencies", currency);
	        		String numberOfDecimals = "";
	        		
	        		if (map!=null && !map.isEmpty() && map.containsKey("CURRENCY_DEC_POINTS")){
	        			numberOfDecimals = map.get("CURRENCY_DEC_POINTS");
	        		}
	                
                	return StringValue.makeStringValue(numberOfDecimals);

				} catch (Exception e) {
					throw new XPathException("Unable to retrieve currency decimals", e);
				}
            }
			
        };
    }
}
