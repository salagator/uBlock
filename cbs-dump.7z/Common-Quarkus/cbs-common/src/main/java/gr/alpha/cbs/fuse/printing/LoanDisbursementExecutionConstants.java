package gr.alpha.cbs.fuse.printing;

public class LoanDisbursementExecutionConstants {

    private LoanDisbursementExecutionConstants() {
        // Intentionally empty
    }

    public static final String P01C1 = "&&SALDOSSIER&& από &&SALDATE[10]&& Σύμβαση Πίστωσης Ανοικτού Λογ/σμού, μετά των μεταγενεστέρων πρόσθετων πράξεων αυτής από Νο &&SALADDMIN&& έως Νο &&SALADDMAX&& συνολικού ποσού &&SALLIMIT&&";
    public static final String MC01 = "Χορήγηση Δανείου σε Συνάλλαγμα με βάση την υπ'αριθ.";
    public static final String P01C2 = "&&SALDOSSIER&& από &&SALDATE[10]&& Σύμβαση Πίστωσης Ανοικτού Λογ/σμού συνολικού ποσού &&SALLIMIT&&";
    public static final String P02C1 = "&&CONTRACT&& Σύμβαση Δανείου, σε συσχετισμό με την υποθήκη μέσω της υπ' αριθ &&COURTNUM&& από &&COURTDATE&& Σύμβαση Υποθήκης του Συμβολαιογράφου κ &&COURTNAME&&";
    public static final String P02C2 = "&&CONTRACT&& Σύμβαση Δανείου, σε συσχετισμό με την Προσημείωση απόφασης του Προέδρου Πρωτοδικών.";
    public static final String P02C3 = "&&CONTRACT&& Σύμβαση Δανείου, εξασφαλισμένου μέσω υποθηκοπροσημειώσεων.";
    public static final String P03C0 = "&&CONTRACT&& Σύμβαση Δανείου.";
    public static final String P03C1 = "Χορήγηση δυνάμει της υπ'αριθμ. &&CONTRACT&& από &&SALDATE1[10]&&.";
    public static final String P05C1 = "&&SALDOSSIER&& από &&SALDATE[10]&& Σύμβαση Πίστωσης Ανοικτού Λογ/σμού, μετά των μεταγενεστέρων πρόσθετων πράξεων αυτής από Νο &&SALADDMIN&& έως Νο &&SALADDMAX&& συνολικού ποσού &&SALLIMIT&& σε συσχετισμό με την υποθήκη μέσω της υπ' αριθ &&COURTNUM&& από &&COURTDATE&& Σύμβαση Υποθήκης του Συμβολαιογράφου κ &&COURTNAME&&";
    public static final String P05C5 = "&&SALDOSSIER&& από &&SALDATE[10]&& Σύμβαση Πίστωσης Ανοικτού Λογ/σμού, μετά των μεταγενεστέρων πρόσθετων πράξεων αυτής από Νο &&SALADDMIN&& έως Νο &&SALADDMAX&& συνολικού ποσού &&SALLIMIT&& εξασφαλισμένου μέσω υποθηκοπροσημειώσεων.";
    public static final String P05C2 = "&&SALDOSSIER&& από &&SALDATE[10]&& Σύμβαση Πίστωσης Ανοικτού Λογ/σμού, μετά των μεταγενεστέρων πρόσθετων πράξεων αυτής από Νο &&SALADDMIN&& έως Νο &&SALADDMAX&& συνολικού ποσού &&SALLIMIT&& σε συσχετισμό με την Προσημείωση απόφασης του Προέδρου Πρωτοδικών.";
    public static final String P05C3 = "&&SALDOSSIER&& από &&SALDATE[10]&& Σύμβαση Πίστωσης Ανοικτού Λογ/σμού συνολικού ποσού &&SALLIMIT&& σε συσχετισμό με την υποθήκη μέσω της υπ' αριθ &&COURTNUM&& από &&COURTDATE&& Σύμβαση Υποθήκης του Συμβολαιογράφου κ &&COURTNAME&&";
    public static final String P05C6 = "&&SALDOSSIER&& από &&SALDATE[10]&& Σύμβαση Πίστωσης Ανοικτού Λογ/σμού συνολικού ποσού &&SALLIMIT&& εξασφαλισμένου μέσω υποθηκοπροσημειώσεων.";
    public static final String P05C4 = "&&SALDOSSIER&& από &&SALDATE[10]&& Σύμβαση Πίστωσης Ανοικτού Λογ/σμού συνολικού ποσού &&SALLIMIT&& σε συσχετισμό με την Προσημείωση απόφασης του Προέδρου Πρωτοδικών.";
    public static final String P06C1 = ", μετά των μεταγενεστέρων πρόσθετων πράξεων αυτής από Νο &&SALADDMIN&& έως Νο &&SALADDMAX&& συνολικού ποσού &&SALLIMIT&&";
    public static final String P06C2 = "συνολικού ποσού &&SALLIMIT&&";
    public static final String P07C1 = ", μετά των μεταγενεστέρων πρόσθετων πράξεων αυτής από Νο &&SALADDMIN&& έως Νο &&SALADDMAX&& συνολικού ποσού &&SALLIMIT&& σε συσχετισμό με την υποθήκη μέσω της υπ' αριθ &&COURTNUM&& από &&COURTDATE&& Σύμβαση Υποθήκης του Συμβολαιογράφου κ &&COURTNAME&&";
    public static final String P07C5 = ", μετά των μεταγενεστέρων πρόσθετων πράξεων αυτής από Νο &&SALADDMIN&& έως Νο &&SALADDMAX&& συνολικού ποσού &&SALLIMIT&& εξασφαλισμένου μέσω υποθηκοπροσημειώσεων";
    public static final String P07C2 = ", μετά των μεταγενεστέρων πρόσθετων πράξεων αυτής από Νο &&SALADDMIN&& έως Νο &&SALADDMAX&& συνολικού ποσού &&SALLIMIT&& σε συσχετισμό με την Προσημείωση απόφασης του Προέδρου Πρωτοδικών.";
    public static final String P07C3 = "συνολικού ποσού &&SALLIMIT&& σε συσχετισμό με την υποθήκη μέσω της υπ' αριθ &&COURTNUM&& από &&COURTDATE&& Σύμβαση Υποθήκης του Συμβολαιογράφου κ &&COURTNAME&&";
    public static final String P07C6 = "συνολικού ποσού &&SALLIMIT&& εξασφαλισμένου μέσω υποθηκοπροσημειώσεων";
    public static final String P07C4 = "συνολικού ποσού &&SALLIMIT&& σε συσχετισμό με την Προσημείωση απόφασης του Προέδρου Πρωτοδικών.";
    public static final String P0607 = "Εναντι λογ/σμού με βάση την υπ'αριθ. &&SALDOSSIER&& από &&SALDATE[10]&& Σύμβαση Πίστωσης Ανοικτού Λογ/σμού";
    public static final String P0105 = "Χορήγηση Δανείου με βάση την υπ'αριθ.";
    public static final String P0608B = "Κάλυψη Ομολογιακού Δανείου";
    public static final String P0608K = "Κάλυψη Ομολογιακού Κοινοπρακτικού Δανείου";
    public static final String P0608S = "Κάλυψη Κοινοπρακτικού Δανείου";
    public static final String RYT = "Ρύθμιση υπολοίπου οφειλής προερχομένου από την χορήγηση &&RELATION&& δανείου, αρχικού ποσού &&OLDOPENING&&, χορηγηθέν με την υπ'αρ &&OLDCONTRACT&&&&OLDLEGCONTR&& σύμβαση δανείου. Μεταφορά από λογαριασμό &&OLDACCOUNT&& σε λογαριασμό &&NEWACCOUNT&& δυνάμει προσθέτου συμφώνου που υπογράφτηκε στις &&SIGNDATE&&)";
    public static final String P99 = "Κόστος αξιολόγησης αιτήματος";
    public static final String R99 = "Εφάπαξ δαπάνη σύμβασης εκχωρ. ενεχ. κτθ τίτλων";
    public static final String P14 = "Εφάπαξ Δαπάνη νομικού ή/και τεχνικού ελέγχου";
    public static final String P66 = "για την εκταμίευση &&TAMOUNT&& Ενταλμα Πληρωμής Νο &&NumOper&& &&CodDom&& &&NumNod&&";
    public static final String WORKING_CAPITAL = "28";
    public static final String LETTER_OF_GUARANTEE = "24";
    public static final String GREEK = "el";
    public static final String ENGLISH = "en";
}
