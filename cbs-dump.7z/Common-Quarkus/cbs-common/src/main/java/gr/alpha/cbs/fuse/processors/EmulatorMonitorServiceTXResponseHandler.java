package gr.alpha.cbs.fuse.processors;

import gr.alpha.cbs.fuse.legacy.EmulatorMonitorServiceTXResponse;
import gr.alpha.cbs.fuse.legacy.ErrorMessageType;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import gr.alpha.cbs.fuse.legacy.ObjectFactory;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

@Named("emulatorMonitorServiceTXResponseHandler")
@ApplicationScoped
@RegisterForReflection
public class EmulatorMonitorServiceTXResponseHandler implements Processor {

	private static final Logger LOGGER = Logger.getLogger(EmulatorMonitorServiceTXResponseHandler.class);
	
	public void process(Exchange exchange){
			
		ObjectFactory factory = new ObjectFactory();
		Document doc = exchange.getIn().getBody(Document.class);

		EmulatorMonitorServiceTXResponse response = factory.createEmulatorMonitorServiceTXResponse();
		
		NodeList errorlist = doc.getElementsByTagName("ErrorMessage");
	
		if(errorlist.getLength() == 0) {
			LOGGER.info("ErrorMessage not detected. Service succeeded");

			String cdata = FormatUtils.getValue(doc, "/*[1]");
			response.setResponse(cdata);
		} else {
			LOGGER.info("ErrorMessage element is: " + errorlist.item(0).toString());
			
			ErrorMessageType type = new ErrorMessageType();
			type.setErrorType(FormatUtils.getValue(doc, "//*:ErrorMessage/*:ErrorType"));
			type.setSourceSystem(FormatUtils.getValue(doc, "//*:ErrorMessage/*:SourceSystem"));
			type.setComponent(FormatUtils.getValue(doc, "//*:ErrorMessage/*:Component"));
			type.setErrorCode(FormatUtils.getValue(doc, "//*:ErrorMessage/*:ErrorCode"));
			type.setSeverityLevel(FormatUtils.getValue(doc, "//*:ErrorMessage/*:SeverityLevel"));
			type.setSuggestions(FormatUtils.getValue(doc, "//*:ErrorMessage/*:Suggestions"));
			type.setDescription(FormatUtils.getValue(doc, "//*:ErrorMessage/*:Description"));
			type.setServerName(FormatUtils.getValue(doc, "//*:ErrorMessage/*:ServerName"));
			type.setParameterValues(FormatUtils.getValue(doc, "//*:ErrorMessage/*:ParameterValues"));
			response.setErrorMessage(type);
		}
		
		LOGGER.info("ErrorMessage before setBopdy is : " + response.toString());
		
		exchange.getIn().setBody(response);
	}
	
}
