package gr.alpha.cbs.fuse.kie;

import java.util.List;

public interface ItemList<T> {

    List<T> getItems();
}
