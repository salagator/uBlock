package gr.alpha.cbs.fuse.masking;

public class GenericMask implements IMask{

	@Override
	public String mask(String value , int length) {
		StringBuilder builder = new StringBuilder(value.substring(0,1));
		for(int i=1;i<value.length()-1;i++){
			builder.append("*");
		}
		builder.append(value.substring(value.length()-1));
		return builder.toString();
	}
}
