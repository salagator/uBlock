package gr.alpha.cbs.fuse.service;

import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import io.smallrye.faulttolerance.api.RateLimitException;
import io.smallrye.faulttolerance.api.RateLimitType;
import io.smallrye.faulttolerance.api.TypedGuard;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.eclipse.microprofile.faulttolerance.exceptions.BulkheadException;
import org.eclipse.microprofile.faulttolerance.exceptions.CircuitBreakerOpenException;
import org.eclipse.microprofile.faulttolerance.exceptions.TimeoutException;
import org.jboss.resteasy.reactive.RestResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.CompletionStage;

public interface RESTAPIHelper {
    Logger logger = LoggerFactory.getLogger(RESTAPIHelper.class);

    Map<String, Object> getHeaders(String operation, Element requestRootElement);

    void setServiceOperationInfo(String flowName, String operation, Map<String, Object> property);

    String getConsumer(String operation);

    /**
     * Override in case where there are operations that should be handled asynchronously.
     * This would be so that @Bulkhead for the operation.
     *
     * @return a set of operation names
     */
    default Set<String> asynchronousOperations() {
        return Set.of();
    }

    /**
     * Override this to set up fault tolerance for various operations.
     * If overridden, make sure to initialize the map only once by setting an
     * instance variable to the return value of this method in the constructor.
     * Otherwise, the fault tolerance logic will not work correctly.
     * Also make sure that the map is synchronized.
     * @return the map from operation name to FaultTolerance instance.
     */
    default Map<String, TypedGuard<RestResponse<String>>> getTypedGuardMap() {
        return new HashMap<>();
    }

    /**
     * Re-initialize the typed guard map. Called from the clearFaultToleranceGuards()
     * method that is used to re-read the fault tolerance settings from the datagrid.
     */
    default void reinitializeTypedGuardMap() {
    }

    /**
     * Override this to set up fault tolerance for various operations.
     * If overridden, make sure to initialize the map only once by setting an
     * instance variable to the return value of this method in the constructor.
     * Otherwise, the fault tolerance logic will not work correctly.
     * Also make sure that the map is synchronized.
     * @return the map from operation name to FaultTolerance instance.
     */
    default Map<String, TypedGuard<CompletionStage<RestResponse<String>>>> getAsynchronousTypedGuardMap() {
        return new HashMap<>();
    }

    /**
     * Re-initialize the typed guard map. Called from the clearFaultToleranceGuards()
     * method that is used to re-read the fault tolerance settings from the datagrid.
     */
    default void reinitializeAsynchronousTypedGuardMap() {
    }

    default RestResponse<String> handleCircuitBreakerOpenException(String operation, Object input, CircuitBreakerOpenException exception) {
        logger.error("Handling Circuit Breaker Open Exception: " + exception.getMessage() + ". " +
                "This method should not be called. Implementors that use circuit breaker functionality " +
                "should override RESTAPIHelper.handleCircuitBreakerOpenException() " +
                "to provide a custom implementation.");
        throw exception;
    }

    default RestResponse<String> handleBulkheadException(String operation, Object input, BulkheadException exception) {
        logger.error("Handling Bulkhead Exception: " + exception.getMessage() + ". " +
                "This method should not be called. Implementors that use bulkhead functionality " +
                "should override RESTAPIHelper.handleBulkheadException() " +
                "to provide a custom implementation.");
        throw exception;
    }

    default RestResponse<String> handleTimeoutException(String operation, Object input, TimeoutException exception) {
        logger.error("Handling Timeout Exception: " + exception.getMessage() + ". " +
                "This method should not be called. Implementors that use timeout functionality " +
                "should override RESTAPIHelper.handleTimeoutException() " +
                "to provide a custom implementation.");
        throw exception;
    }

    default RestResponse<String> handleRateLimitException(String operation, Object input, RateLimitException exception) {
        return RestResponse.status(429, "Too Many Requests");
    }

    default void setDatagridHelper(RemoteDatagridClientHelper<String, String> datagridHelper) {
        // default implementation does nothing
    }

    default RemoteDatagridClientHelper<String, String> getDatagridHelper() {
        // Override in case where datagridHelper is needed
        return null;
    }


    default int getIntegerConfigValue(String operation, String configSuffix, int defaultValue) {
        if (getDatagridHelper() != null) {
            String configKey = this.getClass().getSimpleName() + operation + configSuffix;
            logger.info("Looking up config key {} in datagrid.", configKey);
            String cachedValue = getDatagridHelper().get(configKey);
            if (cachedValue == null) {
                return defaultValue;
            }
            return Integer.parseInt(cachedValue);
        }
        return defaultValue;
    }

    default double getDoubleConfigValue(String operation, String configSuffix, double defaultValue) {
        if (getDatagridHelper() != null) {
            String configKey = this.getClass().getSimpleName() + operation + configSuffix;
            logger.info("Looking up config key {} in datagrid.", configKey);
            String cachedValue = getDatagridHelper().get(configKey);
            if (cachedValue == null) {
                return defaultValue;
            }
            return Double.parseDouble(cachedValue);
        }
        return defaultValue;
    }

    default ChronoUnit getChronoUnitConfigValue(String operation, String configSuffix, ChronoUnit defaultValue) {
        if (getDatagridHelper() != null) {
            String configKey = this.getClass().getSimpleName() + operation + configSuffix;
            logger.info("Looking up config key {} in datagrid.", configKey);
            String cachedValue = getDatagridHelper().get(configKey);
            if (cachedValue == null) {
                return defaultValue;
            }
            return ChronoUnit.valueOf(cachedValue);
        }
        return defaultValue;
    }

    default RateLimitType getRateLimitTypeConfigValue(String operation, String configSuffix, RateLimitType defaultValue) {
        if (getDatagridHelper() != null) {
            String configKey = this.getClass().getSimpleName() + operation + configSuffix;
            logger.info("Looking up config key {} in datagrid.", configKey);
            String cachedValue = getDatagridHelper().get(configKey);
            if (cachedValue == null) {
                return defaultValue;
            }
            return RateLimitType.valueOf(cachedValue);
        }
        return defaultValue;
    }

    /**
     * Override in case where the response payload should be wrapped.
     *
     * @return true/false
     */
    default ResponseLayout keepRootElement(){
        return ResponseLayout.WRAP;
    }

    /**
     * Override in case the initial request will be handled as is.
     * @return
     */
    default boolean requestWithPayloadOnly(){
        return true;
    }

    /**
     * Override in order to perform special customization for EnvParamsType dates.
     * @return a list of strings of the class names of EnvParamsType that you want
     * to be modified
     */
    default List<String> getEnvParamsTypes() {
        return new ArrayList<>();
    }

    /**
     * Override in order to perform special customization for LoggingInfoType dates.
     * @return a list of strings of the class names of LoggingInfoType that you want
     * to be modified
     */
    default List<String> getLoggingInfoTypes() {
        return new ArrayList<>();
    }

    /**
     * Temporary stop-gap measure to use the alternative error handling mechanism.
     * Default implementation returns false (which means that the error handling
     * is done as per the normal CBS way: HTTP 200 status is returned with the
     * presence of an error element in the response payload). Override to return true
     * in order to use the alternative error handling mechanism (HTTP 422 status is returned
     * with extra information in the response payload).
     */
    default boolean useAlternativeErrorHandling() {
        return false;
    }
}
