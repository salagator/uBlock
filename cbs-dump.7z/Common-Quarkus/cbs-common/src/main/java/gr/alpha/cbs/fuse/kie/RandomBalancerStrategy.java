//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

import java.util.ArrayList;
import java.util.List;

public class RandomBalancerStrategy extends AbstractBalancerStrategy {
    private List<String> availableEndpoints = new ArrayList();

    public RandomBalancerStrategy(List<String> availableEndpoints) {
        availableEndpoints.forEach((endpoint) -> this.markAsOnline(endpoint));
    }

    public String next() {
        this.checkEmpty(this.availableEndpoints);
        if (this.availableEndpoints.size() == 1) {
            return (String)this.availableEndpoints.get(0);
        } else {
            int index = this.getRandomInt(0, this.availableEndpoints.size() - 1);
            return (String)this.availableEndpoints.get(index);
        }
    }

    public String markAsOffline(String url) {
        this.checkEmpty(this.availableEndpoints);
        synchronized(this.availableEndpoints) {
            this.checkEmpty(this.availableEndpoints);
            String baseUrl = this.locateUrl(this.availableEndpoints, url);
            this.availableEndpoints.remove(baseUrl);
            return baseUrl;
        }
    }

    public String markAsOnline(String url) {
        synchronized(this.availableEndpoints) {
            String baseUrl = this.locateUrl(this.availableEndpoints, url);
            if (!this.availableEndpoints.contains(baseUrl)) {
                this.availableEndpoints.add(baseUrl);
            }

            return baseUrl;
        }
    }

    public List<String> getAvailableEndpoints() {
        return new ArrayList(this.availableEndpoints);
    }

    protected int getRandomInt(int min, int max) {
        return (int)Math.floor(Math.random() * (double)(max - min + 1)) + min;
    }

    public String toString() {
        return "RandomBalancerStrategy{availableEndpoints=" + this.availableEndpoints + '}';
    }
}
