package gr.alpha.cbs.fuse.ifaces;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import gr.alpha.cbs.fuse.tools.CodeValue;

public interface ProductStudioInterface {
	
	String getProductDetailsXML(Integer productId, Integer productVersion, Integer productAttributeCode, Integer languageId) throws Exception;
		
	String getProductDetailsByDateXML(Integer productId, String productDate, Integer productAttributeCode, Integer languageId) throws Exception;
	
	String getProductListWithFiltersXML(String workingDate, Integer languageId, List<CodeValue> filteringAttributes) throws Exception;
	
	
	HashMap <String,List<Integer>> getProductAttributeValuesLists(Integer productId, Integer productVersion, List<Integer> productAttributeCodes) throws Exception;
	
	HashMap <String,List<Integer>> getProductAttributeValuesLists(Integer productId, Integer productVersion, List<Integer> productAttributeCodes, Integer languageId) throws Exception;
	
	HashMap <String,List<Integer>> getProductAttributeValuesListsByDate(Integer productId, String productDate, List<Integer> productAttributeCodes) throws Exception;
	
	HashMap <String,List<Integer>> getProductAttributeValuesListsByDate(Integer productId, String productDate, List<Integer> productAttributeCodes, Integer languageId) throws Exception;
	
	HashMap <String,List<String>> getProductAttributeRealValuesLists(Integer productId, Integer productVersion, List<Integer> productAttributeCodes) throws Exception;
	
	HashMap <String,List<String>> getProductAttributeRealValuesLists(Integer productId, Integer productVersion, List<Integer> productAttributeCodes, Integer languageId) throws Exception;
	
	HashMap <String,List<String>> getProductAttributeRealValuesListsByDate(Integer productId, String productDate, List<Integer> productAttributeCodes) throws Exception;
	
	HashMap <String,List<String>> getProductAttributeRealValuesListsByDate(Integer productId, String productDate, List<Integer> productAttributeCodes, Integer languageId) throws Exception;
	
	HashMap <String,String> getProductAttributeNamesListsByDate(Integer productId, String productDate, List<Integer> productAttributeCodes) throws Exception;
	
	HashMap <String,String> getProductAttributeNamesListsByDate(Integer productId, String productDate, List<Integer> productAttributeCodes, Integer languageId) throws Exception;
	
	HashMap <String,String> getProductAttributeNamesListsByVersion(Integer productId, Integer productVersion, List<Integer> productAttributeCodes, Integer languageId) throws Exception;
	
	Map<String, HashMap<String,String>> getProductAttributeMetadata(String productAttributeCode, String glCode) throws Exception;
	
	HashMap<String, Boolean> getAccountProfile(String transactionID, Integer profileID, Integer productId, Integer carrierID) throws Exception;
	
	Map<String, List<String>> getInterestRateCategoriesByProductId(Integer productId, Integer productVersion, Integer isNormalDebitSpread, Integer languageId, Integer currencyCode) throws Exception;
	
	Map<String, String> getInterestRatesByProductIDandCategoryID(Integer productId, Integer productVersion, String interestCategory, BigDecimal debitSpread, BigDecimal creditSpread, Integer unitsOrPercentageCR, Integer unitsOrPercentageDB, Integer isNormalDebitSpread, Integer languageId, Integer currencyCode) throws Exception;
	
	HashMap <String,String> getProductDetailsByVersion(Integer productId, Integer productVersion, Integer languageId) throws Exception;
	
	HashMap<String, List<String>> getInterestRatesAuthorizationsByInterestCategory(Integer productCode, Integer productVersion, String productCategory, Integer carrierID, Integer currencyCode) throws Exception;
	
	HashMap<String, HashMap<String,String>> getInterestRateAuthorizationsList(Integer productCode, Integer productVersion, Integer carrierID, Integer currencyCode) throws Exception;
	
}
