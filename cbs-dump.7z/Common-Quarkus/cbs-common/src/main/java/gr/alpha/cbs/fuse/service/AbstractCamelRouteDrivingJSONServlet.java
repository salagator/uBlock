package gr.alpha.cbs.fuse.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import gr.alpha.cbs.fuse.common.tools.AlternativePathsFlagHolder;
import io.quarkus.runtime.LaunchMode;
import jakarta.inject.Inject;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import javax.xml.XMLConstants;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import gr.alpha.cbs.fuse.exceptions.BadRequestException;
import gr.alpha.cbs.fuse.support.NonCopyingByteArrayOutputStream;
import gr.alpha.cbs.fuse.tools.*;
import gr.alpha.cbs.fuse.logging.LoggingMDCInterceptor;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpHeaderValues;
import io.netty.handler.codec.http.HttpResponseStatus;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.support.DefaultExchange;
import org.apache.commons.io.IOUtils;

import org.apache.hc.core5.http.HttpStatus;
import org.eclipse.microprofile.config.ConfigProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import gr.alpha.cbs.fuse.common.logging.LoadLoggingHelper;

public abstract class AbstractCamelRouteDrivingJSONServlet extends HttpServlet implements SerializationHelper {
    private static final long serialVersionUID = -2461207879902892565L;

    private static final Logger logger = LoggerFactory.getLogger(AbstractCamelRouteDrivingJSONServlet.class);

    @Inject
    CamelContext camelContext;

    @Inject
    LoggingMDCInterceptor loggingMDCInterceptor;

    private static final int MAX_RESPONSE_SIZE = 10000;
    private static final boolean TRIMMING_RESPONSE = Boolean.parseBoolean(ConfigProvider.getConfig().getOptionalValue("do.not.trim.camel.responses", String.class).orElse("true"));
    private static final String CBS_ERROR = "https://alpha.gr/cbs/general-error";

    /*
     * The following four member variables are state that is used as a performance optimization.
     * Construction of the Jackson ObjectMapper is expensive and is only done once in the
     * initialization of this object. According to the documentation, keeping and reusing
     * ObjectReader and ObjectWriter objects is thread-safe and light weight:
     * https://fasterxml.github.io/jackson-databind/javadoc/2.8/com/fasterxml/jackson/databind/ObjectReader.html
     * https://fasterxml.github.io/jackson-databind/javadoc/2.8/com/fasterxml/jackson/databind/ObjectWriter.html
     * So we cache them in the respective <code>HashMap</code>, keyed by the class name they
     * "represent".
     *
     * Similarly, construction of the JAXBContext is also expensive, so we only do it lazily
     * the first time a particular class is marshalled or unmarshalled. We cache such objects
     * in a <code>HashMap</code>, keyed by the class name they "represent".
     */
    private ObjectMapper objectMapper;
    private Map<String, JAXBContext> jaxbContextMap;
    private Map<String, ObjectReader> objectReaderMap;
    private Map<String, ObjectWriter> objectWriterMap;

    protected abstract Map<String, Object> getHeaders(String operation, Element requestRootElement);

    // It should be Implemented to Set 3 Importanst Headers
    // 1 Operation Name map.put(CBSConstants.HEADER_TRANSACTION_NAME,operation)
    // 2 Flow Name hardCoded from EventRegistry map.put(CBSConstants.HEADER_TRANSACTION_FLOW, flow-name )
    // 3 Service Name "hard coded for each service"
    protected abstract void setServiceOperationInfo(String flowName, String operation, Map<String, Object> property);

    @Override
    public void init() throws ServletException {
        super.init();

        logger.info("Initializing JSON servlet.");

        objectMapper = initObjectMapper();

        jaxbContextMap = new HashMap<>();
        objectReaderMap = new HashMap<>();
        objectWriterMap = new HashMap<>();
    }

    @Override
    public void destroy() {
        super.destroy();
        jaxbContextMap.clear();
        objectReaderMap.clear();
        objectWriterMap.clear();
    }

    @Override
    protected void doGet(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws ServletException, IOException {
        httpServletResponse.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
    }

    @Override
    protected void doPost(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws ServletException, IOException {
        long startTime = System.currentTimeMillis();

        try {
            String operation = null;
            String flowName = null;
            Element requestRootElement = null;

            if (logger.isDebugEnabled()) {
                logger.debug("URI requested is: {}.", httpServletRequest.getRequestURI());
            }

            String operationName = httpServletRequest.getPathInfo();
            operationName = operationName.startsWith("/") ? operationName.substring(1) : operationName;

            logger.info("Operation name from servlet is: {}", operationName);

            long readingServletStartTime = System.currentTimeMillis();
            NonCopyingByteArrayOutputStream servletBodyContents = new NonCopyingByteArrayOutputStream();
            IOUtils.copy(httpServletRequest.getInputStream(), servletBodyContents);
            String servletBodyContentsAsString = new String(
                    servletBodyContents.getBuffer(), 0, servletBodyContents.size(), StandardCharsets.UTF_8);

            logger.info("Reading servlet input stream took {}ms.", System.currentTimeMillis() - readingServletStartTime);

            logger.info("RequestId header is: '{}'.", httpServletRequest.getHeader("RequestId"));
            logger.info("UserId header is: '{}'.", httpServletRequest.getHeader("UserId"));
            logger.info("PageKey header is: '{}'.", httpServletRequest.getHeader("PageKey"));
            logger.info("PageSize header is: '{}'.", httpServletRequest.getHeader("PageSize"));
            logger.info("Language header is: '{}'.", httpServletRequest.getHeader("language"));
            logger.info("ChannelTypeCode header is: '{}'.", httpServletRequest.getHeader("channelTypeCode"));
            logger.info("JSON Body is: '{}'.", servletBodyContentsAsString);

            if (!servletBodyContentsAsString.contains("envParams")) {
                long adornHeadersStartTime = System.currentTimeMillis();

                // EnvParams is missing from the request. It must be a call from an external system, that knows not
                // of CBS intricacies. Call the adorn headers micro service to "tack on" the logging info and
                // env parameters necessary for the Fuse call to work properly. The servletBodyContents object (and
                // most importantly its underlying buffer) is modified in the process accordingly.
                servletBodyContents = adornHeaders(httpServletRequest, objectMapper, servletBodyContents);

                logger.info("Calling adorn headers took {}ms.", System.currentTimeMillis() - adornHeadersStartTime);
            }

            long conversionToXMLStartTime = System.currentTimeMillis();

            Document requestDocument;
            try {
                requestDocument = getInputDocument(
                        new ByteArrayInputStream(servletBodyContents.getBuffer(), 0, servletBodyContents.size()),
                        operationName, objectMapper, jaxbContextMap, objectReaderMap);
                requestRootElement = requestDocument.getDocumentElement();
                operation = requestRootElement.getLocalName();
            } catch (Exception e) {
                logger.error("Unable to parse JSON input", e);
                httpServletResponse.setStatus(HttpStatus.SC_BAD_REQUEST);
                return;
            }

            logger.info("Conversion to XML took {}ms.", System.currentTimeMillis() - conversionToXMLStartTime);

            DOMSource inputDOMSource = new DOMSource(requestRootElement);
            loggingMDCInterceptor.processMessageIn(inputDOMSource);

            if (logger.isDebugEnabled()) {
                logger.debug("Operation called: '" + operation + "'.");
            }

            AlternativePathsFlagHolder.setAlternativePathsFlag(
                    ConfigProvider.getConfig().getOptionalValue("cbs.common.tools.formatutils.alternativepaths", Boolean.class).orElse(false)
            );
            Boolean operationSpecificSetting =
                    ConfigProvider.getConfig().getOptionalValue("cbs.common.tools.formatutils." + operation + ".alternativepaths", Boolean.class).orElse(null);
            if (operationSpecificSetting != null) {
                AlternativePathsFlagHolder.setAlternativePathsFlag(operationSpecificSetting);
            }

            // Get the headers from the concrete class
            Map<String, Object> headers = getHeaders(operation, requestRootElement);

            if(headers.containsKey(CBSConstants.HEADER_XSD_PATHS)){
                logger.info("XML after deserialization is: {}", formatNodeToString(operation, requestDocument));
                boolean xsdValidation = validateXMLSchema((String[]) headers.get(CBSConstants.HEADER_XSD_PATHS), requestDocument);
                logger.info("XSD validation result:" + xsdValidation);
                if(!xsdValidation){
                    throw new BadRequestException("XSD validation failed");
                }
            }

            if (LaunchMode.current().isDevOrTest()) {
                camelContext.setMessageHistory(true);
            }
            ProducerTemplate producerTemplate = camelContext.createProducerTemplate();

            Element payload = getXMLRootElement(requestRootElement);
            flowName = payload.getLocalName();

            // Log the input
            logger.info("Call web service " + flowName + "." + operation + " RequestBody:\n" + formatNodeToString(operation, requestRootElement));

            setServiceOperationInfo(flowName, operation, headers);

            // Perform the call to the camel route (to the template first, which
            // will call the proper route passed in the header above).
            Exchange exchange = new DefaultExchange(camelContext);
            headers.forEach(exchange::setProperty);
            exchange.getIn().setBody(payload);
            Object r = producerTemplate.send(getConsumer(operation),exchange).getIn().getBody();

            // Abnormal condition all exception should be handled by camel routes
            if (exchange.getException() != null){
                throw new RuntimeException(exchange.getException());
            }

            // Capture point of errorCode for Dynatrace monitoring purposes
            AppMonitoringHelper.captureErrorCode(exchange);

            Document s = camelContext.getTypeConverter().convertTo(Document.class, r);

            Document responseDocument = createResponse(s,operation);

            httpServletResponse.setStatus(HttpResponseStatus.OK.code());
            httpServletResponse.setContentType(HttpHeaderValues.APPLICATION_JSON.toString());
            httpServletResponse.setCharacterEncoding(StandardCharsets.UTF_8.toString());
            NonCopyingByteArrayOutputStream outputStream = new NonCopyingByteArrayOutputStream();
            writeOutputDocument(outputStream, operationName, responseDocument, objectMapper,
                    jaxbContextMap, objectWriterMap);
            String jsonResponse = new String(outputStream.getBuffer(), 0, outputStream.size(), StandardCharsets.UTF_8);

            // Severity level 4 is a warning. Should not barf error status in that case.
            if (jsonResponse.contains("\"errorMessage\"") && !jsonResponse.contains("\"severityLevel\":\"4\"")) {
                // There was an error message in the response. Convert it to ProblemDetails representation and return problematic status code.
                jsonResponse = modifyResponseInThePresenceOfError(httpServletRequest, httpServletResponse, objectMapper, exchange, outputStream, jsonResponse);
            } else {
                // Normal case
                try (OutputStream responseOutputStream = httpServletResponse.getOutputStream()) {
                    responseOutputStream.write(outputStream.getBuffer(), 0, outputStream.size());
                }
            }

            long duration = System.currentTimeMillis() - startTime;

            // Log the output
            logger.info("Call web service " + flowName + "." + operation +" Took " + duration + "ms. " + "ResponseBody:\n"
                    + formatNodeToString(operation, responseDocument));
            logger.info("JSON Response: {}", jsonResponse);

            LoadLoggingHelper.createMessage("FUSE", operation, duration);

        } catch (BadRequestException | JsonMappingException e ) {
            logger.error("JSON parsing failed or XSD Validation failed or something went wrong while adding env params", e);
            httpServletResponse.setStatus(HttpResponseStatus.BAD_REQUEST.code());
        } catch (TransformerFactoryConfigurationError | TransformerException | IOException |
                ParserConfigurationException | ClassNotFoundException | JAXBException | CBSException  e) {
            logger.error("Unable to process web service call", e);
            httpServletResponse.setStatus(HttpResponseStatus.INTERNAL_SERVER_ERROR.code());
        } finally {
            loggingMDCInterceptor.processMessageOut();
        }
    }

    @SuppressWarnings({"deprecation", "unchecked"})
    private NonCopyingByteArrayOutputStream adornHeaders(HttpServletRequest httpServletRequest, ObjectMapper mapper, NonCopyingByteArrayOutputStream servletBodyContents) throws IOException, BadRequestException, CBSException {
        String flowName;
        JsonNode requestJSON = mapper.readTree(
                new ByteArrayInputStream(servletBodyContents.getBuffer(), 0, servletBodyContents.size()));
        flowName = requestJSON.fieldNames().next();

        JsonNodeFactory jsonNodeFactory = new JsonNodeFactory(false);
        ObjectNode requestToAdornHeaders = new ObjectNode(jsonNodeFactory);

        String userId = Optional.ofNullable(httpServletRequest.getHeader("UserId")).orElseThrow(BadRequestException::new);
        String requestId =  Optional.ofNullable(httpServletRequest.getHeader("RequestId")).orElseThrow(BadRequestException::new);
        String language = httpServletRequest.getHeader("language");
        String channelTypeCode = httpServletRequest.getHeader("channelTypeCode");

        Map<String,String> envParams = Collections.emptyMap();
        if (language != null || channelTypeCode != null) {
            envParams = new HashMap<>();
            if (language != null) {
                envParams.put("language", language);
            }
            if (channelTypeCode != null) {
                envParams.put("channelTypeCode", channelTypeCode);
            }
        }
        requestToAdornHeaders.set("envParams", mapper.convertValue(envParams, ObjectNode.class));

        Map<String,String> loggingInfo = Stream.of(new String [][] {
                {"requestId", requestId},
                {"userId", userId}
        }).collect(Collectors.toMap(kv -> kv[0], kv -> kv[1]));
        requestToAdornHeaders.set("loggingInfo", mapper.convertValue(loggingInfo, ObjectNode.class));

        try {
            String adornHeadersEndpoint = ConfigProvider.getConfig().getValue("cbs.mw.adorn.headers.endpoint", String.class);
            logger.info("Using {} as the endpoint to call the adorn headers micro service", adornHeadersEndpoint);
            String requestToAdornHeadersAsString = mapper.writeValueAsString(requestToAdornHeaders);
//            if (logger.isDebugEnabled()) {
                logger.info("Adorn headers micro service called with :" + requestToAdornHeadersAsString);
//            }
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .header(HttpHeaderNames.CONTENT_TYPE.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
                    .header(HttpHeaderNames.ACCEPT.toString(), HttpHeaderValues.APPLICATION_JSON.toString())
                    .POST(HttpRequest.BodyPublishers.ofString(requestToAdornHeadersAsString))
                    .uri(new URI(adornHeadersEndpoint + "/adorn"))
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == HttpResponseStatus.OK.code()) {
                JsonNode responseJSON = mapper.readTree(response.body());
                loggingInfo = mapper.convertValue(responseJSON.findPath("loggingInfo"), Map.class);
                envParams = mapper.convertValue(responseJSON.findPath("envParams"), Map.class);
            } else {
                throw new Exception("Unable to contact the adorn headers micro service (" + response.statusCode() + ").");
            }
        } catch (Exception e) {
            logger.error("Exception while calling the adorn headers service.", e);
            throw new CBSException(ErrorTypeModel.createErrorModel(
                    ErrorTypeModel.ERROR_TYPE_TECHNICAL,
                    ErrorTypeModel.ERROR_SYSTEM_ID_BPM,
                    "JSONProvider",
                    ErrorTypeModel.DEFAULT_ERROR_CODE,
                    ErrorTypeModel.SEVERITY_SEVERE,
                    e.getMessage()
            ));
        }

        envParams.compute("pageKey", (k,v) -> Optional.ofNullable(httpServletRequest.getHeader("PageKey")).orElse(v));
        envParams.compute("pageSize", (k,v) -> Optional.ofNullable(httpServletRequest.getHeader("PageSize")).orElse(v));

        ObjectNode requestPayload = (ObjectNode) requestJSON.path(flowName);
        requestPayload.set("loggingInfo", mapper.convertValue(loggingInfo, ObjectNode.class));
        requestPayload.set("envParams",  mapper.convertValue(envParams, ObjectNode.class));

        logger.debug("Final request JSON: " + requestJSON.toString());

        servletBodyContents = new NonCopyingByteArrayOutputStream();
        IOUtils.copy(new ByteArrayInputStream(
                requestJSON.toString().getBytes(StandardCharsets.UTF_8)), servletBodyContents);
        return servletBodyContents;
    }

    private String modifyResponseInThePresenceOfError(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, ObjectMapper mapper, Exchange exchange, NonCopyingByteArrayOutputStream outputStream, String jsonResponse) throws IOException {
        JsonNode responsePayload = mapper.readTree(jsonResponse);
        JsonNode errorMessage = responsePayload.findPath("errorMessage");

        try (OutputStream responseOutputStream = httpServletResponse.getOutputStream()) {
            httpServletResponse.setStatus(getProblemStatus(exchange));
            httpServletResponse.setContentType(getContentType(exchange));

            @SuppressWarnings("unchecked")
            ProblemDetails problemDetails = ProblemDetails.getBuilder()
                    .setType(getProblemType(exchange))
                    .setTitle(Optional.ofNullable(errorMessage.get("description")).map(JsonNode::asText).orElse(""))
                    .setStatus(getProblemStatus(exchange))
                    .setInstance(httpServletRequest.getRequestURI() + Optional.ofNullable(httpServletRequest.getQueryString()).map(q -> "?" + q).orElse(""))
                    .setLoggingInfo(mapper.readValue(responsePayload.findPath("loggingInfo").toString(), Map.class))
                    .setErrorMessage(mapper.readValue(errorMessage.toString(), Map.class))
                    .build();

            byte[] responseBytes = mapper.writeValueAsBytes(problemDetails);
            jsonResponse = new String(responseBytes, StandardCharsets.UTF_8);
            responseOutputStream.write(responseBytes);
        }
        return jsonResponse;
    }

    public String getConsumer(String operation) {
        return "direct:start";
    }

    public String formatNodeToString(String operation, Node node) throws TransformerFactoryConfigurationError, TransformerException {
        String returnValue = FormatUtils.nodeToString(node, FormatUtils.OMIT_XML_DECLARATION_YES, FormatUtils.INDENT_NO);
        if (TRIMMING_RESPONSE && "getListReferenceDataItem".equals(operation) && returnValue.length() > MAX_RESPONSE_SIZE) {
            return returnValue.substring(0, MAX_RESPONSE_SIZE) + "... (trimmed)";
        }
        return returnValue;
    }

    /**
     * Method to get the root element of the request XML.<br>
     * Default behavior is to get the first element child from the root.<br>
     *
     * Override this method for other behavior
     *
     * @param rootElement Initial SOAP request XML
     * @return Root element
     */
    protected Element getXMLRootElement(Element rootElement){
        Element newRoot = null;

        if (requestWithPayloadOnly()) {
            Node childNode = rootElement.getFirstChild();
            while (childNode != null && childNode.getNodeType() != Node.ELEMENT_NODE) {
                childNode = childNode.getNextSibling();
            }
            newRoot = (Element) childNode;
        }else{
            newRoot = rootElement;
        }

        return newRoot;
    }

    public boolean validateXMLSchema(String[] xsdPath, Document doc){
        try {
            SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            final StreamSource[] sources = generateStreamSourcesFromXsdPaths(xsdPath);
            Schema schema = factory.newSchema(sources);
            Validator validator = schema.newValidator();
            validator.validate(new DOMSource(doc));
        } catch (IOException | SAXException e) {
            logger.info("Exception: "+e.getMessage());
            return false;
        }
        return true;
    }


    private static StreamSource[] generateStreamSourcesFromXsdPaths(final String[] xsdFilesPaths) {
        return Arrays.stream(xsdFilesPaths)
                .map((String s) -> new StreamSource(Thread.currentThread().getContextClassLoader().getResource(s).toExternalForm()))
                .collect(Collectors.toList()).toArray(new StreamSource[xsdFilesPaths.length]);
    }

    private Document createResponse(Document response,String operation) throws ParserConfigurationException{

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.newDocument();

        // root element
        Element rootElement = doc.createElementNS(response.getDocumentElement().getNamespaceURI(),  operation+"Response");

        doc.appendChild(rootElement);

        Node nNode = null;
        if(keepRootElement() == ResponseLayout.WRAP){
            nNode = doc.importNode(response.getDocumentElement(), true);
        }else if(keepRootElement() == ResponseLayout.WRAP_UNWRAP){
            nNode = doc.importNode(getXMLRootElement(response.getDocumentElement()), true);
        }
        else{
            return response;
        }
        rootElement.appendChild(nNode);

        return doc;
    }

    /**
     * Override in case where the response payload should be wrapped.
     *
     * @return true/false
     */
    protected ResponseLayout keepRootElement(){
        return ResponseLayout.WRAP;
    }

    /**
     * Override in case the initial request will be handled as is.
     * @return
     */
    protected boolean requestWithPayloadOnly(){
        return true;
    }

    /**
     * Override if custom error -> http status mapping is needed per project
     */
    protected int getProblemStatus(Exchange exchange) {
        return HttpResponseStatus.UNPROCESSABLE_ENTITY.code();
    }

    /**
     * Override if custom error -> type mapping is needed per project
     */
    protected String getProblemType(Exchange exchange) {
        return CBS_ERROR;
    }

    /**
     * Override if other content types are needed on error
     */
    protected String getContentType(Exchange exchange) {
        return "application/problem+json";
    }

}
