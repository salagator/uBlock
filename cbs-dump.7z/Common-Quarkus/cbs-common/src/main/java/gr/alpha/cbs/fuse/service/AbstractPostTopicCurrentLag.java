package gr.alpha.cbs.fuse.service;

import io.quarkus.rest.client.reactive.QuarkusRestClientBuilder;
import jakarta.annotation.PostConstruct;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.common.PartitionInfo;
import org.apache.kafka.common.TopicPartition;

import java.net.URI;
import java.util.*;

public abstract class AbstractPostTopicCurrentLag {
    protected abstract String getDynatraceProtocol();
    protected abstract String getDynatraceHost();
    protected abstract String getDynatraceInstance();
    protected abstract String getDynatraceToken() ;
    protected abstract String getServiceId();
    protected abstract Map<TopicAndGroup, Integer> getTopicAndGroupThresholdMap();
    protected abstract Map<TopicAndGroup, Consumer> getKafkaConsumerMap();

    private interface DynatraceClient {
        @POST
        @Path("/api/v2/events/ingest")
        @Produces(MediaType.APPLICATION_JSON)
        @Consumes(MediaType.APPLICATION_JSON)
        Response postEvent(@HeaderParam("Authorization") String authorization, String body);
    }

    public static class TopicAndGroup {
        private final String topic;
        private final String group;

        public TopicAndGroup(String topic, String group) {
            this.topic = topic;
            this.group = group;
        }

        public String getTopic() {
            return topic;
        }

        public String getGroup() {
            return group;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            TopicAndGroup that = (TopicAndGroup) o;
            return Objects.equals(topic, that.topic) && Objects.equals(group, that.group);
        }

        @Override
        public int hashCode() {
            return Objects.hash(topic, group);
        }
    }

    /* State for performance reasons */
    private Map<TopicAndGroup, Integer> topicAndGroupThresholdMap;
    private Map<TopicAndGroup, Consumer> kafkaConsumerMap;

    @PostConstruct
    public void afterPropertiesSet() {
        topicAndGroupThresholdMap = getTopicAndGroupThresholdMap();
        kafkaConsumerMap = getKafkaConsumerMap();
    }

    public void postCurrentTopicLag() throws Exception {
        if (StringUtils.isBlank(getDynatraceProtocol()) || StringUtils.isBlank(getDynatraceHost())
                || StringUtils.isBlank(getDynatraceInstance()) || StringUtils.isBlank(getDynatraceToken())
                || StringUtils.isBlank(getServiceId())) {
            throw new IllegalArgumentException("There are required system properties missing for Dynatrace events [cbs.camel.dynatrace.server.protocol, cbs.camel.dynatrace.server.address, cbs.camel.dynatrace.server.instance, cbs.camel.dynatrace.token, cbs.camel.dynatrace.serviceEntityId]");
        }

        String dynatraceEndpoint = String.format("%s://%s/e/%s", getDynatraceProtocol(), getDynatraceHost(), getDynatraceInstance());

        for (TopicAndGroup topicAndGroup : topicAndGroupThresholdMap.keySet()) {
            Integer threshold = topicAndGroupThresholdMap.get(topicAndGroup);
            Map<Integer, Long> currentLag = getTopicCurrentLag(kafkaConsumerMap.get(topicAndGroup), topicAndGroup.getTopic());

            if(currentLag.size() > 0){
                for (Map.Entry<Integer, Long> currentLagEntry : currentLag.entrySet()) {
                    if (threshold < currentLagEntry.getValue()) {

                        String body = String.format("{\n" +
                                "  \"eventType\": \"ERROR_EVENT\",\n" +
                                "  \"title\": \"Kafka Topic Lag Issue\",\n" +
                                "  \"entitySelector\": \"entityId(%s)\",\n" +
                                "  \n" +
                                "  \"properties\": {\n" +
                                "        \"Topic Name\": \"%s\", \n" +
                                "        \"Partition Number\": \"%s\", \n" +
                                "        \"Current Lag\": \"%s\"\n" +
                                "    }\n" +
                                "}", getServiceId(), topicAndGroup.getTopic(), currentLagEntry.getKey(), currentLagEntry.getValue());

                        Response response = QuarkusRestClientBuilder.newBuilder().baseUri(URI.create(dynatraceEndpoint)).build(DynatraceClient.class).postEvent(String.format("Api-Token %s", getDynatraceToken()), body);
                        int responseStatus = response.getStatus();
                        if (responseStatus != 200 && responseStatus != 201) {
                            throw new Exception(String.format("Post Event to Dynatrace failed with http code: %s", responseStatus));
                        }
                    }
                }
            }
        }
    }

    public static Map<Integer, Long> getTopicCurrentLag(Consumer consumer, String topicName) throws Exception {
        Map<Integer, Long> beggingOffsetsMap = new HashMap<>();
        Map<Integer, Long> endOffsetsMap = new HashMap<>();
        Map<Integer, Long> currentLag = new HashMap<>();

        Map<String, List<PartitionInfo>> topics = consumer.listTopics();
        List<PartitionInfo> partitionInfos = topics.get(topicName);
        Collection<TopicPartition> partitions = new ArrayList<>();

        //retrieve partitions for specific topic
        if(partitionInfos.size() > 0) {
            try {
                for (PartitionInfo partitionInfo : partitionInfos) {
                    partitions.add(new TopicPartition(topicName, partitionInfo.partition()));
                }

                //get begging offsets
                consumer.assign(partitions);
                consumer.seekToEnd(partitions);
                Map<TopicPartition, Long> beggingOffsets = consumer.beginningOffsets(partitions);
                for (TopicPartition partition2 : beggingOffsets.keySet()) {
                    if (consumer.committed(partition2) != null) {
                        beggingOffsetsMap.put(partition2.partition(), consumer.committed(partition2).offset());
                    }
                }

                //get ending offsets
                Map<TopicPartition, Long> endingOffsets = consumer.endOffsets(partitions);
                for (TopicPartition partition : endingOffsets.keySet()) {
                    if (consumer.committed(partition) != null) {
                        endOffsetsMap.put(partition.partition(), endingOffsets.get(partition));
                    }
                }

                if (endOffsetsMap.size() > 0 && beggingOffsetsMap.size() > 0) {
                    //iterate the 2 maps and put to a new map the current lag
                    for (Map.Entry<Integer, Long> endOffsetsMapEntry : endOffsetsMap.entrySet()) {
                        Map.Entry<Integer, Long> beggingsetsMapEntry = beggingOffsetsMap.entrySet().stream()
                                .filter(e -> e.getKey().equals(endOffsetsMapEntry.getKey()))
                                .findFirst()
                                .orElse(null);
                        currentLag.put(endOffsetsMapEntry.getKey(), (endOffsetsMapEntry.getValue() - beggingsetsMapEntry.getValue()));
                    }
                }
            }catch(Exception ignored){}
        }
        return currentLag;
    }

}
