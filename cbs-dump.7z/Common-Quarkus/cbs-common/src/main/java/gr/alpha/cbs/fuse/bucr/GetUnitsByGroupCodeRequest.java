package gr.alpha.cbs.fuse.bucr;

public class GetUnitsByGroupCodeRequest {
	
	private String groupCode;
	
	public GetUnitsByGroupCodeRequest(){
		
	}
	
	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	@Override
	public String toString() {
		return "GetUnitsByGroupCodeRequest{" +
				"groupCode='" + groupCode + '\'' +
				'}';
	}
}
