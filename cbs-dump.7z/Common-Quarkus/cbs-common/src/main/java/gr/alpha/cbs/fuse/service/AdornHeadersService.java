package gr.alpha.cbs.fuse.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import gr.alpha.cbs.domain.Container;
import io.quarkus.rest.client.reactive.jackson.ClientObjectMapper;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;

@Path(("/adorn"))
@RegisterRestClient
public interface AdornHeadersService {

    @POST
    Container adornHeaders(Container input);

    @ClientObjectMapper
    static ObjectMapper objectMapper(ObjectMapper defaultObjectMapper) {
        ObjectMapper newObjectMapper =  defaultObjectMapper.copy();
        SerializationHelper serializationHelper = () -> {
            return ""; // We do not care about this as we are using only the object mapper configuration.
        };
        serializationHelper.configureObjectMapper(newObjectMapper);
        return newObjectMapper;
    }
}
