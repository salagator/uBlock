package gr.alpha.cbs.fuse.ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;
import jakarta.transaction.Transactional;

import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Body;
import org.apache.camel.ExchangeProperties;
import org.apache.camel.Header;
import org.apache.camel.Headers;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.jboss.logging.Logger;

@Named("vlmHandlerEjb")
@Dependent
@RegisterForReflection
public class VLMHandlerEjb {
	@Inject
	@io.quarkus.agroal.DataSource("cbsxa")
	DataSource sqlDS;


	private static final Logger LOGGER = Logger.getLogger(VLMHandlerEjb.class);

	@Transactional(Transactional.TxType.SUPPORTS)
	public void checkVLMNotification(@Headers Map<String,Object> headers, @ExchangeProperties Map<String,Object> properties) throws Exception {

		String sql ;
		sql = " SELECT v1.VLM_ID FROM dbo.VLM_DATA v1 ";
		sql += "WHERE v1.VLM_ID = ? AND AcceptByUserId IS NULL";

		try(Connection conn = sqlDS.getConnection();PreparedStatement pst = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);) {

			pst.setInt(1, Integer.parseInt((String)properties.get("cbs.common.ID")));

			try (ResultSet rs = pst.executeQuery()){
				if (rs.next()){
					properties.put("cbs.common.count", rs.getString("VLM_ID").trim());
				}
			}


		} catch (Exception ex) {
			LOGGER.error("Exception on checking VLM", ex);

			throw ex;
		}
	}


	@Transactional(Transactional.TxType.SUPPORTS)
	public Object acceptVLMNotification(@Body Object body,@Headers Map<String,Object> headers,@ExchangeProperties Map<String,Object> properties) throws Exception {

		try(Connection conn = sqlDS.getConnection();) {

			doVLMAcceptance(body, headers, properties, conn);

			return body;
		} catch (Exception ex) {
			LOGGER.error("Exception on updating VLM", ex);

			throw ex;
		}
	}


	private void doVLMAcceptance(Object body,Map<String,Object> headers,@ExchangeProperties Map<String,Object> properties,Connection conn) throws Exception {

		String vlmIdStr = (String) headers.get("vlmId");

		boolean isMultipleIds = vlmIdStr.contains(",");

		String sql ;

		if(isMultipleIds){
			// Multiple IDs case with comma-separated string
			String[] idArray = vlmIdStr.split(",");
			List<Integer> vlmIds = Arrays.stream(idArray)
					.map(String::trim)
					.map(Integer::valueOf)
					.toList();

			String placeholders = vlmIds.stream().map(id -> "?").collect(Collectors.joining(","));
			sql = "UPDATE dbo.VLM_DATA SET AcceptByUserId = ?, AcceptDate = getdate() "
					+ " WHERE VLM_ID IN (" + placeholders + ") AND AcceptByUserId IS NULL";

			try (PreparedStatement pst = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

				pst.setString(1, (String) properties.get("cbs.common.userId"));
				for (int i = 0; i < vlmIds.size(); i++) {
					pst.setInt(i + 2, vlmIds.get(i)); // Set values dynamically
				}

				int affectedRows = pst.executeUpdate();
				if (affectedRows == 0) {
					//throw new SQLException("Unable to insert to database");
				}

			} catch (Exception ex) {
				LOGGER.error("Exception on updating VLM", ex);
				throw ex;
			}
		}else{

			sql = "UPDATE dbo.VLM_DATA SET AcceptByUserId = ?, AcceptDate = getdate() "
					+ " WHERE VLM_ID = ? AND AcceptByUserId IS NULL";

			try (PreparedStatement pst = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

				pst.setString(1, (String) properties.get("cbs.common.userId"));
				pst.setInt(2, Integer.valueOf((String) headers.get("vlmId")));

				int affectedRows = pst.executeUpdate();
				if (affectedRows == 0) {
					;//throw new SQLException("Unable to insert to database");
				}

			} catch (Exception ex) {
				LOGGER.error("Exception on updating VLM", ex);
				throw ex;
			}
		}


	}

	public void createVlmRecord(@Header("vlmMap") HashMap<String, Object> vlmMap) throws SQLException {

		String sql = "Insert into VLM_DATA (GeneratedSystem, Critical, VLMCode, AcceptByUserId, AcceptDate, BranchCode, BankCode, TargetAudienceTypeId, BCID, BUN, MessageLanguage, VLMMessage, VLMMessageDetails, PropagateStatus, CreationDate, processed, MsgType, TargetUser, PropagateDate, Priority, MsgSubType, MsgSerial, Filler )"
				+ "	  values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,GETDATE(),?,?,?,?)";

		try (Connection conn = this.sqlDS.getConnection();PreparedStatement statement = conn.prepareStatement(sql)) {

			/*GeneratedSystem*/			statement.setString(1,  checkOrElse(vlmMap.get("GeneratedSystem"), null));
			/*Critical*/				statement.setString(2,  checkOrElse(vlmMap.get("Critical"), false));
			/*VLMCode*/					statement.setString(3,  checkOrElse(vlmMap.get("VLMCode"), null));
			/*AcceptByUserId*/			statement.setString(4,  checkOrElse(vlmMap.get("AcceptByUserId"), null));
			/*AcceptDate*/				statement.setString(5,  checkOrElse(vlmMap.get("AcceptDate"), null));
			/*BranchCode*/				statement.setString(6,  checkOrElse( vlmMap.get("BranchCode"), null));
			/*BankCode*/				statement.setString(7,  checkOrElse(vlmMap.get("BankCode"), null));
			/*TargetAudienceTypeId*/	statement.setString(8,  checkOrElse( vlmMap.get("TargetAudienceTypeId"), null));
			/*BCID*/					statement.setString(9,  checkOrElse(vlmMap.get("BCID"), null));
			/*BUN*/						statement.setString(10, checkOrElse(vlmMap.get("BUN"), null));
			/*MessageLanguage*/			statement.setString(11, checkOrElse(vlmMap.get("MessageLanguage"), null));
			/*VLMMessage*/				statement.setString(12, checkOrElse(vlmMap.get("VLMMessage"), null));
			/*VLMMessageDetails*/		statement.setString(13, checkOrElse(vlmMap.get("VLMMessageDetails"), null));
			/*PropagateStatus*/			statement.setString(14, checkOrElse(vlmMap.get("PropagateStatus"), null));
			/*CreationDate*/			statement.setString(15, checkOrElse(vlmMap.get("CreationDate"), LocalDate.now()));
			/*processed*/				statement.setString(16, checkOrElse(vlmMap.get("processed"), "0")); //0: default value for unprocessed (not propagated to channel) vlm messages
			/*MsgType*/					statement.setString(17, checkOrElse(vlmMap.get("MsgType"), null));
			/*TargetUser*/				statement.setString(18, checkOrElse(vlmMap.get("TargetUser"), null));
			/*Priority*/  		        statement.setString(19, checkOrElse(vlmMap.get("Priority"), null));
			/*MsgSubType*/				statement.setString(20, checkOrElse(vlmMap.get("MsgSubType"), null));
			/*MsgSerial*/				statement.setString(21, checkOrElse(vlmMap.get("MsgSerial"), null));
			/*Filler*/					statement.setString(22, checkOrElse(vlmMap.get("Filler"), null));
			statement.execute();

		}
	}

	public static <T> String checkOrElse(T value, T defaultValue){

		String returnValue = null;

		if(value == null && defaultValue != null){
			value = defaultValue;
		}

		if(value instanceof Boolean){
			if(Boolean.TRUE.equals(value)){
				returnValue = "1";
			}
			else{
				returnValue = "0";
			}
		}else{
			if(value != null)
				returnValue = value.toString();
		}

		return returnValue;

	}


	@Transactional(Transactional.TxType.NOT_SUPPORTED)
	public String getVlmInfo(@Header("vlmId") String id, @Header("reqBUN") String bun, @Header("reqVLMCode") String vlmCode) throws SQLException {
		StringBuilder sqlBuilder = new StringBuilder("SELECT (select VLM_ID, GeneratedSystem, VLMCode, VLMMessageDetails, VLMMessage, PropagateDate, BUN, MsgType, MsgSubType from VLM_DATA where ");
		if(StringUtils.isNotEmpty(id)){
			sqlBuilder.append(" VLM_ID = ? ");
		}else if(StringUtils.isNotEmpty(bun)){
			sqlBuilder.append(" BUN = ? ");
		}else{
			sqlBuilder.append(" VLMCode = ? AND MsgType = ? ");
		}

		sqlBuilder.append(" AND AcceptByUserId IS NULL FOR XML RAW, root, elements) AS XMLRESULT");
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Query:" +sqlBuilder.toString());
		}
		try (Connection conn = this.sqlDS.getConnection();PreparedStatement pst = conn.prepareStatement(sqlBuilder.toString())) {
			if(StringUtils.isNotEmpty(id)){
				pst.setLong(1, NumberUtils.createLong(id));
			}else if(StringUtils.isNotEmpty(bun)){
				pst.setString(1, bun);
			}else{
				pst.setString(1, FormatUtils.getTUN16(vlmCode));
				pst.setString(2, "4"); //TODO Replace with Constant from Refdata
			}

			try (ResultSet rs = pst.executeQuery()) {
				if (rs.next() && ! StringUtils.isEmpty(rs.getString("XMLRESULT")))
					return rs.getString("XMLRESULT");
				else
					return "NotFound";
			}
		}
	}
}
