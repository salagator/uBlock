package gr.alpha.cbs.fuse.bucr;

public class GetEnvParamsByUserIdRequest {
	
	private String Username;
	
	public GetEnvParamsByUserIdRequest(){
		
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String Username) {
		this.Username = Username;
	}

}