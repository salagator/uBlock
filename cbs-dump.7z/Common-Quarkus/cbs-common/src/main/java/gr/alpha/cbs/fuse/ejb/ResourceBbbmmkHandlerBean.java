package gr.alpha.cbs.fuse.ejb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import javax.sql.DataSource;
import jakarta.transaction.Transactional;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.ifaces.ResourceBbbmmkHandlerInterface;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.jboss.logging.Logger;

@Dependent
@RegisterForReflection
public class ResourceBbbmmkHandlerBean implements ResourceBbbmmkHandlerInterface {
	@Inject
	@io.quarkus.agroal.DataSource("channelSql")
	DataSource sqlDS;

	private static final Logger LOGGER = Logger.getLogger(ResourceBbbmmkHandlerBean.class);

	@Transactional(Transactional.TxType.NOT_SUPPORTED)
	public String readBbbmmk(String resource) throws Exception {
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("ReadBbbmmk start");
		}

		String resourceId = resource;

		String bbbmmk = "";
		String sqlQuery = "Select BBBMMK From BNK_Resources where Id = ?";
		try(Connection conn = this.sqlDS.getConnection();PreparedStatement statement = conn.prepareStatement(sqlQuery)) {
			statement.setString(1, resourceId);

			try(ResultSet result = statement.executeQuery()){
				if (result.next()) {
					if(!result.wasNull()){
						bbbmmk = result.getString("BBBMMK");
					} else{
						handleError(resourceId);
					}
				}else{
					handleError(resourceId);
				}
			}
		} catch (Exception ex) {
			if (!(ex instanceof CBSException)){
				ErrorUtils.throwCBSException(ex,
						String.valueOf(ConstantError_Types._Functional),
						String.valueOf(ConstantError_System_IDs._FUSE),
						this.getClass().getCanonicalName(),
						String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob),
						String.valueOf(ConstantError_Levels._Error),
						ex.getMessage(),
						"",
						"",
						"");
			}else{
				throw ex;
			}
		}

		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("ReadBbbmmk  end");
		}

		return bbbmmk;
	}

	private void handleError(String resourceId) throws CBSException {
		ErrorUtils.throwCBSException(null,
				String.valueOf(ConstantError_Types._Functional),
				String.valueOf(ConstantError_System_IDs._FUSE),
				this.getClass().getCanonicalName(),
				String.valueOf(ConstantErrorMessages._UERRMSGS_300001_texniko_prob),
				String.valueOf(ConstantError_Levels._Error),
				"Δεν βρέθηκε BBBMMK για τον χρήστη με Resource ID ("+resourceId+")",
				"",
				"",
				"");
	}
}
