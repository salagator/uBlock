package gr.alpha.cbs.fuse.masking;

public class RightMask implements IMask{
	
	
	@Override
	public String mask(String value, int length) {
		StringBuilder builder = new StringBuilder();
		
		builder.append(value.substring(0,value.length()-length ));
		for(int i=0;i<length;i++){
			builder.append("*");
		}
		
		return builder.toString();
	}
}
