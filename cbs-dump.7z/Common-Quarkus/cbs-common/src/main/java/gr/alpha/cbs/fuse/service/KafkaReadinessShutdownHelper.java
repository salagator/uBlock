package gr.alpha.cbs.fuse.service;

import io.quarkus.runtime.ShutdownEvent;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Observes;
import org.eclipse.microprofile.health.HealthCheck;
import org.eclipse.microprofile.health.HealthCheckResponse;
import org.eclipse.microprofile.health.Readiness;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The following class is used to manage the readiness state of the application.
 * When the application is stopping, it sets the readiness state to false.
 * This is reported to the health check endpoint, and is therefore used by Kubernetes to
 * determine if the application is ready to receive traffic. No more kafka messages will be processed
 * after the readiness state is set to false.
 *
 * This should be used in conjunction with the preStop hook in the application configuration,
 * which will give the application time to finish processing any in-flight messages before it stops.
 * example:
 * lifecycle:
 *   preStop:
 *     exec:
 *       command: ["/bin/sh", "-c", "sleep 10"]
 *
 * The amount of time to wait before the application stops can be adjusted as needed.
 * It depends on the expected processing time of the in-flight messages.
 */
@Readiness
@ApplicationScoped
public class KafkaReadinessShutdownHelper implements HealthCheck {
    private static final Logger logger = LoggerFactory.getLogger(KafkaReadinessShutdownHelper.class);

    private volatile boolean isReady = true;

    void onStop(@Observes ShutdownEvent event) {
        logger.info("KafkaReadinessShutdownHelper is stopping, setting readiness to false.");
        setNotReady();
    }

    public void setNotReady() {
        isReady = false;
    }

    @Override
    public HealthCheckResponse call() {
        return isReady ?
                HealthCheckResponse.up("Kafka Readiness Check") :
                HealthCheckResponse.down("Kafka Readiness Check");
    }
}
