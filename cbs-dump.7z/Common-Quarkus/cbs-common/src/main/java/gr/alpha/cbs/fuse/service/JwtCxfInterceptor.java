package gr.alpha.cbs.fuse.service;

//import io.smallrye.jwt.auth.principal.JWTParser;
//import io.smallrye.jwt.auth.principal.ParseException;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
//import org.eclipse.microprofile.jwt.JsonWebToken;

import java.util.List;
import java.util.Map;

// @Singleton
public class JwtCxfInterceptor extends AbstractPhaseInterceptor<Message> {

    // @Inject
    // JWTParser jwtParser;

    public JwtCxfInterceptor() {
        super(Phase.PRE_STREAM);
    }

    @Override
    public void handleMessage(Message message) {
        // You may retrieve the Authorization header from the message
        @SuppressWarnings("unchecked")
        Map<String, List<String>> headers = (Map<String, List<String>>) message.get(Message.PROTOCOL_HEADERS);
        if (headers == null) {
            throw new Fault(new Exception("No headers available"));
        }
        List<String> authHeaders = headers.get("Authorization");
        if (authHeaders == null || authHeaders.isEmpty()) {
            throw new Fault(new Exception("Missing Authorization header"));
        }
        String auth = authHeaders.get(0);
        if (!auth.startsWith("Bearer ")) {
            throw new Fault(new Exception("Invalid Authorization header scheme"));
        }
        String token = auth.substring("Bearer ".length()).trim();
        /*
        try {
            JsonWebToken jwt = jwtParser.parse(token);
            // optionally extra claims validation
            // inject into message so downstream handlers / your service logic can access it
            message.put("jwt", jwt);
        } catch (ParseException e) {
            throw new Fault(new Exception("Invalid JWT: " + e.getMessage(), e));
        }
         */
    }
}
