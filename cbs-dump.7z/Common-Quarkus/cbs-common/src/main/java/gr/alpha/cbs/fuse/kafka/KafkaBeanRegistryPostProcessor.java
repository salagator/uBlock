package gr.alpha.cbs.fuse.kafka;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import io.quarkus.arc.Unremovable;
import io.quarkus.arc.properties.IfBuildProperty;
import org.apache.camel.quarkus.component.jta.TransactionalJtaTransactionPolicy;
import org.jboss.logging.Logger;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.transaction.TransactionManager;

@ApplicationScoped
@Unremovable
@IfBuildProperty(name = "kafka.facility.enabled", stringValue = "true")
public class KafkaBeanRegistryPostProcessor {
	private static final Logger LOGGER = Logger.getLogger(KafkaBeanRegistryPostProcessor.class);
	@Inject
	TransactionManager transactionManager;

	@Named(KafkaConstants.TRX_POLICY_BEAN_NAME)
	@ApplicationScoped
	TransactionalJtaTransactionPolicy kafkaTransactionPolicy() {
		LOGGER.info("Registering Kafka transaction policy");

		return new TransactionalJtaTransactionPolicy() {
			@Override
			public void run(Runnable runnable) throws Throwable {
				transactionManager.setTransactionTimeout(30); // 30 seconds
				runWithTransaction(runnable, !hasActiveTransaction());
			}
		};
	}

	@Named(KafkaConstants.ERROR_UTILS_BEAN_NAME)
	@ApplicationScoped
	ErrorUtils kafkaErrorUtils() {
		return new ErrorUtils();
	}

}
