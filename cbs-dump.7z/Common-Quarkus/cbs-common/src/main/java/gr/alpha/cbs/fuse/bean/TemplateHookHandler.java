package gr.alpha.cbs.fuse.bean;

import gr.alpha.cbs.fuse.common.CBSConstants;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.ExchangeProperties;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Named;
import java.util.Map;

@Named("templateHookHandler")
@Dependent
@RegisterForReflection
public class TemplateHookHandler {
	private static final String PREPARE_BUN_HANDLER_PREFIX = "direct:prepare-bunHandler";
	private static final String HANDLE_FAILURE_PREFIX = "direct:handleFailure";
	private static final String CALL_SUCCESS_PREFIX = "direct:callSuccess";
	
	public String handlePrepareBUNHandlerHook(@ExchangeProperties Map<String, Object> properties) {
		String globalTarget = PREPARE_BUN_HANDLER_PREFIX;
		String defaultTarget = PREPARE_BUN_HANDLER_PREFIX + "-" + properties.get(CBSConstants.HEADER_TRANSACTION_FLOW);
		if (properties.containsKey(CBSConstants.HEADER_USE_GLOBAL_PREPARE_BUN_HANDLER)) {
			return globalTarget;
		}
		return defaultTarget;
	}
	
	public String handleFailureHook(@ExchangeProperties Map<String, Object> properties) {
		String globalTarget = HANDLE_FAILURE_PREFIX;
		String defaultTarget = HANDLE_FAILURE_PREFIX + "-" + properties.get(CBSConstants.HEADER_TRANSACTION_FLOW);
		if (properties.containsKey(CBSConstants.HEADER_USE_GLOBAL_FAILURE_HANDLER)) {
			return globalTarget;
		}
		return defaultTarget;
	}
	
	public String callSuccessHook(@ExchangeProperties Map<String, Object> properties) {
		String globalTarget = CALL_SUCCESS_PREFIX;
		String defaultTarget = CALL_SUCCESS_PREFIX + "-" + properties.get(CBSConstants.HEADER_TRANSACTION_FLOW);
		if (properties.containsKey(CBSConstants.HEADER_USE_GLOBAL_CALL_SUCESS)) {
			return globalTarget;
		}
		return defaultTarget;
	}
}
