package gr.alpha.cbs.fuse.bean;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Named;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.xpath.*;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import gr.alpha.cbs.fuse.ifaces.IHorizontalProcessor;
import gr.alpha.cbs.fuse.masking.GenericMask;
import gr.alpha.cbs.fuse.masking.IMask;
import gr.alpha.cbs.fuse.masking.MaskFactory;
import gr.alpha.cbs.fuse.support.OrderedProperties;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangeProperty;
import org.apache.camel.Expression;
import org.apache.camel.language.simple.types.SimpleIllegalSyntaxException;
import org.apache.camel.spi.Language;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.jboss.logging.Logger;
import org.w3c.dom.*;

import net.sf.saxon.om.Sequence;
import net.sf.saxon.s9api.Processor;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XPathCompiler;
import net.sf.saxon.s9api.XPathSelector;
import net.sf.saxon.s9api.XdmNode;
import net.sf.saxon.s9api.XdmValue;

@Named("horizontalProcessor")
@Dependent
@RegisterForReflection
public class HorizontalProcessor implements IHorizontalProcessor {
	private static final Logger LOGGER = Logger.getLogger(HorizontalProcessor.class);
	public void process(Exchange exchange, @ExchangeProperty("phase") String phase)
			throws TransformerFactoryConfigurationError, Exception {
		
		LOGGER.debug("HorizontalProcessor Start" );

		/*
		 * contains the horizontal property files that it has to read and create
		 * Maps for example journal These values are initiated during Get
		 * MEtaData step
		 */
		@SuppressWarnings("unchecked")

		List<String> horizontalPropertyFiles = exchange.getProperty("horizontalPropertyFiles", List.class);

		if (horizontalPropertyFiles != null) {
			LOGGER.debug("HorizontalProcessor Step1" );
			for (String horizontal : horizontalPropertyFiles) {
				LOGGER.debug("HorizontalProcessor Step2" );
				Map<String, Object> horizontalMap = getHorizontalMap(exchange, horizontal);
				LOGGER.debug("HorizontalProcessor Step3" );
				Map<String, Object> newValues = null;
				
				newValues = fillMap(exchange, phase, horizontal);

				for (Entry<String, Object> entry : newValues.entrySet()) {
					horizontalMap.put(entry.getKey(), entry.getValue());
				}
				LOGGER.debug("HorizontalProcessor Step4" );
				exchange.setProperty(horizontal + "Map", horizontalMap);
			}
		}
		LOGGER.debug("HorizontalProcessor Complete" );

	}

	@SuppressWarnings("el-syntax")
	private Map<String, Object> fillMap(Exchange exchange, String phase, String horizontal)
			throws XPathExpressionException, IOException, ParserConfigurationException {

		LinkedHashMap<String, Object> newJournalValues = new LinkedHashMap<>();

		List<Map<String, String>> listOfMaps = readPropertiesFileAsMap(exchange, phase, horizontal);

		Map<String, String> mapXpaths = listOfMaps.get(0);
		Map<String, String> mapSimles = listOfMaps.get(1);

		if (listOfMaps.get(0).size() != 0 || listOfMaps.get(1).size() != 0) {

			Document body = exchange.getIn().getBody(Document.class);
			//XPathFactory xPathfactory = new net.sf.saxon.xpath.XPathFactoryImpl();

			XPath xpath = FormatUtils.getXpath(null);
			for (Entry<String, String> entry : mapXpaths.entrySet()) {
				
				XPathExpression expr;
				Object result = null;
				NodeList nodes = null;
				
				try {
					LOGGER.debug("Compiling "  + entry.getValue());
					expr = xpath.compile(entry.getValue());
					result = expr.evaluate(body, XPathConstants.NODESET);
					nodes = (NodeList) result;

					if (nodes.getLength() != 0) {
						if (nodes.item(0).getNodeType() == Node.ELEMENT_NODE) {
							Node node = (nodes.item(0));
							DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
							dbFactory.setNamespaceAware(true);
							DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
							Document doc = dBuilder.newDocument();
							doc.appendChild(doc.importNode(node, true));
							Element nodeWithoutNameSpace = doc.getDocumentElement();
							nodeWithoutNameSpace = removeNamespaces((Element) nodeWithoutNameSpace);
							newJournalValues.put(entry.getKey(), nodeWithoutNameSpace);
						}
						else {
							if(nodes.item(0).getNodeValue() == null || nodes.item(0).getNodeValue().isBlank()){
								String alternativeXPath = addWildcardToElementNames(entry.getValue());

								try {
									if (LOGGER.isDebugEnabled()) {
										LOGGER.debug("Using alternative XPath: " + alternativeXPath);
									}
									expr = xpath.compile(alternativeXPath);
									result = (String) expr.evaluate(body, XPathConstants.STRING);

									newJournalValues.put(entry.getKey(), result);
								} catch (Exception e) {
									LOGGER.error("Error: " + e.getMessage() + " when compiling/evaluating alternative XPath: " + alternativeXPath);
								}
							}
							else{
								putValueInMap(newJournalValues, entry.getKey(), nodes.item(0).getNodeValue());
							}
							
						}
					}
					else{
						String alternativeXPath = addWildcardToElementNames(entry.getValue());
						expr = xpath.compile(alternativeXPath);
						result = expr.evaluate(body, XPathConstants.NODESET);

						nodes = (NodeList) result;
						if (nodes.getLength() != 0) {
							if (nodes.item(0).getNodeType() == Node.ELEMENT_NODE) {
								Node node = (nodes.item(0));
								DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
								dbFactory.setNamespaceAware(true);
								DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
								Document doc = dBuilder.newDocument();
								doc.appendChild(doc.importNode(node, true));
								Element nodeWithoutNameSpace = doc.getDocumentElement();
								nodeWithoutNameSpace = removeNamespaces((Element) nodeWithoutNameSpace);
								newJournalValues.put(entry.getKey(), nodeWithoutNameSpace);
							}
							else {
								if(nodes.item(0).getNodeValue() == null || nodes.item(0).getNodeValue().isBlank()){

									try {
										if (LOGGER.isDebugEnabled()) {
											LOGGER.debug("Using alternative XPath: " + alternativeXPath);
										}
										expr = xpath.compile(alternativeXPath);
										result = (String) expr.evaluate(body, XPathConstants.STRING);

										newJournalValues.put(entry.getKey(), result);
									} catch (Exception e) {
										LOGGER.error("Error: " + e.getMessage() + " when compiling/evaluating alternative XPath: " + alternativeXPath);
									}
								}
								else{
									putValueInMap(newJournalValues, entry.getKey(), nodes.item(0).getNodeValue());
								}

							}// TODO needs check if it finds multiple elements
						}
					}
				} catch (XPathException e) {
					try {
						if (entry != null){
							String tempValue = xpath2Evaluate(exchange, entry.getValue());
							LOGGER.debug("XPathExpressionException occured trying xpath 2.0");
							/** If the evaluation of the xpath fails tries with a library for XPATH-2.0 */

							if(tempValue == null || tempValue.isBlank()){
								String alternativeXPath = addWildcardToElementNames(entry.getValue());

								if (LOGGER.isDebugEnabled()) {
									LOGGER.debug("TryCatch Using alternative XPath: " + alternativeXPath);
								}
								tempValue = xpath2Evaluate(exchange, alternativeXPath);
								putValueInMap(newJournalValues, entry.getKey(), tempValue);
							}
							else{
								putValueInMap(newJournalValues, entry.getKey(), tempValue);
							}
						}
					} catch (SaxonApiException e1) {
						throw new XPathExpressionException("Error in xpath " + entry.getValue() + " during phase " + phase
							+ " for horizontal " + horizontal);
					}
				}

			}

			CamelContext camelContext = exchange.getContext();
			Language language = camelContext.resolveLanguage("simple");
			Expression expression = null;
			Object obj = null;
			for (Entry<String, String> entry : mapSimles.entrySet()) {

				try {
					/* when expression starts with header - property - body it is evaluated as object otherwise it is evaluated as constant */
					String expressionStr = null;
					if(entry.getValue()!= null && (entry.getValue().startsWith("body") ||entry.getValue().startsWith("header") || entry.getValue().startsWith("exchangeProperty")))
						expressionStr = "${" + entry.getValue() + "}";
					else if (entry.getValue()!= null && entry.getValue().startsWith("property")) {
						expressionStr = "${" + entry.getValue().replace("property","exchangeProperty") + "}";
					}
					else
						expressionStr = entry.getValue();
					expression = language.createExpression(expressionStr);
					obj = expression.evaluate(exchange, Object.class);
				} catch (SimpleIllegalSyntaxException e) {

					throw new SimpleIllegalSyntaxException(e.getExpression(), e.getIndex(),
							"Error in Simple Expression " + entry.getValue() + " for phase " + phase
									+ " and horizontal " + horizontal);
				}
				if(obj instanceof String){
					putValueInMap(newJournalValues, entry.getKey(), (String) obj);
				}else{
					newJournalValues.put(entry.getKey(), obj);
				}	
			}
		}

		return newJournalValues;
	}

	private List<Map<String, String>> readPropertiesFileAsMap(Exchange exchange, String phase, String horizontal)
			throws IOException {

		Map<String, String> propertiesMapXpath = new LinkedHashMap<>();
		Map<String, String> propertiesMapSimple = new LinkedHashMap<>();

		if ("journal".equals(horizontal) && "post-Validation".equals(phase)) {
			getStandardJournalbleInformation(propertiesMapXpath, propertiesMapSimple);
		}
		if ("journal".equals(horizontal) && "post-Success".equals(phase)) {
			getFinalJournalbleInformation(propertiesMapXpath, propertiesMapSimple);
		}
		/* This snippet was added in order for BUN to be written as Journable information */
		if ("journalReverse".equals(horizontal) && "post-Validation".equals(phase)) {
			getStandardJournalbleInformation(propertiesMapXpath, propertiesMapSimple);
		}
		if ("journalReverse".equals(horizontal) && "post-Success".equals(phase)) {
			getFinalJournalbleInformation(propertiesMapXpath, propertiesMapSimple);
		}

		if ("extrait".equals(horizontal) && "post-Validation".equals(phase)) {
			getStandardExtraitInformation(propertiesMapSimple);
		}
		if ("extrait".equals(horizontal) && "post-Success".equals(phase)) {
			getFinalExtraitInformation(propertiesMapSimple);
		}

		List<Map<String, String>> mapsList = new ArrayList<>();

		OrderedProperties properties = getJournalProperties(exchange, horizontal);
		String writeTableOrXml = null;

		boolean sensitive = false;
		for (Entry<String, String> entry : properties.entrySet()) {
			Object k = entry.getKey();
			Object v = entry.getValue();
			String kStr = k.toString();
			sensitive = false;
			String typeOfSensitive = null;
			
			if(kStr.matches(".*\\.Sensitive\\..*Mask")){
				sensitive = true;
				int indexOfsensitiveKeyword = kStr.lastIndexOf(".Sensitive.");
				typeOfSensitive = kStr.substring(indexOfsensitiveKeyword+1);
				kStr = kStr.substring(0, indexOfsensitiveKeyword);
			}

			if (kStr.endsWith(".B")) {
				writeTableOrXml = "B";
				kStr = kStr.substring(0, kStr.length() - 2);
			} else if (kStr.endsWith(".M")) {
				writeTableOrXml = "M";
				kStr = kStr.substring(0, kStr.length() - 2);
			} else if (kStr.endsWith(".T")) {
				writeTableOrXml = "T";
				kStr = kStr.substring(0, kStr.length() - 2);
			} else if ("extrait".equals(horizontal)){
				LOGGER.debug("String to be parsed =" + kStr);
				String pattern = "(.[0-9]+$)";
				Pattern r = Pattern.compile(pattern);
				Matcher m = r.matcher(kStr);

				if(m.find()){
					String endingNumber = m.group(0);
					writeTableOrXml = endingNumber.substring(1);
					kStr = kStr.substring(0, kStr.length() - m.group(0).length());
					LOGGER.debug("kStr			 = " + kStr);
					writeTableOrXml = writeTableOrXml + "~";
					LOGGER.debug("writeTableOrXml = " + writeTableOrXml);
				}
			} else {
				writeTableOrXml = "T";
			}
			
			if(sensitive){
				writeTableOrXml = writeTableOrXml +typeOfSensitive+".";
			}
			
			if ((kStr).startsWith(phase + ".")) {
				if (kStr.endsWith(".S")) {
					kStr = kStr.replace(phase + ".", "");
					if ("extrait".equals(horizontal)){
						LOGGER.debug("Key to be added = " + writeTableOrXml + kStr.substring(0, kStr.length() - 2));
						LOGGER.debug("VAl to be added = " + v.toString());
					}
					propertiesMapSimple.put(writeTableOrXml + kStr.substring(0, kStr.length() - 2), v.toString());
				} else {
					kStr = kStr.replace(phase + ".", "");
					propertiesMapXpath.put(writeTableOrXml + kStr.replace(".X", ""), v.toString());
				}
			}

		}

		mapsList.add(propertiesMapXpath);
		mapsList.add(propertiesMapSimple);

		return mapsList;
	}

	private OrderedProperties getJournalProperties(Exchange ex, String horizontal) throws IOException {
		
		LOGGER.debug("getJournalProperties called");
		OrderedProperties pro = (OrderedProperties) ex.getProperty(horizontal + "PropertiesMap", Object.class);

		String transaction = ex.getProperty(CBSConstants.HEADER_TRANSACTION_NAME, String.class);
		if (transaction == null) {
			throw new IllegalArgumentException("Ambiguous transaction Name specify property operation");
		}

		if (pro == null) {
			
			LOGGER.debug("loading file");
			/* First it searches the file in the specific path -> horizontal/file-name
			/*For example if  horizontal is journal then searches the file in journal/file-Name   */
			/* if it does not find it searches in the root folder of classpath (for backward compatibility)*/
			OrderedProperties properties = new OrderedProperties();
			ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			InputStream input = null;
			try{
				String file = horizontal+"/"+horizontal + "-" + transaction + ".properties";
				
				LOGGER.debug("loading file " + file);
				
				input = classLoader.getResourceAsStream(file);
				properties.load(input);
			}catch (Exception e) {
				try{
					input = classLoader.getResourceAsStream(horizontal + "-" + transaction + ".properties");
					properties.load(input);
				}catch(Exception exeption){
					throw new IOException( "Event registry requires a " + horizontal + "-" + transaction + ".properties in classpath", e);
				}
			} finally {
				if (input != null) {
					try {
						input.close();
					} catch (IOException e) {
						LOGGER.error("Exception closing input stream");
					}
				}
			}
			
			ex.setProperty(horizontal + "PropertiesMap", properties);
			LOGGER.debug ("Return fresh");
			
			return properties;
		}
		LOGGER.debug ("Return cached");
		return pro;
	}

	private Map<String, Object> getHorizontalMap(Exchange ex, String horizontal) {
		@SuppressWarnings("unchecked")
		Map<String, Object> map = ex.getProperty(horizontal + "Map", Map.class);

		if (map == null || map.isEmpty()) {
			return new LinkedHashMap<String, Object>();
		}
		return map;
	}

	private Element removeNamespaces(Element element) throws ParserConfigurationException {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(false);
		DocumentBuilder builder = dbf.newDocumentBuilder();
		Document document = builder.newDocument();

		String name = element.getLocalName();
		if (name == null) {
			name = element.getNodeName();
		}
		Element rootElement = document.createElement(name);
		document.appendChild(rootElement);

		NodeList list = element.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			Node child = list.item(i);
			if (child instanceof Element) {
				rootElement.appendChild(removeNamespacesFromChildren(document, (Element) child));
			} else {
				rootElement.appendChild(document.importNode(child, true));
			}
		}

		return document.getDocumentElement();
	}

	private Element removeNamespacesFromChildren(Document newDocument, Element element) {
		String name = element.getLocalName();
		if (name == null) {
			name = element.getNodeName();
		}
		Element newElement = newDocument.createElement(name);

		NodeList list = element.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			Node child = list.item(i);
			if (child instanceof Element) {
				newElement.appendChild(removeNamespacesFromChildren(newDocument, (Element) child));
			} else {
				newElement.appendChild(newDocument.importNode(child, false));
			}
		}

		return newElement;
	}

	/**
	 * This Methods Is Used to setUp standard Journable Information without the
	 * need to specify it in Journal properties file.
	 **/
	public static void getStandardJournalbleInformation(Map<String, String> propertiesMapXpath,
			Map<String, String> propertiesMapSimple) {

		propertiesMapSimple.put("TTransactionCode", "exchangeProperty[configuration.eventCode]");
		propertiesMapSimple.put("TBMR", "exchangeProperty[configuration.bmr]");
		propertiesMapSimple.put("TTransactionAlias", "exchangeProperty[configuration.aliasName]");
		propertiesMapSimple.put("TFunctionalTechnicalFlag", "exchangeProperty[configuration.eventType]");
		propertiesMapSimple.put("TOperation", "exchangeProperty[configuration.operation]");
		propertiesMapSimple.put("TService", "exchangeProperty[configuration.service]");
		propertiesMapSimple.put("TTransactionType", "exchangeProperty[configuration.transactionNature]");
		propertiesMapSimple.put("TSensitivityFlag", "exchangeProperty[configuration.sensitive]");
		propertiesMapSimple.put("TTransactionTag", "exchangeProperty[configuration.tagGroup]");
		propertiesMapSimple.put("TApprovalTypePoint", "exchangeProperty[cbs.common.approvalTypePoint]");
		propertiesMapSimple.put("TApprovalTypeRole", "exchangeProperty[cbs.common.approvalTypeRole]");
		
		propertiesMapXpath.put("TBDate", "//*:EnvParams/*:WorkingDate/text()");
		propertiesMapXpath.put("TUserID", "//*:LoggingInfo/*:UserId/text()");
		propertiesMapXpath.put("TBCID", "//*:LoggingInfo/*:BusinessCaseId/text()");
		
		propertiesMapXpath.put("TBUCR_Level1UnitCode", "//*:EnvParams/*:UnitCodeLevel1/text()");
		propertiesMapXpath.put("TBUCR_Level1UnitType", "//*:EnvParams/*:UnitTypeCodeLevel1/text()");
		propertiesMapXpath.put("TBUCR_Level2UnitCode", "//*:EnvParams/*:UnitCodeLevel2/text()");
		propertiesMapXpath.put("TBUCR_Level2UnitType", "//*:EnvParams/*:UnitTypeCodeLevel2/text()");
		propertiesMapXpath.put("TBUCR_Level3UnitCode", "//*:EnvParams/*:UnitCodeLevel3/text()");
		propertiesMapXpath.put("TBUCR_Level3UnitType", "//*:EnvParams/*:UnitTypeCodeLevel3/text()");
		propertiesMapXpath.put("TBUCR_Level4UnitCode", "//*:EnvParams/*:UnitCodeLevel4/text()");
		propertiesMapXpath.put("TBUCR_Level4UnitType", "//*:EnvParams/*:UnitTypeCodeLevel4/text()");
		propertiesMapXpath.put("TResourceType", "//*:EnvParams/*:ResourceTypeCode/text()");
		propertiesMapXpath.put("TBUCR_Channel", "//*:EnvParams/*:ChannelTypeCode/text()");
		propertiesMapXpath.put("TRecourceIdentifier", "//*:EnvParams/*:ResourceID/text()");
		propertiesMapXpath.put("TREQID", "//*:LoggingInfo/*:RequestId/text()");
		propertiesMapXpath.put("TFlowName", "//*:EnvParams/*:BusinessFlowName/text()");
		propertiesMapXpath.put("TCardReader", "//*:EnvParams/*:CardReaderPresent/text()");
		propertiesMapXpath.put("TUserRole", "string-join( //*:EnvParams/*:UserRoleList/*:UserRole/text(), ',')");
		propertiesMapXpath.put("TApproval_ID", "//*:EnvParams/*:ApprovalID/text()");
		propertiesMapXpath.put("TApprovalType", "//*:EnvParams/*:ApprovalType/text()");
		propertiesMapSimple.put("TRunAsUser", "property.cbs.common.runAsUser");
		propertiesMapSimple.put("TRunAsUnit", "property.cbs.common.runAsUnit");
	
}

	public static void getFinalJournalbleInformation(Map<String, String> propertiesMapXpath,
			Map<String, String> propertiesMapSimple) {
		propertiesMapSimple.put("TBUN", "exchangeProperty[cbs.common.bun]");
		propertiesMapSimple.put("TBUNRef", "exchangeProperty[cbs.common.bunReference]");
	}
	
	
	/** 
	 * this method is used to evaluate XPATH-2.0 expressions 
	 * when the javax.xml.xpath library fails this method tries to 
	 * execute the xpath and if it fail an exception will be thrown
	 * */
	public static String xpath2Evaluate(Exchange exchange , String xpathString) throws SaxonApiException {
 
            Processor proc = new Processor(false);
            XPathCompiler xpath = proc.newXPathCompiler();
            net.sf.saxon.s9api.DocumentBuilder builder = proc.newDocumentBuilder();

			XdmNode doc = builder.wrap(exchange.getIn().getBody(Document.class));
 
            XPathSelector selector = xpath.compile(xpathString).load();
            selector.setContextItem(doc);
            
            XdmValue children = selector.evaluate();
			@SuppressWarnings("rawtypes")
           Sequence seq = null;
           if (children instanceof  net.sf.saxon.s9api.XdmAtomicValue)
             seq = children.getUnderlyingValue();
           if(seq != null)
        	   return seq.toString().replace("\"", "");
           else 
        	   return null;
    }
	
	
	/**	
	 * This function uses the Strategy pattern to mask different types of sensitive information
	 *
	 * in the property file the configuration for sensitive data is the following :
	 * phase.Name.X.M.Sensitive.GenericMask=//*:GetCustomerListByNameRequestItem/*:CustomerLastName/text()
	 * keywords Sensitive and the Class that Masks are added at the end of the key in property file
	 * 
	 * if you want to add different classes for masking, you create a new class in package gr.alpha.cbs.fuse.masking
	 * that implements the IMask Interface and you add a case in the class MaskFactory.
	 * these classes should End whith the word Mask CardMask, GenericMask, etc
	 * 
	 * @param valuesMap is the map That contains the journal information
	 * @param key is the key from property file of horizontal
	 * @param value is the value of the property file of horizontal
	 */
	public static void putValueInMap(Map<String, Object> valuesMap, String key, String value){
		
		
		if(!StringUtils.isEmpty(value)){
			value = value.trim();
			if(key.matches(".Sensitive\\..*")){
				int indexOfFirsDot = key.indexOf(".");
	            int indexOfLastDot = key.lastIndexOf(".");
				String maskClass = key.substring(indexOfFirsDot+1, indexOfLastDot);
				key = key.substring(0, 1)+key.substring(indexOfLastDot+1);
				
				String num = "";
				Pattern pattern = Pattern.compile("([0-9]+)");
		        Matcher matcher = pattern.matcher(value);
		        for(int i = 0 ; i < matcher.groupCount(); i++) {
		            matcher.find();
		            num = matcher.group();
		        }
		        if(StringUtils.isEmpty(num)){
		        	num = "0";
		        }else{
		         maskClass = maskClass.replace(num, "");
		        }
		        
				IMask mask = MaskFactory.getMask(maskClass);
				int length = NumberUtils.toInt(num);
				try{
					value = mask.mask(value, length);
				}catch (Exception e) {
					value = new GenericMask().mask(value, 0);
				}
			}
			valuesMap.put(key, value);
		}
	}

	/**
	 * This Methods Is Used to setUp standard Extrait Information without the
	 * need to specify it in Extrait properties file.
	 **/
	public static void getStandardExtraitInformation(Map<String, String> propertiesMapSimple) {

		propertiesMapSimple.put("0~ChannelExecBranch",	"property.cbs.common.branch");
		propertiesMapSimple.put("0~ChannelFunctionCode",	"property.configuration.eventCode");
		propertiesMapSimple.put("0~ChannelRFunctionCode",	"property.configuration.aliasName");
		propertiesMapSimple.put("0~WorkingDate",			"property.cbs.common.workDate");
		propertiesMapSimple.put("0~ChannelTerminalID",	"property.cbs.common.resourceId");
		propertiesMapSimple.put("0~PostingDate",			"property.cbs.common.machineDate");
	}

	public static void getFinalExtraitInformation(Map<String, String> propertiesMapSimple) {
		propertiesMapSimple.put("0~Bun", "property[cbs.common.bun]");
	}

	public static String addWildcardToElementNames(String xpath) {
		// This regex matches element names not already prefixed and not functions or node tests
		if (xpath!=null) {
			return xpath.replaceAll(
					"(?<=/)(?!\\*)(?!text\\(\\))(?!comment\\(\\))(?!node\\(\\))(?!processing-instruction\\(\\))(?!(?:[a-zA-Z_][\\w\\-]*)\\s*\\()([a-zA-Z_][\\w\\-]*)",
					"*:$1"
			);
		}
		else{
			return null;
		}
	}
}
