
package gr.alpha.cbs.fuse.legacy;

import gr.alpha.cbs.domain.EnvParamsType;
import gr.alpha.cbs.domain.LoggingInfoType;

import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlElementDecl;
import jakarta.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the gr.alpha.cbs.fuse.legacycontracts.generated.odissydispatcher package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _EnvParams_QNAME = new QName("http://alpha.gr/odissy/dispatcher", "EnvParams");
    private final static QName _LoggingInfo_QNAME = new QName("http://alpha.gr/odissy/dispatcher", "LoggingInfo");
    private final static QName _ErrorMessage_QNAME = new QName("http://alpha.gr/odissy/dispatcher", "ErrorMessage");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: gr.alpha.cbs.fuse.legacycontracts.generated.odissydispatcher
     * 
     */
    public ObjectFactory() {
    }
    
    /**
     * Create an instance of {@link AdornHeadersResponse }
     * 
     */
    public AdornHeadersResponse createAdornHeadersResponse() {
        return new AdornHeadersResponse();
    }

    /**
     * Create an instance of {@link EnvParamsType }
     * 
     */
    public EnvParamsType createEnvParamsType() {
        return new EnvParamsType();
    }

    /**
     * Create an instance of {@link EmulatorMonitorServiceTX }
     * 
     */
    public EmulatorMonitorServiceTX createEmulatorMonitorServiceTX() {
        return new EmulatorMonitorServiceTX();
    }

    /**
     * Create an instance of {@link Hello }
     * 
     */
    public Hello createHello() {
        return new Hello();
    }

    /**
     * Create an instance of {@link ServeResponse }
     * 
     */
    public ServeResponse createServeResponse() {
        return new ServeResponse();
    }

    /**
     * Create an instance of {@link HelloResponse }
     * 
     */
    public HelloResponse createHelloResponse() {
        return new HelloResponse();
    }

    /**
     * Create an instance of {@link ServeByName }
     * 
     */
    public ServeByName createServeByName() {
        return new ServeByName();
    }

    /**
     * Create an instance of {@link ServeByNameResponse }
     * 
     */
    public ServeByNameResponse createServeByNameResponse() {
        return new ServeByNameResponse();
    }

    /**
     * Create an instance of {@link EmulatorMonitorServiceTXResponse }
     * 
     */
    public EmulatorMonitorServiceTXResponse createEmulatorMonitorServiceTXResponse() {
        return new EmulatorMonitorServiceTXResponse();
    }

    /**
     * Create an instance of {@link ErrorMessageType }
     * 
     */
    public ErrorMessageType createErrorMessageType() {
        return new ErrorMessageType();
    }

    /**
     * Create an instance of {@link LoggingInfoType }
     * 
     */
    public LoggingInfoType createLoggingInfoType() {
        return new LoggingInfoType();
    }

    /**
     * Create an instance of {@link Serve }
     * 
     */
    public Serve createServe() {
        return new Serve();
    }

    /**
     * Create an instance of {@link UserRoleList }
     * 
     */
    public UserRoleList createUserRoleList() {
        return new UserRoleList();
    }

    /**
     * Create an instance of {@link AliasListType }
     * 
     */
    public AliasListType createAliasListType() {
        return new AliasListType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EnvParamsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://alpha.gr/odissy/dispatcher", name = "EnvParams")
    public JAXBElement<EnvParamsType> createEnvParams(EnvParamsType value) {
        return new JAXBElement<EnvParamsType>(_EnvParams_QNAME, EnvParamsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LoggingInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://alpha.gr/odissy/dispatcher", name = "LoggingInfo")
    public JAXBElement<LoggingInfoType> createLoggingInfo(LoggingInfoType value) {
        return new JAXBElement<LoggingInfoType>(_LoggingInfo_QNAME, LoggingInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ErrorMessageType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://alpha.gr/odissy/dispatcher", name = "ErrorMessage")
    public JAXBElement<ErrorMessageType> createErrorMessage(ErrorMessageType value) {
        return new JAXBElement<ErrorMessageType>(_ErrorMessage_QNAME, ErrorMessageType.class, null, value);
    }

}
