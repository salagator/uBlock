package gr.alpha.cbs.fuse.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.quarkus.jackson.ObjectMapperCustomizer;
import jakarta.inject.Singleton;

@Singleton
public class CBSObjectMapperConverter implements SerializationHelper, ObjectMapperCustomizer {

    @Override
    public String getPackageName() {
        // Intentionally return empty string to shut up the compiler
        return "";
    }

    @Override
    public void customize(ObjectMapper objectMapper) {
        configureObjectMapper(objectMapper);
    }
}
