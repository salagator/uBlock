package gr.alpha.cbs.fuse.tools;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import jakarta.xml.bind.JAXBElement;

import java.io.IOException;

public class JAXBElementSerializer extends StdSerializer<JAXBElement> {
    public JAXBElementSerializer() {
        super((Class<JAXBElement>) null);
    }

    @Override
    public void serialize(JAXBElement jaxbElement, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
        if (!jaxbElement.isNil() && jaxbElement.getValue() != null) {
            jsonGenerator.writeString(jaxbElement.getValue().toString());
        } else {
            jsonGenerator.writeString("");
        }
    }
}
