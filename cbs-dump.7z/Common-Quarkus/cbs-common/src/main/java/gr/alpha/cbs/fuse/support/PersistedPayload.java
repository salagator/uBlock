package gr.alpha.cbs.fuse.support;

import java.sql.Timestamp;

import org.w3c.dom.Document;

public class PersistedPayload {
	private Timestamp payloadTimestamp;
	private String payloadRequestId;
	private String serviceName;
	private String operationName;
	private Document payload;

	public PersistedPayload(Timestamp payloadTimestamp, String payloadRequestId, String serviceName, String operationName, Document payload) {
		this.payloadTimestamp = payloadTimestamp;
		this.payloadRequestId = payloadRequestId;
		this.serviceName = serviceName;
		this.operationName = operationName;
		this.payload = payload;
	}

	public Timestamp getPayloadTimestamp() {
		return payloadTimestamp;
	}

	public String getPayloadRequestId() {
		return payloadRequestId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public String getOperationName() {
		return operationName;
	}

	public Document getPayload() {
		return payload;
	}
}
