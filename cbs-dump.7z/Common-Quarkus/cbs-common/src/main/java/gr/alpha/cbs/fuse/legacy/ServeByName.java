
package gr.alpha.cbs.fuse.legacy;

import jakarta.xml.bind.annotation.*;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ServiceName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Request" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Reply" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CommitStatus" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/>
 *         &lt;element name="TransactionMode" type="{http://alpha.gr/odissy/dispatcher}TransactionMode"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "serviceName",
    "request",
    "reply",
    "commitStatus",
    "transactionMode"
})
@XmlRootElement(name = "ServeByName")
public class ServeByName {

    @XmlElement(name = "ServiceName")
    protected String serviceName;
    @XmlElement(name = "Request")
    protected String request;
    @XmlElement(name = "Reply")
    protected String reply;
    @XmlElement(name = "CommitStatus")
    @XmlSchemaType(name = "unsignedByte")
    protected short commitStatus;
    @XmlElement(name = "TransactionMode", required = true)
    protected TransactionMode transactionMode;

    /**
     * Gets the value of the serviceName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceName() {
        return serviceName;
    }

    /**
     * Sets the value of the serviceName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceName(String value) {
        this.serviceName = value;
    }

    /**
     * Gets the value of the request property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequest() {
        return request;
    }

    /**
     * Sets the value of the request property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequest(String value) {
        this.request = value;
    }

    /**
     * Gets the value of the reply property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReply() {
        return reply;
    }

    /**
     * Sets the value of the reply property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReply(String value) {
        this.reply = value;
    }

    /**
     * Gets the value of the commitStatus property.
     * 
     */
    public short getCommitStatus() {
        return commitStatus;
    }

    /**
     * Sets the value of the commitStatus property.
     * 
     */
    public void setCommitStatus(short value) {
        this.commitStatus = value;
    }

    /**
     * Gets the value of the transactionMode property.
     * 
     * @return
     *     possible object is
     *     {@link TransactionMode }
     *     
     */
    public TransactionMode getTransactionMode() {
        return transactionMode;
    }

    /**
     * Sets the value of the transactionMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionMode }
     *     
     */
    public void setTransactionMode(TransactionMode value) {
        this.transactionMode = value;
    }

}
