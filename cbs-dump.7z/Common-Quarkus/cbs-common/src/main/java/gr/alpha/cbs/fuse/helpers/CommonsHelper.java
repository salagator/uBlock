package gr.alpha.cbs.fuse.helpers;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.inject.Named;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.jboss.logging.Logger;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.common.ifaces.RefDataTranslator;
import gr.alpha.cbs.fuse.enums.ConstantAccountOpenActiveType;
import gr.alpha.cbs.fuse.enums.ConstantAccountStatusActiveFlag;
import gr.alpha.cbs.fuse.enums.ConstantBNK_Groups;
import gr.alpha.cbs.fuse.enums.ConstantBalanceOfPayment;
import gr.alpha.cbs.fuse.enums.ConstantBlockAccountIndicators;
import gr.alpha.cbs.fuse.enums.ConstantBranches;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantInstrumentalAccountType;
import gr.alpha.cbs.fuse.enums.ConstantLoanAccountIndicator;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@Named("commonsHelper")
@ApplicationScoped
@RegisterForReflection
public class CommonsHelper {
	
	private static final Logger LOGGER = Logger.getLogger(CommonsHelper.class);
	
	private static final String SIGLO_PREFIX="989";
	private static final String FLEX_PREFIX="942";

    @Inject
	RefDataTranslator translator;
    @Inject
	ChannelBucrCallerHelper channelBucrCallerHelper;

	/*
	 * 
	 * Be careful!!!! 
 	 * Method combineAccountStatusActiveAndAccountStatusOpenClose has been copied from CommonsHelper class of time-deposits project in order to be commonly used. 
 	 * This method is implemented in order to be used from all projects and operations of CBS. 
 	 * Until the replacement task takes place, be careful that any modification needs to be implemented in other projects as well.
	 * 
	 */
	
	public String combineAccountStatusActiveAndAccountStatusOpenClose(String activeFlag, String openClosedIndicator, boolean isOverloaded){
		String status = String.valueOf(ConstantAccountOpenActiveType._ACCOUNT_IS_OPEN___OK);
		Integer closedInactiveFlag = 0;
		if(StringUtils.isNumeric(openClosedIndicator)){
			closedInactiveFlag = NumberUtils.toInt(openClosedIndicator);
		}
		int isActiveAccount = NumberUtils.toInt(activeFlag);
		switch (closedInactiveFlag) {
		case 0:
			//status = "ΕΝΕΡΓΟΣ"
			status = String.valueOf(ConstantAccountOpenActiveType._ACCOUNT_IS_OPEN___OK);
			if(isActiveAccount == 1){
				//status = "ΑΚΙΝΗΤΟΣ"
				status = String.valueOf(ConstantAccountOpenActiveType._DORMANT_ACCOUNT);
			} else if (isActiveAccount == 2){
				//status = "ΦΡΑΓΗ ΚΙΝΗΣΕΩΝ"
				status = String.valueOf(ConstantAccountOpenActiveType._ACCOUNT_BLOCKED_FOR_TRANSACTIONS);
			}
			break;
		case 1:
			//status = "ΕΞΟΦΛΗΜΕΝΟΣ"
			status = String.valueOf(ConstantAccountOpenActiveType._ACCOUNT_CLOSED_BY_ACCOUNTING_TXON);
			break;
		case 2 :
			//status = "ΚΛΕΙΣΤΟΣ"
			status = String.valueOf(ConstantAccountOpenActiveType._ACCOUNT_CLOSED_BY_CAM_TXON);
			break;
		case 3 :
			//status = "ΑΚΙΝΗΤΟΣ"
			status = String.valueOf(ConstantAccountOpenActiveType._ACCOUNT_DOES_NOT_EXIST);
			if (isActiveAccount == 2){
				//status = "ΦΡΑΓΗ ΚΙΝΗΣΕΩΝ"
				status = String.valueOf(ConstantAccountOpenActiveType._ACCOUNT_BLOCKED_FOR_TRANSACTIONS);
			}
			break;
		}
		return status;
	}
	
	
	/*
	 * 
	 * Be careful!!!! 
 	 * Method tellerBeneficiary has been copied from CommonsHelper class of time-deposits project in order to be commonly used. 
 	 * This method is implemented in order to be used from all projects and operations of CBS. 
 	 * Until the replacement task takes place, be careful that any modification needs to be implemented in other projects as well.
	 * 
	 */
	
	
	public boolean tellerBeneficiary (String employeeNbr1, String employeeNbr2, String 	employeeNbr3, String employeeNbr4, Map<String,Object> properties ){
		
		
		LOGGER.debug("Input parameters : "+employeeNbr1 + "-" + employeeNbr2 + "-" + employeeNbr3 + "-" +employeeNbr4);
		
		String envHeader= properties.get(CBSConstants.HEADER_BRANCH_CODE).toString();
		String envUser= properties.get(CBSConstants.HEADER_USER_ID).toString();
		LOGGER.debug("Current user : "+envUser);
		
		if(!StringUtils.isEmpty(envUser)){
			envUser = envUser.substring(envUser.length()-5);
			LOGGER.debug("Current user (5 digits) : "+envUser);
		}
		else{
			return false;
		}
		
		
		if(envHeader.equals(ConstantBranches._YPSIA_ALPHAPHONE)){
			return false;
		}
		
		if(envUser.equals("00000")){
			return false;
		}
		
		if ((StringUtils.isEmpty(employeeNbr1) || employeeNbr1.equalsIgnoreCase("00000")) &&
			(StringUtils.isEmpty(employeeNbr2) || employeeNbr2.equalsIgnoreCase("00000")) &&
			(StringUtils.isEmpty(employeeNbr3) || employeeNbr3.equalsIgnoreCase("00000")) &&
			(StringUtils.isEmpty(employeeNbr4) || employeeNbr4.equalsIgnoreCase("00000")))
		{
			return false;
		}
		
		List<String> customerEmployeeNbrs = Arrays.asList(employeeNbr1,employeeNbr2,employeeNbr3,employeeNbr4);
		
		if (customerEmployeeNbrs.contains(envUser)){
			return true;
		}
		
		return false;
	}
	
	/**
	 * Function that returns if the provided branch belongs to PRIVATE BANKING Group.
	 * Provided branch should be translated according to UFE.
	 * 
	 * @param branch
	 * @return
	 * @throws Exception
	 */
	public boolean isPrivateBanking(String branch) throws Exception{
		
		List<String> groups = channelBucrCallerHelper.getGroupsCodesByUnitCode(branch);
		
		
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Show groups to which belong the provided branch("+branch+") : "+groups);
		}
		
		return groups.contains(ConstantBNK_Groups._PRIVATE);
	}
	
	public boolean accountBelongsToPrivateBanking(String mngmntBranch , String realBranch) throws Exception{
		
		return isPrivateBanking(mngmntBranch) ||  isPrivateBanking(realBranch);
	}
	
	
	/**
	 * Function that checks the basic info for account status
	 * inputs should be translated to HOST values
	 * 
	 * @param inaFlag, loanNdx, activeFlag, className
	 * @return
	 * @throws Exception
	 */
	public void checkAccountStatusBasic(String inaFlag, String loanNdx, String activeFlag, String className) throws Exception{
		
		
        int inaFlagTranslated = Integer.parseInt(translator.translateData(CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_DATA_SYSTEM_UI, CBSConstants.REF_NAME_ACCOUNT_OPEN_ACTIVE_TYPE,inaFlag));
		int loanNdxTranslated = Integer.parseInt(translator.translateData(CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_DATA_SYSTEM_UI, CBSConstants.REF_NAME_LOAN_ACCOUNT_INDICATOR,loanNdx));
		int activeFlagTranslated = Integer.parseInt(translator.translateData(CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_DATA_SYSTEM_UI, CBSConstants.REF_NAME_ACCOUNT_STATUS_ACTIVE_FLAG,activeFlag));
				
//		"IF Input.InaFlag = RefData.AccountOpenActiveType.""3-ACCOUNT DOES NOT EXIST "" THEN 
//	    ERROR 301410 - O Λογαριασμός δεν υπάρχει"
		if (inaFlagTranslated == ConstantAccountOpenActiveType._ACCOUNT_DOES_NOT_EXIST){
			ErrorUtils.throwCBSException(null ,  
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, 
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, 
					className, 
					ConstantErrorMessages._O_LOGARIASMOS_DEN_YPARXEI_MW,
					"3",
					"", "", "");
		}
		
		
//		"If Input.LoanNdx=RefData.LoanAccountIndicator.""1-Loan Account"" THEN
//	    ERROR 301411 - Λογαριασμός χρηματοδοτήσεων"
		if (loanNdxTranslated == ConstantLoanAccountIndicator._LoanAccountYes){
			ErrorUtils.throwCBSException(null ,  
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, 
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, 
					className, 
					ConstantErrorMessages._LOGARIASMOS_XRIMATODOTISEON_MW,
					"3",
					"", "", "");
		}
		
//		"IF Input.ActiveFlag=RefData.AccountStatusActiveFlag.""4-Account with Transaction Restrictions"".HOST_CODE THEN 
//	    ERROR 300055 -Λογαριασμός με φραγή κινήσεων"
		if (activeFlagTranslated == ConstantAccountStatusActiveFlag._Account_with_Transaction_Restrictions){
			ErrorUtils.throwCBSException(null ,  
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, 
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, 
					className, 
					ConstantErrorMessages._Account_Blocked_For_Transactions,
					"3",
					"", "", "");
		}
	}
	
	/**
	 * Function that checks if the account is closed or not
	 * inputs should be translated to HOST values
	 * 
	 * @param inaFlag, className
	 * @return
	 * @throws Exception
	 */
	public void checkAccountStatusCheckCamClosed(String inaFlag, String className) throws Exception{
		
		int inaFlagTranslated = Integer.parseInt(translator.translateData(CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_DATA_SYSTEM_UI, CBSConstants.REF_NAME_ACCOUNT_OPEN_ACTIVE_TYPE,inaFlag));
				
//		"IF Input.InaFlag = RefData.AccountOpenActiveType.""2-ACCOUNT CLOSED BY CAM TXON"" THEN 
//	    ERROR 300616 - Κλειστός Λογαριασμός"

		if (inaFlagTranslated == ConstantAccountOpenActiveType._ACCOUNT_CLOSED_BY_CAM_TXON){
			ErrorUtils.throwCBSException(null ,  
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, 
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, 
					className, 
					ConstantErrorMessages._ClosedAccount,
					"3",
					"", "", "");
		}
		
	}
	
	/**
	 * Function that checks if the account status is blocked or not
	 * inputs should be translated to HOST values
	 * 
	 * @param inaFlag, blockFlag, className
	 * @return
	 * @throws Exception
	 */
	public void checkAccountStatusBlocked(String inaFlag, String blockFlag, String className) throws Exception{
		
		int inaFlagTranslated = Integer.parseInt(translator.translateData(CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_DATA_SYSTEM_UI, CBSConstants.REF_NAME_ACCOUNT_OPEN_ACTIVE_TYPE,inaFlag));
		int blockFlagTranslated = Integer.parseInt(translator.translateData(CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_DATA_SYSTEM_UI, CBSConstants.REF_NAME_BLOCK_ACCOUNT_INDICATORS,blockFlag));
				
//		"IF Input.InaFlag = RefData.AccountOpenActiveType.""1-ACCOUNT CLOSED BY ACCOUNTING TXON THEN 
//	    ERROR 300084 - Ο λογαριασμός έχει εξοφληθεί"

		if (inaFlagTranslated == ConstantAccountOpenActiveType._ACCOUNT_CLOSED_BY_ACCOUNTING_TXON){
			ErrorUtils.throwCBSException(null ,  
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, 
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, 
					className, 
					ConstantErrorMessages._AccountHasBeenSettled,
					"3",
					"", "", "");
		}
		
		
//		"IF Input.BlkFlag = RefData.BlockAccountIndicators.""2-Account Totally Blocked"" THEN
//	    ERROR 301151 -  Ο Λογαριασμός Είναι Δεσμευμένος (Ολική Δέσμευση)"

		if (blockFlagTranslated == ConstantBlockAccountIndicators._Account_Totally_Blocked){
			ErrorUtils.throwCBSException(null ,  
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, 
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, 
					className, 
					ConstantErrorMessages._Account_Totally_Blocked_MW,
					"3",
					"", "", "");
		}
	}
	
	/**
	 * Function that checks if the account status is "akinitos" or not
	 * inputs should be translated to HOST values
	 * 
	 * @param activeFlag, className
	 * @return
	 * @throws Exception
	 */
	public void checkAccountStatusAkinitos(String activeFlag, String className) throws Exception{
		
		int activeFlagTranslated = Integer.parseInt(translator.translateData(CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_DATA_SYSTEM_UI, CBSConstants.REF_NAME_ACCOUNT_STATUS_ACTIVE_FLAG,activeFlag));
						
//		"IF Input.ActiveFlag= RefData..AccountStatusActiveFlag.""2-Normal Account"".HOST_CODE THEN 
//	    Exit Function"
		
//		"IF Input.ActiveFlag!= RefData..AccountStatusActiveFlag.""3-Dormant Account"".HOST_CODE THEN 
//	    Exit Function"
		
//		Error 300306 - Ακίνητος Λογαριασμός

		if (activeFlagTranslated == ConstantAccountStatusActiveFlag._Normal_Account_00){
			return;
		}else if (activeFlagTranslated != ConstantAccountStatusActiveFlag._Dormant_Account_01){
			return;
		}else{
			ErrorUtils.throwCBSException(null ,  
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, 
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, 
					className, 
					ConstantErrorMessages._No_Transaction_Can_Be_Performed_On_Account,
					"3",
					"", "", "");
		}
	}
	
	/**
	 * Function that checks if the account belongs to siglo or not
	 * inputs should be translated to HOST values
	 * 
	 * @param accountNumber
	 * @return isSiglo
	 * @throws
	 */
	public boolean isSigloAccount(String accountNumber){
		boolean isSiglo = false;
		
		if(accountNumber != null && accountNumber.length() >= 3 && accountNumber.substring(0, 3).equals(SIGLO_PREFIX)){
			isSiglo = true;
		}
		
		return isSiglo;
	}
	
	/** 
	 * Function that returns the correct BalanceOfPaymentCode for ReverseFunctions based on a map attached on ticket #129294 
	 * 
	 * @param balanceOfPaymentCode
	 * @return reverseBOPC
	 * @throws
	 */
	public String reverseBalanceOfPaymentCode(String balanceOfPaymentCode){
		String reverseBOPC = null;
		
		Map<Integer,String> bopcMap = new HashMap<Integer,String>();
		bopcMap.put(ConstantBalanceOfPayment._DIASYNORIAKES_EKSAGOGES_50000_EYRO, String.valueOf(ConstantBalanceOfPayment._DIASYNORIAKES_EISAGOGES_50000_EYRO));
		bopcMap.put(ConstantBalanceOfPayment._DIASYNORIAKES_EISAGOGES_50000_EYRO, String.valueOf(ConstantBalanceOfPayment._DIASYNORIAKES_EKSAGOGES_50000_EYRO));
		bopcMap.put(ConstantBalanceOfPayment._DIASYNOREISPRLOIPON_SYNGONAFORKOD201_61150000_EYRO, String.valueOf(ConstantBalanceOfPayment._DIASYNORPLIRLOIPON_SYNGONAFORKOD201_61150000_EYRO));
		bopcMap.put(ConstantBalanceOfPayment._DIASYNORPLIRLOIPON_SYNGONAFORKOD201_61150000_EYRO, String.valueOf(ConstantBalanceOfPayment._DIASYNOREISPRLOIPON_SYNGONAFORKOD201_61150000_EYRO));
		bopcMap.put(ConstantBalanceOfPayment._DIASYNOREISPRAKSLOIPON_SYNGONAFORKOD701_911_50000_EYRO, String.valueOf(ConstantBalanceOfPayment._DIASYNORPLIRLOIPON_SYNGONAFORKOD701_911_50000_EYRO));
		bopcMap.put(ConstantBalanceOfPayment._DIASYNORPLIRLOIPON_SYNGONAFORKOD701_911_50000_EYRO, String.valueOf(ConstantBalanceOfPayment._DIASYNOREISPRAKSLOIPON_SYNGONAFORKOD701_911_50000_EYRO));
		
		if(balanceOfPaymentCode != null &&  (!"".equals(balanceOfPaymentCode))){
			int bocInteger = Integer.parseInt(balanceOfPaymentCode);
			reverseBOPC = balanceOfPaymentCode;
			if(bopcMap.containsKey(bocInteger)){
				reverseBOPC = bopcMap.get(bocInteger);
			}			
		}			
		return reverseBOPC;
	}

	public Map<String, String> getImpersonateAccountInfo(String accountNumber, int instrumentalAccountType, int baseCurrency, String className) throws CBSException {

		String accountCCY = ((accountNumber.length() >= 6) ? accountNumber.substring(3, 5) : null);
		String accountLastDigits = ((accountNumber.length() >= 15) ? accountNumber.substring(9, 14) : StringUtils.EMPTY);
		
		Boolean instrumentalAccountTypeIsSyndesmonBC = (instrumentalAccountType == ConstantInstrumentalAccountType._SYNDESMON_BC);
		Boolean instrumentalAccountTypeIsSyndesmonFC = (instrumentalAccountType == ConstantInstrumentalAccountType._SYNDESMON_FC);
		Boolean accountCurrencyIsEuro = (Integer.valueOf(accountCCY) == baseCurrency);
		Boolean accountLastDigitsAreNines = (accountLastDigits.equals("99999"));
		Boolean accountLastDigitsAreZeroesTrailedByOne = (accountLastDigits.equals("00001"));
		
		if (instrumentalAccountType == ConstantInstrumentalAccountType._NONE){
			ErrorUtils.throwCBSException(null,
				ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
				ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
				className,
				ConstantErrorMessages._InvalidAccountType_MW,
				String.valueOf(ConstantError_Levels._Error),
				"", "", "");
		}
		
		
		if (instrumentalAccountTypeIsSyndesmonBC) {
			
			if (!accountCurrencyIsEuro) {
				ErrorUtils.throwCBSException(null,
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					className,
					ConstantErrorMessages._AccountLinkTypeinBC_MW,
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
				
			} else if (!accountLastDigitsAreNines) {
				ErrorUtils.throwCBSException(null,
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					className,
					ConstantErrorMessages._ErrorAccountLinkEntry_MW,
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
			}
			
		} else if (instrumentalAccountTypeIsSyndesmonFC) {
			
			if (accountCurrencyIsEuro) {
				ErrorUtils.throwCBSException(null,
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					className,
					ConstantErrorMessages._AccountLinkTypeinFC_MW,
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
			} else if (!accountLastDigitsAreZeroesTrailedByOne) {
				ErrorUtils.throwCBSException(null,
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					className,
					ConstantErrorMessages._ErrorAccountLinkEntryFC_MW,
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
			}
			
		}
		
		HashMap<String, String> map = new HashMap<>();
		
		map.put("cbs.GetImpersonateAccountInfo.accountBranch", (accountNumber.length() >= 3 ? accountNumber.substring(0, 3) : StringUtils.EMPTY));
		map.put("cbs.GetImpersonateAccountInfo.accountCCY", accountCCY);
		
		return map;
		
	}
	
	/**
	 * Function that checks if the account belongs to flex or not
	 * inputs should be translated to HOST values
	 * 
	 * @param accountNumber
	 * @return isFlex
	 * @throws
	 */
	public boolean isFlexAccount(String accountNumber){
		boolean isFlex = false;
		
		if(accountNumber != null && accountNumber.length() >= 3 && accountNumber.substring(0, 3).equals(FLEX_PREFIX)){
			isFlex = true;
		}
		
		return isFlex;
	}
	
}

