package gr.alpha.cbs.fuse.printing.siglo;


import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import gr.alpha.cbs.fuse.common.tools.FormatUtils;

public class PrintingExtentions {
	
	private static String[] m = {"", "ΕΝΑ ", "ΔΥΟ ", "ΤΡΙΑ ", "ΤΕΣΣΕΡΑ ", "ΠΕΝΤΕ ", "ΕΞΙ ", "ΕΠΤΑ ", "ΟΚΤΩ ", "ΕΝΝΕΑ "};
    private static String[] mF = {"", "ΜΙΑ ", "", "ΤΡΕΙΣ ", "ΤΕΣΣΕΡΙΣ "};
    private static String[] d1 = { "ΔΕΚΑ ", "ΕΝΤΕΚΑ ", "ΔΩΔΕΚΑ "};
    private static String[] d = {"", "ΔΕΚΑ", "ΕΙΚΟΣΙ ", "ΤΡΙΑΝΤΑ ", "ΣΑΡΑΝΤΑ ", "ΠΕΝΗΝΤΑ ", "ΕΞΗΝΤΑ ", "ΕΒΔΟΜΗΝΤΑ ", "ΟΓΔΟΝΤΑ ", "ΕΝΕΝΗΝΤΑ "};
    private static String[] e = {"", "ΕΚΑΤΟ", "ΔΙΑΚΟΣΙ", "ΤΡΙΑΚΟΣΙ", "ΤΕΤΡΑΚΟΣΙ", "ΠΕΝΤΑΚΟΣΙ", "ΕΞΑΚΟΣΙ", "ΕΠΤΑΚΟΣΙ", "ΟΚΤΑΚΟΣΙ", "ΕΝΝΙΑΚΟΣΙ"};
    private static String[] idx = {"%subCurrency%", "%currency% ", "ΧΙΛΙΑΔΕΣ ", "ΕΚΑΤΟΜΜΥΡΙ", "ΔΙΣ", "ΤΡΙΣ", "ΤΕΤΡΑΚΙΣ ", "ΠΕΝΤΑΚΙΣ "};
    private static String[] iso = {"EUR", "CHF", "JPY", "USD", "GBP"};
    private static String[] cur = {"ΕΥΡΩ", "CHF", "JPY", "USD", "GBP"};
    private static String[] subCur = {"ΛΕΠΤΑ", "RP/CTS", "YEN", "CENTS", "PENCE"};
    private static String[] oneSubCur = {"ΛΕΠΤΟ", "RP/CT", "YEN", "CENT", "PENNY"};
    private static final String EMPTY_STRING = "";
    private static final String SPACE = " ";
	private static final String DOUBLE_SLASH ="//";
    
	private PrintingExtentions() {
		throw new IllegalStateException("Utility class");
	}

	public static Map<String, String> readPrintingMap(Map<String, Object> printingMap) {
		
		Map<String, String> localMap = new HashMap<>();
		printingMap.entrySet().stream().forEach(mapping -> {
			String key = mapping.getKey().substring(1);
			if (mapping.getValue() instanceof String) {
				if (mapping.getValue() != null)
					localMap.put(key, (String) mapping.getValue());
				else	
					localMap.put(key, EMPTY_STRING);
			}
			else if (mapping.getValue() instanceof NodeList) {
				NodeList nodeList = (NodeList) mapping.getValue();			
				for (int i = 0; i < nodeList.getLength(); i++) {
					Node node = nodeList.item(i);
					try {
						removeNameSpace(node, null);
						String nodeString = FormatUtils.nodeToString(node, FormatUtils.OMIT_XML_DECLARATION_YES, FormatUtils.INDENT_NO);
						localMap.put(key, nodeString);
					} catch (Exception e) {
						throw new RuntimeException("Unable to serialize node to string", e);
					}
				}
				if (nodeList.getLength() <= 0)
					localMap.put(key, EMPTY_STRING);
			} 
			else	
				localMap.put(key, EMPTY_STRING);
		});			
		
		return localMap;
		
	}
	
	
	
	public static String generatePlaceholders(String resultString, Map<String, Object> printingMap) {
		
		Map<String, String> localMap = readPrintingMap(printingMap);		
		
		for (Map.Entry<String, String> entry : localMap.entrySet())
		{
			if (entry.getKey().startsWith("&&")) {
				resultString = resultString.replaceAll(Pattern.quote(entry.getKey()), entry.getValue());
			}
		}
		
		return resultString;
	}
	
	
    public static double round2(double value, int numberOfDigitsAfterDecimalPoint) {
        BigDecimal bigDecimal =  BigDecimal.valueOf(value);
        bigDecimal = bigDecimal.setScale(numberOfDigitsAfterDecimalPoint,
                RoundingMode.HALF_UP);
        return bigDecimal.doubleValue();
    }

    public static double round(double value, short precision) {
        return round2(value, precision);
    }

    public static String getVerbal(double money, String currency, boolean showZero,
                                   boolean showCurrency) {
        String str;
        short index = 0;
        boolean isZero = true;
        boolean isNegative = false;

        str = "";

        if (money < 0) {
            money = -money;
            isNegative = true;
        }

        if (money - Math.floor(money) != 0) {
            short value = (short) round(100 * money
                    - 100 * Math.floor(money), (short) 0);
            if (value >= 100) {
                value -= 100;
                money += 1.0;
            }

            money = (long) money;
            if (value > 0) {
                isZero = false;

                if (money >= 1 && value > 0) {
                    str += "ΚΑΙ ";
                }
                str += getValue(value, index, showCurrency, currency);
            }
        }

        while (money >= 1) {
            isZero = false;
            short value = (short) ((long) money % 1000);
            money /= 1000;
            index += 1;
            str = getValue(value, index, showCurrency, currency) + str;
            money = (long) money;
        }

        if (isZero) {
            if (showZero) {
                str = "ΜΗΔΕΝ ";
                if (showCurrency) {
                    str += idx[1];
                }
            }
        } else {
            if (isNegative)
                str = str.substring(0, 0) + "MEION " + str.substring(0);
        }

        if(Arrays.asList(iso).indexOf(currency) != -1) {        
	        str = str.replaceAll("%currency%", cur[Arrays.asList(iso).indexOf(currency)]);
	        str = str.replaceAll("%subCurrency%", subCur[Arrays.asList(iso).indexOf(currency)]);
        }
        else {
        	str = str.replaceAll("%currency%", currency);
	        str = str.replaceAll("%subCurrency%", "CENTS");
        }
        
        return str;
    }

    static String getValue(short money, short index, boolean showCurrency, String currency) {
        if (index == 2 && money == 1) {
            return "ΧΙΛΙΑ ";
        }

        String str = "";
        int dekmon = money % 100;
        int monades = dekmon % 10;
        int ekatontades = money / 100;
        int dekades = dekmon / 10;

        //EKATONTADES
        if (ekatontades == 1) {
            if (dekmon == 0) {
                str = e[1] + " ";
            } else {
                str = e[1] + "Ν ";
            }
        } else if (ekatontades > 1) {
            if (index == 2) {
                str = e[ekatontades] + "ΕΣ ";
            } else {
                str = e[ekatontades] + "Α ";
            }
        }

        //DEKADES
        switch (dekmon) {
            case 10:
                str += d1[monades];    //"ΔΕΚΑ " με κενό στο τέλος
                break;
            case 11:
            case 12:
                str += d1[monades];
                monades = 0;
                break;
            default:
                str += d[dekades];
                break;
        }

        //MONADES
        if ((index == 2) &&
                (monades == 1 || monades == 3 || monades == 4)) {
            str += mF[monades];
        } else {
            if (dekmon < 10 || dekmon > 12) {
                str += m[monades];
            }
        }

        if (str.length() > 0 || index == 1) {
            if (index == 0 && money == 1) {
                if (showCurrency) {
                    if(Arrays.asList(iso).indexOf(currency) != -1) {        
            	        str += oneSubCur[Arrays.asList(iso).indexOf(currency)];
                    }
                    else {                    	
            	        str += "CENT";
                    }
                }
            } else {
                if (index > 1 || showCurrency) {
                    str += idx[index];
                    if (index > 2) {
                        if (index > 3) {
                            str += idx[3];
                        }
                        if (money > 1) {
                            str += "Α ";
                        } else {
                            str += "Ο ";
                        }
                    }
                }
            }
        }

        return str;
    }	

	
	private static void removeNameSpace(Node node, String nameSpaceURI) {

	    if (node.getNodeType() == Node.ELEMENT_NODE) {
	        Document ownerDoc = node.getOwnerDocument();
	        NamedNodeMap map = node.getAttributes();
	        Node n;
	        while (map.getLength() != 0) {
	            n = map.item(0);
	            map.removeNamedItemNS(n.getNamespaceURI(), n.getLocalName());
	        }
            if (node.getLocalName() == null){
                ownerDoc.renameNode(node, nameSpaceURI, node.getNodeName());
            } else {
                ownerDoc.renameNode(node, nameSpaceURI, node.getLocalName());
            }

	    }
	    NodeList list = node.getChildNodes();
	    for (int i = 0; i < list.getLength(); i++) {
	        removeNameSpace(list.item(i), nameSpaceURI);
	    }
	}

}