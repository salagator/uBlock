package gr.alpha.cbs.fuse.kafka;

public class KafkaConstants {
	public static final String DATA_SOURCE_REF = "dataSourceRef";
	public static final String MESSAGE_ID = "messageId";
	public static final String PROCESS_NAME = "processName";
	public static final String PERSIST_MESSAGE = "persistMessage";
	public static final String TRANSACTED_PERSIST_MESSAGE = "transactedPersistMessage";
	public static final String PERSIST_MESSAGE_ID_PATH = "persistMessageIdPath";
	public static final String PERSIST_MESSAGE_TYPE = "persistMessageType";
	public static final String VALIDATE_MESSAGE = "validateMessage";

	public static final String DIRECT_ROUTE_FORMAT = "%s-%s-%s";
	public static final String DIRECT_SETUP_KAFKA_CONSUMER_MESSAGE_ID_EXCHANGE_PROPERTY = "direct:setupKafkaConsumerMessageIdExchangeProperty";
	public static final String DIRECT_PERSIST_KAFKA_CONSUMER_MESSAGE = "direct:persistKafkaConsumerMessage";
	public static final String DIRECT_SETUP_KAFKA_CONSUMER_EXCHANGE_PROPERTIES = "direct:setupKafkaConsumerExchangeProperties";
	public static final String DIRECT_VALIDATE_KAFKA_CONSUMER_MESSAGE = "direct:validateKafkaConsumerMessage";
	public static final String DIRECT_KAFKA_CONSUMER_MESSAGE_ROUTE = "direct:kafkaConsumerMessageRoute";

	public static final String DATASOURCE_BEAN_NAME = "kafkaDatasource";
	public static final String TRX_POLICY_BEAN_NAME = "kafkaTransactionPolicy";
	public static final String ERROR_UTILS_BEAN_NAME = "kafkaErrorUtils";

	private KafkaConstants() {
	}
}
