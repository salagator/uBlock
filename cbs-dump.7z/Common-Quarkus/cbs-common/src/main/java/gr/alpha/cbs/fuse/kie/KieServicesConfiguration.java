//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface KieServicesConfiguration {
    String getServerUrl();

    KieServicesConfiguration setServerUrl(String url);

    String getUserName();

    KieServicesConfiguration setUserName(String userName);

    String getPassword();

    KieServicesConfiguration setPassword(String password);

    MarshallingFormat getMarshallingFormat();

    KieServicesConfiguration setMarshallingFormat(MarshallingFormat format);

    boolean isJms();

    boolean isRest();

    Set<Class<?>> getExtraClasses();

    boolean addExtraClasses(Set<Class<?>> extraClassList);

    KieServicesConfiguration setExtraClasses(Set<Class<?>> extraClasses);

    KieServicesConfiguration clearExtraClasses();

    Transport getTransport();

    long getTimeout();

    KieServicesConfiguration setTimeout(long timeout);

    boolean getUseSsl();

    KieServicesConfiguration setUseSsl(boolean useSsl);

    void dispose();

    KieServicesConfiguration clone();

    void setCapabilities(List<String> capabilities);

    List<String> getCapabilities();

    void setCredentialsProvider(CredentialsProvider credentialsProvider);

    CredentialsProvider getCredentialsProvider();

    void setLoadBalancer(LoadBalancer loadBalancer);

    LoadBalancer getLoadBalancer();

/*
    void setJmsTransactional(boolean transacted);

    boolean isJmsTransactional();
*/

    void setHeaders(Map<String, String> headers);

    Map<String, String> getHeaders();

    /** @deprecated */
    @Deprecated
    Set<Class<?>> getExtraJaxbClasses();

    /** @deprecated */
    @Deprecated
    boolean addJaxbClasses(Set<Class<?>> extraJaxbClassList);

    /** @deprecated */
    @Deprecated
    KieServicesConfiguration setExtraJaxbClasses(Set<Class<?>> extraJaxbClasses);

    /** @deprecated */
    @Deprecated
    KieServicesConfiguration clearJaxbClasses();

    public static enum Transport {
        REST,
        JMS;
    }
}
