package gr.alpha.cbs.fuse.tools;

import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import org.apache.camel.Exchange;
import org.slf4j.MDC;
import org.w3c.dom.Document;

import gr.alpha.cbs.fuse.common.CBSConstants;

/* 
 * This is dummy class containing methods to help the CBS Application Monitoring platform to capture useful info
 */

public class AppMonitoringHelper {
			
	public static void initialize() {
		getBusinessCaseId();
		getRequestId();
		getUserId();
	}
	
	public static String getBusinessCaseId() {
		return MDC.get(CBSConstants.MDC_KEY_BUSINESS_CASE_ID);
	}
	
	public static String getUserId() {
		return MDC.get(CBSConstants.MDC_KEY_USER_ID);
	}
	
	public static String getRequestId() {
		return MDC.get(CBSConstants.MDC_KEY_REQUEST_ID);
	}
	
	public static String captureErrorCode(Exchange exchange) {
		try {
			Document doc = exchange.getIn().getBody(Document.class);
			return FormatUtils.getValue(doc, "//*:ErrorMessage/*:ErrorCode");
		} catch (Exception e) {
			return null;
		}
	}
}
