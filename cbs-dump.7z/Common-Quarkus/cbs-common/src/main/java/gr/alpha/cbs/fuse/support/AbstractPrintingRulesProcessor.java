package gr.alpha.cbs.fuse.support;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.tools.Holder;
import org.apache.camel.Exchange;
//import org.kie.api.runtime.KieSession;

public abstract class AbstractPrintingRulesProcessor extends AbstractRulesProcessor {
	
	private boolean useOperationAgenda;
	
	public AbstractPrintingRulesProcessor() {
		super();
		this.useOperationAgenda = false;
	}
	
	public AbstractPrintingRulesProcessor(String kjarGroupId, String kjarArtifactId, String kjarVersion, String kieProcessName, boolean useOperationAgenda) {
		super(kjarGroupId, kjarArtifactId, kjarVersion, kieProcessName);
		this.useOperationAgenda = useOperationAgenda;
	}
	
	public void setUseOperationAgenda(boolean useOperationAgenda) {
		this.useOperationAgenda = useOperationAgenda;
	}
	
	public boolean isUseOperationAgenda() {
		return useOperationAgenda;
	}

	private PrintingResponse callBRMS(Map<String, Object> printingMap, String operationName, String slipType,
			String templateName, boolean cardReaderPresentFlag, boolean sendByEmail) throws Exception {
		
		PrintingMetadata metaData = new PrintingMetadata();
		metaData.setOperationName(operationName);
		metaData.setSlipType(slipType);
		metaData.setTemplateName(templateName);
		metaData.setCardReaderPresentFlag(cardReaderPresentFlag);
		metaData.setSendByEmail(sendByEmail);
		
		final Holder<String> errorHolder = new Holder<>(null);
		printingMap.entrySet().stream().filter(mapping -> mapping.getKey().substring(1).startsWith("brms_")).forEach(mapping -> {
			String key = mapping.getKey().substring(6);
			try {
				Object value = mapping.getValue();
				Field field = PrintingMetadata.class.getDeclaredField(key);
				field.setAccessible(true);
				field.set(metaData, value);
			} catch (NoSuchFieldException | IllegalArgumentException | IllegalAccessException e) {
				errorHolder.value = "Unable to set field: '" + key + "' on PrintingMetadata object.";
			}
		});
		if (errorHolder.value != null) {
			throw new Exception(errorHolder.value);
		}
		
		PrintingResponse response = new PrintingResponse();
		response.setOperationName(operationName);
		response.setSlipType(slipType);
		response.setCardReaderPresentFlag(cardReaderPresentFlag);
		response.setSendByEmail(sendByEmail);
		response.setTemplateName(templateName);
		response.setStatus("");
		
		// KieSession kieSession = getKieContainer().newKieSession("ksession-printing");
		
		// kieSession.insert(metaData);
		// kieSession.insert(response);

		// if (useOperationAgenda) {
		// 	kieSession.getAgenda().getAgendaGroup(operationName).setFocus();
		// }
		// kieSession.fireAllRules();

		// kieSession.dispose();
		
		return response;
	}
	
	protected abstract void performCustomProcessing(
			Exchange exchange,
			Map<String, Object> printingMap,
			String operationName,
			List<String> templateList,
			List<String> slipTypeList,
			List<String> modeList,
			List<String> statusList,
			List<PrintingResponse> responseList);
	
	protected static class PrintingInfoFromRoute {
		List<String> slipTypeList;
		List<String> templateList;
		List<String> statusList;
		List<String> modeList;
	}
	
	@SuppressWarnings("unchecked")
	protected PrintingInfoFromRoute initPrintingInfoFromRoute(Exchange exchange) throws Exception {
		PrintingInfoFromRoute returnValue = new PrintingInfoFromRoute();
		
		Map<String, Object> properties = exchange.getProperties();
		returnValue.slipTypeList = (List<String>) properties.get(CBSConstants.HEADER_PRINTING_SLIP_TYPE);
		returnValue.templateList = (List<String>) properties.get(CBSConstants.HEADER_PRINTING_TEMPLATE_CODE);

		if (returnValue.slipTypeList == null || returnValue.templateList == null) {
			if (returnValue.slipTypeList == null) {
				returnValue.slipTypeList = new ArrayList<>();
			}
			if (returnValue.templateList == null) {
				returnValue.templateList = new ArrayList<>();
			}
		}
		if (returnValue.slipTypeList.size() != returnValue.templateList.size()) {
			throw new Exception("Slip type list (" + returnValue.slipTypeList.size() +
					") and template list (" + returnValue.templateList.size() + ") have different sizes.");
		}
		
		returnValue.statusList = new ArrayList<>();
		returnValue.modeList = new ArrayList<>();
		
		return returnValue;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void process(Exchange exchange) throws Exception {
		Map<String, Object> properties = exchange.getProperties();
		
		String operationName = (String) properties.get(CBSConstants.HEADER_TRANSACTION_NAME);
		boolean cardReaderPresentFlag = Boolean.parseBoolean((String) properties.get(CBSConstants.HEADER_CARD_READER_PRESENT));
		boolean sendByEmail = false; // TODO where do we get this from the body? - possibly coming from the event registry?
		Map<String, Object> printingMap = (Map<String, Object>) properties.get("printingMap");
		PrintingInfoFromRoute printingInfoFromRoute = initPrintingInfoFromRoute(exchange);
		List<PrintingResponse> responseList = new ArrayList<>();
		
		for (int i = printingInfoFromRoute.slipTypeList.size() - 1; i >= 0; i--) {
			String slipType = printingInfoFromRoute.slipTypeList.get(i);
			String templateName = printingInfoFromRoute.templateList.get(i);
			
			PrintingResponse responseData = callBRMS(printingMap, operationName, slipType, templateName, cardReaderPresentFlag, sendByEmail);
			
			printingInfoFromRoute.statusList.add(responseData.getStatus());
			printingInfoFromRoute.modeList.add(responseData.getMode());
			
			responseList.add(0, responseData);
		}
		
		performCustomProcessing(exchange, printingMap, operationName,
				printingInfoFromRoute.templateList,
				printingInfoFromRoute.slipTypeList,
				printingInfoFromRoute.modeList,
				printingInfoFromRoute.statusList,
				responseList);
		
		properties.put(CBSConstants.HEADER_PRINTING_STATUS, printingInfoFromRoute.statusList);
		properties.put(CBSConstants.HEADER_PRINTING_MODE, printingInfoFromRoute.modeList);
		properties.put(CBSConstants.HEADER_PRINTING_SLIP_TYPE, printingInfoFromRoute.slipTypeList);
		properties.put(CBSConstants.HEADER_PRINTING_TEMPLATE_CODE, printingInfoFromRoute.templateList);		
	}

}
