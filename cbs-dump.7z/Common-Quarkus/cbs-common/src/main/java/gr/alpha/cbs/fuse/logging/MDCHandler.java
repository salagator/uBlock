package gr.alpha.cbs.fuse.logging;

import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.jboss.logging.Logger;
import org.slf4j.MDC;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

@Named("mdcHandler")
@ApplicationScoped
@RegisterForReflection
public class MDCHandler implements Processor {

	/*
	 * The following are the names that are used to store the "logging" information on the
	 * MDC log4j infrastructure.
	 */
	public static final String MDC_KEY_REQUEST_ID = "cbs.RequestId";
	public static final String MDC_KEY_SESSION_ID = "cbs.SessionId";
	public static final String MDC_KEY_BUSINESS_CASE_ID = "cbs.BusinessCaseId";
	public static final String MDC_KEY_SEQUENCE_ID = "cbs.SequenceId";
	public static final String MDC_KEY_USER_ID = "cbs.UserId";
	public static final String MDC_KEY_CBS_UN_ID = "cbs.CBSUnId";
	

	public static final String DEFAULT_SEQUENCE_ID = "1";	
	public static final String DEFAULT_USER_ID = "LegacyDispatcher";	
	
	private static final Logger LOGGER = Logger.getLogger(MDCHandler.class);
	

	@Override
	public void process(Exchange exchange) throws Exception {
		
		
	      		
        String requestId = (String) exchange.getProperty("cbs.legacyDispatcher.common.requestId");
        String sequenceId = (String) exchange.getProperty("cbs.legacyDispatcher.common.sequenceId");
        String sessionId = (String) exchange.getProperty("cbs.legacyDispatcher.common.sessionId");
        String businessCaseId =  (String) exchange.getProperty("cbs.legacyDispatcher.common.businesscaseId");
        String userId =  (String) exchange.getProperty("cbs.legacyDispatcher.common.userId");
        String cbsunId =  (String) exchange.getProperty("cbs.legacyDispatcher.common.cbsunId");
        
		MDC.put(MDC_KEY_REQUEST_ID, requestId);
		MDC.put(MDC_KEY_SEQUENCE_ID, sequenceId);
		MDC.put(MDC_KEY_SESSION_ID, sessionId);
		MDC.put(MDC_KEY_BUSINESS_CASE_ID, businessCaseId);
		MDC.put(MDC_KEY_USER_ID, userId);
		MDC.put(MDC_KEY_CBS_UN_ID, cbsunId);
		
	
		
       if(LOGGER.isDebugEnabled()){
			LOGGER.debug("MDC set. requestId:" + requestId + " sequenceId:" + sequenceId + " sessionId:" + sessionId + " businessCaseId:" + businessCaseId+ " userId:" + userId);
		}        			

       exchange.setProperty("requestIdProp", requestId);
       exchange.setProperty("sessionIdProp", sessionId);
       exchange.setProperty("businessCaseIdProp", businessCaseId);
       exchange.setProperty("sequenceIdProp", sequenceId);
       exchange.setProperty("userIdProp", userId);
	}
	
}

