package gr.alpha.cbs.fuse.processors;

import gr.alpha.cbs.fuse.bean.HorizontalProcessor;
import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.support.TransactionConfig;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import gr.alpha.cbs.fuse.support.OrderedProperties;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import net.sf.saxon.s9api.SaxonApiException;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Expression;
import org.apache.camel.language.simple.types.SimpleIllegalSyntaxException;
import org.apache.camel.spi.Language;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

import static org.apache.commons.lang3.StringUtils.leftPad;
import static org.apache.commons.lang3.StringUtils.rightPad;

@Named("accountingProcessor")
@ApplicationScoped
@RegisterForReflection
public class AccountingProcessor {

    private static final Logger LOGGER = Logger.getLogger(AccountingProcessor.class);

    private static final String ACCOUNTING_FOLDER_NAME = "accounting";

    private static final String KIND = "Kind";
    private static final String LENGTH = "Length";

    /*
     * 				ACCOUNTING PROCESSOR functionality
     *
     * Accounting Processor should be invoked in the inner routeContext of each ESB operation that has accounting, before the call to the BE ACGENTRCRE component
     * The processor performs the following steps :
     *
     * 1-> Reads the configuration exchange property that holds the Event Registry Configuration in order to get the defined accounting templates for the operation.
     * --If no accounting template has been defined, returns an exception.
     * --If only one accounting template has been defined in the Event Registry, sets the template code in the cbs.selectedAccountingTemplate exchange property
     * --If more than one accounting templates has been defined in the Event Registry , the processor gets the cbs.selectedAccountingTemplate exchange property (that should be already defined
     * in the inner routeContext with the template value, depending on the template selection logic for each operation) and checks if the selected template value exists in the Event Registry Configuration.
     * If does not exist, an exception is raised.
     *
     * 2-> With the selected accountingTemplate value, reads the corresponding property file that holds the values to form the accounting buffer. The way that the property file is being read  is pretty similar
     * to this of the journal properties file.
     *
     * 3-> One exchange property, named cbs.accounting.buffer is being initialized with the final accounting buffer, and is ready to be used as input in the L-ACGENTRCRE-IN-BUFFER field of the BE ACGENTRCRE component
     */
    public void process(Exchange exchange) throws Exception{

        String transactionName = exchange.getProperty(CBSConstants.HEADER_TRANSACTION_NAME, String.class);

        LinkedHashMap<String,Object> accountingBufferMap = new LinkedHashMap<String,Object>();

        //Read Event Registry Configuration to get the accountingTemplate values
        TransactionConfig conf = (TransactionConfig)exchange.getProperty("configuration");

        String accountingTemplatesFromConf = conf.getAccountingTemplate();

        LOGGER.debug("Accounting Template Configured from Event Registry : " + accountingTemplatesFromConf);

        //if no accountingTemplate has been defined in the event registry for the specified transaction, then an exception will be thrown
        if (StringUtils.isEmpty(accountingTemplatesFromConf)){
            throw new Exception("No accounting template has been defined in the event registry for operation "+transactionName);
        }

        //split the event registry configuration into an array of strings in order to be able to identify the number of distinct templates configured
        //substring is used in order to remove the first occurence of the character "|" since normal value of the configuration attribute accountingTemplate is for example "|1|"
        //TODO remove substring and find a better way to achieve the elimination of first "|"

        String[] accountingTemplatesArray = accountingTemplatesFromConf.substring(1).split("\\|");


        //if only one accounting template has been defined in the event registry, then this value will be set in the cbs.selectedAccountingTemplate exchange property
        //and will be used to select the appropriate property file
        if(accountingTemplatesArray.length == 1){
            exchange.setProperty("cbs.selectedAccountingTemplate", accountingTemplatesArray[0]);
        }

        //otherwise the provided cbs.selectedAccountingTemplate exchange property  will be used to select the appropriate property file

        else if (accountingTemplatesArray.length > 1 ){

            //if no accountingTemplate has been defined in the selectedAccountingTemplate property, then an exception will be thrown
            if (StringUtils.isEmpty(exchange.getProperty("cbs.selectedAccountingTemplate",String.class))){
                throw new Exception("No accounting template has been selected.");
            }

            //if the accountingTemplates defined in the Event Registry do not contain the selectedAccountingTemplate, then an exception will be thrown
            if(!Arrays.asList(accountingTemplatesArray).contains(exchange.getProperty("cbs.selectedAccountingTemplate",String.class))){
                throw new Exception("The selected accounting template is not among in the accounting templates defined in the event registry for operation "+transactionName);
            }

        }

        String selectedAccountingTemplate = exchange.getProperty("cbs.selectedAccountingTemplate",String.class);

        LOGGER.debug("Selected Accounting Template is " +selectedAccountingTemplate);

        accountingBufferMap = readAccountingPropertyFile(exchange,selectedAccountingTemplate);

        LinkedHashMap<String,String> finalAccountingBufferMap = new LinkedHashMap<String,String>();

        //Read the configuration for the different accounting codes
        Map<String, Map<String,String>> accountingCodesConfiguration = (Map<String, Map<String, String>>) exchange.getProperty("accountingCodesConfiguration");

        LOGGER.debug("Accounting Map : "+accountingCodesConfiguration);

        for (Map.Entry<String, Object> entry : accountingBufferMap.entrySet())
        {
            String currentKey = entry.getKey();
            //currentKeyToInt is used in order to search the accounting code characteristics from the dictionary
            //e.g. if the accounting code is N00031 we will search in the dictionary with the key 31
            int currentKeyToInt = NumberUtils.toInt(currentKey.substring(1));
            String currentValue = entry.getValue().toString();
            int currentValueLength = currentValue.length();


            String currentKeyKind = accountingCodesConfiguration.get(String.valueOf(currentKeyToInt)).get(KIND);
            int currentKeyLength = NumberUtils.toInt(accountingCodesConfiguration.get(String.valueOf(currentKeyToInt)).get(LENGTH));

            LOGGER.debug("currentKey : "+currentKey+ ", currentValue : "+currentValue+ ", currentValueLength : "+String.valueOf(currentValueLength)+ ", currentKeyType : "+currentKeyKind+ ", currentKeyLength : "+String.valueOf(currentKeyLength));

            if (currentValueLength == currentKeyLength){

                finalAccountingBufferMap.put(currentKey, currentValue);
            }
            else if (currentValueLength < currentKeyLength){
                StringBuilder fixedLengthValue = new StringBuilder();

                if("2".equalsIgnoreCase(currentKeyKind)){	// 2 stands for string
                    fixedLengthValue.append(rightPad(currentValue, currentKeyLength, ' '));
                }
                else if ("1".equalsIgnoreCase(currentKeyKind)){	//1 stands for numeric
                    fixedLengthValue.append(leftPad(currentValue, currentKeyLength, '0'));
                }

                finalAccountingBufferMap.put(currentKey, fixedLengthValue.toString());
            }
            else if (currentValueLength > currentKeyLength){
                throw new Exception("Value :" +currentValue+ " for accounting code : " +currentKey+ " has length : "+String.valueOf(currentValueLength)+ " but configured length is : "+String.valueOf(currentKeyLength));
            }


        }

        String accountingBuffer = finalAccountingBufferMap.entrySet()
                .stream()
                .map(entry -> entry.getKey() + "|" + entry.getValue())
                .collect(Collectors.joining("|"));

        //append accounting template value
        accountingBuffer = selectedAccountingTemplate + "|" + accountingBuffer + "|";

        LOGGER.debug("The delivered accounting buffer is : "+accountingBuffer);

        exchange.setProperty("cbs.accounting.buffer", accountingBuffer);

    }

    private LinkedHashMap<String,Object> readAccountingPropertyFile(Exchange exchange,String selectedAccountingTemplate) throws IOException, XPathExpressionException, ParserConfigurationException {

        LinkedHashMap<String,Object> accountingPropertiesMap = new LinkedHashMap<String,Object>();

        //read the property file that corresponds to the selectedAccountingTemplate
        OrderedProperties accountProperties =  getAccountingProperties(exchange,selectedAccountingTemplate);

        if (accountProperties.size() > 0){

            Document body = exchange.getIn().getBody(Document.class);

            XPath xpath = FormatUtils.getXpath(null);

            CamelContext camelContext = exchange.getContext();
            Language language = camelContext.resolveLanguage("simple");

            for(Map.Entry<String, String> record : accountProperties.entrySet()){

                String recordKey = record.getKey().toString();
                String recordValue = record.getValue().toString();
                LOGGER.debug(recordKey+"-"+recordValue);

                if(recordKey.endsWith(".S")){
                    Expression expression = null;
                    Object obj = null;
                    recordKey = recordKey.substring(0, recordKey.length() - 2);

                    try {
                        /* when expression starts with header - property - body it is evaluated as object otherwise it is evaluated as constant */
                        String expressionStr = null;
                        if(record.getValue()!= null && (record.getValue().startsWith("body") ||record.getValue().startsWith("header") || record.getValue().startsWith("exchangeProperty")))
                            expressionStr = "${" + record.getValue() + "}";
                        else if (record.getValue()!= null && record.getValue().startsWith("property")) {
                            expressionStr = "${" + record.getValue().replace("property","exchangeProperty") + "}";
                        }
                        else
                            expressionStr = record.getValue();

                        expression = language.createExpression(expressionStr);
                        obj = expression.evaluate(exchange, Object.class);
                    } catch (SimpleIllegalSyntaxException e) {

                        throw new SimpleIllegalSyntaxException(e.getExpression(), e.getIndex(),
                                "Error in Simple Expression " + record.getValue() + " of accounting template " + selectedAccountingTemplate);
                    }

                    accountingPropertiesMap.put(recordKey, (String)obj);

                }

                else if (recordKey.endsWith(".X")){
                    XPathExpression expr;
                    Object result = null;

                    recordKey = recordKey.substring(0, recordKey.length() - 2);

                    try {
                        expr = xpath.compile(record.getValue());
                        result = expr.evaluate(body, XPathConstants.NODESET);

                        NodeList nodes = (NodeList) result;



                        if (nodes.getLength() != 0) {
                            LOGGER.debug("Get node type :"+nodes.item(0).getNodeType());
                            if (nodes.item(0).getNodeType() == Node.ELEMENT_NODE) {
                                Node node = (nodes.item(0));
                                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                                dbFactory.setNamespaceAware(true);
                                DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                                Document doc = dBuilder.newDocument();
                                doc.appendChild(doc.importNode(node, true));
                                Node nodeWithoutNameSpace = doc.getFirstChild();
                                removeNamSpace(nodeWithoutNameSpace, null);
                                accountingPropertiesMap.put(recordKey, nodeWithoutNameSpace);
                                LOGGER.debug("Record : "+recordKey+" is node!");
                            } else {
                                accountingPropertiesMap.put(recordKey, nodes.item(0).getNodeValue());
                                LOGGER.debug("Record : "+recordKey+" is NOT node!");

                            }
                        }

                    } catch (XPathExpressionException e) {
                        try {
                            LOGGER.debug("XPathExpressionException occured trying xpath 2.0");
                            String tempValue = HorizontalProcessor.xpath2Evaluate(exchange, record.getValue());
                            LOGGER.debug("Record : "+recordKey+" uses XPath 2");
                            /** If the evaluation of the xpath fails tries with a library for XPATH-2.0 */
                            accountingPropertiesMap.put(recordKey, tempValue);
                        } catch (SaxonApiException e1) {
                            throw new XPathExpressionException("Error in xpath " + record.getValue() + " of accounting template " + selectedAccountingTemplate);
                        }
                    }

                }
            }


        }

        return accountingPropertiesMap;
    }


    private OrderedProperties getAccountingProperties(Exchange exchange, String selectedAccountingTemplate) throws IOException{
        OrderedProperties accountProperties = new OrderedProperties();

        String transactionName = exchange.getProperty(CBSConstants.HEADER_TRANSACTION_NAME, String.class);

        String folderName = ACCOUNTING_FOLDER_NAME;

        OrderedProperties accountProps = new OrderedProperties();

        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        InputStream input = null;

        try{
            String file = folderName + "/" + folderName + "-" + transactionName + "-" + selectedAccountingTemplate + ".properties";

            LOGGER.debug("loading file " + file);
            input = classLoader.getResourceAsStream(file);
            accountProps.load(input);

        } catch (Exception e) {
            throw new IOException( "No accounting properties file found for " + selectedAccountingTemplate + " of "+ transactionName + " operation.", e);
        }  finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    LOGGER.error("Exception closing input stream");
                }
            }
        }

        return accountProps;
    }

    private void removeNamSpace(Node node, String nameSpaceURI) {

        if (node.getNodeType() == Node.ELEMENT_NODE) {
            Document ownerDoc = node.getOwnerDocument();
            NamedNodeMap map = node.getAttributes();
            Node n;
            while (!(0==map.getLength())) {
                n = map.item(0);
                map.removeNamedItemNS(n.getNamespaceURI(), n.getLocalName());
            }
            ownerDoc.renameNode(node, nameSpaceURI, node.getLocalName());
        }
        NodeList list = node.getChildNodes();
        for (int i = 0; i < list.getLength(); i++) {
            removeNamSpace(list.item(i), nameSpaceURI);
        }
    }

}
