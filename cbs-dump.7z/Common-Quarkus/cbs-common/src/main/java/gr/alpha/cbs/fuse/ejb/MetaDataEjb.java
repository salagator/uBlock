package gr.alpha.cbs.fuse.ejb;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import javax.sql.DataSource;

import jakarta.inject.Singleton;
import jakarta.transaction.Transactional;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import gr.alpha.cbs.fuse.common.support.TransactionConfig;
import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangeProperty;
import org.apache.commons.lang3.StringUtils;
import org.infinispan.client.hotrod.exceptions.HotRodClientException;
import org.jboss.logging.Logger;

@Named("metaDataEjb")
@Singleton
@RegisterForReflection
@Transactional(Transactional.TxType.NOT_SUPPORTED)
public class MetaDataEjb {

	private static final Logger LOGGER = Logger.getLogger(MetaDataEjb.class);

	@Inject
	@io.quarkus.agroal.DataSource("hostcbsparams")
	DataSource sqlCbsParamsDS;

	private static final String EVENT_REGISTRY_CACHE_NAME = "eventRegistryCache";
	private static final String EVENT_REGISTRY_CACHE_KEY = "EVT_REG";

	private static final int COL_CBSREFCODE = 2;
	private static final int COL_DESCRIPTION = 4;
	private static final int COL_ALIAS = 5;
	private static final int COL_ACOBFUNCTIONCODE = 6;
	private static final int COL_TXNNATCODE = 9;
	private static final int COL_TXNTYPECODE = 11;
	private static final int COL_APPLICATIONDESCRIPTION = 14;
	private static final int COL_SERVICENAME = 17;
	private static final int COL_OPERATIONNAME = 18;
	private static final int COL_ISVISIBLE = 19;
	private static final int COL_REVERSALSERVICEOPERATION = 20;
	private static final int COL_TXNATTRCODE = 21;
	private static final int COL_TXNATTRVALUE = 23;
	private static final int COL_TXNATTRVALUEDESCR = 24;
	private static final int COL_INTERNALESLIPTYPEID = 25;
	private static final int COL_INTERNALTEMPLATEID = 26;

	RemoteDatagridClientHelper<String,Object> datagridHelper;

	public void loadMetaData(Exchange exchange, @ExchangeProperty(CBSConstants.HEADER_TRANSACTION_NAME) String operationName) throws CBSException {
		LOGGER.info("loadMetaData start");

		String serviceName = exchange.getProperty(CBSConstants.HEADER_TRANSACTION_SERVICE, String.class);
		String eventKey = serviceName + operationName;

		LOGGER.info("Lookup event key: " + eventKey);
		TransactionConfig configuration = getEventRegistryConfiguration(serviceName, operationName);
		if (configuration == null) {
			LOGGER.warn("There is not Configuration for " + eventKey + " In Event Registry");

			ErrorUtils.throwCBSException(null,
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					this.getClass().getCanonicalName(),
					ConstantErrorMessages._ServiceNotParameterizedEventsRegistry,
					"3", "", "", "", "");
		}
		exchange.setProperty("configuration", configuration);

		List<String> horizontalPropertyFiles = new ArrayList<>();
		if (configuration != null) {
			if (configuration.getJournal()) {
				horizontalPropertyFiles.add("journal");
			}
			if (configuration.getBmr()) {
				horizontalPropertyFiles.add("bmr");
			}
			if (configuration.getGenEctronicSlip()) {
				horizontalPropertyFiles.add("printing");
				exchange.setProperty(CBSConstants.HEADER_PRINTING_SLIP_TYPE, configuration.getElectronicSlipTypeList());
				exchange.setProperty(CBSConstants.HEADER_PRINTING_TEMPLATE_CODE, configuration.getTemplateIDList());
			}
			if (configuration.isCanReverse()) {
				horizontalPropertyFiles.add("journalReverse");
			}
			if (configuration.getGeneratesExtrait()) {
				horizontalPropertyFiles.add("extrait");
			}
		}
		exchange.setProperty("horizontalPropertyFiles", horizontalPropertyFiles);

		LOGGER.info("loadMetaData end");
	}

	/**
	 * Gets the event registry.
	 *
	 * @return a {@link Map} of service + operation as key and associated {@link TransactionConfig} as value.
	 * @throws CBSException
	 */
	public Map<String, TransactionConfig> getEventRegistryConfiguration() throws CBSException {
		Map<String, TransactionConfig> eventRegistry = null;
		boolean saveEventRegistryInCache = true;
		try {
			eventRegistry = getEventRegistryFromCache();
		} catch (HotRodClientException e) {
			if (datagridHelper.isCausedByInvalidClass(e)) {
				saveEventRegistryInCache = false;
				LOGGER.error("Invalid class when getting value in cache. Will not save DB value in cache. Suppressing... (" + e.getMessage() + ")");
			} else {
				LOGGER.error("Invalid class when getting value in cache. Suppressing...", e);
				throw e;
			}
		}
		if (eventRegistry == null) {
			LOGGER.info("No event registry found in cache");
			eventRegistry = loadTransactionsFromDB(saveEventRegistryInCache);
			if (eventRegistry == null) {
				ErrorUtils.throwCBSException(null,
						ErrorTypeModel.ERROR_TYPE_TECHNICAL,
						ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
						this.getClass().getCanonicalName(),
						ErrorTypeModel.DEFAULT_ERROR_CODE,
						ErrorTypeModel.SEVERITY_ERROR,
						"", "", "", "");
			}
		}
		return eventRegistry;
	}

	/**
	 * Gets the {@link TransactionConfig} for the requested service and operation names.
	 *
	 * @param serviceName service name
	 * @param operationName operation name
	 * @return the {@link TransactionConfig} associated with requested event registry key or null
	 * @throws CBSException
	 */
	public TransactionConfig getEventRegistryConfiguration(String serviceName, String operationName) throws CBSException {
		TransactionConfig config = getTransactionConfigFromCache(serviceName + operationName);
		if (config == null) {
			LOGGER.info("No transaction configuration found in cache");
			config = loadTransactionFromDB(serviceName, operationName);
			if (config == null) {
				ErrorUtils.throwCBSException(null,
						ErrorTypeModel.ERROR_TYPE_TECHNICAL,
						ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
						this.getClass().getCanonicalName(),
						ConstantErrorMessages._ServiceNotParameterizedEventsRegistry,
						ErrorTypeModel.SEVERITY_ERROR,
						"", "", "", "");
			}
		}
		return config;
	}

	Map<String, TransactionConfig> loadTransactionsFromDB(boolean saveEventRegistryToCache) throws CBSException {
		Map<String, TransactionConfig> eventRegistry = null;
		try (Connection conn = sqlCbsParamsDS.getConnection(); CallableStatement cstmt = conn.prepareCall("{call usp_PRD_GetTransactions(?)}");) {
			cstmt.setQueryTimeout(30);
			cstmt.setInt(1, 1);

			LOGGER.info("Building event registry");
			TransactionConfig config = null;

			try (ResultSet rs = cstmt.executeQuery();) {
				eventRegistry = new HashMap<>();

				while (rs.next()) {
					int transactionAttribute = rs.getInt(COL_TXNATTRCODE);
					if (transactionAttribute == 101) {
						if (config != null) {
							addTransactionInEventRegistry(eventRegistry, config);
						}

						config = new TransactionConfig();
						initTransactionConfig(config, rs);
					} else {
						addTransactionConfigAttribute(config, transactionAttribute, rs);
					}
				}

				addTransactionInEventRegistry(eventRegistry, config);
				if (saveEventRegistryToCache) {
					LOGGER.info("Saving event registry in cache");
					storeEventRegistryInCache(eventRegistry);
				}
			}
		} catch (SQLException e) {
			LOGGER.error("Error in loadTransactionsFromDB: " + e.getCause());
			ErrorUtils.throwCBSException(e,
					ErrorTypeModel.ERROR_TYPE_TECHNICAL,
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					this.getClass().getCanonicalName(),
					ErrorTypeModel.DEFAULT_ERROR_CODE,
					ErrorTypeModel.SEVERITY_ERROR,
					e.getMessage(), "", "", "");
		}
		return eventRegistry;
	}

	void addTransactionInEventRegistry(Map<String, TransactionConfig> eventRegistry, TransactionConfig config) {
		if (eventRegistry != null && config != null) {
			String eventServiceName = config.getService();
			String eventOperationName = config.getOperation();
			String eventKey = eventServiceName + eventOperationName;
			eventRegistry.put(eventKey, config);
		}
	}

	TransactionConfig loadTransactionFromDB(String serviceName, String operationName) throws CBSException {
		try (Connection conn = sqlCbsParamsDS.getConnection(); CallableStatement cstmt = conn.prepareCall("{call usp_PRD_GetTransactions(?, ?, ?)}");) {
			cstmt.setQueryTimeout(30);
			cstmt.setInt(1, 1);
			cstmt.setString(2, operationName);
			cstmt.setString(3, serviceName);

			if (cstmt.execute()) {
				LOGGER.info("Building transaction configuration");
				try (ResultSet rs = cstmt.getResultSet();) {
					TransactionConfig config =new TransactionConfig();
					while (rs.next()) {
						int transactionAttribute = rs.getInt(COL_TXNATTRCODE);
						if (transactionAttribute == 101) {
							initTransactionConfig(config, rs);
						} else {
							addTransactionConfigAttribute(config, transactionAttribute, rs);
						}
					}
					storeTransactionConfigInCache(config);
					return config;
				}
			}
		} catch (SQLException e) {
			LOGGER.error("Error in loadTransactionFromDB: " + e.getCause());
			ErrorUtils.throwCBSException(e,
					ErrorTypeModel.ERROR_TYPE_TECHNICAL,
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					this.getClass().getCanonicalName(),
					ErrorTypeModel.DEFAULT_ERROR_CODE,
					ErrorTypeModel.SEVERITY_ERROR,
					e.getMessage(), "", "", "");
		}

		return null;
	}

	void initTransactionConfig(TransactionConfig config, ResultSet rs) throws SQLException {
		config.setEventCode(rs.getString(COL_CBSREFCODE));
		config.setDescriptionNative(rs.getString(COL_DESCRIPTION));
		config.setAliasName(rs.getString(COL_ALIAS));
		config.setAcobFunctionCode(rs.getString(COL_ACOBFUNCTIONCODE));
		config.setSourceApplication(rs.getString(COL_APPLICATIONDESCRIPTION));
		config.setOperation(rs.getString(COL_OPERATIONNAME));
		config.setVisible(rs.getBoolean(COL_ISVISIBLE));
		config.setDebit(rs.getBoolean(COL_TXNATTRVALUE));
		config.setEventType(rs.getString(COL_TXNTYPECODE));
		config.setTransactionNature(rs.getString(COL_TXNNATCODE));
		config.setService(rs.getString(COL_SERVICENAME));
		config.setReversalServiceOperation(rs.getString(COL_REVERSALSERVICEOPERATION));
		config.setCreateBUN(true); // This will get overwritten by the proper attribute below
	}

	void addTransactionConfigAttribute(TransactionConfig config, int transactionAttribute, ResultSet rs) throws SQLException {
		if (config != null && rs != null) {
			switch (transactionAttribute) {
				case 102:
					config.setCredit(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 103:
					config.setManagerial(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 104:
					config.setInquiry(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 105:
					config.setRestrictionGrouping(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 106:
					config.setAllowTransactionChannel(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 107:
					config.setRequiresApproval(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 108:
					config.setReversalEvent(rs.getString(COL_TXNATTRVALUE));
					break;
				case 109:
					config.setSensitive(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 201:
					config.setJournal(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 202:
					config.setVlm(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 203:
					config.setBmr(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 204:
					config.setGenAlert(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 205:
					config.setGenEctronicSlip(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 206:
					config.setElectronicSlipType(rs.getString(COL_TXNATTRVALUE));
					config.addElectronicSlipTypeAndTemplateID(rs.getString(COL_INTERNALESLIPTYPEID), rs.getString(COL_INTERNALTEMPLATEID));
					break;
				case 207:
					config.setEventExMode(rs.getString(COL_TXNATTRVALUE));
					break;
				case 208:
					config.setJournalOnException(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 209:
					config.setCheckDateValidation(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 210:
					config.setHasTotals(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 211:
					config.setTagGroup(StringUtils.isEmpty(config.getTagGroup()) ? "|" + rs.getString(COL_TXNATTRVALUE) + "|" : config.getTagGroup() + rs.getString(COL_TXNATTRVALUE) + "|");
					break;
				case 212:
					config.setGeneratesExtrait(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 301:
					config.setAccountingTemplate(StringUtils.isEmpty(config.getAccountingTemplate()) ? "|" + rs.getString(COL_TXNATTRVALUEDESCR) + "|" : config.getAccountingTemplate() + rs.getString(COL_TXNATTRVALUEDESCR) + "|");
					break;
				case 302:
					config.setUnTransNumberType(rs.getString(COL_TXNATTRVALUE));
					break;
				case 110:
					config.setJtaTransactionTimeout(rs.getString(COL_TXNATTRVALUE));
					break;
				case 111:
					config.setTransactionElementTimeout(rs.getString(COL_TXNATTRVALUE));
					break;
				case 112:
					config.setCanReverse(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 213:
					config.setPersistsRequestPayload(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 214:
					config.setInPrintoutGroup(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 215:
					config.setGeneratesDocumentRequirements(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				case 216:
					config.setCreateBUN(rs.getBoolean(COL_TXNATTRVALUE));
					break;
				default:
					break;
			}
		}
	}

	@SuppressWarnings("unchecked")
	Map<String, TransactionConfig> getEventRegistryFromCache() throws HotRodClientException {
		Map<String, TransactionConfig> cachedValue = null;
		if (datagridHelper.getCache() != null) {
			Object value;
			try {
				value = datagridHelper.getNoErrorSuppression(EVENT_REGISTRY_CACHE_KEY);
			} catch(HotRodClientException e) {
				if (datagridHelper.isCausedByInvalidClass(e)) {
					LOGGER.error("Invalid class when getting value in cache. Suppressing... (" + e.getMessage() + ")");
					throw e;
				}
				LOGGER.error("Exception when getting value from cache. Suppressing...", e);
				return null;
			}
			if (value != null) {
				cachedValue = (Map<String, TransactionConfig>) value;
			}
		}
		return cachedValue;
	}

	void storeEventRegistryInCache(Map<String, TransactionConfig> eventRegistry) {
		if (datagridHelper.getCache() != null && eventRegistry != null) {
			datagridHelper.put(EVENT_REGISTRY_CACHE_KEY, eventRegistry);
			datagridHelper.putAll(eventRegistry);
		}
	}

	TransactionConfig getTransactionConfigFromCache(String key) {
		TransactionConfig cachedValue = null;
		if (datagridHelper.getCache() != null) {
			Object value = null;
			try {
				value = datagridHelper.getNoErrorSuppression(key);
			} catch (HotRodClientException e) {
				LOGGER.warn("Could not retrieve value from Datagrid");
			}
			if (value != null) {
				LOGGER.info("Retrieving cached value from Datagrid");
				cachedValue = (TransactionConfig) value;
			}
		}
		return cachedValue;
	}

	void storeTransactionConfigInCache(TransactionConfig config){
		if (datagridHelper.getCache() != null && config != null) {
			String eventServiceName = config.getService();
			String eventOperationName = config.getOperation();
			String cacheKey = eventServiceName + eventOperationName;
			datagridHelper.put(cacheKey, config);
		}
	}

	@PostConstruct
	protected void postConstruct() {
		datagridHelper = new RemoteDatagridClientHelper<>();
		datagridHelper.initCacheManager();
		datagridHelper.setCache(EVENT_REGISTRY_CACHE_NAME);
		
		try {
			getEventRegistryConfiguration();
		} catch (Exception e) {
			LOGGER.error("Unable to get event registry configuration. Ignoring for now.", e);
		}
		LOGGER.info("postConstruct called");
	}

	@PreDestroy
	protected void preDestroy() {
		datagridHelper.stopCacheManager();
	}

	public RemoteDatagridClientHelper<String, Object> getDatagridHelper() {
		return datagridHelper;
	}

}
