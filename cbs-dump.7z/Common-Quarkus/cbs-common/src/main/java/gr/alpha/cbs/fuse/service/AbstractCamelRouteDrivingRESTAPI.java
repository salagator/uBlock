package gr.alpha.cbs.fuse.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import gr.alpha.cbs.domain.Container;
import gr.alpha.cbs.domain.EnvParamsType;
import gr.alpha.cbs.domain.LoggingInfoType;
import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.logging.LoadLoggingHelper;
import gr.alpha.cbs.fuse.common.tools.AlternativePathsFlagHolder;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import gr.alpha.cbs.fuse.logging.LoggingMDCInterceptor;
import gr.alpha.cbs.fuse.support.NonCopyingByteArrayOutputStream;
import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import gr.alpha.cbs.fuse.tools.*;
import io.quarkus.runtime.LaunchMode;
import io.quarkus.runtime.annotations.RegisterForReflection;
import io.smallrye.faulttolerance.api.RateLimitException;
import io.smallrye.faulttolerance.api.TypedGuard;
import io.vertx.core.http.HttpServerRequest;
import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriInfo;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.bytecode.AnnotationsAttribute;
import javassist.bytecode.ConstPool;
import javassist.bytecode.FieldInfo;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.BooleanMemberValue;
import javassist.bytecode.annotation.ClassMemberValue;
import javassist.bytecode.annotation.StringMemberValue;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.support.DefaultExchange;
import org.eclipse.microprofile.config.ConfigProvider;
import org.eclipse.microprofile.faulttolerance.exceptions.BulkheadException;
import org.eclipse.microprofile.faulttolerance.exceptions.CircuitBreakerOpenException;
import org.eclipse.microprofile.faulttolerance.exceptions.TimeoutException;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.resteasy.reactive.RestResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import jakarta.annotation.PreDestroy;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.InternalServerErrorException;
import javax.xml.XMLConstants;
import jakarta.xml.bind.*;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.CompletionStage;
import java.util.function.Function;

@RegisterForReflection
public abstract class AbstractCamelRouteDrivingRESTAPI implements SerializationHelper {

    private static final Logger logger = LoggerFactory.getLogger(AbstractCamelRouteDrivingRESTAPI.class);

    private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ISO_LOCAL_DATE;
    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
    private static final String CBS_ERROR = "https://alpha.gr/cbs/general-error";
    private static final Response.StatusType UNPROCESSABLE_ENTITY_STATUS = new Response.StatusType() {
        @Override
        public int getStatusCode() {
            return 422;
        }

        @Override
        public Response.Status.Family getFamily() {
            return Response.Status.Family.CLIENT_ERROR;
        }

        @Override
        public String getReasonPhrase() {
            return "Unprocessable Entity";
        }
    };

    @Inject
    CamelContext camelContext;

    @Inject
    LoggingMDCInterceptor loggingMDCInterceptor;

    @RestClient
    AdornHeadersService adornHeadersService;

    private static final int MAX_RESPONSE_SIZE = 10000;
    private static final boolean TRIMMING_RESPONSE = Boolean.parseBoolean(ConfigProvider.getConfig().getOptionalValue("do.not.trim.camel.responses", String.class).orElse("true"));
    private static final String FAULT_TOLERANCE_GUARD_CACHE_NAME = "FaultToleranceGuardCache";

    private ObjectMapper objectMapper;
    private Map<String, JAXBContext> jaxbContextMap;
    private Map<String, ObjectWriter> objectWriterMap;

    protected RESTAPIHelper restapiHelper;

    protected Map<String, CtClass> javassistLoggingInfoClasses;
    protected Map<String, CtClass> javassistEnvParamsClasses;

    private RemoteDatagridClientHelper<String, String> datagridHelper;

    @Override
    public String getPackageName() {
        return ""; // Shot the compiler up
    }

    /*
     * Override this method to register a custom JAXBElementStringSerializer
     * in order to serialize the BusinessCaseId as a simple string and not as
     * a full-blown JAXBElement object.
     */
    protected boolean registerJAXBElementStringSerializer() {
        return true;
    }

    public void init() {
        logger.info("Initializing REST API.");

        objectMapper = initObjectMapper();

        if (faultToleranceEnabled()) {
            // datagridHelper is only used for get the lookup of fault tolerance settings
            // so that we can dynamically adjust them at runtime
            datagridHelper = new RemoteDatagridClientHelper<>();
            datagridHelper.initCacheManagerWithMarshaller(null);
            datagridHelper.setCache(FAULT_TOLERANCE_GUARD_CACHE_NAME);
            restapiHelper.setDatagridHelper(datagridHelper);
            logger.debug("Datagrid helper is set");
        }

        javassistEnvParamsClasses = new HashMap<>();
        javassistLoggingInfoClasses = new HashMap<>();
        ClassPool pool = ClassPool.getDefault();
        for (String className : restapiHelper.getEnvParamsTypes()) {
            try {
                // First make sure that the package is loaded by the normal class loader.
                // The assumption here is that the class in named EnvParamsType, and that
                // the class named AliasListType exists in the same package. In normal CBS
                // both of these assumptions are true.
                Class<?> aliasListTypeClass = this.getClass().getClassLoader().loadClass(
                        className.replace("EnvParamsType", "AliasListType"));
                if (logger.isDebugEnabled()) {
                    logger.debug("Loaded class {}", aliasListTypeClass.getName());
                }
                // Now perform the class modifications.
                CtClass clazz = pool.get(className);
                if (clazz.isFrozen()) {
                    logger.info("Class: " + className + " is already loaded (in frozen state). Skipping modification.");
                    continue;
                }
                logger.info("Registering class through javassist: " + className);
                CtField workingDateField = clazz.getDeclaredField("workingDate");
                CtField previousWorkingDateField = clazz.getDeclaredField("previousWorkingDate");
                CtField nextWorkingDateField = clazz.getDeclaredField("nextWorkingDate");
                CtField valeurDateField = clazz.getDeclaredField("valeurDate");
                CtField machineDateField = clazz.getDeclaredField("machineDate");
                createAdapterAttribute(workingDateField);
                createAdapterAttribute(previousWorkingDateField);
                createAdapterAttribute(nextWorkingDateField);
                createAdapterAttribute(valeurDateField);
                createAdapterAttribute(machineDateField);
                clazz.toClass();
                javassistEnvParamsClasses.put(className, clazz);
            } catch (Exception e) {
                logger.error("Unable to load javassist class: " + className, e);
            }
        }
        for (String className : restapiHelper.getLoggingInfoTypes()) {
            try {
                // First make sure that the package is loaded by the normal class loader.
                // The assumption here is that the class in named LoggingInfoType, and that
                // the class named AliasListType exists in the same package. In normal CBS
                // both of these assumptions are true.
                Class<?> aliasListTypeClass = this.getClass().getClassLoader().loadClass(
                        className.replace("LoggingInfoType", "AliasListType"));
                if (logger.isDebugEnabled()) {
                    logger.debug("Loaded class {}", aliasListTypeClass.getName());
                }
                // Now perform the class modifications
                CtClass clazz = pool.get(className);
                if (clazz.isFrozen()) {
                    logger.info("Class: " + className + " is already loaded (in frozen state). Skipping modification.");
                    continue;
                }
                logger.info("Registering class through javassist: " + className);
                CtField cbsUnIdField = clazz.getDeclaredField("cbsUnId");
                updateXMLElementAttribute(cbsUnIdField);
                clazz.toClass();
                javassistLoggingInfoClasses.put(className, clazz);
            } catch (Exception e) {
                logger.error("Unable to load javassist class: " + className, e);
            }
        }

        jaxbContextMap = new HashMap<>();
        objectWriterMap = new HashMap<>();
    }

    protected void createAdapterAttribute(CtField field) {
        FieldInfo fieldInfo = field.getFieldInfo();
        ConstPool constPool = fieldInfo.getConstPool();
        AnnotationsAttribute attrInfo = (AnnotationsAttribute) fieldInfo.getAttribute(AnnotationsAttribute.visibleTag);
        AnnotationsAttribute attr = new AnnotationsAttribute(constPool, AnnotationsAttribute.visibleTag);
        for (Annotation annotation : attrInfo.getAnnotations()) {
            attr.addAnnotation(annotation);
        }
        Annotation annotation = new Annotation("jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter", constPool);
        annotation.addMemberValue("value", new ClassMemberValue("gr.alpha.cbs.fuse.tools.XMLGregorianCalendarAdapter", constPool));
        attr.addAnnotation(annotation);
        fieldInfo.addAttribute(attr);
    }

    protected void updateXMLElementAttribute(CtField field) {
        FieldInfo fieldInfo = field.getFieldInfo();
        ConstPool constPool = fieldInfo.getConstPool();
        AnnotationsAttribute attrInfo = (AnnotationsAttribute) fieldInfo.getAttribute(AnnotationsAttribute.visibleTag);
        AnnotationsAttribute attr = new AnnotationsAttribute(constPool, AnnotationsAttribute.visibleTag);
        for (Annotation annotation : attrInfo.getAnnotations()) {
            if (annotation.getTypeName().equals("jakarta.xml.bind.annotation.XmlElement")) {
                Annotation newAnnotation = new Annotation("jakarta.xml.bind.annotation.XmlElement", constPool);
                newAnnotation.addMemberValue("name", new StringMemberValue("cbsUnId", constPool));
                newAnnotation.addMemberValue("required", new BooleanMemberValue(true, constPool));
                attr.addAnnotation(newAnnotation);
            } else {
                attr.addAnnotation(annotation);
            }
        }
        fieldInfo.addAttribute(attr);
    }

    @PreDestroy
    public void cleanup() {
        if (datagridHelper != null) {
            datagridHelper.stopCacheManager();
        }
        jaxbContextMap.clear();
        objectWriterMap.clear();
        logger.debug("preDestroy called");
    }

    private boolean faultToleranceEnabled() {
        return !restapiHelper.getTypedGuardMap().isEmpty() ||
                !restapiHelper.getAsynchronousTypedGuardMap().isEmpty();
    }

    public void clearFaultToleranceGuards() {
        restapiHelper.reinitializeTypedGuardMap();
        restapiHelper.reinitializeAsynchronousTypedGuardMap();
    }

    public RestResponse<String> performOperation(String requestId, String userId, String language, String channelTypeCode, UriInfo uriInfo, HttpServerRequest request, Object input) {
        String operationName = input.getClass().getName();
        if (restapiHelper.asynchronousOperations().contains(operationName)) {
            CompletionStage<RestResponse<String>> completionStage =
                    performOperationAsynchronously(requestId, userId, language, channelTypeCode, uriInfo, request, input);
            try {
                return completionStage.toCompletableFuture().join();
            } catch (CompletionException completionException) {
                logger.error("Completion exception while processing request.", completionException);
                throw completionException;
            }
        } else {
            TypedGuard<RestResponse<String>> guard = restapiHelper.getTypedGuardMap().get(operationName);
            if (guard != null) {
                try {
                    logger.info("Calling operation {} synchronously through the tolerance guard.", operationName);
                    return guard.get(() ->
                            performOperationSynchronously(requestId, userId, language, channelTypeCode, uriInfo, request, input));
                } catch (CircuitBreakerOpenException circuitBreakerOpenException) {
                    logger.error("Circuit breaker is open, cannot process request: " + circuitBreakerOpenException.getMessage());
                    return restapiHelper.handleCircuitBreakerOpenException(operationName, input, circuitBreakerOpenException);
                } catch (BulkheadException bulkheadException) {
                    logger.error("Bulkhead limit reached, cannot process request: " + bulkheadException.getMessage());
                    return restapiHelper.handleBulkheadException(operationName, input, bulkheadException);
                } catch (TimeoutException timeoutException) {
                    logger.error("Request timed out: " + timeoutException.getMessage());
                    return restapiHelper.handleTimeoutException(operationName, input, timeoutException);
                } catch (RateLimitException rateLimitException) {
                    logger.error("Rate limit exceeded, cannot process request: " + rateLimitException.getMessage());
                    return restapiHelper.handleRateLimitException(operationName, input, rateLimitException);
                }
            } else {
                logger.info("Calling operation {} synchronously but no tolerance guard exists.", operationName);
                return performOperationSynchronously(requestId, userId, language, channelTypeCode, uriInfo, request, input);
            }
        }
    }

    public CompletionStage<RestResponse<String>> performOperationAsynchronously(String requestId, String userId, String language, String channelTypeCode, UriInfo uriInfo, HttpServerRequest request, Object input) {
        String operationName = input.getClass().getName();
        TypedGuard<CompletionStage<RestResponse<String>>> guard = restapiHelper.getAsynchronousTypedGuardMap().get(operationName);
        if (guard != null) {
            logger.info("Calling operation {} asynchronously through the tolerance guard.", operationName);
            return guard.get(() -> CompletableFuture.supplyAsync(() ->
                    performOperationSynchronously(requestId, userId, language, channelTypeCode, uriInfo, request, input)));
        } else {
            logger.info("Calling operation {} asynchronously but no tolerance guard exists.", operationName);
            return CompletableFuture.supplyAsync(() ->
                    performOperationSynchronously(requestId, userId, language, channelTypeCode, uriInfo, request, input));
        }
    }

    public RestResponse<String> performOperationSynchronously(String requestId, String userId, String language, String channelTypeCode, UriInfo uriInfo, HttpServerRequest request, Object input) {
        long startTime = System.currentTimeMillis();

        RestResponse<String> restResponse;
        try {
            String operation = null;
            String flowName = null;
            Element requestRootElement = null;

            String operationName = input.getClass().getName();

            logger.info("Operation name from input class name is: {} called from {}, with headers: {}.", operationName, request.remoteAddress(), request.headers());

            long conversionToXMLStartTime = System.currentTimeMillis();

            JAXBContext jaxbContext = getJAXBContext(jaxbContextMap, input.getClass());
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            Document requestDocumentPriorToAdornHeaders = dbf.newDocumentBuilder().newDocument();
            jaxbMarshaller.marshal(input, requestDocumentPriorToAdornHeaders);
            requestRootElement = requestDocumentPriorToAdornHeaders.getDocumentElement();

            // Try to see if we need to call adorn headers
            Document requestDocument;
            if (!optionallyCallAdornHeaders(input, requestId, userId, language, channelTypeCode,
                    requestRootElement.getNamespaceURI(),
                    container -> adornHeadersService.adornHeaders(container))) {
                // We will use the document as is.
                requestDocument = requestDocumentPriorToAdornHeaders;
            } else {
                // We need to convert the document anew, as EnvParams and LoggingHeader was added.
                requestDocument = dbf.newDocumentBuilder().newDocument();
                jaxbMarshaller.marshal(input, requestDocument);
                requestRootElement = requestDocument.getDocumentElement();
            }
            operation = requestRootElement.getLocalName();

            if (logger.isInfoEnabled()) {
                logger.debug("Conversion to XML took {}ms.", System.currentTimeMillis() - conversionToXMLStartTime);
            }

            DOMSource inputDOMSource = new DOMSource(requestRootElement);
            loggingMDCInterceptor.processMessageIn(inputDOMSource);

            if (logger.isDebugEnabled()) {
                logger.debug("Operation called: '" + operation + "'.");
            }

            AlternativePathsFlagHolder.setAlternativePathsFlag(
                    ConfigProvider.getConfig().getOptionalValue("cbs.common.tools.formatutils.alternativepaths", Boolean.class).orElse(false)
            );
            Boolean operationSpecificSetting =
                    ConfigProvider.getConfig().getOptionalValue("cbs.common.tools.formatutils." + operation + ".alternativepaths", Boolean.class).orElse(null);
            if (operationSpecificSetting != null) {
                AlternativePathsFlagHolder.setAlternativePathsFlag(operationSpecificSetting);
            }

            // Get the headers from the concrete class
            Map<String, Object> headers = restapiHelper.getHeaders(operation, requestRootElement);

            if(headers.containsKey(CBSConstants.HEADER_XSD_PATHS)){
                boolean xsdValidation = validateXMLSchema((String[]) headers.get(CBSConstants.HEADER_XSD_PATHS), requestDocument);
                logger.info("XSD validation result:" + xsdValidation);
                if(!xsdValidation){
                    throw new BadRequestException("XSD validation failed");
                }
            }

            if (LaunchMode.current().isDevOrTest()) {
                camelContext.setMessageHistory(true);
            }
            ProducerTemplate producerTemplate = camelContext.createProducerTemplate();

            Element payload = getXMLRootElement(requestRootElement);
            flowName = payload.getLocalName();

            // Log the input
            logger.info("Call web service " + flowName + "." + operation + " RequestBody:\n" + formatNodeToString(operation, requestRootElement));

            restapiHelper.setServiceOperationInfo(flowName, operation, headers);

            // Perform the call to the camel route (to the template first, which
            // will call the proper route passed in the header above).
            Exchange exchange = new DefaultExchange(camelContext);
            headers.forEach(exchange::setProperty);
            exchange.getIn().setBody(payload);
            Object r = producerTemplate.send(restapiHelper.getConsumer(operation),exchange).getIn().getBody();

            // Abnormal condition all exception should be handled by camel routes
            if (exchange.getException() != null){
                throw new RuntimeException(exchange.getException());
            }

            // Capture point of errorCode for Dynatrace monitoring purposes
            AppMonitoringHelper.captureErrorCode(exchange);

            Document s = camelContext.getTypeConverter().convertTo(Document.class, r);

            Document responseDocument = createResponse(s,operation);

            Class<?> responseJaxbClass = Class.forName(input.getClass().getCanonicalName() + "Response",
                    true, Thread.currentThread().getContextClassLoader());
            JAXBContext responseJaxbContext = getJAXBContext(jaxbContextMap, responseJaxbClass);
            Unmarshaller responseJaxbUnmarshaller = responseJaxbContext.createUnmarshaller();
            Object responseObject = responseJaxbUnmarshaller.unmarshal(responseDocument);

            NonCopyingByteArrayOutputStream outputStream = new NonCopyingByteArrayOutputStream();
            writeOutputDocument(outputStream, operationName, responseDocument, objectMapper,
                    jaxbContextMap, objectWriterMap);
            String jsonResponse = new String(outputStream.getBuffer(), 0, outputStream.size(), StandardCharsets.UTF_8);

            // Only modify the response in order to conform to the ProblemDetails class if the
            // alternative error handling is enabled and there is an error message in the response.
            // Severity level 4 is a warning. Should not barf error status in that case.
            if (restapiHelper.useAlternativeErrorHandling() &&
                    jsonResponse.contains("\"errorMessage\"") && !jsonResponse.contains("\"severityLevel\":\"4\"")) {
                // There was an error message in the response. Convert it to ProblemDetails representation and return problematic status code.
                restResponse = modifyResponseInThePresenceOfError(objectMapper, exchange, uriInfo, jsonResponse);
            } else {
                // Normal case
                restResponse = RestResponse.ResponseBuilder.
                        ok(jsonResponse).
                        header("Content-Type", "application/json;charset=UTF-8").
                        build();
            }

            long duration = System.currentTimeMillis() - startTime;

            // Log the output
            logger.info("Call web service " + flowName + "." + operation +" Took " + duration + "ms. " + "ResponseBody:\n"
                    + FormatUtils.nodeToString(responseDocument, FormatUtils.OMIT_XML_DECLARATION_YES, FormatUtils.INDENT_NO));

            LoadLoggingHelper.createMessage("FUSE", operation, duration);
        } catch (BadRequestException e ) {
            logger.error("XSD Validation failed or something went wrong while adding env params", e);
            restResponse = RestResponse.ResponseBuilder.create(Response.Status.BAD_REQUEST, "Bad request").build();
        } catch (TransformerFactoryConfigurationError | TransformerException | ParserConfigurationException |
                 ClassNotFoundException | JAXBException | IOException e) {
            logger.error("Unable to process web service call", e);
            restResponse = RestResponse.ResponseBuilder.create(Response.Status.INTERNAL_SERVER_ERROR, "Internal server error").build();
        } finally {
            loggingMDCInterceptor.processMessageOut();
        }
        return restResponse;
    }

    public String formatNodeToString(String operation, Node node) throws TransformerFactoryConfigurationError, TransformerException {
        String returnValue = FormatUtils.nodeToString(node, FormatUtils.OMIT_XML_DECLARATION_YES, FormatUtils.INDENT_NO);
        if (TRIMMING_RESPONSE && "getListReferenceDataItem".equals(operation) && returnValue.length() > MAX_RESPONSE_SIZE) {
            return returnValue.substring(0, MAX_RESPONSE_SIZE) + "... (trimmed)";
        }
        return returnValue;
    }

    public boolean optionallyCallAdornHeaders(Object input,
                                              String requestId,
                                              String userId,
                                              String language,
                                              String channelTypeCode,
                                              String namespaceURI,
                                              Function<Container, Container> function) {
        long adornHeadersStartTime = System.currentTimeMillis();

        try {
            Class<?> inputClass = input.getClass();
            Object payload = null;
            for (Method method : inputClass.getMethods()) {
                // Assume there is only one getter for the payload
                if (method.getName().startsWith("get") && method.getParameterCount() == 0) {
                    payload = method.invoke(input);
                    break;
                }
            }
            if (payload != null) {
                Class<?> payloadClass = payload.getClass();
                Method getEnvParamsMethod = payloadClass.getMethod("getEnvParams");
                if (getEnvParamsMethod.invoke(payload) == null) {
                    logger.info("No env params passed in the payload. Invoking adorn headers.");
                    adornHeaders(payload, requestId, userId, language, channelTypeCode, namespaceURI, function);
                    logger.info("Call to adorn headers took {}ms.", System.currentTimeMillis() - adornHeadersStartTime);
                    return true;
                }
            } else {
                // No payload. Das ist verboten!
                throw new InternalServerErrorException("No payload found in request.");
            }
        } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException |
                 InstantiationException | DatatypeConfigurationException e) {
            throw new InternalServerErrorException(e);
        }
        return false;
    }

    protected void adornHeaders(Object payload,
                                String requestId,
                                String userId,
                                String language,
                                String channelTypeCode,
                                String namespaceURI,
                                Function<Container, Container> function) throws NoSuchMethodException,
            InvocationTargetException, InstantiationException, IllegalAccessException, DatatypeConfigurationException {
        logger.info("Calling adorn headers with user ID: {} and requestId {}.", userId, requestId);

        if (userId == null) {
            throw new BadRequestException("No userId specified and no env params supplied.");
        }

        Container container = new Container();
        container.setLoggingInfo(new LoggingInfoType());
        container.getLoggingInfo().setUserId(userId);
        container.getLoggingInfo().setRequestId(requestId == null ? UUID.randomUUID().toString() : requestId);
        if (language != null || channelTypeCode != null) {
            container.setEnvParams(new EnvParamsType());
            if (language != null) {
                container.getEnvParams().setLanguage(language);
            }
            if (channelTypeCode != null) {
                container.getEnvParams().setChannelTypeCode(channelTypeCode);
            }
        }

        Container responseContainer = function.apply(container);

        copyLoggingInfoAndEnvParams(payload, responseContainer, namespaceURI);
    }

    protected void copyLoggingInfoAndEnvParams(Object payload,
                                               Container responseContainer,
                                               String namespaceURI) throws NoSuchMethodException,
            InvocationTargetException, InstantiationException, IllegalAccessException, DatatypeConfigurationException {
        Class<?> payloadClass = payload.getClass();
        Method getLoggingInfoMethod = payloadClass.getMethod("getLoggingInfo");
        Method getEnvParamsMethod = payloadClass.getMethod("getEnvParams");
        Class<?> loggingInfoClass = getLoggingInfoMethod.getReturnType();
        Class<?> envParamsClass = getEnvParamsMethod.getReturnType();
        Method setLoggingInfoMethod = payloadClass.getMethod("setLoggingInfo", loggingInfoClass);
        Method setEnvParamsMethod = payloadClass.getMethod("setEnvParams", envParamsClass);
        Object loggingInfo = loggingInfoClass.getDeclaredConstructor().newInstance();
        Object envParams = envParamsClass.getDeclaredConstructor().newInstance();
        setLoggingInfoMethod.invoke(payload, loggingInfo);
        setEnvParamsMethod.invoke(payload, envParams);

        deepCopyObject(responseContainer.getLoggingInfo(), loggingInfo, namespaceURI);
        deepCopyObject(responseContainer.getEnvParams(), envParams, namespaceURI);
    }

    protected void deepCopyObject(Object source, Object target, String namespaceURI) throws NoSuchMethodException, InvocationTargetException,
            IllegalAccessException, DatatypeConfigurationException, InstantiationException {
        for (Method method : source.getClass().getMethods()) {
            if (method.getName().startsWith("get") && method.getParameterCount() == 0) {
                // This is a getter method. Find the field name to get to the setter in the target object
                String fieldName = method.getName().substring(3);
                Method setterMethod = findSetterMethod(target, fieldName);
                if (setterMethod == null || setterMethod.getParameterCount() != 1) {
                    logger.warn("Unable to find setter for {}.", fieldName);
                    continue;
                }
                Parameter parameter = setterMethod.getParameters()[0];
                if (parameter.getType().isAssignableFrom(String.class)) {
                    String value = safeGetStringFromSource(method, source);
                    setterMethod.invoke(target, value);
                } else if (parameter.getType().isAssignableFrom(Integer.class)) {
                    Integer sourceValue = safeGetIntegerFromSource(method, source);
                    if (sourceValue != null) {
                        setterMethod.invoke(target, sourceValue);
                    }
                } else if (parameter.getType().isAssignableFrom(Boolean.class)) {
                    Boolean sourceValue = safeGetBooleanFromSource(method, source);
                    if (sourceValue != null) {
                        setterMethod.invoke(target, sourceValue);
                    }
                } else if (parameter.getType().isAssignableFrom(JAXBElement.class)) {
                    // Adorn headers always returns Strings where JAXBElements are involved
                    JAXBElement<String> value = new JAXBElement<>(
                            new QName(namespaceURI, fieldName),
                            String.class,
                            (String) method.invoke(source)
                    );
                    setterMethod.invoke(target, value);
                } else if (parameter.getType().isAssignableFrom(XMLGregorianCalendar.class)) {
                    String dateValue = (String) method.invoke(source);
                    GregorianCalendar gcal = null;
                    try {
                        LocalDateTime date = LocalDateTime.parse(dateValue, dateTimeFormatter);
                        gcal = GregorianCalendar.from(ZonedDateTime.of(date, ZoneId.of("Europe/Athens")));
                    } catch (DateTimeParseException e) {
                        try {
                            LocalDate date = LocalDate.parse(dateValue, dateFormatter);
                            gcal = GregorianCalendar.from(date.atStartOfDay(TimeZone.getTimeZone("UTC").toZoneId()));
                        } catch (DateTimeParseException ie) {
                            logger.error("Unable to parse " + dateValue + ".", ie);
                            throw new InternalServerErrorException("Unable to parse {}.", ie);
                        }
                    }
                    XMLGregorianCalendar xgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
                    setterMethod.invoke(target, xgcal);
                } else {
                    // This is either the UserRoleList or the AliasList
                    Object[] values = (Object[]) method.invoke(source);
                    if (values != null) {
                        Class<?> assignClass = parameter.getType();
                        Object assignObject = assignClass.getDeclaredConstructor().newInstance();
                        for (Method assignObjectMethod : assignClass.getMethods()) {
                            if (assignObjectMethod.getName().startsWith("get") && assignObjectMethod.getParameterCount() == 0) {
                                @SuppressWarnings("unchecked")
                                List<Object> listOfStrings = (List<Object>) assignObjectMethod.invoke(assignObject);
                                listOfStrings.addAll(Arrays.asList(values));
                                break;
                            }
                        }
                        setterMethod.invoke(target, assignObject);
                    }
                }
            }
        }
    }

    protected String safeGetStringFromSource(Method method, Object source) {
        try {
            return (String) method.invoke(source);
        } catch (Exception e) {
            logger.error("Unable to get string from source.", e);
            throw new InternalServerErrorException("Unable to get string from source.", e);
        }
    }

    protected Integer safeGetIntegerFromSource(Method method, Object source) {
        try {
            return (Integer) method.invoke(source);
        } catch (Exception e) {
            // try as a fallback to convert from String
            try {
                return Integer.parseInt((String) method.invoke(source));
            } catch (Exception e2) {
                logger.error("Unable to get integer from source.", e);
                throw new InternalServerErrorException("Unable to get integer from source.", e);
            }
        }
    }

    protected Boolean safeGetBooleanFromSource(Method method, Object source) {
        try {
            return (Boolean) method.invoke(source);
        } catch (Exception e) {
            // try as a fallback to convert from String
            try {
                return Boolean.parseBoolean((String) method.invoke(source));
            } catch (Exception e2) {
                logger.error("Unable to get boolean from source.", e);
                throw new InternalServerErrorException("Unable to get boolean from source.", e);
            }
        }
    }

    protected Method findSetterMethod(Object target, String fieldName) {
        for (Method method : target.getClass().getMethods()) {
            if (method.getName().equals("set" + fieldName) ||
                    (method.getName().equals("setCBSUnId") && fieldName.equals("CbsunId"))) {
                return method;
            }
        }
        return null;
    }

    private RestResponse<String> modifyResponseInThePresenceOfError(ObjectMapper mapper, Exchange exchange, UriInfo uriInfo, String jsonResponse) throws IOException {
        RestResponse<String> restResponse;
        JsonNode responsePayload = mapper.readTree(jsonResponse);
        JsonNode errorMessage = responsePayload.findPath("errorMessage");

        ProblemDetails problemDetails = ProblemDetails.getBuilder()
                .setType(getProblemType(exchange))
                .setTitle(Optional.ofNullable(errorMessage.get("description")).map(JsonNode::asText).orElse(""))
                .setStatus(getProblemStatus(exchange).getStatusCode())
                .setInstance(uriInfo.getRequestUri().toString())
                .setLoggingInfo(mapper.readValue(responsePayload.findPath("loggingInfo").toString(), Map.class))
                .setErrorMessage(mapper.readValue(errorMessage.toString(), Map.class))
                .build();

        byte[] responseBytes = mapper.writeValueAsBytes(problemDetails);
        jsonResponse = new String(responseBytes, StandardCharsets.UTF_8);

        restResponse = RestResponse.ResponseBuilder.
                create(getProblemStatus(exchange), jsonResponse).
                header("Content-Type", getContentType(exchange)).
                build();

        return restResponse;
    }

    /**
     * Override if custom error -> http status mapping is needed per project
     */
    protected Response.StatusType getProblemStatus(Exchange exchange) {
        return UNPROCESSABLE_ENTITY_STATUS;
    }

    /**
     * Override if custom error -> type mapping is needed per project
     */
    protected String getProblemType(Exchange exchange) {
        return CBS_ERROR;
    }

    /**
     * Override if other content types are needed on error
     */
    protected String getContentType(Exchange exchange) {
        return "application/problem+json";
    }

    /**
     * Method to get the root element of the request XML.<br>
     * Default behavior is to get the first element child from the root.<br>
     *
     * Override this method for other behavior
     *
     * @param rootElement Initial SOAP request XML
     * @return Root element
     */
    protected Element getXMLRootElement(Element rootElement){
        Element newRoot = null;

        if (restapiHelper.requestWithPayloadOnly()) {
            Node childNode = rootElement.getFirstChild();
            while (childNode != null && childNode.getNodeType() != Node.ELEMENT_NODE) {
                childNode = childNode.getNextSibling();
            }
            newRoot = (Element) childNode;
        }else{
            newRoot = rootElement;
        }

        return newRoot;
    }

    public boolean validateXMLSchema(String[] xsdPath, Document doc){
        try {
            SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            final StreamSource[] sources = generateStreamSourcesFromXsdPaths(xsdPath);
            Schema schema = factory.newSchema(sources);
            Validator validator = schema.newValidator();
            validator.validate(new DOMSource(doc));
        } catch (IOException | SAXException e) {
            logger.info("Exception: "+e.getMessage());
            return false;
        }
        return true;
    }


    private static StreamSource[] generateStreamSourcesFromXsdPaths(final String[] xsdFilesPaths) {
        return Arrays.stream(xsdFilesPaths)
                .map((String s) -> new StreamSource(Objects.requireNonNull(
                        Thread.currentThread().getContextClassLoader().getResource(s)).toExternalForm()))
                .toList().toArray(new StreamSource[xsdFilesPaths.length]);
    }

    private Document createResponse(Document response,String operation) throws ParserConfigurationException{

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.newDocument();

        // root element
        Element rootElement = doc.createElementNS(response.getDocumentElement().getNamespaceURI(),  operation+"Response");

        doc.appendChild(rootElement);

        Node nNode = null;
        if(restapiHelper.keepRootElement() == ResponseLayout.WRAP){
            nNode = doc.importNode(response.getDocumentElement(), true);
        }else if(restapiHelper.keepRootElement() == ResponseLayout.WRAP_UNWRAP){
            nNode = doc.importNode(getXMLRootElement(response.getDocumentElement()), true);
        }
        else{
            return response;
        }
        rootElement.appendChild(nNode);

        return doc;
    }

}
