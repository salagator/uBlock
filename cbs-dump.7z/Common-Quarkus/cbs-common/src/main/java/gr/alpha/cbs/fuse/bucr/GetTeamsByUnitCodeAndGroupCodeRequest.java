package gr.alpha.cbs.fuse.bucr;

public class GetTeamsByUnitCodeAndGroupCodeRequest {
	
	private String unitCode;
	
	private String groupCode;
	
	public GetTeamsByUnitCodeAndGroupCodeRequest(){
		
	}

	public String getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(String unitCode) {
		this.unitCode = unitCode;
	}

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	@Override
	public String toString() {
		return "GetTeamsByUnitCodeAndGroupCodeRequest{" +
				"unitCode='" + unitCode + '\'' +
				", groupCode='" + groupCode + '\'' +
				'}';
	}
}
