package gr.alpha.cbs.fuse.bucr;

public class GetGroupsByMasterUnitGroupTypeRequest {
	
	private String masterUnitCode;
	private String groupTypeCode;
	
	public GetGroupsByMasterUnitGroupTypeRequest(){
	}

	public String getMasterUnitCode() {
		return masterUnitCode;
	}

	public void setMasterUnitCode(String masterUnitCode) {
		this.masterUnitCode = masterUnitCode;
	}

	public String getGroupTypeCode() {
		return groupTypeCode;
	}

	public void setGroupTypeCode(String groupTypeCode) {
		this.groupTypeCode = groupTypeCode;
	}

	@Override
	public String toString() {
		return "GetGroupsByMasterUnitGroupTypeRequest{" +
				"masterUnitCode='" + masterUnitCode + '\'' +
				", groupTypeCode='" + groupTypeCode + '\'' +
				'}';
	}
}
