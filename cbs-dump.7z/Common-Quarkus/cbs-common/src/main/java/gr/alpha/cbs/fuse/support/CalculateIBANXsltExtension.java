package gr.alpha.cbs.fuse.support;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import org.apache.commons.lang3.StringUtils;

import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;

@Named("calculateIBANXsltExtension")
@ApplicationScoped
@RegisterForReflection
public class CalculateIBANXsltExtension extends ExtensionFunctionDefinition {

    /**
     *
     */
    private static final long serialVersionUID = 2060328806406054962L;

    @Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("cb", "http://fuse.cbs.alpha.gr/calculateIBAN/", "iban");
    }

    @Override
    public int getMinimumNumberOfArguments() {
        return 1;
    }

    @Override
    public int getMaximumNumberOfArguments() {
        return 4;
    }

    @Override
    public SequenceType[] getArgumentTypes() {
        return new SequenceType[]{SequenceType.SINGLE_STRING, SequenceType.OPTIONAL_STRING, SequenceType.OPTIONAL_STRING, SequenceType.OPTIONAL_STRING};
    }

    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
        return SequenceType.SINGLE_STRING;
    }

    @Override
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {

            /**
             *
             */
            private static final long serialVersionUID = -2058195002203838019L;

            @Override
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
                try {

                    String account = null;
                    //Check the account number - Required field
                    if (arguments[0] instanceof LazySequence) {
                        account = ((LazySequence)arguments[0]).head().getStringValue();
                    } else if (arguments[0] instanceof StringValue) {
                        account = ((StringValue)arguments[0]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type for fromIntPart parameter: " + arguments[0].getClass().getCanonicalName());
                    }

                    //Optional fields: String unitCode, String unitCountry, String unitIBANCalculationMethod
                    String unitCode = null;
                    String unitCountry = null;
                    String unitIBANCalculationMethod = null;
                    if (arguments.length == 4) {
                        unitCode = getVal(arguments[1]);
                        unitCountry = getVal(arguments[2]);
                        unitIBANCalculationMethod = getVal(arguments[3]);
                    }

                    if(StringUtils.isEmpty(unitCode) || StringUtils.isEmpty(unitCountry) || StringUtils.isEmpty(unitIBANCalculationMethod)) {
                        return StringValue.makeStringValue(FormatUtils.calculateIBAN(account));
                    }else{
                        return StringValue.makeStringValue(FormatUtils.calculateIBAN(account, unitCode, unitCountry, unitIBANCalculationMethod));
                    }
                } catch (Exception e) {
                    throw new XPathException("Unable to translate value", e);
                }
            }

            private String getVal(Sequence argument) throws Exception {
                String val = null;
                if (argument instanceof LazySequence) {
                    val = ((LazySequence) argument).head().getStringValue();
                } else if (argument instanceof StringValue) {
                    val = ((StringValue)argument).getStringValue();
                } else {
                    throw new Exception("Unrecognized argument type for fromIntPart parameter: " + argument.getClass().getCanonicalName());
                }
                return val;
            }
        };
    }
}