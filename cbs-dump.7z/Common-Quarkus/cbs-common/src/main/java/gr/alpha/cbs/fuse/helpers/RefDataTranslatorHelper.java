package gr.alpha.cbs.fuse.helpers;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.Body;
import org.apache.camel.ExchangeProperty;
import org.w3c.dom.Document;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.ifaces.RefDataTranslator;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;

@Named("refDataTranslatorHelper")
@Dependent
@RegisterForReflection
public class RefDataTranslatorHelper {

	@Inject
	RefDataTranslator refDataTranslator;

	/**
	 *  This method is used inside camel to get the translated ufe value in Greek
	 * @param body
	 * @param fromSystem
	 * @param toSystem
	 * @param parentName
	 * @param xPathValue
	 * @return the translated value or a generic description when not found
	 * @throws Exception
	 */
	 public String getUfeValueToGreek(@Body Document body, String parentName, String xPathValue) throws Exception{
			String translatedValue = refDataTranslator.translateDataOrReturnNull(CBSConstants.REF_DATA_SYSTEM_UI, "Greek", parentName, FormatUtils.getValue(body, xPathValue));
			if (translatedValue == null || "".equals(translatedValue.trim())){
			  return "Δεν βρέθηκε περιγραφή";
			}else{
				return translatedValue;
			}
	 }
	 
	 public String getUfeValueDescription(@Body Document body, String parentName, String xPathValue, @ExchangeProperty(value = "cbs.common.language") String lang) throws Exception{
			String translatedValue = refDataTranslator.translateData(CBSConstants.REF_DATA_SYSTEM_UI, lang, parentName, FormatUtils.getValue(body, xPathValue));
			return translatedValue;
			
	 }
}
