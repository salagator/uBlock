package gr.alpha.cbs.fuse.bucr;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class GetEnvParamsByUserIdResponse {

	private UserEssentialInfo userEssentialInfo;

	public UserEssentialInfo getUserEssentialInfo() {
		return userEssentialInfo;
	}

	public void setUserEssentialInfo(UserEssentialInfo userEssentialInfo) {
		this.userEssentialInfo = userEssentialInfo;
	}
	
}
