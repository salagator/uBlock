//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package gr.alpha.cbs.fuse.kie;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

public interface KieServerHttpResponse {
    int code() throws KieServerHttpRequestException;

    String message() throws KieServerHttpRequestException;

    String body() throws KieServerHttpRequestException;

    byte[] bytes() throws KieServerHttpRequestException;

    InputStream stream() throws KieServerHttpRequestException;

    BufferedInputStream buffer() throws KieServerHttpRequestException;

    String header(String var1) throws KieServerHttpRequestException;

    int intHeader(String var1) throws KieServerHttpRequestException;

    Map<String, List<String>> headers() throws KieServerHttpRequestException;

    String[] headers(String var1);

    String headerParameter(String var1, String var2);

    Map<String, String> headerParameters(String var1);

    String contentEncoding();

    String contentType();

    int contentLength();

    String charset();
}
