package gr.alpha.cbs.fuse.strategies;

import java.util.Map;

import org.apache.camel.Exchange;

public class XsltAggregationStrategyAlpha extends ThreadSafeXsltAggregationStrategy {
    public XsltAggregationStrategyAlpha(String xslFileLocation) {
        super(xslFileLocation);
        this.setTransformerFactoryClass("net.sf.saxon.TransformerFactoryImpl");
    }

    @Override
    public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
        Exchange ex = super.aggregate(oldExchange, newExchange);
        Map<String, Object> newMap = newExchange.getIn().getHeaders();
        Map<String, Object> newPropertiesMap = newExchange.getProperties();

        newMap.forEach((k,v) -> {ex.getOut().setHeader(k, v);});
        newMap = oldExchange.getIn().getHeaders();
        newMap.forEach((k,v) -> {ex.getOut().setHeader(k, v);});

        newPropertiesMap.forEach((k,v) -> {ex.setProperty(k, v);});
        newPropertiesMap = oldExchange.getProperties();
        newPropertiesMap.forEach((k,v) -> {ex.setProperty(k, v);});

        return  ex;
    }

}

