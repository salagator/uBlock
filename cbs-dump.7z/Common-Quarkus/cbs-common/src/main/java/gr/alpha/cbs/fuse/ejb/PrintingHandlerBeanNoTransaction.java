package gr.alpha.cbs.fuse.ejb;

import gr.alpha.cbs.fuse.support.DefaultPrintingRulesProcessor;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.spi.CreationalContext;
import jakarta.enterprise.inject.spi.Bean;
import jakarta.enterprise.inject.spi.BeanManager;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.*;
import org.jboss.logging.Logger;
import java.util.Set;

@Named("printingHandlerBeanNoTransaction")
@ApplicationScoped
@RegisterForReflection
public class PrintingHandlerBeanNoTransaction {
	private static final Logger LOGGER = Logger.getLogger(PrintingHandlerBeanNoTransaction.class);

	@Inject
	BeanManager beanManager;

	public void callPrintGroupRulesBRMS(Exchange exchange) throws Exception {
		// Cast to the Camel processor interface to avoid adding yet another
		// interface in the common module. Care must be taken so that the bean
		// that we extract from the camel context is an instance of
		// AbstractPrintingRulesProcessor (one of its subclasses actually).
		Processor printingRulesProcessor = null;
		Class<?> clazz = Processor.class;
		Set<Bean<?>> beans = beanManager.getBeans("printingRulesProcessor");
		if (beans != null && beans.iterator().hasNext()) {
			Bean<?> bean = beans.iterator().next();
			CreationalContext<?> ctx = beanManager.createCreationalContext(bean);
			printingRulesProcessor = (Processor) beanManager.getReference(bean, clazz, ctx);
		}
		if (printingRulesProcessor == null) {
			LOGGER.info(
					"Electronic slip is specified on the operation, but no implementation of 'PrintingRulesProcessor' defined in the spring context. Using defaults.");
			printingRulesProcessor = new DefaultPrintingRulesProcessor();
		}
		printingRulesProcessor.process(exchange);
	}

}
