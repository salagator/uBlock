package gr.alpha.cbs.fuse.tools;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlElementDecl;

import javax.xml.namespace.QName;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.List;

public class JAXBElementDeserializer extends StdDeserializer<JAXBElement<?>> {

    Class [] classesToBind;

    public JAXBElementDeserializer() {
        this(null);
    }

    protected JAXBElementDeserializer(Class ... classesToBind) {
        super(JAXBElement.class);
        this.classesToBind = classesToBind;
    }

    @Override
    public JAXBElement<?> deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException, JacksonException {
        if (!jsonParser.isExpectedStartObjectToken()) {
            return null;
        }

        Class declaredType = null;
        String name = "undef";
        Object value = null;

        JsonToken currentToken;
        while ((currentToken = jsonParser.nextValue()) != JsonToken.END_OBJECT) {
            switch (currentToken) {
                case VALUE_STRING:
                    switch (jsonParser.getCurrentName()) {
                        case "declaredType":
                            try {
                                declaredType = deserializationContext.findClass(jsonParser.getText());
                            } catch (ClassNotFoundException e) {
                                //leave declaredType null
                            }
                            break;
                        case "name":
                            name = jsonParser.getText();
                            if (declaredType == null) declaredType = typeFor(qNameFromString(name));
                            break;
                        case "value":
                            value = jsonParser.getText();
                            break;
                        default:
                    }
                    break;
                case START_OBJECT:
                    if (declaredType == null) declaredType = LinkedHashMap.class;
                    value = deserializationContext.readValue(jsonParser, declaredType);
                    break;
                case START_ARRAY:
                    if (declaredType == null) declaredType = List.class;
                    value = deserializationContext.readValue(jsonParser, declaredType);
                    break;
                case VALUE_NUMBER_INT:
                    value = jsonParser.getLongValue();
                    break;
                case VALUE_NUMBER_FLOAT:
                    value = jsonParser.getDoubleValue();
                    break;
                case VALUE_TRUE:
                    value = Boolean.TRUE;
                    break;
                case VALUE_FALSE:
                    value = Boolean.FALSE;
                    break;
                case VALUE_NULL:
                    value = null;
                    break;
                case NOT_AVAILABLE:
                case END_OBJECT:
                case END_ARRAY:
                case FIELD_NAME:
                case VALUE_EMBEDDED_OBJECT:
                    break;
                default:
            }
        }
        if (declaredType == null) declaredType = value.getClass();
        return new JAXBElement<>(qNameFromString(name), declaredType, value);
    }

    QName qNameFromString(String s) {
        String[] parts = s.split("[{}]");
        if (parts.length > 2) return new QName(parts[1], parts[2]);
        if (parts.length == 1) return new QName(parts[0]);
        return new QName("undef");
    }

    Class typeFor(QName qname) {
        if (classesToBind == null) return null;
        for (Class objectFactoryClass : classesToBind) {
            if (objectFactoryClass != null) {
                Method[] methods = objectFactoryClass.getDeclaredMethods();
                for (Method method : methods) {
                    XmlElementDecl decl = method.getAnnotation(XmlElementDecl.class);
                    if (decl != null && qNameMatches(qname, decl.namespace(), decl.name())) {
                        return method.getParameterTypes()[0];
                    }
                }
            }
        }
        return null;
    }

    private boolean qNameMatches(QName qName, String namespace, String localPart) {
        return (qName.getNamespaceURI() == null ? namespace == null : qName.getNamespaceURI().equals(namespace)) &&
                (qName.getLocalPart() == null ? localPart == null : qName.getLocalPart().equals(localPart));
    }
}
