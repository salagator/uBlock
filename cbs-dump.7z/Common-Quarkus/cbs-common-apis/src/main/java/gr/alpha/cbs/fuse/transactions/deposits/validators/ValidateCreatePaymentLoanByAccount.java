package gr.alpha.cbs.fuse.transactions.deposits.validators;

import static gr.alpha.cbs.fuse.common.tools.FormatUtils.getValue;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;

import gr.alpha.cbs.fuse.common.support.TransactionConfig;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.helpers.CommonsHelper;
import gr.alpha.cbs.fuse.ifaces.ProductStudioInterface;
import gr.alpha.cbs.fuse.enums.ConstantAccountOpenActiveType;
import gr.alpha.cbs.fuse.enums.ConstantCurrencies;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import gr.alpha.cbs.fuse.enums.ConstantYesNoOption;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;

@Named("validateCreatePaymentLoanByAccount")
@ApplicationScoped
@RegisterForReflection
public class ValidateCreatePaymentLoanByAccount {
	
	private static final Logger LOGGER = Logger.getLogger(ValidateCreatePaymentLoanByAccount.class);
	@Inject
	CommonsHelper commonsHelper;

	@Inject
	ProductStudioInterface productStudio;
	/**
	 * <b>Method that retrieves and puts in a Map specific Account Profile Attributes.</b><br>
	 * <b>It occurs only for elements with the below format only.</b><br>
	 * e.g. [Debit=true, Credit=true, Inquiry=true, Managerial=true]
	 * 
	 * @param String  - EventRegistry CBSRefCode attribute (retrieved from TransactionConfig.class)
	 * @param Integer - Account Profile Code retrieved form accountMultiGetResponse
	 * @param Integer - Account Product Code retrieved form accountMultiGetResponse
	 * @param Integer - CarrierID retrieved from BRMS.CarriedID
	 * @return Map<String, Boolean> - a map filled with key-value extracted from PS Tables (PRD_AccountProfile, PRD_ProductBehavior)
	 */
	
	public void checkAccountProfile (Exchange exchange) throws Exception{

		Document doc = exchange.getIn().getBody(Document.class);
		
		TransactionConfig eventRgistryConf = exchange.getProperty("configuration", TransactionConfig.class);
		
		/*Get EventRegistry Attributes */
		String eventCode = eventRgistryConf.getEventCode();
		
		ArrayList<Integer> carrierCodes=new ArrayList<Integer>();
		carrierCodes =exchange.getProperty("brms.carrierID.getCarrierID", ArrayList.class);
		
		/*Get Product and Profile Attributes */
		int intProfile = NumberUtils.toInt(FormatUtils.getValue(doc, "//*:accountMultiGetResponse/*:accountProfile_1"));
		int intProductCode = NumberUtils.toInt(FormatUtils.getValue(doc, "//*:accountMultiGetResponse/*:productCode_1"));		
		
		HashMap<String,Boolean> map = productStudio.getAccountProfile(eventCode, intProfile, intProductCode, carrierCodes.get(0));
		LOGGER.info("eventCode: " + eventCode + " accountProfile: " + intProfile + " productCode: " + intProductCode + " carrierCode: " + carrierCodes.get(0));
		
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("Input eventCode : "+eventCode);
			LOGGER.debug("Input intProfile : "+intProfile);
			LOGGER.debug("Input intProductCode : "+intProductCode);
			LOGGER.debug("Input carrierID : "+carrierCodes.get(0));
			LOGGER.debug("Account Profile Returned MAP : "+map);
			LOGGER.debug("Account Position -- Attribute value for Debit: "+map.get("Debit"));
		}
		
		if (map!=null){
			LOGGER.info("Can Credit? = "+ map.get("Credit"));
			LOGGER.info("Can Debit? = "+ map.get("Debit"));
			LOGGER.info("Can Inq? = "+ map.get("Inquiry"));
			LOGGER.info("Can Manage? = "+ map.get("Managerial"));
			
			if (!map.get("Debit")){
				ErrorUtils.throwCBSException(null ,  
						String.valueOf(ConstantError_Types._Functional), 
						String.valueOf(ConstantError_System_IDs._FUSE), 
						ValidateCreatePaymentLoanByAccount.class.getCanonicalName(), 
						ConstantErrorMessages._Invalid_Account_Billing,
						String.valueOf(ConstantError_Levels._Error),
						"",
						"", "");
			}
		}
	}
	
	public void step250(Exchange exchange) throws Exception{
		
		Document body = exchange.getIn().getBody(Document.class);
		
		
//		If Request.Amount = null, then error #300002	
		String depositAmountFromRequest = FormatUtils.getValueOrNull(body, "//*:CreatePaymentLoanByAccountRequestItem/*:Amount", null, null, null);
		if(depositAmountFromRequest == null){
			ErrorUtils.throwCBSException(null ,  
					String.valueOf(ConstantError_Types._Functional), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					ValidateCreatePaymentLoanByAccount.class.getCanonicalName(), 
					String.valueOf(ConstantErrorMessages._Input_validations_failed),
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
		}
		
//		If Request.Amount <=0, then error #300142
		BigDecimal depositAmount = new BigDecimal(FormatUtils.getValue(body, "//*:CreatePaymentLoanByAccountRequestItem/*:Amount"));
		
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("### STEP 250 VALIDATIONS ###");
			
			LOGGER.debug("Deposit amount  :"+depositAmount);
		}
		
		if(depositAmount.compareTo(BigDecimal.ZERO) <=0){
			ErrorUtils.throwCBSException(null ,  
					String.valueOf(ConstantError_Types._Functional), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					ValidateCreatePaymentLoanByAccount.class.getCanonicalName(), 
					String.valueOf(ConstantErrorMessages._Amount_Is_Less_Than_Minimum_Allowed),
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
		}
		
//		If Request.Amount > 9.999.999.999,99 then error #300915
		BigDecimal maxAmount = new BigDecimal("9999999999.99");
		
		if(depositAmount.compareTo(maxAmount) > 0){
			ErrorUtils.throwCBSException(null ,  
					String.valueOf(ConstantError_Types._Functional), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					ValidateCreatePaymentLoanByAccount.class.getCanonicalName(), 
					String.valueOf(ConstantErrorMessages._UpTo10Digits),
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
		}

		
		

	}
	
	public void step500(Exchange exchange) throws Exception{

		Document body = exchange.getIn().getBody(Document.class);

		
//		if GetProductAttributesByProductId.ProductCategoryCode <> 1 then error #300840
		
		int productCategoryCode = exchange.getProperty("productCategoryCode",Integer.class);
		
		if (productCategoryCode!=1){
			ErrorUtils.throwCBSException(null ,  
					String.valueOf(ConstantError_Types._Functional), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					ValidateCreatePaymentLoanByAccount.class.getCanonicalName(), 
					String.valueOf(ConstantErrorMessages._Unacceptable_productMW),
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
		}
		
		//Check account status

		String closedInactiveFlag = getValue(body, "//*:accountMultiGetResponse/*:openClosedIndicator_1");
		String activeFlag = getValue(body, "//*:accountMultiGetResponse/*:activeFlag_1");	

		int combinedAccountstatus = NumberUtils.toInt(commonsHelper.combineAccountStatusActiveAndAccountStatusOpenClose(activeFlag,closedInactiveFlag,true));
		
		
		Map<Integer,String> matchAccountStatusToErrorMessageMap = new HashMap<Integer,String>();
		matchAccountStatusToErrorMessageMap.put(ConstantAccountOpenActiveType._ACCOUNT_CLOSED_BY_ACCOUNTING_TXON, String.valueOf(ConstantErrorMessages._AccountHasBeenSettled));
		matchAccountStatusToErrorMessageMap.put(ConstantAccountOpenActiveType._ACCOUNT_CLOSED_BY_CAM_TXON, String.valueOf(ConstantErrorMessages._ClosedAccount));
		matchAccountStatusToErrorMessageMap.put(ConstantAccountOpenActiveType._DORMANT_ACCOUNT, String.valueOf(ConstantErrorMessages._No_Transaction_Can_Be_Performed_On_Account));
		matchAccountStatusToErrorMessageMap.put(ConstantAccountOpenActiveType._ACCOUNT_BLOCKED_FOR_TRANSACTIONS, String.valueOf(ConstantErrorMessages._Account_Blocked_For_Transactions));
		matchAccountStatusToErrorMessageMap.put(ConstantAccountOpenActiveType._ACCOUNT_DOES_NOT_EXIST, String.valueOf(ConstantErrorMessages._Account_Not_Found));
		
		
		if(matchAccountStatusToErrorMessageMap.containsKey(combinedAccountstatus)){
			ErrorUtils.throwCBSException(null ,  
					String.valueOf(ConstantError_Types._Functional), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					ValidateCreatePaymentLoanByAccount.class.getCanonicalName(), 
					matchAccountStatusToErrorMessageMap.get(combinedAccountstatus),
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
		}
		
		
		
//		"IF L-ACCSMLGET-OUT-FC != 00 THEN
//	    ERROR 300854 - ..."
		String currency = getValue(body, "//*:accountMultiGetResponse/*:accountCurrency_1");

		if (Integer.valueOf(currency) != 0){
			ErrorUtils.throwCBSException(null ,  
					String.valueOf(ConstantError_Types._Functional), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					this.getClass().getCanonicalName(), 
					ConstantErrorMessages._Invalid_Account_Currency_MW,
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
		}
		
		
		// If ps.702 does not contain 99 then error
		//  301142 (...)

			
		String prodVersion = exchange.getProperty("productVersion", String.class);
		String prodCode = exchange.getProperty("productCode", String.class);
		
		Map<String, List<String>> prdMap = productStudio.getProductAttributeRealValuesLists(Integer.valueOf(prodCode), Integer.valueOf(prodVersion), null);

		if (prdMap!=null && prdMap.get("702") != null && !prdMap.get("702").contains("99")){
			ErrorUtils.throwCBSException(null ,  
					String.valueOf(ConstantError_Types._Functional), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					this.getClass().getCanonicalName(), 
					ConstantErrorMessages._O_LOGARIASMOS_PU_EISAGATE_DEN_EINAI_LOGARIASMOS_PLIROMON_MW,
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
		}
		
		
	}
}
