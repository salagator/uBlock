package gr.alpha.cbs.fuse.transactions.deposits.helpers;

import java.math.BigDecimal;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.math.NumberUtils;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.enums.ConstantCreditLoanToAccountAction;
import gr.alpha.cbs.fuse.enums.ConstantExtraitLanguages;
import gr.alpha.cbs.fuse.common.ifaces.RefDataTranslator;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;

@Named("createPaymentLoanByAccountHelper")
@ApplicationScoped
@RegisterForReflection
public class CreatePaymentLoanByAccountHelper {
	@Inject
	RefDataTranslator translator;
	private static final Logger LOGGER = Logger.getLogger(CreatePaymentLoanByAccountHelper.class);
	
	public void prepareDataForJournal(Exchange exchange) throws Exception{
		
		Document body = exchange.getIn().getBody(Document.class);
	
		String depositAmount =  FormatUtils.getValue(body, "//*:CreatePaymentLoanByAccountRequestItem/*:Amount");	
		String accountCurrency = FormatUtils.getValue(body, "//*:accountMultiGetResponse/*:accountCurrency_1");
		
		exchange.setProperty("depositAmountForHost", FormatUtils.getDecimalToHost(depositAmount, 13, 2));
		exchange.setProperty("depositAccountCurrencyHost", accountCurrency);
		exchange.setProperty("depositAccountCurrencyDesc", translator.translateData(CBSConstants.REF_DATA_SYSTEM_OS2200, "Greek", CBSConstants.REF_NAME_CURRENCIES_ISO, accountCurrency));
		
	}
	
	public void setPrepValues(Exchange exchange) throws Exception{
		Document body = exchange.getIn().getBody(Document.class);
		String transactionName = exchange.getProperty(CBSConstants.HEADER_TRANSACTION_NAME, String.class);
		String additionalInfo = FormatUtils.getValue(body, "//*:CreatePaymentLoanByAccountRequestItem/*:ReferenceKey");
		String accdcbalReasonCode = "";
		String accdcbalReason = "";
		String acgentrcreTransCode = "";

		accdcbalReasonCode="";
		accdcbalReason = additionalInfo;
		acgentrcreTransCode="";
		
		
		exchange.setProperty("accdcbalCode", accdcbalReasonCode);
		exchange.setProperty("accdcbalReason", accdcbalReason);
		exchange.setProperty("acgentrcreTransCode", acgentrcreTransCode);
		
		String branch = exchange.getProperty("cbs.common.branch", String.class);
		Boolean isCallFromWeb = false;
		if (branch.equals("0096") || branch.equals("096") || branch.equals("96")){
			isCallFromWeb = true;
		}
		if(isCallFromWeb){
			exchange.setProperty("cbs.selectedAccountingTemplate", "T00183");
		}else{
			exchange.setProperty("cbs.selectedAccountingTemplate", "T00308");
		}
		exchange.setProperty("CreatePaymentLoanByAccount.isCallFromWeb", isCallFromWeb);
	}
	
	public void setApplicationGroup(Exchange exchange) throws Exception{
		
		if(exchange.getProperty("depositAccountCurrencyHost", String.class).equals("00")){
			exchange.setProperty("cbs.accounting.applGroup", "1");
		}
		else{
			exchange.setProperty("cbs.accounting.applGroup", "8");
		}
	}
	
	public void prepareDataForExtrait(Exchange exchange) throws Exception {
		LOGGER.debug("#### START OF PREPARING DATA FOR EXTRAIT ####");
		
		Document body = exchange.getIn().getBody(Document.class);
		String transactionName = exchange.getProperty(CBSConstants.HEADER_TRANSACTION_NAME, String.class);
		String accountNumber = FormatUtils.getValue(body, "//*:CreatePaymentLoanByAccountRequestItem/*:DepositAccountNumber");		
		String timestampUTC = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse/*:timestampUTC");
		String timestampUTCFormatted = timestampUTC.replace("S", ":");		
		String ufeRealBranch = FormatUtils.getValue(body, "//*:accountMultiGetResponse/*:accountRealBranch_1");
		String productId = FormatUtils.getValue(body, "//*:accountMultiGetResponse/*:productCode_1");
		String depositAmount =  FormatUtils.getValue(body, "//*:CreatePaymentLoanByAccountRequestItem/*:Amount");		
		String valeurDate = FormatUtils.getValue(body, "//*:CreatePaymentLoanByAccountRequestItem/*:ValueDate"); 
		String valeurDateTrim = valeurDate.replace("-", "");	

		String customerNumber = FormatUtils.getValue(body, "//*:CreatePaymentLoanByAccountRequestItem/*:CustomerNumber");		
		String balanceLogisticBeforeParse = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse/*:balanceLogistic");
        BigDecimal balanceLogisticDecimal = FormatUtils.getDecimalFromHost(balanceLogisticBeforeParse, 16);
        String balanceLogisticSign = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse/*:balanceLogisticSign");
        String balanceLogistic = balanceLogisticSign.equals("-") ? balanceLogisticSign + String.valueOf(balanceLogisticDecimal) : String.valueOf(balanceLogisticDecimal);
        String balanceAvailableBeforeParse = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse/*:balanceAvailable");
		BigDecimal balanceAvailableDecimal = FormatUtils.getDecimalFromHost(balanceAvailableBeforeParse, 16);
		String balanceAvailableSign = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse/*:balanceAvailableSign");
		String balanceAvailable = balanceAvailableSign.equals("-") ? balanceAvailableSign + String.valueOf(balanceAvailableDecimal) : String.valueOf(balanceAvailableDecimal);		
		String timestampCurrent = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse/*:timestampCurrent");
		String timestampCurrentFormatted = timestampCurrent.replace("S", ":");	
		String spacesForProperties = "      ";  
		String remarks = FormatUtils.getValue(body, "//*:CreatePaymentLoanByAccountRequestItem/*:ReferenceKey");	
		String eventSubCategory = "";
		String eventCategory = "";
		String productKind = "";
		String reason="";
		String reasonCode = "";

		eventSubCategory="010086";
		eventCategory="010068";
		productKind="010004";
		reasonCode = "000";
		reason = "ΠΛΗΡ." + remarks;



		if(LOGGER.isDebugEnabled()){
			
		LOGGER.debug("Account number: " + accountNumber);
		LOGGER.debug("UTCPostingTimestamp: " + timestampUTC);
		LOGGER.debug("RealBranchNumber: " + ufeRealBranch);
		LOGGER.debug("CbsProductCode: " + productId);
		LOGGER.debug("Deposit amount: " + depositAmount);
		LOGGER.debug("Valeur date: " + valeurDateTrim);
		LOGGER.debug("AitCode/AitSapCode: " + reasonCode);
		LOGGER.debug("AitOnlineExtrait/AitSapExtrait: " + reason);
		LOGGER.debug("Customer number: " + customerNumber);
		LOGGER.debug("GrossBalance: " + balanceLogistic);
		LOGGER.debug("AvailableBalance: " + balanceAvailable);
		LOGGER.debug("CurrentTimestamp: " + timestampCurrentFormatted);
		LOGGER.debug("EventSubCategory: " + eventSubCategory);
		LOGGER.debug("eventCategory: " + eventCategory);
		LOGGER.debug("productKind: " + productKind);
		}
		
		exchange.setProperty("AccountNumber", accountNumber);
		exchange.setProperty("UTCPostingTimestamp", timestampUTCFormatted);
		exchange.setProperty("RealBranchNumber", ufeRealBranch);
		exchange.setProperty("CbsProductCode", productId);
		exchange.setProperty("Amount", depositAmount); 
		exchange.setProperty("ValeurDate", valeurDateTrim);
		exchange.setProperty("AitCode", reasonCode);
		exchange.setProperty("AitSapCode", reasonCode);
		exchange.setProperty("AitOnlineExtrait", reason);
		exchange.setProperty("AitSapExtrait", reason);
		exchange.setProperty("CustomerID", customerNumber);
		exchange.setProperty("GrossBalance", balanceLogistic);
		exchange.setProperty("AvailableBalance", balanceAvailable);
		exchange.setProperty("CurrentTimestamp", timestampCurrentFormatted);
		exchange.setProperty("EventSubCategory", eventSubCategory);
		exchange.setProperty("EventCategory", eventCategory);
		exchange.setProperty("ProductKind", productKind);
		exchange.setProperty("Remarks", remarks);
		exchange.setProperty("Spaces", spacesForProperties);

		
		LOGGER.debug("#### END OF PREPARING DATA FOR EXTRAIT ####");
	}

}
