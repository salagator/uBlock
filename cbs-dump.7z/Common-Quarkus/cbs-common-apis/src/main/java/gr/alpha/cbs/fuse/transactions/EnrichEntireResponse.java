package gr.alpha.cbs.fuse.transactions;

import gr.alpha.cbs.fuse.strategies.XsltAggregationStrategyAlpha;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import org.apache.camel.component.xslt.XsltOutput;

@Named("enrichEntireResponse.xsl")
@ApplicationScoped
@RegisterForReflection
public class EnrichEntireResponse extends XsltAggregationStrategyAlpha {
    public EnrichEntireResponse() {
        super("gr/alpha/cbs/fuse/xslt/enrichEntireResponse.xsl");
        setOutput(XsltOutput.DOM);
    }
}
