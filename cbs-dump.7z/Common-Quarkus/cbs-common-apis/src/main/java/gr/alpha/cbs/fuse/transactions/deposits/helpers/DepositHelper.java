package gr.alpha.cbs.fuse.transactions.deposits.helpers;

import org.apache.camel.Exchange;
import org.slf4j.MDC;

import gr.alpha.cbs.fuse.common.CBSConstants;

public class DepositHelper {
	
	private static gr.alpha.cbs.fuse.transactions.deposits.transactional.generated.ObjectFactory transactionalfactory = new gr.alpha.cbs.fuse.transactions.deposits.transactional.generated.ObjectFactory();
	public static gr.alpha.cbs.fuse.transactions.deposits.transactional.generated.LoggingInfoType getLoggingInfoTransactional(Exchange exchange) {
		gr.alpha.cbs.fuse.transactions.deposits.transactional.generated.LoggingInfoType loggingInfoType = transactionalfactory.createLoggingInfoType();

		loggingInfoType.setRequestId(exchange.getProperty(CBSConstants.HEADER_REQUEST_ID,String.class));
		loggingInfoType.setSessionId(exchange.getProperty(CBSConstants.HEADER_FRONT_END_SESSION_ID,String.class));
		loggingInfoType.setBusinessCaseId(exchange.getProperty(CBSConstants.HEADER_BUSINESS_CASE_ID,String.class));
		loggingInfoType.setSequenceId(MDC.get(CBSConstants.MDC_KEY_SEQUENCE_ID));
		loggingInfoType.setUserId(exchange.getProperty(CBSConstants.HEADER_USER_ID,String.class));
		loggingInfoType.setCBSUnId(exchange.getProperty(CBSConstants.HEADER_BUN,String.class));
        
		return loggingInfoType;
	}
}
