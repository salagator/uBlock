package gr.alpha.cbs.fuse.transactions.periodicreviews.ejbs;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import io.quarkus.agroal.runtime.AgroalDataSourceSupport;
import io.quarkus.agroal.runtime.AgroalDataSourceUtil;
import io.quarkus.agroal.runtime.DataSources;
import io.quarkus.arc.Arc;
import io.quarkus.datasource.runtime.DataSourceSupport;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.Resource;
import javax.sql.DataSource;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Instance;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.transaction.Transactional;
import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.enums.ConstantBusinessReassessmentStatus;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import gr.alpha.cbs.fuse.enums.ConstantPeriodicReviewStatus;
import gr.alpha.cbs.fuse.enums.ConstantPeriodicReviewsLegalEntityType;

@Named("periodicReviewsEJB")
@ApplicationScoped
@RegisterForReflection
@SuppressWarnings({ "unchecked" })
public class PeriodicReviewsEJB {

    private static final Logger LOGGER = LoggerFactory.getLogger(PeriodicReviewsEJB.class);

    private DataSource ds;
    private DataSource dsXA;

    @PostConstruct
    protected void init() {
        if (AgroalDataSourceUtil.dataSourceIfActive("cst").isPresent()) {
            LOGGER.info("Found cst datasource");
            ds = AgroalDataSourceUtil.dataSourceIfActive("cst").get();
        }
        if (AgroalDataSourceUtil.dataSourceIfActive("cst").isPresent()) {
            LOGGER.info("Found cst datasource");
            dsXA = AgroalDataSourceUtil.dataSourceIfActive("cstxa").get();
        }
    }

    @Transactional(Transactional.TxType.SUPPORTS)
    public void getCountOfPeriodicReviewsReadyForAssessment(Exchange exchange) throws Exception {

        int casesCount = 0;
        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement("SELECT COUNT(a.CaseID) as CasesCount FROM PeriodicReviews a "
                      + "INNER JOIN Customer c ON a.CaseID = c.CaseID "
                      + "where a.StatusID = '3' "
                      + "and a.PendingNotificationsIndicator = '1' "
                      + "and c.IsActiveDKS = '1';" ); ) {

            try (ResultSet rs = pstmt.executeQuery()){

                if(rs.next()){
                    casesCount = rs.getInt("CasesCount");
                }

            }

        }

        LOGGER.debug("getCountOfPeriodicReviewsReadyForAssessment result is: " + casesCount);
        exchange.setProperty("getCountOfPeriodicReviewsReadyForAssessmentResult", casesCount);
    }

    @Transactional(Transactional.TxType.SUPPORTS)
    public void checkPeriodicReviewsExists(Exchange exchange, String caseID) throws Exception {

        boolean caseFound = false;
        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement("SELECT 1 AS CaseFound FROM PeriodicReviews WHERE CaseID = ? ;" ); ) {

            pstmt.setString(1, caseID);

            try (ResultSet rs = pstmt.executeQuery()){

                if(rs.next()){
                    caseFound = rs.getBoolean("CaseFound");
                }

            }

        }

        LOGGER.debug("checkPeriodicReviewsExists result is: " + caseFound);
        exchange.setProperty("checkPeriodicReviewsExistsResult", caseFound);
    }

    @Transactional(Transactional.TxType.SUPPORTS)
    public void getPeriodicReviewsReadyForAssessment(Exchange exchange) throws Exception {

        String topNum = exchange.getContext().resolvePropertyPlaceholders("{{cst.listener.top.results}}");
        List<Map<String, String>> result = new ArrayList<>();

        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement("SELECT TOP (CAST( ? as int)) * FROM PeriodicReviews a "
                      + "INNER JOIN Customer c ON a.CaseID = c.CaseID "
                      + "where a.StatusID = '3' "
                      + "and a.PendingNotificationsIndicator = '1' "
                      + "and c.IsActiveDKS = '1'" ); ) {

            pstmt.setString(1, topNum);

            try (ResultSet rs = pstmt.executeQuery()){
                result = getResultListFromResultSet(rs);
            }

        }

        LOGGER.debug("getPeriodicReviewsReadyForAssessment result is: " + result);
        exchange.setProperty("getPeriodicReviewsReadyForAssessmentResultList", result);
    }

    @Transactional(Transactional.TxType.SUPPORTS)
    public void getSironEventsForCaseIDsReadyForAssessment(Exchange exchange) throws Exception {

        List<String> caseIDs = exchange.getProperty("caseIDsReadyForAssessmentList", List.class);
        List<Map<String, String>> result = new ArrayList<>();

        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM PeriodicReviews_SironEventsForBussinessReassessment per_sebr "
                      + "INNER JOIN SironEventsForBussinessReassessment sebr ON sebr.EventID = per_sebr.EventID "
                      + "WHERE per_sebr.CaseID IN ("+ caseIDs.stream().map(l -> "?").collect(Collectors.joining(",")) +")"
                      + " AND sebr.isActive = '1' " ); ) {

            for(int i = 0; i < caseIDs.size(); i++){
                pstmt.setString(i+1, caseIDs.get(i));
            }

            try (ResultSet rs = pstmt.executeQuery()){
                result = getResultListFromResultSet(rs);
            }

        }

        LOGGER.debug("getSironEventsForCaseIDsReadyForAssessment result is: " + result);
        exchange.setProperty("getSironEventsForCaseIDsReadyForAssessmentResultList", result);
    }

    @Transactional(Transactional.TxType.MANDATORY)
    public void closeAutomaticallyPeriodicReviews(Exchange exchange) throws Exception {

        List<String> caseIDs = exchange.getProperty("caseIDsToCloseAutomatically", List.class);

        String sql = "UPDATE PeriodicReviews SET StatusID = ?, EndDate = GETDATE() WHERE CaseID IN ( "+ caseIDs.stream().map(l -> "?").collect(Collectors.joining(",")) +" );";

        int currentpos = 0;

        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {
            pstmt.setString(++currentpos, String.valueOf(ConstantPeriodicReviewStatus._Customer_Has_Positive_Screening));
            for(int i = 0; i < caseIDs.size(); i++){
                pstmt.setString(++currentpos, caseIDs.get(i));
            }
            pstmt.executeUpdate();
        }

        LOGGER.debug("Closed automatically periodic reviews with non critical events.");
    }

    @Transactional(Transactional.TxType.MANDATORY)
    public void startManualReassessment(Exchange exchange) throws Exception {

        List<Map<String, String>> manualReassessmentData = exchange.getProperty("manualReassessmentData", List.class);

        String sql = "INSERT INTO BusinessReassessment (BusinessReassessmentID,CreationDate,BusinessReassessmentStatus, BusinessReassessmentShowFlag) VALUES (?,GETDATE(),?,?)";

        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {

            for(Map<String, String> entry : manualReassessmentData){
                pstmt.setString(1, entry.get("BusinessReassessmentID"));
                pstmt.setString(2, String.valueOf(ConstantBusinessReassessmentStatus._Proposed));
                pstmt.setString(3, "isShippingCustomer=" + entry.get("isShippingCustomer") + "|" + "status=" + String.valueOf(ConstantBusinessReassessmentStatus._Proposed));
                pstmt.addBatch();

            }

            pstmt.executeBatch();

        }

        String sqlPeriodicReviews = "UPDATE PeriodicReviews SET BusinessReassessmentID = ? , StatusID = ? WHERE CaseID = ? ; ";
        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt2 = conn.prepareStatement(sqlPeriodicReviews); ) {

            for(Map<String, String> entry : manualReassessmentData){
                pstmt2.setString(1, entry.get("BusinessReassessmentID"));
                pstmt2.setString(2, String.valueOf(ConstantPeriodicReviewStatus._Customer_Has_Negative_Screening));
                pstmt2.setString(3, entry.get("CaseID"));
                pstmt2.addBatch();

            }

            pstmt2.executeBatch();

        }


        LOGGER.debug("Started Manual Business Reassessments.");
    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public void getPeriodicReviewDetails(Exchange exchange, String caseID) throws Exception {

        Map<String, String> result = new LinkedHashMap<>();

        try ( Connection conn = ds.getConnection();
              PreparedStatement pstmt = conn.prepareStatement("Select *, ph.RiskCategory as Physical_RiskCategory, le.RiskCategory as LegalEntity_RiskCategory from PeriodicReviews p "
                      + " LEFT JOIN Customer c ON p.CaseID = c.CaseID "
                      + "	LEFT JOIN PhysicalPerson ph ON p.CaseID = ph.CaseID "
                      + " LEFT JOIN LegalEntity le ON p.CaseID = le.CaseID "
                      + " LEFT JOIN BusinessReassessment b ON p.BusinessReassessmentID = b.BusinessReassessmentID "
                      + " WHERE p.CaseID = ?; "); ) {
            pstmt.setString(1, caseID);

            try (ResultSet rs = pstmt.executeQuery()){
                result = getResultFromResultSet(rs);
            }
        }

        if (result.isEmpty()){
            ErrorUtils.throwCBSException(null ,
                    String.valueOf(ConstantError_Types._Functional),
                    String.valueOf(ConstantError_System_IDs._FUSE),
                    this.getClass().getCanonicalName(),
                    ConstantErrorMessages._ADYNATI_EPEKSERGASIA_YPOTHESIS,
                    String.valueOf(ConstantError_Levels._Error),
                    "Δεν είναι δυνατή η ανάκτηση λεπτομερειών για την υπόθεση: " +caseID, "", "");
        }

        LOGGER.debug("getPeriodicReviewDetails result is: " + result);
        exchange.setProperty("getPeriodicReviewDetailsResult", !result.isEmpty() ? result : null);

    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public void getPeriodicReviewDetailsMulti(Exchange exchange, List<String> caseIDList) throws Exception {

        List<Map<String, String>> result = new ArrayList<>();

        try ( Connection conn = ds.getConnection();
              PreparedStatement pstmt = conn.prepareStatement("Select * from PeriodicReviews p "
                      + "inner join Customer c on p.CaseID = c.CaseID "
                      + "left join BusinessReassessment b on p.BusinessReassessmentID = b.BusinessReassessmentID "
                      + "where p.CaseID in ( "+caseIDList.stream().map(e -> "?").collect(Collectors.joining(","))+"); "); ) {

            for(int i = 0; i < caseIDList.size(); i++){
                pstmt.setString(i+1, caseIDList.get(i));
            }

            try (ResultSet rs = pstmt.executeQuery()){
                result = getResultListFromResultSet(rs);
            }
        }

        if (result.size()<caseIDList.size()){
            ErrorUtils.throwCBSException(null ,
                    String.valueOf(ConstantError_Types._Functional),
                    String.valueOf(ConstantError_System_IDs._FUSE),
                    this.getClass().getCanonicalName(),
                    ConstantErrorMessages._ADYNATI_EPEKSERGASIA_YPOTHESIS,
                    String.valueOf(ConstantError_Levels._Error),
                    "Δεν είναι δυνατή η ανάκτηση λεπτομερειών για όλες τις υποθέσεις: " +caseIDList, "", "");
        }

        LOGGER.debug("getPeriodicReviewDetailsMulti result list is: " + result);
        exchange.setProperty("getPeriodicReviewDetailsMultiResultList", !result.isEmpty() ? result : null);

    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public void insertNewComment(Exchange exchange) throws Exception {

        String sql = "INSERT INTO Questionnaire VALUES (?,?,?,?,?,'',?)";

        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {

            pstmt.setString(1, exchange.getProperty("questionnaireId", String.class));
            pstmt.setString(2, exchange.getProperty("questionnaireUser", String.class));
            pstmt.setString(3, exchange.getProperty("dateTimeNow", String.class));
            pstmt.setString(4, exchange.getProperty("commentTextEscaped", String.class));
            pstmt.setString(5, exchange.getProperty("questionnaireSelection", String.class));
            pstmt.setString(6, exchange.getProperty("cbs.CST_DB.Response.BusinessReassessmentID", String.class));
            pstmt.executeUpdate();
        }

        LOGGER.debug("Commment Inserted Succesfully");

    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public void updateExistingComment(Exchange exchange) throws Exception {

        String questionnaireSelection = exchange.getProperty("QuestionnaireSelection", String.class);
        String sql = "UPDATE Questionnaire SET CommentText = ?";

        //If QuestionnaireSelection exists, it should be added to the query in order to be updated
        if (questionnaireSelection != ""){
            sql = sql + ", QuestionnaireSelection = ?";
        }

        sql = sql + " WHERE QuestionnaireId = ? AND BusinessReassessmentID = (SELECT BusinessReassessmentID FROM PeriodicReviews WHERE CaseID = ?);";

        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {

            pstmt.setString(1, exchange.getProperty("commentTextEscaped", String.class));
            if (questionnaireSelection != ""){
                pstmt.setString(2, exchange.getProperty("questionnaireSelection", String.class));
                pstmt.setString(3, exchange.getProperty("questionnaireId", String.class));
                pstmt.setString(4, exchange.getProperty("caseID", String.class));
            }
            else{
                pstmt.setString(2, exchange.getProperty("questionnaireId", String.class));
                pstmt.setString(3, exchange.getProperty("caseID", String.class));
            }
            pstmt.executeUpdate();
        }

        LOGGER.debug("Commment Updated Succesfully");

    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public void getPreviousReviewCustomerInfo(Exchange exchange, String caseID, String legalEntityType) throws Exception {

        boolean isIndividual = legalEntityType.equals(String.valueOf(ConstantPeriodicReviewsLegalEntityType._Individual));
        Map<String, String> result = new LinkedHashMap<>();

        String sql = "WITH temp (CaseEndDate, CustomerNumber) as (SELECT EndDate, CustomerNumber FROM PeriodicReviews WHERE CaseID=?) "
                + "SELECT cus.*, "
                + (isIndividual ? " ph.*, " : " le.*, ")
                + " per.EndDate as LastPeriodicReviewEndDate, br.BusinessReassessmentFinalSelection as LastPeriodicReviewOutcome FROM Customer cus "

                + (isIndividual ? " LEFT JOIN PhysicalPerson ph ON ph.CaseID = cus.CaseID " : " LEFT JOIN LegalEntity le ON le.CaseID = cus.CaseID ")

                + " LEFT JOIN PeriodicReviews per on per.CaseID = cus.CaseID "
                + " LEFT JOIN BusinessReassessment br on br.BusinessReassessmentID = per.BusinessReassessmentID "

                + "WHERE cus.CaseID =  "
                + "( "
                + "  SELECT p.CaseID FROM PeriodicReviews p, temp "
                + "  WHERE p.CustomerNumber = temp.CustomerNumber "
                + "  AND p.EndDate =  "
                + "	  ( "
                + "		SELECT max(EndDate) FROM PeriodicReviews c, temp "
                + "		LEFT JOIN BusinessReassessment b ON p.BusinessReassessmentID = b.BusinessReassessmentID "
                + "		WHERE c.CustomerNumber = temp.CustomerNumber  "
                + "		AND c.EndDate IS NOT NULL "
                + "		AND ((temp.CaseEndDate IS NOT NULL AND c.EndDate < temp.CaseEndDate) OR temp.CaseEndDate IS NULL) "
                + "		AND  ( c.StatusID='4' OR (c.StatusID='5' AND b.BusinessReassessmentStatus='6')) "
                + "	  ) "
                + "  ); ";

        try ( Connection conn = ds.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {
            pstmt.setString(1, caseID);

            try (ResultSet rs = pstmt.executeQuery()){
                result = getResultFromResultSet(rs);
            }
        }

        LOGGER.debug("getPreviousReviewCustomerInfo result is: " + result);
        exchange.setProperty("getPreviousReviewCustomerInfoResult", !result.isEmpty() ? result : null);

    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public void getCustomerAddresses(Exchange exchange, String caseID) throws Exception {

        List<Map<String, String>> resultList = new ArrayList<>();

        String sql = " SELECT * "
                + " FROM Addresses a"
                + " WHERE a.CaseID = ?; ";

        try ( Connection conn = ds.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {
            pstmt.setString(1, caseID);

            try (ResultSet rs = pstmt.executeQuery()){
                resultList = getResultListFromResultSet(rs);
            }
        }

        LOGGER.debug("getCustomerAddresses result list is: " + resultList);
        exchange.setProperty("getCustomerAddressesResultList", !resultList.isEmpty() ? resultList : null);

    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public void getKycQuestionnaire(Exchange exchange, String caseID) throws Exception {

        List<Map<String, String>> resultList = new ArrayList<>();

        String sql = " SELECT * "
                + " FROM KycQuestionnaire a"
                + " WHERE a.CaseID = ?; ";

        try ( Connection conn = ds.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {
            pstmt.setString(1, caseID);

            try (ResultSet rs = pstmt.executeQuery()){
                resultList = getResultListFromResultSet(rs);
            }
        }

        LOGGER.debug("getKycQuestionnaire result list is: " + resultList);
        exchange.setProperty("getKycQuestionnaireResultList", !resultList.isEmpty() ? resultList : null);

    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public void getRelationships(Exchange exchange, String caseID) throws Exception {

        List<Map<String, String>> resultList = new ArrayList<>();

        String sql = " SELECT * "
                + " FROM KycQuestionnaire a"
                + " WHERE a.CaseID = ?; ";

        try ( Connection conn = ds.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {
            pstmt.setString(1, caseID);

            try (ResultSet rs = pstmt.executeQuery()){
                resultList = getResultListFromResultSet(rs);
            }
        }

        LOGGER.debug("getRelationships result list is: " + resultList);
        exchange.setProperty("getRelationshipsResultList", !resultList.isEmpty() ? resultList : null);

    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public void getNotificationsPerCase(Exchange exchange, String caseID) throws Exception {

        List<Map<String, String>> resultList = new ArrayList<>();

        String sql = " SELECT * "
                + " FROM PeriodicReviews_Notifications b "
                + " LEFT JOIN Notifications c ON c.NotificationID = b.NotificationID"
                + " WHERE b.CaseID = ?; ";

        try ( Connection conn = ds.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {
            pstmt.setString(1, caseID);

            try (ResultSet rs = pstmt.executeQuery()){
                resultList = getResultListFromResultSet(rs);
            }
        }

        LOGGER.debug("getNotificationsPerCase result list is: " + resultList);
        exchange.setProperty("getNotificationsPerCaseResultList", !resultList.isEmpty() ? resultList : null);

    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public void getSironEventsForBussinessReassessment(Exchange exchange, String caseID) throws Exception {

        List<Map<String, String>> resultList = new ArrayList<>();

        String sql = " SELECT * "
                + " FROM PeriodicReviews_SironEventsForBussinessReassessment f "
                + " LEFT JOIN SironEventsForBussinessReassessment g on f.EventID = g.EventID"
                + " WHERE f.CaseID = ?; ";

        try ( Connection conn = ds.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {
            pstmt.setString(1, caseID);

            try (ResultSet rs = pstmt.executeQuery()){
                resultList = getResultListFromResultSet(rs);
            }
        }

        LOGGER.debug("getSironEventsForBussinessReassessment result list is: " + resultList);
        exchange.setProperty("getSironEventsForBussinessReassessmentResultList", !resultList.isEmpty() ? resultList : null);

    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public void getSironEventsForPerimeter(Exchange exchange, String caseID) throws Exception {

        List<Map<String, String>> resultList = new ArrayList<>();

        String sql = " SELECT * "
                + " FROM PeriodicReviews_SironEventsForPerimeter f "
                + " LEFT JOIN SironEventsForPerimeter g on f.EventID = g.EventID"
                + " WHERE f.CaseID = ?; ";

        try ( Connection conn = ds.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {
            pstmt.setString(1, caseID);

            try (ResultSet rs = pstmt.executeQuery()){
                resultList = getResultListFromResultSet(rs);
            }
        }

        LOGGER.debug("getSironEventsForPerimeter result list is: " + resultList);
        exchange.setProperty("getSironEventsForPerimeterResultList", !resultList.isEmpty() ? resultList : null);

    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public void getQuestionnaire(Exchange exchange, String caseID) throws Exception {

        List<Map<String, String>> resultList = new ArrayList<>();

        String sql = " SELECT q.* FROM PeriodicReviews p "
                + "INNER JOIN BusinessReassessment b ON p.BusinessReassessmentID = b.BusinessReassessmentID "
                + "INNER JOIN Questionnaire q ON p.BusinessReassessmentID = q.BusinessReassessmentID "
                + "WHERE p.CaseID = ?; ";

        try ( Connection conn = ds.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {
            pstmt.setString(1, caseID);

            try (ResultSet rs = pstmt.executeQuery()){
                resultList = getResultListFromResultSet(rs);
            }
        }

        LOGGER.debug("getQuestionnaire result list is: " + resultList);
        exchange.setProperty("getQuestionnaireResultList", !resultList.isEmpty() ? resultList : null);

    }


    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public void getBusinessReassessmentsList(Exchange exchange) throws Exception {

        List<Map<String, String>> resultList = new ArrayList<>();
        String sql = exchange.getProperty("getBusinessReassessmentsListFinalSearch.query", String.class);
        List<String> paramsList = exchange.getProperty("getBusinessReassessmentsListFinalSearch.queryParams", List.class);

        try ( Connection conn = ds.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {
            for(int i = 0; i < paramsList.size(); i++){
                pstmt.setString(i+1, paramsList.get(i));
            }

            try (ResultSet rs = pstmt.executeQuery()){
                resultList = getResultListFromResultSet(rs);
            }
        }

        LOGGER.debug("getBusinessReassessmentsList result list is: " + resultList);
        exchange.setProperty("getBusinessReassessmentsListResultList", !resultList.isEmpty() ? resultList : null);

    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public void getPeriodicReviewsList(Exchange exchange) throws Exception {

        List<Map<String, String>> resultList = new ArrayList<>();
        String sql = exchange.getProperty("getPeriodicReviewsList.mainQuery", String.class);
        List<String> paramsList = exchange.getProperty("getPeriodicReviewsList.mainQueryParams", List.class);

        try ( Connection conn = ds.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {
            for(int i = 0; i < paramsList.size(); i++){
                pstmt.setString(i+1, paramsList.get(i));
            }

            try (ResultSet rs = pstmt.executeQuery()){
                resultList = getResultListFromResultSet(rs);
            }
        }

        LOGGER.debug("getPeriodicReviewsList result list is: " + resultList);
        exchange.setProperty("getPeriodicReviewsListResultList", !resultList.isEmpty() ? resultList : null);

    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public void periodicReviewsDataReport(Exchange exchange) throws Exception {

        List<Map<String, String>> resultList = new ArrayList<>();
        String sql = exchange.getProperty("periodicReviewsDataReport.mainQuery", String.class);
        List<String> paramsList = exchange.getProperty("periodicReviewsDataReport.mainQueryParams", List.class);

        try ( Connection conn = ds.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {
            for(int i = 0; i < paramsList.size(); i++){
                pstmt.setString(i+1, paramsList.get(i));
            }

            try (ResultSet rs = pstmt.executeQuery()){
                resultList = getResultListFromResultSet(rs);
            }
        }

        LOGGER.debug("periodicReviewsDataReport result list is: " + resultList);
        exchange.setProperty("periodicReviewsDataReportResultList", !resultList.isEmpty() ? resultList : null);

    }

    @Transactional(Transactional.TxType.MANDATORY)
    public void approveBusinessReassessmentReview(Exchange exchange) throws Exception {

        String businessReassessmentID = exchange.getProperty("businessReassessmentID", String.class);
        String newBusinessReassessmentStatus = exchange.getProperty("newBusinessReassessmentStatus", String.class);
        String businessReassessmentCurrentSelection = exchange.getProperty("businessReassessmentCurrentSelection", String.class);
        String businessReassessmentFinalSelection = exchange.getProperty("businessReassessmentFinalSelection", String.class);

        String sql = "UPDATE BusinessReassessment SET BusinessReassessmentStatus = ? "
                + ", BusinessReassessmentCurrentSelection = ?  "
                + ", BusinessReassessmentFinalSelection = ? "
                + " WHERE BusinessReassessmentID = ? ;";

        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {

            pstmt.setString(1, newBusinessReassessmentStatus);
            pstmt.setString(2, businessReassessmentCurrentSelection);
            pstmt.setString(3, businessReassessmentFinalSelection);
            pstmt.setString(4, businessReassessmentID);

            pstmt.executeUpdate();

        }
        LOGGER.debug("BusinessReassessment state updated in CST DB after Approve action.");
    }

    @Transactional(Transactional.TxType.MANDATORY)
    public void assignBusinessReassessmentReview(Exchange exchange) throws Exception {

        Map<String, Map<String, String>> assignmentData = exchange.getProperty("assignBusinessReassessmentReviewData", Map.class);
        String newBusinessReassessmentStatus = exchange.getProperty("newBusinessReassessmentStatus", String.class);

        String sql = "UPDATE BusinessReassessment SET BusinessReassessmentStatus = ?, "
                + "BusinessReassessmentCurrentAsignee = ?, "
                + "BusinessReassessmentShowFlag = NULL, "
                + "BusinessReassessmentAssignee = ? , BusinessReassessmentAssignmentDate = GETDATE() "
                + "WHERE BusinessReassessmentID = ? ;";

        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {


            for(Map.Entry<String, Map<String, String>> entry : assignmentData.entrySet()){
                pstmt.setString(1, newBusinessReassessmentStatus);
                pstmt.setString(2, entry.getValue().get("Assignee"));
                pstmt.setString(3, entry.getValue().get("Assignee"));
                pstmt.setString(4, entry.getValue().get("BusinessReassessmentID"));

                pstmt.addBatch();

            }

            pstmt.executeBatch();

        }

        LOGGER.debug("Assignement of Business Reassessments completed.");

    }

    @Transactional(Transactional.TxType.MANDATORY)
    public void assignSignOffBusinessReassessmentReview(Exchange exchange) throws Exception {

        Map<String, Map<String, String>> assignmentData = exchange.getProperty("assignBusinessReassessmentSignOffData", Map.class);
        String newBusinessReassessmentStatus = exchange.getProperty("newBusinessReassessmentStatus", String.class);

        String sql = "UPDATE BusinessReassessment SET BusinessReassessmentStatus = ?, "
                + "BusinessReassessmentCurrentAsignee = ?, "
                + "BusinessReassessmentShowFlag = NULL "
                + "WHERE BusinessReassessmentID = ? ;";

        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {

            for(Map.Entry<String, Map<String, String>> entry : assignmentData.entrySet()){
                pstmt.setString(1, newBusinessReassessmentStatus);
                pstmt.setString(2, entry.getValue().get("Assignee"));
                pstmt.setString(3, entry.getValue().get("BusinessReassessmentID"));

                pstmt.addBatch();

            }

            pstmt.executeBatch();

        }

        LOGGER.debug("Assignement of Business Reassessments for sign off completed.");

    }

    @Transactional(Transactional.TxType.MANDATORY)
    public void committeeDecisionBusinessReassessmentReview(Exchange exchange) throws Exception {

        String sql = "UPDATE BusinessReassessment SET BusinessReassessmentStatus = ?, "
                + "CommitteeDecision = ? "
                + "WHERE BusinessReassessmentID = ? ;";

        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {
            pstmt.setString(1, exchange.getProperty("newBusinessReassessmentStatus", String.class));
            pstmt.setString(2, exchange.getProperty("committeeDecision", String.class));
            pstmt.setString(3, exchange.getProperty("businessReassessmentID", String.class));
            pstmt.executeUpdate();
        }
        LOGGER.debug("Committee Desicion updated in CST DB.");

    }

    @Transactional(Transactional.TxType.MANDATORY)
    public void completePeriodicReview(Exchange exchange, String caseID) throws Exception {

        String sql = "UPDATE PeriodicReviews SET EndDate = GETDATE() WHERE CaseID = ?";
        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {
            pstmt.setString(1, caseID);
            pstmt.executeUpdate();
        }

        LOGGER.debug("Completed Periodic Review.");
    }

    @Transactional(Transactional.TxType.MANDATORY)
    public void completeBusinessReassessmentReview(Exchange exchange) throws Exception {

        String businessReassessmentID = exchange.getProperty("businessReassessmentID", String.class);
        String newBusinessReassessmentStatus = exchange.getProperty("newBusinessReassessmentStatus", String.class);
        String businessReassessmentShowFlag = exchange.getProperty("businessReassessmentShowFlag", String.class);
        String businessReassessmentCurrentAsignee = exchange.getProperty("businessReassessmentCurrentAsignee", String.class);
        String businessReassessmentFinalSelection = exchange.getProperty("businessReassessmentFinalSelection", String.class);
        String businessReassessmentCurrentSelection = exchange.getProperty("businessReassessmentCurrentSelection", String.class);

        String sql = "UPDATE BusinessReassessment SET BusinessReassessmentStatus = ?, "
                + "BusinessReassessmentCurrentAsignee = ?, "
                + "BusinessReassessmentShowFlag = ?,  "
                + "BusinessReassessmentCurrentSelection = ?,  "
                + "BusinessReassessmentSignOffStartDate = GETDATE()";

        if (newBusinessReassessmentStatus.equals(String.valueOf(ConstantBusinessReassessmentStatus._Completed))){
            sql = sql + ", BusinessReassessmentFinalSelection = ? ";
        }

        sql = sql + " WHERE BusinessReassessmentID = ? ;";

        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {

            if (newBusinessReassessmentStatus.equals(String.valueOf(ConstantBusinessReassessmentStatus._Completed))){
                pstmt.setString(1, newBusinessReassessmentStatus);
                if(businessReassessmentCurrentAsignee != null) {
                    pstmt.setString(2, businessReassessmentCurrentAsignee);
                }else{
                    pstmt.setNull(2, Types.VARCHAR);
                }
                if(businessReassessmentShowFlag != null) {
                    pstmt.setString(3, businessReassessmentShowFlag);
                }else{
                    pstmt.setNull(3, Types.VARCHAR);
                }
                pstmt.setString(4, businessReassessmentCurrentSelection);
                pstmt.setString(5, businessReassessmentFinalSelection);
                pstmt.setString(6, businessReassessmentID);
            } else{
                pstmt.setString(1, newBusinessReassessmentStatus);
                if(businessReassessmentCurrentAsignee != null) {
                    pstmt.setString(2, businessReassessmentCurrentAsignee);
                }else{
                    pstmt.setNull(2, Types.VARCHAR);
                }
                if(businessReassessmentShowFlag != null) {
                    pstmt.setString(3, businessReassessmentShowFlag);
                }else{
                    pstmt.setNull(3, Types.VARCHAR);
                }
                pstmt.setString(4, businessReassessmentCurrentSelection);
                pstmt.setString(5, businessReassessmentID);
            }

            pstmt.executeUpdate();

        }

        LOGGER.debug("BusinessReassessment state updated in CST DB after Complete action.");

    }


    @Transactional(Transactional.TxType.MANDATORY)
    public void confirmBusinessReassessmentReview(Exchange exchange) throws Exception {

        String businessReassessmentID = exchange.getProperty("businessReassessmentID", String.class);
        String newBusinessReassessmentStatus = exchange.getProperty("newBusinessReassessmentStatus", String.class);
        String businessReassessmentShowFlag = exchange.getProperty("businessReassessmentShowFlag", String.class);
        String businessReassessmentCurrentAsignee = exchange.getProperty("businessReassessmentCurrentAsignee", String.class);
        String businessReassessmentFinalSelection = exchange.getProperty("businessReassessmentFinalSelection", String.class);
        String businessReassessmentCurrentSelection = exchange.getProperty("businessReassessmentCurrentSelection", String.class);

        String sql = "UPDATE BusinessReassessment SET BusinessReassessmentStatus = ?, "
                + "BusinessReassessmentCurrentSelection = ?  ";

        if (newBusinessReassessmentStatus.equals(String.valueOf(ConstantBusinessReassessmentStatus._Wait_Approval))){
            sql = sql + ", BusinessReassessmentCurrentAsignee = ? , BusinessReassessmentShowFlag = ?  ";
        }

        if (newBusinessReassessmentStatus.equals(String.valueOf(ConstantBusinessReassessmentStatus._Completed))){
            sql = sql + ", BusinessReassessmentFinalSelection = ? ";
        }

        sql = sql + " WHERE BusinessReassessmentID = ? ;";

        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {

            if (newBusinessReassessmentStatus.equals(String.valueOf(ConstantBusinessReassessmentStatus._Completed))){
                pstmt.setString(1, newBusinessReassessmentStatus);
                pstmt.setString(2, businessReassessmentCurrentSelection);
                pstmt.setString(3, businessReassessmentFinalSelection);
                pstmt.setString(4, businessReassessmentID);
            } else{
                pstmt.setString(1, newBusinessReassessmentStatus);
                pstmt.setString(2, businessReassessmentCurrentSelection);
                if(businessReassessmentCurrentAsignee != null) {
                    pstmt.setString(3, businessReassessmentCurrentAsignee);
                }else{
                    pstmt.setNull(3, Types.VARCHAR);
                }
                if(businessReassessmentShowFlag != null) {
                    pstmt.setString(4, businessReassessmentShowFlag);
                }else{
                    pstmt.setNull(4, Types.VARCHAR);
                }
                pstmt.setString(5, businessReassessmentID);
            }

            pstmt.executeUpdate();

        }

        LOGGER.debug("BusinessReassessment state updated in CST DB after Confirm action.");

    }

    @Transactional(Transactional.TxType.MANDATORY)
    public void insertPhysicalPersonMaiInfoData(Exchange exchange) throws Exception {

        Map<String, String> insertLegalEntityMainInfoData = exchange.getProperty("getInsertPhysicalPersonMaiInfoData", Map.class);
        List<String> keySet = insertLegalEntityMainInfoData.keySet().stream().collect(Collectors.toList());
        String sql = "INSERT INTO PhysicalPerson("+keySet.stream().collect(Collectors.joining(","))+") "
                + "VALUES ("+keySet.stream().map(e -> "?").collect(Collectors.joining(","))+");";

        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {

            for (int i = 1; i <= keySet.size(); i++) {
                pstmt.setString(i, insertLegalEntityMainInfoData.get(keySet.get(i-1)));
            }

            pstmt.executeUpdate();
        }

        LOGGER.debug("Inserted Physical Person Main Info");

    }

    @Transactional(Transactional.TxType.MANDATORY)
    public void insertLegalEntityMainInfo(Exchange exchange) throws Exception {

        Map<String, String> insertLegalEntityMainInfoData = exchange.getProperty("insertLegalEntityMainInfoData", Map.class);
        List<String> keySet = insertLegalEntityMainInfoData.keySet().stream().collect(Collectors.toList());
        String sql = "INSERT INTO LegalEntity("+keySet.stream().collect(Collectors.joining(","))+") "
                + "VALUES ("+keySet.stream().map(e -> "?").collect(Collectors.joining(","))+");";

        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {

            for (int i = 1; i <= keySet.size(); i++) {
                String v = insertLegalEntityMainInfoData.get(keySet.get(i-1));
                if(v != null){
                    pstmt.setString(i, v);
                }else{
                    pstmt.setNull(i, Types.NVARCHAR);
                }
            }

            pstmt.executeUpdate();
        }

        LOGGER.debug("Inserted Legal Entity Main Info");

    }

    @Transactional(Transactional.TxType.MANDATORY)
    public void insertAddresses(Exchange exchange) throws Exception {

        List<Map<String, String>> insertAddressDataList = exchange.getProperty("insertAddressDataList", List.class);
        String sql = "INSERT INTO Addresses(CaseID, City, Country, Number, Street, ZipCode, AddressType, HasTelephone, Telephone) VALUES (?,?,?,?,?,?,?,?,?);";

        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {


            for(Map<String, String> data : insertAddressDataList){

                int i = 0;
                for(Map.Entry<String, String> entry : data.entrySet()){
                    String v = entry.getValue();
                    if(entry.getValue() != null){
                        pstmt.setString(++i, v);
                    }else{
                        pstmt.setNull(++i, Types.NVARCHAR);
                    }
                }
                pstmt.addBatch();
            }
            pstmt.executeBatch();
        }

        LOGGER.debug("Inserted Addresses.");

    }

    @Transactional(Transactional.TxType.MANDATORY)
    public void insertRelations(Exchange exchange) throws Exception {

        List<Map<String, String>> insertAddressDataList = exchange.getProperty("insertRelationsData", List.class);
        List<String> keySet = insertAddressDataList.get(0).keySet().stream().collect(Collectors.toList());
        String sql = "INSERT INTO Relationships("+keySet.stream().collect(Collectors.joining(","))+") "
                + "VALUES ("+keySet.stream().map(e -> "?").collect(Collectors.joining(","))+");";

        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {


            for(Map<String, String> data : insertAddressDataList){

                int i = 0;
                for(Map.Entry<String, String> entry : data.entrySet()){
                    String v = entry.getValue();
                    if(entry.getValue() != null){
                        pstmt.setString(++i, v);
                    }else{
                        pstmt.setNull(++i, Types.NVARCHAR);
                    }
                }
                pstmt.addBatch();
            }
            pstmt.executeBatch();
        }

        LOGGER.debug("Inserted Relations.");

    }

    @Transactional(Transactional.TxType.MANDATORY)
    public void insertKYCQuestionnaire(Exchange exchange) throws Exception {

        Map<String, String> insertKYCQuestionnaireData = exchange.getProperty("insertKYCQuestionnaireData", Map.class);
        String sql = "INSERT INTO KycQuestionnaire(CaseID, QuestionnaireIndicator, QuestionnaireDate, QuestionnaireVersion, Channel) VALUES (?,?,?,?,?);";

        try ( Connection conn = dsXA.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql); ) {

            pstmt.setString(1, insertKYCQuestionnaireData.get("CaseID"));
            pstmt.setString(2, insertKYCQuestionnaireData.get("QuestionnaireIndicator"));
            pstmt.setString(3, insertKYCQuestionnaireData.get("QuestionnaireDate"));
            pstmt.setString(4, insertKYCQuestionnaireData.get("QuestionnaireVersion"));
            pstmt.setString(5, insertKYCQuestionnaireData.get("Channel"));

            pstmt.executeUpdate();
        }

        LOGGER.debug("Inserted KYC Questionnaire.");

    }

    private Map<String, String> getResultFromResultSet(ResultSet rs) throws SQLException{
        Map<String, String> result = new LinkedHashMap<>();

        ResultSetMetaData rsmd = rs.getMetaData();
        int columnsNumber = rsmd.getColumnCount();

        if(rs.next()) {

            for (int i = 1; i <= columnsNumber; i++) {
                if(!result.containsKey(rsmd.getColumnName(i))){
                    result.put(rsmd.getColumnName(i), rs.getString(i));
                }
            }

        }

        return result;
    }

    private List<Map<String, String>> getResultListFromResultSet(ResultSet rs) throws SQLException{
        List<Map<String, String>> resultList = new ArrayList<>();

        ResultSetMetaData rsmd = rs.getMetaData();
        int columnsNumber = rsmd.getColumnCount();

        while(rs.next()) {

            Map<String, String> row = new LinkedHashMap<>();


            for (int i = 1; i <= columnsNumber; i++) {
                if(!row.containsKey(rsmd.getColumnName(i))){
                    row.put(rsmd.getColumnName(i), rs.getString(i));
                }
            }

            resultList.add(row);

        }
        return resultList;
    }
}
