package gr.alpha.cbs.fuse.transactions.deposits.processors;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import gr.alpha.cbs.fuse.transactions.deposits.helpers.DepositHelper;
import gr.alpha.cbs.fuse.transactions.deposits.transactional.generated.CreditDepositAccountByLoanAmountResponse;
import gr.alpha.cbs.fuse.transactions.deposits.transactional.generated.CreditDepositAccountByLoanAmountResponsePayload;
import gr.alpha.cbs.fuse.transactions.deposits.transactional.generated.LoggingInfoType;
import gr.alpha.cbs.fuse.transactions.deposits.transactional.generated.ObjectFactory;

@Named("successCreditDepositAccountByLoanAmount")
@ApplicationScoped
@RegisterForReflection
public class SuccessCreditDepositAccountByLoanAmount implements Processor{
	
	ObjectFactory factory;
	
	@Override
	public void process(Exchange exchange) throws Exception {
		
		factory = new ObjectFactory();
		
		ObjectFactory factory = new ObjectFactory();
		
		CreditDepositAccountByLoanAmountResponse response = factory.createCreditDepositAccountByLoanAmountResponse();
		CreditDepositAccountByLoanAmountResponsePayload payload = factory.createCreditDepositAccountByLoanAmountResponsePayload();
		
		/* **************** */
		/* set Logging Info */
		/* **************** */
		LoggingInfoType loggingInfo = DepositHelper.getLoggingInfoTransactional(exchange);
		payload.setLoggingInfo(loggingInfo);
		
		response.setCreditDepositAccountByLoanAmountResponsePayload(payload);
		
		exchange.getIn().setBody(response);	
	}

}
