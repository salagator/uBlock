package gr.alpha.cbs.fuse.transactions.cdi.helpers;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import gr.alpha.cbs.fuse.ifaces.ResourceBbbmmkHandlerInterface;

@Named("commonHelper")
@Dependent
@RegisterForReflection
public class CommonHelper {

	@Inject
	ResourceBbbmmkHandlerInterface res;

	public void getBBBMMK(Exchange ex) throws Exception{
		String resourceId = ex.getProperty("cbs.common.resourceId",String.class);
		String bbbmmk = res.readBbbmmk(resourceId);
		ex.setProperty("cbs.common.resourceBbbmmk", bbbmmk);
	}
}
