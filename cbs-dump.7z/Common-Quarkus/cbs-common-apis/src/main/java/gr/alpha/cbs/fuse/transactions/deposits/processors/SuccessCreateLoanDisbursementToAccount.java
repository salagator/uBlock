package gr.alpha.cbs.fuse.transactions.deposits.processors;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import gr.alpha.cbs.fuse.transactions.deposits.helpers.DepositHelper;
import gr.alpha.cbs.fuse.transactions.deposits.transactional.generated.CreateLoanDisbursementToAccountResponse;
import gr.alpha.cbs.fuse.transactions.deposits.transactional.generated.CreateLoanDisbursementToAccountResponsePayload;
import gr.alpha.cbs.fuse.transactions.deposits.transactional.generated.LoggingInfoType;
import gr.alpha.cbs.fuse.transactions.deposits.transactional.generated.ObjectFactory;

@Named("successCreateLoanDisbursementToAccount")
@ApplicationScoped
@RegisterForReflection
public class SuccessCreateLoanDisbursementToAccount implements Processor{
	
	ObjectFactory factory;
	
	@Override
	public void process(Exchange exchange) throws Exception {
		
		factory = new ObjectFactory();
		
		ObjectFactory factory = new ObjectFactory();
		
		CreateLoanDisbursementToAccountResponse response = factory.createCreateLoanDisbursementToAccountResponse();
		CreateLoanDisbursementToAccountResponsePayload payload = factory.createCreateLoanDisbursementToAccountResponsePayload();
		
		/* **************** */
		/* set Logging Info */
		/* **************** */
		LoggingInfoType loggingInfo = DepositHelper.getLoggingInfoTransactional(exchange);
		payload.setLoggingInfo(loggingInfo);
		
		response.setCreateLoanDisbursementToAccountResponsePayload(payload);
		
		exchange.getIn().setBody(response);	
	}

}
