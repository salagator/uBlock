package gr.alpha.cbs.fuse.transactions.deposits.helpers;

import java.math.BigDecimal;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.math.NumberUtils;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.enums.ConstantCreditLoanToAccountAction;
import gr.alpha.cbs.fuse.enums.ConstantExtraitLanguages;
import gr.alpha.cbs.fuse.common.ifaces.RefDataTranslator;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;

@Named("creditDepositAccountByLoanAmountHelper")
@ApplicationScoped
@RegisterForReflection
public class CreditDepositAccountByLoanAmountHelper {
	@Inject
	RefDataTranslator translator;
	private static final Logger LOGGER = Logger.getLogger(CreditDepositAccountByLoanAmountHelper.class);
	
	private static final String ACGENTCRE_ACCOUNT = "187003090000084";
	
	public void prepareDataForJournal(Exchange exchange) throws Exception{
		
		Document body = exchange.getIn().getBody(Document.class);
	
	
		String feeAmount =  FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:FeeAmount");
		String depositValueDate =  FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:DepositValueDate");
		String loanAccountNumber = FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:LoanAccountNumber");
		String depositAccountNumber = FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:DepositAccountNumber");
		String depositAmount =  FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:DepositAmount");
		String depositTrxTypeRequest =  FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:DepositTrxType");
		String depositTrxType = translator.translateData(CBSConstants.REF_DATA_SYSTEM_UI, "Greek", "DepositTransactionType", depositTrxTypeRequest);
		String accgetLanguage = FormatUtils.getValue(body, "//*:accountGetResponse/*:extraitLanguage");
		String reason = FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:DepositReason");
		String reasonForFeeCharge = "ServiceFee.MyAlpha4U";

		String accountCurrency = FormatUtils.getValue(body, "//*:accountMultiGetResponse/*:accountCurrency_1");
		String customerFullName = FormatUtils.getValue(body, "//*:accountMultiGetResponse/*:fullName_1_1").trim();
		String accmulgetCustomerNumber = String.valueOf(NumberUtils.toInt(FormatUtils.getValue(body, "//*:accountMultiGetResponse/*:customerNumber_1_1")));
		
		
		exchange.setProperty("feeAmountForHost", FormatUtils.getDecimalToHost(feeAmount, 13, 2));
		exchange.setProperty("depositAmountForHost", FormatUtils.getDecimalToHost(depositAmount, 13, 2));
		exchange.setProperty("depositTrxTypeTranslated", depositTrxType);
		exchange.setProperty("depositReason", reason);
		exchange.setProperty("CreditDepositAccountByLoanAmount.DepositReasonForFeeCharge", reasonForFeeCharge);
		exchange.setProperty("depositAccountCurrencyHost", accountCurrency);
		exchange.setProperty("depositAccountCurrencyDesc", translator.translateData(CBSConstants.REF_DATA_SYSTEM_OS2200, "Greek", CBSConstants.REF_NAME_CURRENCIES_ISO, accountCurrency));
		exchange.setProperty("CreditDepositAccountByLoanAmount.DepositAmount", depositAmount);
		exchange.setProperty("CreditDepositAccountByLoanAmount.DepositAccountNumber", depositAccountNumber);
		exchange.setProperty("CreditDepositAccountByLoanAmount.DepositValueDate", depositValueDate);
		exchange.setProperty("CreditDepositAccountByLoanAmount.CustomerFullName", customerFullName);
		exchange.setProperty("CreditDepositAccountByLoanAmount.CustomerNumberForJournal", accmulgetCustomerNumber);
		exchange.setProperty("CreditDepositAccountByLoanAmount.hasFeeAmount", !feeAmount.equals("0.0") && !feeAmount.equals("0.00") && !feeAmount.equals(""));
		
	}
	
	public void setAccountingTemplate(Exchange exchange) throws Exception{
		
		boolean hasFee = exchange.getProperty("CreditDepositAccountByLoanAmount.hasFeeAmount", Boolean.class);
		exchange.setProperty("CreditDepositAccountByLoanAmount.AccountNumberACGENTCRE", ACGENTCRE_ACCOUNT);
		exchange.setProperty("CreditDepositAccountByLoanAmount.RealBranchACGENTCRE", "0187");
		if(hasFee){
			exchange.setProperty("cbs.selectedAccountingTemplate", "T00017");
			exchange.setProperty("cbs.accounting.applGroup", "1");
		}else{
			if(exchange.getProperty("depositAccountCurrencyHost", String.class).equals("00")){
				exchange.setProperty("cbs.selectedAccountingTemplate", "T00019");
				exchange.setProperty("cbs.accounting.applGroup", "1");
			}
			else{
				exchange.setProperty("cbs.selectedAccountingTemplate", "T00054");
				exchange.setProperty("cbs.accounting.applGroup", "8");
			}
		}
	}
	
	
	public void setFinalAccountingBuffer(Exchange exchange) throws Exception{
	
		String accountingBufferFirstCall = exchange.getProperty("CreditDepositAccountByLoanAmount.AccountingBufferFirstCall", String.class);
		String accountingBufferSecondCall = exchange.getProperty("CreditDepositAccountByLoanAmount.AccountingBufferSecondCall", String.class);
		StringBuilder finalBuffer = new StringBuilder();
		finalBuffer.append(accountingBufferFirstCall).append(accountingBufferSecondCall);
		LOGGER.debug("finalBuffer: " +finalBuffer.toString());
		exchange.setProperty("cbs.accounting.buffer", finalBuffer.toString());
		
	}	
	
	public void prepareDataForExtrait(Exchange exchange) throws Exception {
		LOGGER.debug("#### START OF PREPARING DATA FOR EXTRAIT ####");
		
		Document body = exchange.getIn().getBody(Document.class);

		String accountNumber = FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:DepositAccountNumber");		
		String timestampUTC = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse/*:timestampUTC");
		String timestampUTCFormatted = timestampUTC.replace("S", ":");		
		String ufeRealBranch = FormatUtils.getValue(body, "//*:accountMultiGetResponse/*:accountRealBranch_1");
		String productId = FormatUtils.getValue(body, "//*:accountMultiGetResponse/*:productCode_1");
		String depositAmount =  FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:DepositAmount");		
		String valeurDate = FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:DepositValueDate"); 
		String valeurDateTrim = valeurDate.replace("-", "");	
		String depositTrxTypeRequest =  FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:DepositTrxType");
		String sign = depositTrxTypeRequest.equals("1") ? "2" : "1";
		
		String reasonCode = "150";
		String reason = exchange.getProperty("depositReason", String.class);
		String customerNumber = FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:CustomerNumber");		
		String balanceLogisticBeforeParse = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse/*:balanceLogistic");
        BigDecimal balanceLogisticDecimal = FormatUtils.getDecimalFromHost(balanceLogisticBeforeParse, 16);
        String balanceLogisticSign = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse/*:balanceLogisticSign");
        String balanceLogistic = balanceLogisticSign.equals("-") ? balanceLogisticSign + String.valueOf(balanceLogisticDecimal) : String.valueOf(balanceLogisticDecimal);
        String balanceAvailableBeforeParse = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse/*:balanceAvailable");
		BigDecimal balanceAvailableDecimal = FormatUtils.getDecimalFromHost(balanceAvailableBeforeParse, 16);
		String balanceAvailableSign = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse/*:balanceAvailableSign");
		String balanceAvailable = balanceAvailableSign.equals("-") ? balanceAvailableSign + String.valueOf(balanceAvailableDecimal) : String.valueOf(balanceAvailableDecimal);		
		String timestampCurrent = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse/*:timestampCurrent");
		String timestampCurrentFormatted = timestampCurrent.replace("S", ":");	
		String spacesForProperties = "      ";  
		String contraAccountNumber =  FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:LoanAccountNumber");
		String flagReversal = depositTrxTypeRequest.equals("1") ? "0" : "1";
		
		if(LOGGER.isDebugEnabled()){
			
			LOGGER.debug("Account number: " + accountNumber);
			LOGGER.debug("UTCPostingTimestamp: " + timestampUTC);
			LOGGER.debug("RealBranchNumber: " + ufeRealBranch);
			LOGGER.debug("CbsProductCode: " + productId);
			LOGGER.debug("Deposit amount: " + depositAmount);
			LOGGER.debug("Valeur date: " + valeurDateTrim);
			LOGGER.debug("AitCode/AitSapCode: " + reasonCode);
			LOGGER.debug("AitOnlineExtrait/AitSapExtrait: " + reason);
			LOGGER.debug("Customer number: " + customerNumber);
			LOGGER.debug("GrossBalance: " + balanceLogistic);
			LOGGER.debug("AvailableBalance: " + balanceAvailable);
			LOGGER.debug("CurrentTimestamp: " + timestampCurrentFormatted);
		}
		
		exchange.setProperty("AccountNumber", accountNumber);
		exchange.setProperty("UTCPostingTimestamp", timestampUTCFormatted);
		exchange.setProperty("RealBranchNumber", ufeRealBranch);
		exchange.setProperty("CbsProductCode", productId);
		exchange.setProperty("Amount", depositAmount); 
		exchange.setProperty("ValeurDate", valeurDateTrim);
		exchange.setProperty("AitCode", reasonCode);
		exchange.setProperty("AitSapCode", reasonCode);
		exchange.setProperty("AitOnlineExtrait", reason);
		exchange.setProperty("AitSapExtrait", reason);
		exchange.setProperty("CustomerID", customerNumber);
		exchange.setProperty("GrossBalance", balanceLogistic);
		exchange.setProperty("AvailableBalance", balanceAvailable);
		exchange.setProperty("CurrentTimestamp", timestampCurrentFormatted);
		exchange.setProperty("Spaces", spacesForProperties);
		exchange.setProperty("Sign", sign);
		exchange.setProperty("FlagReversal", flagReversal);
		exchange.setProperty("ContraAccountNumber", contraAccountNumber);
		
		LOGGER.debug("#### END OF PREPARING DATA FOR EXTRAIT ####");
	}
	
	public void prepareDataForExtraitDebit(Exchange exchange) throws Exception {
		LOGGER.debug("#### START OF PREPARING DATA FOR EXTRAIT DEBIT ####");
		
		Document body = exchange.getIn().getBody(Document.class);

		String accountNumber = FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:DepositAccountNumber");		
		String timestampUTC = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse[2]/*:timestampUTC");
		String timestampUTCFormatted = timestampUTC.replace("S", ":");		
		String ufeRealBranch = FormatUtils.getValue(body, "//*:accountMultiGetResponse/*:accountRealBranch_1");
		String productId = FormatUtils.getValue(body, "//*:accountMultiGetResponse/*:productCode_1");
		String feeAmount =  FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:FeeAmount");		
		String valeurDate = FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:DepositValueDate"); 
		String valeurDateTrim = valeurDate.replace("-", "");	
		String depositTrxTypeRequest =  FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:DepositTrxType");
		String sign = depositTrxTypeRequest.equals("1") ? "1" : "2";
		
		String reasonCode = "151";
		String reason = exchange.getProperty("CreditDepositAccountByLoanAmount.DepositReasonForFeeCharge", String.class);
		String customerNumber = FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:CustomerNumber");		
		String balanceLogisticBeforeParse = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse[2]/*:balanceLogistic");
        BigDecimal balanceLogisticDecimal = FormatUtils.getDecimalFromHost(balanceLogisticBeforeParse, 16);
        String balanceLogisticSign = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse[2]/*:balanceLogisticSign");
        String balanceLogistic = balanceLogisticSign.equals("-") ? balanceLogisticSign + String.valueOf(balanceLogisticDecimal) : String.valueOf(balanceLogisticDecimal);
        String balanceAvailableBeforeParse = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse[2]/*:balanceAvailable");
		BigDecimal balanceAvailableDecimal = FormatUtils.getDecimalFromHost(balanceAvailableBeforeParse, 16);
		String balanceAvailableSign = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse[2]/*:balanceAvailableSign");
		String balanceAvailable = balanceAvailableSign.equals("-") ? balanceAvailableSign + String.valueOf(balanceAvailableDecimal) : String.valueOf(balanceAvailableDecimal);		
		String timestampCurrent = FormatUtils.getValue(body, "//*:accountDebitCreditBalanceResponse[2]/*:timestampCurrent");
		String timestampCurrentFormatted = timestampCurrent.replace("S", ":");	
		String spacesForProperties = "      ";  
		String contraAccountNumber =  FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:LoanAccountNumber");
		String flagReversal = depositTrxTypeRequest.equals("1") ? "0" : "1";
		
		if(LOGGER.isDebugEnabled()){
			
			LOGGER.debug("Account number: " + accountNumber);
			LOGGER.debug("UTCPostingTimestamp: " + timestampUTC);
			LOGGER.debug("RealBranchNumber: " + ufeRealBranch);
			LOGGER.debug("CbsProductCode: " + productId);
			LOGGER.debug("Fee amount: " + feeAmount);
			LOGGER.debug("Valeur date: " + valeurDateTrim);
			LOGGER.debug("AitCode/AitSapCode: " + reasonCode);
			LOGGER.debug("AitOnlineExtrait/AitSapExtrait: " + reason);
			LOGGER.debug("Customer number: " + customerNumber);
			LOGGER.debug("GrossBalance: " + balanceLogistic);
			LOGGER.debug("AvailableBalance: " + balanceAvailable);
			LOGGER.debug("CurrentTimestamp: " + timestampCurrentFormatted);
		}
		
		exchange.setProperty("AccountNumber2", accountNumber);
		exchange.setProperty("UTCPostingTimestamp2", timestampUTCFormatted);
		exchange.setProperty("RealBranchNumber2", ufeRealBranch);
		exchange.setProperty("CbsProductCode2", productId);
		exchange.setProperty("Amount2", feeAmount); 
		exchange.setProperty("ValeurDate2", valeurDateTrim);
		exchange.setProperty("AitCode2", reasonCode);
		exchange.setProperty("AitSapCode2", reasonCode);
		exchange.setProperty("AitOnlineExtrait2", reason);
		exchange.setProperty("AitSapExtrait2", reason);
		exchange.setProperty("CustomerID2", customerNumber);
		exchange.setProperty("GrossBalance2", balanceLogistic);
		exchange.setProperty("AvailableBalance2", balanceAvailable);
		exchange.setProperty("CurrentTimestamp2", timestampCurrentFormatted);
		exchange.setProperty("Spaces", spacesForProperties);
		exchange.setProperty("Sign2", sign);
		exchange.setProperty("FlagReversal2", flagReversal);
		exchange.setProperty("ContraAccountNumber2", contraAccountNumber);
		
		LOGGER.debug("#### END OF PREPARING DATA FOR EXTRAIT DEBIT! ####");
	}
    
    public void prepareDataForAccounting(Exchange exchange) throws Exception{
		
		Document body = exchange.getIn().getBody(Document.class);
	
		String depositAccountNumber = FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:DepositAccountNumber");
		String depositAmount =  FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:DepositAmount");
		String valueDate = FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:DepositValueDate").replace("-", "");
		
		exchange.setProperty("CreditDepositAccountByLoanAmount.A00014", ACGENTCRE_ACCOUNT);
		exchange.setProperty("CreditDepositAccountByLoanAmount.A00040", depositAccountNumber);
		exchange.setProperty("CreditDepositAccountByLoanAmount.P00041", FormatUtils.getDecimalToHost(depositAmount, 13, 2));
		exchange.setProperty("CreditDepositAccountByLoanAmount.O00042", "150");
		exchange.setProperty("CreditDepositAccountByLoanAmount.O00043", "150");
		exchange.setProperty("CreditDepositAccountByLoanAmount.V00019", valueDate);
		exchange.setProperty("CreditDepositAccountByLoanAmount.V00020", valueDate);
		
	}
	
	public void prepareDataForAccountingCaseMicrolending(Exchange exchange) throws Exception{
		
		Document body = exchange.getIn().getBody(Document.class);
	
		String depositAccountNumber = FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:DepositAccountNumber");
		String feeAmount =  FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:FeeAmount");
		String valueDate = FormatUtils.getValue(body, "//*:CreditDepositAccountByLoanAmountRequestItem/*:DepositValueDate").replace("-", "");
		
		exchange.setProperty("CreditDepositAccountByLoanAmount.A00014", depositAccountNumber);
		exchange.setProperty("CreditDepositAccountByLoanAmount.A00040", ACGENTCRE_ACCOUNT);
		exchange.setProperty("CreditDepositAccountByLoanAmount.P00041", FormatUtils.getDecimalToHost(feeAmount, 13, 2));
		exchange.setProperty("CreditDepositAccountByLoanAmount.O00042", "151");
		exchange.setProperty("CreditDepositAccountByLoanAmount.O00043", "151");
		exchange.setProperty("CreditDepositAccountByLoanAmount.V00019", valueDate);
		exchange.setProperty("CreditDepositAccountByLoanAmount.V00020", valueDate);
		
		
	}

}
