package gr.alpha.cbs.fuse.transactions.deposits.beans;

import gr.alpha.cbs.fuse.strategies.XsltAggregationStrategyAlpha;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import org.apache.camel.component.xslt.XsltOutput;

@Named("HoldDepositAmount-enrAccountSmallGet.xsl")
@ApplicationScoped
@RegisterForReflection
public class HoldDepositAmountAggregationStrategy extends XsltAggregationStrategyAlpha {
    public HoldDepositAmountAggregationStrategy() {
        super("gr/alpha/cbs/fuse/deposits/xslt/holdDepositAmount/enrAccountSmallGet.xsl");
        setOutput(XsltOutput.DOM);
    }
}
