package gr.alpha.cbs.fuse.transactions.deposits.validators;

import static gr.alpha.cbs.fuse.common.tools.FormatUtils.getValue;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;

import gr.alpha.cbs.fuse.common.support.TransactionConfig;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.helpers.CommonsHelper;
import gr.alpha.cbs.fuse.ifaces.ProductStudioInterface;
import gr.alpha.cbs.fuse.enums.ConstantAccountOpenActiveType;
import gr.alpha.cbs.fuse.enums.ConstantCurrencies;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import gr.alpha.cbs.fuse.enums.ConstantYesNoOption;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;

@Named("validateCreateLoanDisbursementToAccount")
@ApplicationScoped
@RegisterForReflection
public class ValidateCreateLoanDisbursementToAccount {
	
	private static final Logger LOGGER = Logger.getLogger(ValidateCreateLoanDisbursementToAccount.class);

	@Inject
	CommonsHelper commonsHelper;

	@Inject
	ProductStudioInterface productStudio;

	/**
	 * <b>Method that retrieves and puts in a Map specific Account Profile Attributes.</b><br>
	 * <b>It occurs only for elements with the below format only.</b><br>
	 * e.g. [Debit=true, Credit=true, Inquiry=true, Managerial=true]
	 * 
	 * @param String  - EventRegistry CBSRefCode attribute (retrieved from TransactionConfig.class)
	 * @param Integer - Account Profile Code retrieved form accountMultiGetResponse
	 * @param Integer - Account Product Code retrieved form accountMultiGetResponse
	 * @param Integer - CarrierID retrieved from BRMS.CarriedID
	 * @return Map<String, Boolean> - a map filled with key-value extracted from PS Tables (PRD_AccountProfile, PRD_ProductBehavior)
	 */
	
	public void checkAccountProfile (Exchange exchange) throws Exception{
		Document doc = exchange.getIn().getBody(Document.class);
		
		TransactionConfig eventRgistryConf = exchange.getProperty("configuration", TransactionConfig.class);
		
		/*Get EventRegistry Attributes */
		String eventCode = eventRgistryConf.getEventCode();

		Map<String, Integer> carrierCodes;
		carrierCodes = exchange.getProperty("brms.carrierID.getCarrierID", TreeMap.class);
		Integer carrierCode = carrierCodes.values().iterator().next();

		/*Get Product and Profile Attributes */
		int intProfile = NumberUtils.toInt(FormatUtils.getValue(doc, "//*:accountMultiGetResponse/*:accountProfile_1"));
		int intProductCode = NumberUtils.toInt(FormatUtils.getValue(doc, "//*:accountMultiGetResponse/*:productCode_1"));		
		
		HashMap<String,Boolean> map = productStudio.getAccountProfile(eventCode, intProfile, intProductCode, carrierCode);
		LOGGER.info("eventCode: " + eventCode + " accountProfile: " + intProfile + " productCode: " + intProductCode + " carrierCode: " + carrierCode);
		
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("Input eventCode : "+eventCode);
			LOGGER.debug("Input intProfile : "+intProfile);
			LOGGER.debug("Input intProductCode : "+intProductCode);
			LOGGER.debug("Input carrierID : "+carrierCode);
			LOGGER.debug("Account Profile Returned MAP : "+map);
			LOGGER.debug("Account Position -- Attribute value for Credit: "+map.get("Credit"));
		}
		
		if (map!=null){
			LOGGER.info("Can Credit? = "+ map.get("Credit"));
			LOGGER.info("Can Debit? = "+ map.get("Debit"));
			LOGGER.info("Can Inq? = "+ map.get("Inquiry"));
			LOGGER.info("Can Manage? = "+ map.get("Managerial"));
			
			if (!map.get("Credit")){
				ErrorUtils.throwCBSException(null ,  
						String.valueOf(ConstantError_Types._Functional), 
						String.valueOf(ConstantError_System_IDs._FUSE), 
						ValidateCreateLoanDisbursementToAccount.class.getCanonicalName(), 
						ConstantErrorMessages._MI_EPITREPTI_PISTOSI_LOGARIASMU,
						String.valueOf(ConstantError_Levels._Error),
						"",
						"", "");
			}
		}
	}
	
	public void step250(Exchange exchange) throws Exception{
		
		Document body = exchange.getIn().getBody(Document.class);
		
		
//		If Request.DepositAmount = null, then error #300002	
		String depositAmountFromRequest = FormatUtils.getValueOrNull(body, "//*:CreateLoanDisbursementToAccountRequestItem/*:DepositAmount", null, null, null);
		if(depositAmountFromRequest == null){
			ErrorUtils.throwCBSException(null ,  
					String.valueOf(ConstantError_Types._Functional), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					ValidateCreateLoanDisbursementToAccount.class.getCanonicalName(), 
					String.valueOf(ConstantErrorMessages._Input_validations_failed),
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
		}
		
//		If Request.DepositAmount <=0, then error #300142
		BigDecimal depositAmount = new BigDecimal(FormatUtils.getValue(body, "//*:CreateLoanDisbursementToAccountRequestItem/*:DepositAmount"));
		
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("### STEP 250 VALIDATIONS ###");
			
			LOGGER.debug("Deposit amount  :"+depositAmount);
		}
		
		if(depositAmount.compareTo(BigDecimal.ZERO) <=0){
			ErrorUtils.throwCBSException(null ,  
					String.valueOf(ConstantError_Types._Functional), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					ValidateCreateLoanDisbursementToAccount.class.getCanonicalName(), 
					String.valueOf(ConstantErrorMessages._Amount_Is_Less_Than_Minimum_Allowed),
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
		}
		
//		If Request.DepositAmount > 9.999.999.999,99 then error #300915
		BigDecimal maxDepositAmount = new BigDecimal("9999999999.99");
		
		if(depositAmount.compareTo(maxDepositAmount) > 0){
			ErrorUtils.throwCBSException(null ,  
					String.valueOf(ConstantError_Types._Functional), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					ValidateCreateLoanDisbursementToAccount.class.getCanonicalName(), 
					String.valueOf(ConstantErrorMessages._UpTo10Digits),
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
		}

		
		
//		if (cbs.common.WorkingDate -180) > Request.DepositValueDate OR if DepositValueDate > (cbs.common.WorkingDate +180), then error #NEW
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dateWorkingDate = sdf.parse(exchange.getProperty("cbs.common.workDate",String.class));
		Date dateDepositValueDate = sdf.parse(FormatUtils.getValue(body, "//*:CreateLoanDisbursementToAccountRequestItem/*:DepositValueDate"));
		long diffInMillies = Math.abs(dateDepositValueDate.getTime() - dateWorkingDate.getTime());
	    long daysDiff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
		
		if(LOGGER.isDebugEnabled()){			
			LOGGER.debug("Working Date : "+String.valueOf(dateWorkingDate));
			LOGGER.debug("Deposit Value Date : "+String.valueOf(dateDepositValueDate));
			LOGGER.debug("Days Diff :"+String.valueOf(daysDiff));
		}
		
		if(daysDiff > 180){
			ErrorUtils.throwCBSException(null ,  
					String.valueOf(ConstantError_Types._Functional), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					ValidateCreateLoanDisbursementToAccount.class.getCanonicalName(), 
					String.valueOf(ConstantErrorMessages._Valeur_dates_deviation_cannot_exceed_180_daysMW),
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
		}
	}
	
	public void step500(Exchange exchange) throws Exception{

		Document body = exchange.getIn().getBody(Document.class);
		
		
		boolean isMicrolending = exchange.getProperty("CreateLoanDisbursementToAccount.isMicrolending", Boolean.class);
		int accountCurrency = NumberUtils.toInt(FormatUtils.getValue(body, "//*:accountMultiGetResponse/*:accountCurrency_1"));
		LOGGER.debug("isMicrolending is : "+isMicrolending + "   accountCurrency is: "+ accountCurrency);
		
		if(isMicrolending && accountCurrency != ConstantCurrencies._EURO){
			ErrorUtils.throwCBSException(null ,
					String.valueOf(ConstantError_Types._Functional),
					String.valueOf(ConstantError_System_IDs._FUSE),
					ValidateCreateLoanDisbursementToAccount.class.getCanonicalName(),
					String.valueOf(ConstantErrorMessages._Invalid_Account_CurrencyMW),
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
		}
		
		
		
//		if GetProductAttributesByProductId.ProductCategoryCode <> 1 then error #300840
		
		int productCategoryCode = exchange.getProperty("productCategoryCode",Integer.class);
		
		if (productCategoryCode!=1){
			ErrorUtils.throwCBSException(null ,  
					String.valueOf(ConstantError_Types._Functional), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					ValidateCreateLoanDisbursementToAccount.class.getCanonicalName(), 
					String.valueOf(ConstantErrorMessages._Unacceptable_productMW),
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
		}
		
		//Check account status

		String closedInactiveFlag = getValue(body, "//*:accountMultiGetResponse/*:openClosedIndicator_1");
		String activeFlag = getValue(body, "//*:accountMultiGetResponse/*:activeFlag_1");	

		int combinedAccountstatus = NumberUtils.toInt(commonsHelper.combineAccountStatusActiveAndAccountStatusOpenClose(activeFlag,closedInactiveFlag,true));
		
		
		Map<Integer,String> matchAccountStatusToErrorMessageMap = new HashMap<Integer,String>();
		matchAccountStatusToErrorMessageMap.put(ConstantAccountOpenActiveType._ACCOUNT_CLOSED_BY_ACCOUNTING_TXON, String.valueOf(ConstantErrorMessages._AccountHasBeenSettled));
		matchAccountStatusToErrorMessageMap.put(ConstantAccountOpenActiveType._ACCOUNT_CLOSED_BY_CAM_TXON, String.valueOf(ConstantErrorMessages._ClosedAccount));
		matchAccountStatusToErrorMessageMap.put(ConstantAccountOpenActiveType._DORMANT_ACCOUNT, String.valueOf(ConstantErrorMessages._No_Transaction_Can_Be_Performed_On_Account));
		matchAccountStatusToErrorMessageMap.put(ConstantAccountOpenActiveType._ACCOUNT_BLOCKED_FOR_TRANSACTIONS, String.valueOf(ConstantErrorMessages._Account_Blocked_For_Transactions));
		matchAccountStatusToErrorMessageMap.put(ConstantAccountOpenActiveType._ACCOUNT_DOES_NOT_EXIST, String.valueOf(ConstantErrorMessages._Account_Not_Found));
		
		
		if(matchAccountStatusToErrorMessageMap.containsKey(combinedAccountstatus)){
			ErrorUtils.throwCBSException(null ,  
					String.valueOf(ConstantError_Types._Functional), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					ValidateCreateLoanDisbursementToAccount.class.getCanonicalName(), 
					matchAccountStatusToErrorMessageMap.get(combinedAccountstatus),
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
		}
		
		//below validations only in case of microlending
		if(isMicrolending){
	//		if Request.CustomerNumber <> NULL and Request.CustomerNumber NOT in beneficiary list  L-ACCMULGET-OUT-CUSTNUM[ALL] then error #300852 
			
			String customerNumberFromRequest =  StringUtils.leftPad(FormatUtils.getValue(body, "//*:CreateLoanDisbursementToAccountRequestItem/*:CustomerNumber"),10,'0');
	
			
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("Customer Number from request is : "+customerNumberFromRequest);
			}
			
			int numberOfBeneficiaries = NumberUtils.toInt(FormatUtils.getValue(body, "//*:accountMultiGetResponse/*:membersCount_1"));
			boolean customerFound = false;
			int customerIndex = 1;
			String beneficiaryCustomerNumber = "";
			
			while(!customerFound && customerIndex<=numberOfBeneficiaries){
				beneficiaryCustomerNumber = FormatUtils.getValue(body, "//*:accountMultiGetResponse/*:customerNumber_1_" + customerIndex);
				if(LOGGER.isDebugEnabled()){				
					LOGGER.debug("Customer Number of beneficiary "+String.valueOf(customerIndex)+" is : "+String.valueOf(beneficiaryCustomerNumber));
				}
				customerIndex++;
				if(beneficiaryCustomerNumber.equals(customerNumberFromRequest)){
					customerFound = true;
				}
			}
			
			if(!"0000000000".equals(customerNumberFromRequest) && !customerFound){
				ErrorUtils.throwCBSException(null ,  
						String.valueOf(ConstantError_Types._Functional), 
						String.valueOf(ConstantError_System_IDs._FUSE), 
						ValidateCreateLoanDisbursementToAccount.class.getCanonicalName(), 
						String.valueOf(ConstantErrorMessages._O_KATATHETIS_DEN_EINAI_PLEON_DIKAIUXOS_TU_LOGARIASMUMW),
						String.valueOf(ConstantError_Levels._Error),
						"", "", "");
			}
		}
			
		//if L-ACCKTSXCHCK-OUT-IND = 1 #300804
		String hasConfisciation = getValue(body, "//*:accountConfiscationCheckResponse/*:isInvolved");
		LOGGER.debug("Account has confisciation: " + hasConfisciation);
		if(ConstantYesNoOption._Yes == NumberUtils.toInt(hasConfisciation)){
			ErrorUtils.throwCBSException(null ,  
					String.valueOf(ConstantError_Types._Functional), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					ValidateCreateLoanDisbursementToAccount.class.getCanonicalName(), 
					String.valueOf(ConstantErrorMessages._Account_In_Special_Block_Condition),
					String.valueOf(ConstantError_Levels._Error),
					"", "", "");
		}
		
		
	}
	public void step320(Exchange exchange) throws Exception{

		Document body = exchange.getIn().getBody(Document.class);
		
		
		int blockedFlag = NumberUtils.toInt(FormatUtils.getValue(body, "//*:accountMultiGetResponse/*:blockedFlag_1"));
		int seizureFlag = NumberUtils.toInt(FormatUtils.getValue(body, "//*:accountMultiGetResponse/*:seizureFlag_1"));
		LOGGER.debug("blockedFlag is : "+blockedFlag + "   seizureFlag is: "+ seizureFlag);
		
		if(blockedFlag == 2){
			ErrorUtils.throwCBSException(null ,
					String.valueOf(ConstantError_Types._Functional),
					String.valueOf(ConstantError_System_IDs._FUSE),
					ValidateCreateLoanDisbursementToAccount.class.getCanonicalName(),
					String.valueOf(ConstantErrorMessages._Account_Totally_Blocked),
					String.valueOf(ConstantError_Levels._Error),
					"Account Totally Blocked", "", "");
		}
		if(seizureFlag == 1){
			ErrorUtils.throwCBSException(null ,
					String.valueOf(ConstantError_Types._Functional),
					String.valueOf(ConstantError_System_IDs._FUSE),
					ValidateCreateLoanDisbursementToAccount.class.getCanonicalName(),
					String.valueOf(ConstantErrorMessages._Account_In_Special_Block_Condition),
					String.valueOf(ConstantError_Levels._Error),
					"Account in Special Block Condition", "", "");
		}
		 
		
		
	}
	

}
