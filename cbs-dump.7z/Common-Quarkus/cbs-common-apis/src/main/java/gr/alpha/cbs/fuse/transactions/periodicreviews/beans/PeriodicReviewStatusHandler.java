package gr.alpha.cbs.fuse.transactions.periodicreviews.beans;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import gr.alpha.cbs.fuse.enums.ConstantBranches;
import gr.alpha.cbs.fuse.enums.ConstantSegmentation;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.jboss.logging.Logger;

import gr.alpha.cbs.fuse.enums.ConstantSironEventsForBusinessReassessments;

@SuppressWarnings("unchecked")
@Named("periodicReviewStatusHandler")
@ApplicationScoped
@RegisterForReflection
public class PeriodicReviewStatusHandler {

    private static final Logger LOGGER = Logger.getLogger(PeriodicReviewStatusHandler.class);
    private static final String PRD_DATE_TIME_PATTERN = "yyyy-MM-dd HH:mm:ss.SSS";
    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern(PRD_DATE_TIME_PATTERN);


    public List<String> collectCaseIDsReadyForAssessment(Exchange exchange) {

        List<Map<String, Object>> casesList = exchange.getProperty("getPeriodicReviewsReadyForAssessmentResultList", List.class);

        return casesList.stream().map(l -> (String) l.get("CaseID")).collect(Collectors.toList());
    }


    public void processCases(Exchange exchange){

        //Filter out expired events from getSironEventsForCaseIDsReadyForAssessmentResultList
        filterOutExpiredEvents(exchange);

        //Group events by event code
        groupSironEventsByEventCodeByCaseID(exchange);

        //Sort each group by date
        sortEventGroups(exchange);

        //Decide if customer is eligible for business reassessment
        getCriticalEventsByCaseID(exchange);

    }

    private void filterOutExpiredEvents(Exchange exchange){

        LocalDateTime minValidDate = LocalDateTime.now().minusYears(1);
        List<Map<String, Object>> sironEventsForBussinessReassessmentByCaseID = exchange.getProperty("getSironEventsForCaseIDsReadyForAssessmentResultList", List.class);

        sironEventsForBussinessReassessmentByCaseID = sironEventsForBussinessReassessmentByCaseID.stream()
                .filter(e -> LocalDateTime.parse(padDateTimeWithTrailingZeroes(e.get("CreationDate").toString()), formatter).compareTo(minValidDate) >= 0)
                .collect(Collectors.toList());

        exchange.setProperty("getSironEventsForCaseIDsReadyForAssessmentResultList", sironEventsForBussinessReassessmentByCaseID);
    }

    /*
     * This method groups the Siron Events by Event code and by CaseID.
     * It transforms the List of SironEventsForBussinessReassessment
     * into
     * Map with (K, V) = (CaseID, (EventCode, list of siron events))
     * */
    private void groupSironEventsByEventCodeByCaseID(Exchange exchange) {

        List<Map<String, Object>> sironEventsForBussinessReassessmentByCaseID = exchange.getProperty("getSironEventsForCaseIDsReadyForAssessmentResultList", List.class);

        Map<String, Map<String, List<Map<String, Object>>>> sironEventsByEventCodeByCaseID = new HashMap<>();

        for(Map<String, Object> sironEvent : sironEventsForBussinessReassessmentByCaseID) {

            String caseID = sironEvent.get("CaseID").toString();
            String eventCode = sironEvent.get("EventCode").toString();

            if(sironEventsByEventCodeByCaseID.containsKey(caseID)) {

                Map<String, List<Map<String, Object>>> caseIDEntry = sironEventsByEventCodeByCaseID.get(caseID);

                if(caseIDEntry.containsKey(eventCode)) {
                    caseIDEntry.get(eventCode).add(sironEvent);
                } else {
                    List<Map<String, Object>> n = new ArrayList<>();
                    n.add(sironEvent);
                    caseIDEntry.put(eventCode, n);
                }

            } else {
                Map<String, List<Map<String, Object>>> m = new HashMap<>();
                List<Map<String, Object>> n = new ArrayList<>();
                n.add(sironEvent);
                m.put(eventCode, n);
                sironEventsByEventCodeByCaseID.put(caseID, m);
            }
        }

        exchange.setProperty("cbs.CST_DB.Response.SironEventsByEventCodeByCaseID", sironEventsByEventCodeByCaseID);
    }

    private void sortEventGroups(Exchange exchange) {

        Map<String, Map<String, List<Map<String, Object>>>> sironEventsByEventCodeByCaseID = exchange.getProperty("cbs.CST_DB.Response.SironEventsByEventCodeByCaseID", Map.class);

        //Sort each group of Events by date ascending order

        for(Map.Entry<String, Map<String, List<Map<String, Object>>>> caseIDEntry : sironEventsByEventCodeByCaseID.entrySet()) {

            for(Map.Entry<String,List<Map<String, Object>>> eventCodeEntry : caseIDEntry.getValue().entrySet()) {
                eventCodeEntry.getValue().sort((e1, e2) -> LocalDateTime.parse(padDateTimeWithTrailingZeroes(e1.get("CreationDate").toString()), formatter).compareTo(LocalDateTime.parse(padDateTimeWithTrailingZeroes(e2.get("CreationDate").toString()), formatter)));
            }
        }

        exchange.setProperty("cbs.CST_DB.Response.SironEventsByEventCodeByCaseID", sironEventsByEventCodeByCaseID);
    }

    /*
     * For each CaseID, go through the events grouped by event code in order to decide whether there is a critical event.
     * If there is a critical event in any event code group, then the corresponding customer number is eligible for business reassessment.
     * This method sets up the processed results into a
     * Map with (K, V) = (CaseID, (eventCode, the critical eventID))
     * */
    private void getCriticalEventsByCaseID(Exchange exchange) {

        Map<String, Map<String, List<Map<String, Object>>>> sironEventsByEventCodeByCaseID = exchange.getProperty("cbs.CST_DB.Response.SironEventsByEventCodeByCaseID", Map.class);

        Map<String, Map<String, String>> criticalEventsByEventCodeByCaseID = new HashMap<>();

        for(Map.Entry<String, Map<String, List<Map<String, Object>>>> caseIDEntry : sironEventsByEventCodeByCaseID.entrySet()) {

            String caseID = caseIDEntry.getKey();
            Map<String, String> results = new HashMap<>();

            for(Map.Entry<String, List<Map<String, Object>>> eventCodeEntry : caseIDEntry.getValue().entrySet()) {

                List<Map<String, Object>> eventList = eventCodeEntry.getValue();

                //Handle event codes 1, 2, 3
                if(!eventCodeEntry.getKey().equals(String.valueOf(ConstantSironEventsForBusinessReassessments._Alert_have_been_activated_for_the_customer_within_the_last_year_regarding_his_trading_activity))
                        && !eventCodeEntry.getKey().equals(String.valueOf(ConstantSironEventsForBusinessReassessments._XEIROKINITI_ENTAKSI_PELATON_STIN_PERIMETRO))){

                    String finalLevelFrom = "";
                    String finalLevelTo = "";

                    //Get first and last event in the sorted events list

                    finalLevelFrom = eventList.get(0).get("LevelFrom").toString();
                    finalLevelTo = eventList.get(eventList.size()-1).get("LevelTo").toString();

                    if(NumberUtils.toInt(finalLevelFrom) < NumberUtils.toInt(finalLevelTo)) {
                        results.put(eventCodeEntry.getKey(), eventList.get(eventList.size()-1).get("EventID").toString());
                    }

                } else {

                    //Handle event code 4,5
                    //If there is at least one event with code 4 then consider the event critical
                    //If there is at least one event with code 5 then consider the event critical
                    results.put(eventCodeEntry.getKey(), eventList.get(eventList.size()-1).get("EventID").toString());
                }
            }

            LOGGER.debug("Finished processing events for CaseID '" + caseID + "'. Critical (most recent) EventIDs per Event Code: " + results);
            criticalEventsByEventCodeByCaseID.put(caseID, results);
        }

        LOGGER.debug("Critical Siron Events for BR per CaseID: " + criticalEventsByEventCodeByCaseID);
        exchange.setProperty("cbs.CST_DB.Response.criticalEvents", criticalEventsByEventCodeByCaseID);
    }

    public void prepareStartManualReassessmentData(Exchange exchange) {

        List<String> casesForBusinessReassessmentList = exchange.getProperty("caseIDsToStartManualReassessment", List.class);
        List<Map<String, String>> getPeriodicReviewsReadyForAssessmentResultList = exchange.getProperty("getPeriodicReviewsReadyForAssessmentResultList", List.class);

        List<Map<String, String>> manualReassessmentData = new ArrayList<>();
        String todayBasicISO = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);

        for(String caseID : casesForBusinessReassessmentList){
            Map<String, String> m = new HashMap<>();
            Map<String, String> caseDetails = getPeriodicReviewsReadyForAssessmentResultList.stream().filter(e -> e.get("CaseID").equals(caseID)).findFirst().orElseGet(() -> null);
            m.put("CaseID", caseDetails.get("CaseID"));
            m.put("BusinessReassessmentID", todayBasicISO.concat(caseDetails.get("CustomerNumber")));
            m.put("isShippingCustomer", String.valueOf(isShippingCustomer(caseDetails.get("SegmentationID"), caseDetails.get("CRMBranch"))).toLowerCase());
            manualReassessmentData.add(m);
        }

        LOGGER.debug("Manual Reassessment Data: " + manualReassessmentData);
        exchange.setProperty("manualReassessmentData", manualReassessmentData);

    }

    public List<String> collectCaseIDsToStartManualReassessment(Exchange exchange){

        Map<String, Map<String, String>> criticalEventsByEventCodeByCaseID = exchange.getProperty("cbs.CST_DB.Response.criticalEvents", Map.class);

        List<String> casesForBusinessReassessmentList = criticalEventsByEventCodeByCaseID.entrySet().stream()
                .filter(e -> !e.getValue().isEmpty())
                .map(l -> l.getKey())
                .collect(Collectors.toList());

        LOGGER.info("Cases with critical Events: " + casesForBusinessReassessmentList);
        return casesForBusinessReassessmentList;
    }


    public List<String> collectCaseIDsToCloseAutomatically(Exchange exchange){

        Map<String, Map<String, String>> criticalEventsByEventCodeByCaseID = Optional.ofNullable(exchange.getProperty("cbs.CST_DB.Response.criticalEvents", Map.class)).orElse(new HashMap<>());

        // Go to status '4' = Close Automatically
        // If CaseID is not contained in the criticalEventsByCustomerNumberByEventCode, meaning that it has no events at all OR
        // If CaseID is contained in the criticalEventsByCustomerNumberByEventCode by holds an empty critical events map, meaning he has events but they are not critical
        List<Map<String, Object>> casesList = exchange.getProperty("getPeriodicReviewsReadyForAssessmentResultList", List.class);

        List<String> casesToCloseAutomatically = casesList.stream()
                .filter(e -> !criticalEventsByEventCodeByCaseID.containsKey(e.get("CaseID")) ? !criticalEventsByEventCodeByCaseID.containsKey(e.get("CaseID")) : criticalEventsByEventCodeByCaseID.get(e.get("CaseID")) != null && criticalEventsByEventCodeByCaseID.get(e.get("CaseID")).isEmpty() )
                .map(l -> (String) l.get("CaseID"))
                .collect(Collectors.toList());

        LOGGER.info("List of Periodic Review Cases to close Automatically: "+ casesToCloseAutomatically);
        return casesToCloseAutomatically;
    }

    private String padDateTimeWithTrailingZeroes(String sqlDate) {
        return StringUtils.rightPad(sqlDate, 23, "0");
    }

    public int listenerLoopCount(Exchange exchange) throws Exception{

        Double casesReadyForAssessment = exchange.getProperty("getCountOfPeriodicReviewsReadyForAssessmentResult", Double.class);
        Double listenerTop = NumberUtils.toDouble(exchange.getContext().resolvePropertyPlaceholders("{{cst.listener.top.results}}"));

        return ((Double)(casesReadyForAssessment/listenerTop)).intValue()+1;
    }

    public static boolean isShippingCustomer(String segmentation, String crmBranch){

        return segmentation.equals(String.valueOf(ConstantSegmentation._Shipping_Branch_Customers)) ||
                (segmentation.equals(String.valueOf(ConstantSegmentation._Retail_Customers)) && crmBranch.equals(String.valueOf(ConstantBranches._NAYTILIAKO))) ||
                (StringUtils.isEmpty(segmentation) && crmBranch.equals(String.valueOf(ConstantBranches._NAYTILIAKO)));

    }
}