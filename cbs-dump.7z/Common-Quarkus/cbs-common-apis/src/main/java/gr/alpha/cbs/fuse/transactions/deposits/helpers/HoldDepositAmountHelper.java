package gr.alpha.cbs.fuse.transactions.deposits.helpers;

import java.math.BigDecimal;
import java.util.HashMap;

import javax.naming.Context;
import javax.naming.InitialContext;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;

import gr.alpha.cbs.fuse.ifaces.MasterDataInterface;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;

@Named("holdDepositAmountHelper")
@Dependent
@RegisterForReflection
public class HoldDepositAmountHelper {

	@Inject
	MasterDataInterface masterStudio;

	private static final Logger LOGGER = Logger.getLogger(HoldDepositAmountHelper.class);
	
	public void prepareDataForExtrait(Exchange exchange) throws Exception {
		LOGGER.debug("#### START OF PREPARING DATA FOR EXTRAIT ####"); 
		
		Document body = exchange.getIn().getBody(Document.class);

		String accountNumber = FormatUtils.getValue(body, "//*:HoldDepositAmountRequestItem/*:DepositAccountNumber");		
		String timestampUTC = FormatUtils.getValue(body, "//*:accountBlockCreateResponse/*:timestampUTC");
		String timestampUTCFormatted = timestampUTC.replace("S", ":");	
		String ufeRealBranch = "0";
		String productId = "0";
		String amount =  FormatUtils.getValue(body, "//*:HoldDepositAmountRequestItem/*:HoldAmount");	
		String valeurDate = FormatUtils.getValue(body, "//*:HoldDepositAmountRequestItem/*:StartDateOS2200");	
		String reasonCode0 = FormatUtils.getValue(body, "//*:HoldDepositAmountRequestItem/*:HoldCode"); 
		Integer reasonCodeInt = Integer.parseInt(reasonCode0) + 10000;
		String reasonCode = String.valueOf(reasonCodeInt);

		HashMap<String,String> map = masterStudio.getMasterDetailsByItemNameLists("BlockingTypes", reasonCode0);
		
		String description = "" ;
				
		if (map!=null && !map.isEmpty() && map.containsKey("Description") && !map.get("Description").isEmpty() ){
			description = map.get("Description");			
		}
		String reasonExtrait= "      ";
		if(description!=null && !description.equals("")){
			reasonExtrait = description;	
		}
		
		String customerNumber = "0000000000";
		String balanceLogisticBeforeParse = FormatUtils.getValue(body, "//*:accountBlockCreateResponse/*:balanceLogistic");
        BigDecimal balanceLogisticDecimal = FormatUtils.getDecimalFromHost(balanceLogisticBeforeParse, 16);
        String balanceLogisticSign = FormatUtils.getValue(body, "//*:accountBlockCreateResponse/*:balanceLogisticSign");
        String balanceLogistic = balanceLogisticSign.equals("-") ? balanceLogisticSign + String.valueOf(balanceLogisticDecimal) : String.valueOf(balanceLogisticDecimal);
        String balanceAvailableBeforeParse = FormatUtils.getValue(body, "//*:accountBlockCreateResponse/*:balanceAvailable");
		BigDecimal balanceAvailableDecimal = FormatUtils.getDecimalFromHost(balanceAvailableBeforeParse, 16);
		String balanceAvailableSign = FormatUtils.getValue(body, "//*:accountBlockCreateResponse/*:balanceAvailableSign");
		String balanceAvailable = balanceAvailableSign.equals("-") ? balanceAvailableSign + String.valueOf(balanceAvailableDecimal) : String.valueOf(balanceAvailableDecimal);
		String timestampCurrent = FormatUtils.getValue(body, "//*:accountBlockCreateResponse/*:timestampCurrent");
		String timestampCurrentFormatted = timestampCurrent.replace("S", ":");
		
		
		String spacesForProperties = "      "; 
		
		if(LOGGER.isDebugEnabled()){
			
		LOGGER.debug("Account number: " + accountNumber);
		LOGGER.debug("UTCPostingTimestamp: " + timestampUTC);
		LOGGER.debug("RealBranchNumber: " + ufeRealBranch);
		LOGGER.debug("CbsProductCode: " + productId);
		LOGGER.debug("Deposit amount: " + amount);
		LOGGER.debug("Valeur date: " + valeurDate);
		LOGGER.debug("AitCode/AitSapCode: " + reasonCode);
		LOGGER.debug("AitOnlineExtrait/AitSapExtrait: " + reasonExtrait);
		LOGGER.debug("Customer number: " + customerNumber);
		LOGGER.debug("GrossBalance: " + balanceLogistic);
		LOGGER.debug("AvailableBalance: " + balanceAvailable);
		LOGGER.debug("CurrentTimestamp: " + timestampCurrent);


		}
		
		

		exchange.setProperty("AccountNumber", accountNumber);
		exchange.setProperty("UTCPostingTimestamp", timestampUTCFormatted);
		exchange.setProperty("RealBranchNumber", ufeRealBranch);
		exchange.setProperty("CbsProductCode", productId);
		exchange.setProperty("Amount", amount); 
		exchange.setProperty("ValeurDate", valeurDate);
		exchange.setProperty("AitCode", reasonCode);
		exchange.setProperty("AitSapCode", reasonCode);
		exchange.setProperty("AitOnlineExtrait", reasonExtrait);
		exchange.setProperty("AitSapExtrait", reasonExtrait);
		exchange.setProperty("CustomerID", customerNumber);
		exchange.setProperty("GrossBalance", balanceLogistic);
		exchange.setProperty("AvailableBalance", balanceAvailable);
		exchange.setProperty("CurrentTimestamp", timestampCurrentFormatted);
		exchange.setProperty("Spaces", spacesForProperties);

		
		LOGGER.debug("#### END OF PREPARING DATA FOR EXTRAIT ####");
	}
	


}
