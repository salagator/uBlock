package gr.alpha.cbs.fuse.transactions;

import gr.alpha.cbs.fuse.strategies.XsltAggregationStrategyAlpha;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import org.apache.camel.component.xslt.XsltOutput;

@Named("enrichEmptyResponse.xsl")
@ApplicationScoped
@RegisterForReflection
public class EnrichEmptyResponse extends XsltAggregationStrategyAlpha {
    public EnrichEmptyResponse() {
        super("gr/alpha/cbs/fuse/xslt/enrichEmptyResponse.xsl");
        setOutput(XsltOutput.DOM);
    }
}
