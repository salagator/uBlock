package gr.alpha.cbs.fuse.transactions.deposits.validators;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.math.NumberUtils;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;

import gr.alpha.cbs.fuse.common.support.TransactionConfig;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.ifaces.ProductStudioInterface;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;

@Named("validateStoreDepositDonatorDetails")
@Dependent
@RegisterForReflection
public class ValidateStoreDepositDonatorDetails {

	@Inject
	ProductStudioInterface productStudio;

	private static final Logger LOGGER = Logger.getLogger(ValidateStoreDepositDonatorDetails.class);
	
	/**
	 * <b>Method that retrieves and puts in a Map specific Account Profile Attributes.</b><br>
	 * <b>It occurs only for elements with the below format only.</b><br>
	 * e.g. [Debit=true, Credit=true, Inquiry=true, Managerial=true]
	 * 
	 * @param String  - EventRegistry CBSRefCode attribute (retrieved from TransactionConfig.class)
	 * @param Integer - Account Profile Code retrieved form accountMultiGetResponse
	 * @param Integer - Account Product Code retrieved form accountMultiGetResponse
	 * @param Integer - CarrierID retrieved from BRMS.CarriedID
	 * @return Map<String, Boolean> - a map filled with key-value extracted by journal xml
	 */
	public void checkAccountProfile (Exchange exchange) throws Exception{
		Document doc = exchange.getIn().getBody(Document.class);
		TransactionConfig eventRgistryConf =	exchange.getProperty("configuration", TransactionConfig.class);
		
		/*Get EventRegistry Attributes */
		String eventCode = eventRgistryConf.getEventCode();
		
		Map<String, Integer> carrierCodes;
		carrierCodes = exchange.getProperty("brms.carrierID.getCarrierID", TreeMap.class);
		Integer carrierCode = carrierCodes.values().iterator().next();

		/*Get Product and Profile Attributes */
		int intProfile = NumberUtils.toInt(FormatUtils.getValue(doc, "//*:accountMultiGetResponse/*:accountProfile_1"));
		int intProductCode = NumberUtils.toInt(FormatUtils.getValue(doc, "//*:accountMultiGetResponse/*:productCode_1"));		
		
		HashMap<String,Boolean> map = productStudio.getAccountProfile(eventCode, intProfile, intProductCode, carrierCode);
		
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("Input eventCode : "+eventCode);
			LOGGER.debug("Input intProfile : "+intProfile);
			LOGGER.debug("Input intProductCode : "+intProductCode);
			LOGGER.debug("Input carrierID : "+carrierCode);
			LOGGER.debug("Account Profile Returned MAP : "+map);
			LOGGER.debug("Account Position -- Attribute value: "+map.get("Managerial"));
		}
		
		if (!map.get("Managerial")){
			ErrorUtils.throwCBSException(null ,  
					String.valueOf(ConstantError_Types._Functional), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					ValidateStoreDepositDonatorDetails.class.getCanonicalName(), 
					ConstantErrorMessages._MI_EPITREPTI_DIAXEIRISI_LOGARIASMU,
					String.valueOf(ConstantError_Levels._Error),
					"",
					"", "");
		}
	}
}
