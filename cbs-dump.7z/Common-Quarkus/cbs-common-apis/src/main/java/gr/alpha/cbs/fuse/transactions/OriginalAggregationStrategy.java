package gr.alpha.cbs.fuse.transactions;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import org.apache.camel.processor.aggregate.UseOriginalAggregationStrategy;

@Named("originalAggregationStrategy")
@ApplicationScoped
@RegisterForReflection
public class OriginalAggregationStrategy extends UseOriginalAggregationStrategy {
}
