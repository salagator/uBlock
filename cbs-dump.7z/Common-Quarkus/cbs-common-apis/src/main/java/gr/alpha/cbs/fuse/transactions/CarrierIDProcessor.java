package gr.alpha.cbs.fuse.transactions;

import gr.alpha.cbs.brms.CarrierIDUnit;
import gr.alpha.cbs.brms.model.CarrierID;
import gr.alpha.cbs.brms.model.ResultCarrierID;
import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.common.ifaces.RefDataTranslator;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.drools.ruleunits.api.RuleUnit;
import org.drools.ruleunits.api.RuleUnitInstance;
import org.drools.ruleunits.api.RuleUnitProvider;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;

import java.util.*;

@Named("rulesCarrierID")
@ApplicationScoped
@RegisterForReflection
public class CarrierIDProcessor implements Processor {
	
	private static final Logger LOGGER = Logger.getLogger(CarrierIDProcessor.class);

	@Inject
	RefDataTranslator translator;

	@Override
	public void process(Exchange exchange) throws Exception{
		Document doc = exchange.getIn().getBody(Document.class);
		String ruleID = exchange.getProperty("ruleID",String.class);

		int numOfIterration = 0;
		String flowName = exchange.getProperty(CBSConstants.HEADER_TRANSACTION_FLOW, String.class);
		
		if (exchange.getProperty("cbs.fuse.cards.numOfAccountNumbers") instanceof Integer){
			numOfIterration = exchange.getProperty("cbs.fuse.cards.numOfAccountNumbers", Integer.class);
		}
		
		LOGGER.info("Executing Route-To CarrierID Rules with ruleID :" + ruleID);

		/** prepares the Data For different cases */
		Map<String, Integer> carrierCodesIndex = new TreeMap<>();

		CarrierIDUnit carrierIDUnit = new CarrierIDUnit();
		RuleUnitInstance<CarrierIDUnit> instance = RuleUnitProvider.Factory.get()
				.createRuleUnitInstance(carrierIDUnit);
		try {

			for (int i = 1; i <= numOfIterration+1; i++) {
				CarrierID carrierID = prepareRuleInfo(exchange, doc, flowName, i);
				carrierIDUnit.getCarrierIDs().add(carrierID);
				LOGGER.debug("carrierIDUnit.getCarrierIDs().add():" + carrierID);
			}

			List<ResultCarrierID> queryResult = instance.executeQuery("getResultCarrierID").toList("$resultCarrierID");
			if (queryResult == null || queryResult.isEmpty()) {
				ErrorUtils.throwCBSException(null ,
						ErrorTypeModel.ERROR_TYPE_TECHNICAL,
						ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
						this.getClass().getCanonicalName(),
						"300001",
						"3",
						"Τεχνικό Πρόβλημα κλήσης BRMS", "", "");
			} else {
				for (ResultCarrierID r : queryResult) {
					if (r.getCarrierID() != null) {
						carrierCodesIndex.put(r.getId(), Integer.valueOf(r.getCarrierID()));
					}
				}
			}
		} finally {
			instance.close();
		}

		exchange.setProperty("brms.carrierID.getCarrierID", carrierCodesIndex);
	}

	private CarrierID prepareRuleInfo(Exchange exchange, Document doc, String flowName, Integer ID) throws Exception {

		CarrierID carrierID = new CarrierID();
		String realBranch = null;
		String manageBranch = null;
		String transBranchUnitType = null;
		String idx = Integer.toString(ID);

		switch (flowName) {
			case "TransferAmountToDepositAccountsPayload":
			case "ReverseTransferAmountToDepositAccountsPayload":
			case "StoreDepositDonatorDetailsPayload":
			case "CancelStoreDepositDonatorDetailsPayload":
			case "AccountBlockDeletePayload":
			case "TransferAmountToDepositAccountsFCPayload":
			case "ReverseTransferAmountToDepositAccountsFCPayload":

				realBranch = FormatUtils.getValueOrNull(doc, "//*:accountRealBranch_"+ID, CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_NAME_BRANCHES, translator);
				manageBranch = FormatUtils.getValueOrNull(doc, "//*:accountManagementBranch_"+ID, CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_NAME_BRANCHES, translator);

				transBranchUnitType = FormatUtils.getValue(doc, "//*:EnvParams/*:UnitTypeCodeLevel2");

				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("accountNumber ["+ID+"]: "+FormatUtils.getValue(doc, "//*:accountMultiGetResponse/*:accountNumber_"+ID));
					LOGGER.debug("realBranch ["+ID+"]: "+realBranch);
					LOGGER.debug("manageBranch ["+ID+"]: "+manageBranch);
					LOGGER.debug("transBranchUnitGroup: "+exchange.getProperty("cbs.deposits.UnitCodes", List.class));
					LOGGER.debug("transBranchUnitType: "+transBranchUnitType);
				}
				break;

			case "CreateAccountDepositPayload":
			case "ReverseAccountDepositPayload":
			case "ReverseAccountWithdrawalPayload":
			case "ReverseAccountCashWithdrawalPayload":
			case "CreateAccountWithdrawalPayload":
			case "CreateAccountCashWithdrawalPayload":
			case "GetCreditInterestInfoPayload":
			case "CreateCreditInterestStatementPayload":
			case "SetDormantAccountPayload":
			case "UnsetDormantAccountPayload":
			case "GetDepositAccountBalancePayload":
			case "GetDepositAccountExtraitPayload":
			case "GetDepositAccountProvisionsPayload":
			case "GetDepositAccountInterestAmountsInfoPayload":
			case "CreateAccountDepositFCPayload":
			case "ReverseAccountDepositFCPayload":
			case "CreateAccountWithdrawalFCPayload":
			case "ReverseAccountWithdrawalFCPayload":
			case "CreatePaymentWebSubscriptionByAccountPayload":
			case "GetCustomerAccountTransactionsWithFiltersPayload":
			case "SetAlertDetailsPayload":
			case "CreateAlertPayload":
			case "GetAccountBlockTransactionPayload":
			case "InsertAccountBlockTransactionPayload":
			case "RecallAccountBlockTransactionPayload":
			case "CreateClaimsPaymentByAccountPayload":
			case "ReverseClaimsPaymentByAccountPayload":
			case "GetCustomerDetailedTransactionsPayload":

				realBranch = FormatUtils.getValueOrNull(doc, "/*:"+flowName+"/*:accountGetResponse/*:realBranch", CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_NAME_BRANCHES, translator);
				manageBranch = FormatUtils.getValueOrNull(doc, "/*:"+flowName+"/*:accountGetResponse/*:managementBranch", CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_NAME_BRANCHES, translator);

				transBranchUnitType = FormatUtils.getValue(doc, "//*:EnvParams/*:UnitTypeCodeLevel2");

				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("realBranch ["+ID+"]: "+realBranch);
					LOGGER.debug("manageBranch ["+ID+"]: "+manageBranch);
					LOGGER.debug("transBranchUnitGroup: "+exchange.getProperty("cbs.deposits.UnitCodes", List.class));
					LOGGER.debug("transBranchUnitType: "+transBranchUnitType);
				}
				break;

			case "AccountBlockCreatePayload":
			case "AccountBlockUpdatePayload":
			case "HoldDepositAmountPayload":
			case "AccountBlockCreateFCPayload":
			case "CreateMatchFundingDepositPayload":
			case "ReverseMatchFundingDepositPayload":
				realBranch = FormatUtils.getValueOrNull(doc, "//accountSmallGetResponse/realBranch", CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_NAME_BRANCHES, translator);
				manageBranch = FormatUtils.getValueOrNull(doc, "//accountSmallGetResponse/managementBranch", CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_NAME_BRANCHES, translator);

				transBranchUnitType = FormatUtils.getValue(doc, "//*:EnvParams/*:UnitTypeCodeLevel2");

				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("realBranch ["+ID+"]: "+realBranch);
					LOGGER.debug("manageBranch ["+ID+"]: "+manageBranch);
					LOGGER.debug("transBranchUnitGroup: "+exchange.getProperty("cbs.deposits.UnitCodes", List.class));
					LOGGER.debug("transBranchUnitType: "+transBranchUnitType);
				}
				break;

			case "GetLinkedProductsByAccountNumberPayload":
				realBranch = FormatUtils.getValueOrNull(doc, "//accountGetResponse/realBranch", CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_NAME_BRANCHES, translator);
				manageBranch = FormatUtils.getValueOrNull(doc, "//accountGetResponse/managementBranch", CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_NAME_BRANCHES, translator);
				transBranchUnitType = FormatUtils.getValue(doc, "//*:EnvParams/*:UnitTypeCodeLevel2");

				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("realBranch ["+ID+"]: "+realBranch);
					LOGGER.debug("manageBranch ["+ID+"]: "+manageBranch);
					LOGGER.debug("transBranchUnitGroup: "+exchange.getProperty("cbs.deposits.UnitCodes", List.class));
					LOGGER.debug("transBranchUnitType: "+transBranchUnitType);
				}
				break;

			case "DebitDepositAccountPayload":
				realBranch = FormatUtils.getValueOrNull(doc, "//accountMultiGetResponse/accountRealBranch_1", CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_NAME_BRANCHES, translator);
				manageBranch = FormatUtils.getValueOrNull(doc, "//accountMultiGetResponse/accountManagementBranch_1", CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_NAME_BRANCHES, translator);
				transBranchUnitType = FormatUtils.getValue(doc, "//*:EnvParams/*:UnitTypeCodeLevel2");

				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("realBranch ["+ID+"]: "+realBranch);
					LOGGER.debug("manageBranch ["+ID+"]: "+manageBranch);
					LOGGER.debug("transBranchUnitGroup: "+exchange.getProperty("cbs.deposits.UnitCodes", List.class));
					LOGGER.debug("transBranchUnitType: "+transBranchUnitType);
				}
				break;

			case "CreateLoanDisbursementToAccountPayload":
				realBranch = FormatUtils.getValueOrNull(doc, "//accountMultiGetResponse/accountRealBranch_1", CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_NAME_BRANCHES, translator);
				manageBranch = FormatUtils.getValueOrNull(doc, "//accountMultiGetResponse/accountManagementBranch_1", CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_NAME_BRANCHES, translator);
				transBranchUnitType = FormatUtils.getValue(doc, "//*:EnvParams/*:UnitTypeCodeLevel2");

				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("realBranch ["+ID+"]: "+realBranch);
					LOGGER.debug("manageBranch ["+ID+"]: "+manageBranch);
					LOGGER.debug("transBranchUnitGroup: "+exchange.getProperty("cbs.deposits.UnitCodes", List.class));
					LOGGER.debug("transBranchUnitType: "+transBranchUnitType);
				}
				break;
			case "CreateAccountAlertsPayload":
				realBranch = FormatUtils.getValueOrNull(doc, "//accountSmallGetResponse["+idx+"]/realBranch", CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_NAME_BRANCHES, translator);
				manageBranch = FormatUtils.getValueOrNull(doc, "//accountSmallGetResponse["+idx+"]/managementBranch", CBSConstants.REF_DATA_SYSTEM_OS2200, CBSConstants.REF_NAME_BRANCHES, translator);

				transBranchUnitType = FormatUtils.getValue(doc, "//*:EnvParams/*:UnitTypeCodeLevel2");

				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("accountNumber ["+ID+"]: "+FormatUtils.getValue(doc, "//accountSmallGetResponse["+idx+"]/accountNumber"));
					LOGGER.debug("realBranch ["+ID+"]: "+realBranch);
					LOGGER.debug("manageBranch ["+ID+"]: "+manageBranch);
					LOGGER.debug("transBranchUnitGroup: "+exchange.getProperty("cbs.deposits.UnitCodes", List.class));
					LOGGER.debug("transBranchUnitType: "+transBranchUnitType);
				}
				break;

		}

		carrierID.setId(idx);
		carrierID.setManagementBranch(manageBranch);
		carrierID.setRealBranch(realBranch);
		carrierID.setTransactionBranch(exchange.getProperty("cbs.common.branch", String.class));
		carrierID.setTransactionBranchUnitType(transBranchUnitType);
		carrierID.setTransactionBranchUnitGroups(exchange.getProperty("cbs.deposits.UnitCodes", List.class));

		return carrierID;
	}

}
