package gr.alpha.cbs.fuse.transactions.deposits.validators;

import java.util.*;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.math.NumberUtils;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;

import gr.alpha.cbs.fuse.common.support.TransactionConfig;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.ifaces.ProductStudioInterface;
import gr.alpha.cbs.fuse.enums.ConstantBlockingTypes;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.enums.ConstantError_Levels;
import gr.alpha.cbs.fuse.enums.ConstantError_System_IDs;
import gr.alpha.cbs.fuse.enums.ConstantError_Types;
import gr.alpha.cbs.fuse.enums.ConstantPRD_Product_Categories;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;

@Named("ValidateHoldDepositAmount")
@ApplicationScoped
@RegisterForReflection
public class ValidateHoldDepositAmount {

	@Inject
	ProductStudioInterface productStudio;
	@Inject
	ProductStudioInterface prodEjb;
	private static final Logger LOGGER = Logger.getLogger(ValidateHoldDepositAmount.class);
	
	/**
	 * <b>Method that retrieves and puts in a Map specific Account Profile Attributes.</b><br>
	 * <b>It occurs only for elements with the below format only.</b><br>
	 * e.g. [Debit=true, Credit=true, Inquiry=true, Managerial=true]
	 * 
	 * @param String  - EventRegistry CBSRefCode attribute (retrieved from TransactionConfig.class)
	 * @param Integer - Account Profile Code retrieved form accountMultiGetResponse
	 * @param Integer - Account Product Code retrieved form accountMultiGetResponse
	 * @param Integer - CarrierID retrieved from BRMS.CarriedID
	 * @return Map<String, Boolean> - a map filled with key-value extracted from PS Tables (PRD_AccountProfile, PRD_ProductBehavior)
	 */
	public void checkAccountProfile (Exchange exchange) throws Exception{
		Document doc = exchange.getIn().getBody(Document.class);
		
		TransactionConfig eventRgistryConf =	exchange.getProperty("configuration", TransactionConfig.class);
		
		/*Get EventRegistry Attributes */
		String eventCode = eventRgistryConf.getEventCode();

		Map<String, Integer> carrierCodes;
		carrierCodes = exchange.getProperty("brms.carrierID.getCarrierID", TreeMap.class);
		Integer carrierCode = carrierCodes.values().iterator().next();

		/*Get Product and Profile Attributes */
		int intProfile = NumberUtils.toInt(FormatUtils.getValue(doc, "//*:accountSmallGetResponse/*:profileCode"));
		int intProductCode = NumberUtils.toInt(FormatUtils.getValue(doc, "//*:accountSmallGetResponse/*:productCode"));
		
		HashMap<String,Boolean> map = productStudio.getAccountProfile(eventCode, intProfile, intProductCode, carrierCode);
		
		if (LOGGER.isInfoEnabled()){
			LOGGER.info("Input eventCode : "+eventCode);
			LOGGER.info("Input intProfile : "+intProfile);
			LOGGER.info("Input intProductCode : "+intProductCode);
			LOGGER.info("Input carrierID : "+ carrierCode);
			LOGGER.info("Account Profile Returned MAP : "+map);
			LOGGER.info("Account Position -- Attribute value: "+map.get("Managerial"));
		}
		
		if (!map.get("Managerial")){
			ErrorUtils.throwCBSException(null ,  
					String.valueOf(ConstantError_Types._Functional), 
					String.valueOf(ConstantError_System_IDs._FUSE), 
					this.getClass().getCanonicalName(), 
					ConstantErrorMessages._MI_EPITREPTI_KINISI__LOGARIASMU,
					String.valueOf(ConstantError_Levels._Error),
					"",
					"", "");
		}
	}
	
	public void productStudioValidations(Exchange ex) throws Exception {

		Document doc = ex.getIn().getBody(Document.class);
		
		String holdCode = FormatUtils.getValue(doc, "//*:HoldDepositAmountRequestItem/*:HoldCode");
		Integer holdCodeInt = NumberUtils.toInt(holdCode);		
		String prodVersion = FormatUtils.getValue(doc, "//*:accountSmallGetResponse/*:productVersion");
		String prodCode = FormatUtils.getValue(doc, "//*:accountSmallGetResponse/*:productCode");
		Map<String, List<String>> prdMap = prodEjb.getProductAttributeRealValuesLists(Integer.valueOf(prodCode), Integer.valueOf(prodVersion), null);
			
		if (holdCodeInt == ConstantBlockingTypes._MERIKI_GIA_XRISI_THYRIDOS){
			if (prdMap!=null && prdMap.get("ProductCategoryCode")!=null  && 
					!prdMap.get("ProductCategoryCode").contains(String.valueOf(ConstantPRD_Product_Categories._PRD_1_KATATHESEIS_PROTIS_ZITISIS))){
						ErrorUtils.throwCBSException(null, ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, this.getClass().getCanonicalName(),
								ConstantErrorMessages._Product_Transaction_Combination_Not_Allowed, ErrorTypeModel.SEVERITY_ERROR, "","","");
			}
			if (prdMap!=null && prdMap.get("509") != null && !prdMap.get("509").contains("2")){
					ErrorUtils.throwCBSException(null, ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, this.getClass().getCanonicalName(),
						ConstantErrorMessages._Product_Transaction_Combination_Not_Allowed, ErrorTypeModel.SEVERITY_ERROR, "","","");
			}
		}
		
		if (holdCodeInt == ConstantBlockingTypes._OLIKI_GIA_DANEIA_SIGLO){
			if (prdMap!=null && prdMap.get("ProductCategoryCode")!=null  && !(prdMap.get("ProductCategoryCode").contains(String.valueOf(ConstantPRD_Product_Categories._PRD_1_KATATHESEIS_PROTIS_ZITISIS)) || 
					prdMap.get("ProductCategoryCode").contains(String.valueOf(ConstantPRD_Product_Categories._PRD_2_PROTHESMIAKES_KATATHESEIS)))){
						ErrorUtils.throwCBSException(null, ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, this.getClass().getCanonicalName(),
								ConstantErrorMessages._Product_Transaction_Combination_Not_Allowed, ErrorTypeModel.SEVERITY_ERROR, "","","");
			}
		}
	
	}
	
}
