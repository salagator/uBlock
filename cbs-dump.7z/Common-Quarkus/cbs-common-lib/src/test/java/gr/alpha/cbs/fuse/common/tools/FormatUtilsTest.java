package gr.alpha.cbs.fuse.common.tools;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

import static gr.alpha.cbs.fuse.common.tools.FormatUtils.addWildcardToElementNames;
import static gr.alpha.cbs.fuse.common.tools.FormatUtils.clearNamespaceInfoFromXPath;
import static org.junit.jupiter.api.Assertions.*;

@QuarkusTest
public class FormatUtilsTest {
    private static final String hostInput="000012434804Μ11010604683   201103150000        20110321ΙΟΒΗ ΝΙΚΟΛΑΟΥ                           1641600008104000012425102ΛΑΒΕΤΑΚΗ            ΝΙΟΒΗ ΝΙΚΟΛΑΟΥ      ΝΙΟΒΗ               ΛΑΒΕΤΑΚΗ                 ΝΙΚΟΛΑΟΥ                 1978060300000000094009344           GRGRΥ777777             1 000000000300000012424801ΜΑΡΚΟΛΑΚΗΣ          ΜΑΡΚΟΣ ΑΣΗΜΑΚΗ      ΜΑΡΚΟΣ              ΜΑΡΚΟΛΑΚΗΣ               ΑΣΗΜΑΚΗ                  1985040100000000000000000           GRGRΘ907643             1 000000000300000012424902ΣΤΑΙΚΟΥΡΑ           ΜΕΡΟΠΗ ΔΗΜΟΣΘΕΝΗ    ΜΕΡΟΠΗ              ΣΤΑΙΚΟΥΡΑ                ΔΗΜΟΣΘΕΝΗ                1987010100000000094019386           GRGRΤ890234             1 000000000300000012425001ΡΑΜΕΛΙΩΤΗΣ          ΜΑΚΑΡΙΟΣ ΕΜΜΑΝΟΥΗΛ  ΜΑΚΑΡΙΟΣ            ΡΑΜΕΛΙΩΤΗΣ               ΕΜΜΑΝΟΥΗΛ                1988080700000000094005019           GRGRΡ567897             1 000000000300000012343901ΠΑΤΕΡΑΣ             DΕΜΟ ΓΕΡΑΣΙΜΟΥ      DΕΜΟ                ΠΑΤΕΡΑΣ                  ΓΕΡΑΣΙΜΟΥ                1990020100000000078632212           GRGRΞ221985             1 000000000300000012465001ΤΕΣΤΟΠΟΥΛΟΣ         ΤΕΣΤΗΣ ΤΡΕΛΟΣ       ΤΕΣΤΗΣ              ΤΕΣΤΟΠΟΥΛΟΣ              ΤΡΕΛΟΣ                   1980010100000000000000000           USUSΑ123456             1 000000000300000012469601ΤΕΣΤΟΠΟΥΛΟΣ         ΤΕΣΤΗΣ ΤΡΕΛΟΣ       ΤΕΣΤΗΣ              ΤΕΣΤΟΠΟΥΛΟΣ              ΤΡΕΛΟΣ                   1983020100000000000000000           GRGRΑΒΓ67452            6 000000000300000012383301ΑΔΕΡΦΟΣ             DΕΜΟ ΜΑΚΗ           DΕΜΟ                ΑΔΕΡΦΟΣ                  ΜΑΚΗ                     1985050400000000999569620           GRGRΑ215544             1 000000000300000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000";
    private static final String hostOutput="000012434804L11010604683   201103150000        20110321IOBG MIJOKAOV                           1641600008104000012425102KABEUAJG            MIOBG MIJOKAOV      MIOBG               KABEUAJG                 MIJOKAOV                 1978060300000000094009344           ;?;?V777777             1 000000000300000012424801LARJOKAJGS          LARJOS ASGLAJG      LARJOS              LARJOKAJGS               ASGLAJG                  1985040100000000000000000           ;?;?H907643             1 000000000300000012424902SUAIJOVRA           LEROQG DGLOSHEMG    LEROQG              SUAIJOVRA                DGLOSHEMG                1987010100000000094019386           ;?;?U890234             1 000000000300000012425001RALEKIZUGS          LAJARIOS ELLAMOVGK  LAJARIOS            RALEKIZUGS               ELLAMOVGK                1988080700000000094005019           ;?;?R567897             1 000000000300000012343901QAUERAS             &ELO CERASILOV      &ELO                QAUERAS                  CERASILOV                1990020100000000078632212           ;?;?N221985             1 000000000300000012465001UESUOQOVKOS         UESUGS UREKOS       UESUGS              UESUOQOVKOS              UREKOS                   1980010100000000000000000           #:#:A123456             1 000000000300000012469601UESUOQOVKOS         UESUGS UREKOS       UESUGS              UESUOQOVKOS              UREKOS                   1983020100000000000000000           ;?;?ABC67452            6 000000000300000012383301ADERWOS             &ELO LAJG           &ELO                ADERWOS                  LAJG                     1985050400000000999569620           ;?;?A215544             1 000000000300000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000000000000000                                                                                                              0000000000000000                                              000000000000";
    private static final String hostInputAllChars="ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΐίϊΊΪάΆέΈήΉΰϋύΫΎόΌώΏ αβγδεζηθικλμνξοπρστυφχψω abcdefghijklmnopqrstuvwxyz ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ABCDEFGHIJKLMNOPQRSTUVWXYZ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/";
    private static final String hostOutputAllChars="ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/ ΙΙΙΙΙΑΑΕΕΗΗΥΥΥΥΥΟΟΩΩ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ ΑΒCDΕFGΗΙJΚLΜΝΟΡQRSΤUVWΧΥΖ ~!@#$%^&*()_+-={}[]\\|:;\"'<,>.?/";

    @Test
    public void testToHostMultipasses() {
        String out = "";

        long startTimeOverall = System.currentTimeMillis();
        for (int i = 0; i < 5000; i++) {
            out = FormatUtils.toHostOld(FormatUtils.handleSpecialGreekCharacters(FormatUtils.translateEnglish(hostInput)).toUpperCase());
        }
        long finishTimeOverall = System.currentTimeMillis() - startTimeOverall;

        System.out.println("Total Time Multiple passes:"+finishTimeOverall);
        System.out.println("HostIn : "+hostInput);
        System.out.println("HostOut: "+out);

        assertTrue(hostOutput.equals(out));
    }

    @Test
    public void testToHostSinglepass() {
        String out = "";

        long startTimeOverall = System.currentTimeMillis();
        for (int i = 0; i < 5000; i++) {
            out = FormatUtils.toHostTranslation(hostInput);
        }
        long finishTimeOverall = System.currentTimeMillis() - startTimeOverall;

        System.out.println("Total Time Single pass:"+finishTimeOverall);
        System.out.println("HostIn : "+hostInput);
        System.out.println("HostOut: "+out);

        assertTrue(hostOutput.equals(out));
    }

    @Test
    public void testToHostMultipassesAllChars() {
        String out = "";

        long startTimeOverall = System.currentTimeMillis();
        for (int i = 0; i < 5000; i++) {
            out = FormatUtils.toHostOld(FormatUtils.handleSpecialGreekCharacters(FormatUtils.translateEnglish(hostInputAllChars)).toUpperCase());
        }
        long finishTimeOverall = System.currentTimeMillis() - startTimeOverall;

        System.out.println("Total Time Multiple passes all chars:"+finishTimeOverall);
        System.out.println("HostIn : "+hostInputAllChars);
        System.out.println("HostOut: "+FormatUtils.fromHost(out));

        assertTrue(hostOutputAllChars.equals(FormatUtils.fromHost(out)));
    }

    @Test
    public void testToHostSinglepassAllChars() {
        String out = "";

        long startTimeOverall = System.currentTimeMillis();
        for (int i = 0; i < 5000; i++) {
            out = FormatUtils.toHostTranslation(hostInputAllChars);
        }
        long finishTimeOverall = System.currentTimeMillis() - startTimeOverall;

        System.out.println("Total Time Single pass all chars:"+finishTimeOverall);
        System.out.println("HostIn : "+hostInputAllChars);
        System.out.println("HostOut: "+FormatUtils.fromHost(out));

        assertTrue(hostOutputAllChars.equals(FormatUtils.fromHost(out)));
    }

    @Test
    public void testToHostAllCharsCombined() {
        String out = "";

        long startTimeOverall = System.currentTimeMillis();
        for (int i = 0; i < 5000; i++) {
            out = FormatUtils.toHost(hostInputAllChars);
        }
        long finishTimeOverall = System.currentTimeMillis() - startTimeOverall;

        System.out.println("Total Time combined all chars:"+finishTimeOverall);
        System.out.println("HostIn : "+hostInputAllChars);
        System.out.println("HostOut: "+FormatUtils.fromHost(out));

        assertTrue(hostOutputAllChars.equals(FormatUtils.fromHost(out)));
    }

    @Test
    public void testToHostCombined() {
        String out = "";

        long startTimeOverall = System.currentTimeMillis();
        for (int i = 0; i < 5000; i++) {
            out = FormatUtils.toHost(hostInput);
        }
        long finishTimeOverall = System.currentTimeMillis() - startTimeOverall;

        System.out.println("Total Time combined:"+finishTimeOverall);
        System.out.println("HostIn : "+hostInput);
        System.out.println("HostOut: "+FormatUtils.fromHost(out));

        assertTrue(hostOutput.equals(out));
    }

    @Test
    public void testGetDateFromHostFormattedNullInput() throws Exception{
        assertThrows(Exception.class, () -> {
            String date = null;
            FormatUtils.getDateFromHostFormatted(date);
        });
    }

    @Test
    public void testGetDateFromHostFormattedEmptyStringInput() throws Exception{
        assertThrows(Exception.class, () -> {
            String date = "";
            FormatUtils.getDateFromHostFormatted(date);
        });
    }

    @Test
    public void testGetDateFromHostFormattedAlphanumericInput() throws Exception{
        assertThrows(Exception.class, () -> {
            String date = "2018ADAS";
            FormatUtils.getDateFromHostFormatted(date);
        });
    }

    @Test
    public void testGetDateFromHostFormattedZerosInput() throws Exception{
        assertThrows(Exception.class, () -> {
            String date = "00000000";
            System.out.println("Formatted date: " + FormatUtils.getDateFromHostFormatted(date));
        });
    }

    @Test
    public void testGetDateFromHostFormattedFormattedDateInput() throws Exception{
        assertThrows(Exception.class, () -> {
            String date = "2019-05-05";
            try {
                FormatUtils.getDateFromHostFormatted(date);
            } catch (Exception e) {
                System.out.println("Unparsable date" + e.getMessage());
                throw e;
            }
        });
    }

    @Test
    public void testGetDateFromHostFormattedBiggerLengthDateString() throws Exception{
        assertThrows(Exception.class, () -> {
            String date = "654658805050505";
            try {
                FormatUtils.getDateFromHostFormatted(date);
            } catch (Exception e) {
                System.out.println("Unparsable date" + e.getMessage());
                throw e;
            }
        });
    }

    @Test
    public void testGetDateFromHostFormattedValidInput1() throws Exception{
        String date = "20190505";
        System.out.println("Formatted date: " + FormatUtils.getDateFromHostFormatted(date));
    }

    @Test
    public void testGetDateFromHostFormattedValidInput2() throws Exception{
        String date = "00000505";
        System.out.println("Formatted date: " + FormatUtils.getDateFromHostFormatted(date));
    }

    @Test
    public void testClearNamespaceInfoFromXPath() throws Exception {
        // Test case 1: Basic namespace addition
        String input1 = "//Element/SubElement";
        String expected1 = "//*:Element/*:SubElement";
        assertEquals(expected1, addWildcardToElementNames(input1));

        // Test case 2: Namespace with attributes
        String input2 = "//Element/SubElement[@attr='value']";
        String expected2 = "//*:Element/*:SubElement[@attr='value']";
        assertEquals(expected2, addWildcardToElementNames(input2));

        // Test case 3: Namespace with predicates
        String input3 = "//Element/SubElement[Predicate='value']";
        String expected3 = "//*:Element/*:SubElement[Predicate='value']";
        assertEquals(expected3, addWildcardToElementNames(input3));

        // Test case 4: Literal value with colon
        String input4 = "//Element/SubElement[@time='12:00']";
        String expected4 = "//*:Element/*:SubElement[@time='12:00']";
        assertEquals(expected4, addWildcardToElementNames(input4));

        // Test case 5: Mixed namespace and no namespace
        String input5 = "//*:Element/NoNamespaceElement/*:SubElement";
        String expected5 = "//*:Element/*:NoNamespaceElement/*:SubElement";
        assertEquals(expected5, addWildcardToElementNames(input5));

        // Test case 6: Empty input
        String input6 = "";
        String expected6 = "";
        assertEquals(expected6, addWildcardToElementNames(input6));

        // Test case 7: Null input
        String input7 = null;
        String expected7 = null;
        assertEquals(expected7, addWildcardToElementNames(input7));

        // Test case 8: No namespace prefixes
        String input8 = "//Element/SubElement";
        String expected8 = "//*:Element/*:SubElement";
        assertEquals(expected8, addWildcardToElementNames(input8));

        // Test case 9: Complex XPath with multiple predicates
        String input9 = "//Root/Node[Attr1='value1' and Attr2='value2']/Leaf";
        String expected9 = "//*:Root/*:Node[Attr1='value1' and Attr2='value2']/*:Leaf";
        assertEquals(expected9, addWildcardToElementNames(input9));

        String input10 = "//TCRMPersonBObj/TCRMFinancialProfileBObj/TCRMIncomeSourceBObj[IncomeSourceType=1 and InformationObtainedDate='2008-05-29 17:28:13.239']/AnnualAmount";
        String expected10 = "//*:TCRMPersonBObj/*:TCRMFinancialProfileBObj/*:TCRMIncomeSourceBObj[IncomeSourceType=1 and InformationObtainedDate='2008-05-29 17:28:13.239']/*:AnnualAmount";
        assertEquals(expected10, addWildcardToElementNames(input10));
    }

//	@Test
//	public void testToHostAllCharsCombinedStream() {
//		String out = "";
//
//		long startTimeOverall = System.currentTimeMillis();
//		for (int i = 0; i < 5000; i++) {
//			out = FormatUtils.toHostCombinedStream(hostInputAllChars);
//		}
//		long finishTimeOverall = System.currentTimeMillis() - startTimeOverall;
//
//		System.out.println("Total Time combined stream all chars:"+finishTimeOverall);
//		System.out.println("HostIn : "+hostInputAllChars);
//		System.out.println("HostOut: "+FormatUtils.fromHost(out));
//
//		assertTrue(hostOutputAllChars.equals(FormatUtils.fromHost(out)));
//	}
//
//	@Test
//	public void testToHostCombinedStream() {
//		String out = "";
//
//		long startTimeOverall = System.currentTimeMillis();
//		for (int i = 0; i < 5000; i++) {
//			out = FormatUtils.toHostCombinedStream(hostInput);
//		}
//		long finishTimeOverall = System.currentTimeMillis() - startTimeOverall;
//
//		System.out.println("Total Time combined stream:"+finishTimeOverall);
//		System.out.println("HostIn : "+hostInput);
//		System.out.println("HostOut: "+FormatUtils.fromHost(out));
//
//		assertTrue(hostOutput.equals(out));
//	}
}
