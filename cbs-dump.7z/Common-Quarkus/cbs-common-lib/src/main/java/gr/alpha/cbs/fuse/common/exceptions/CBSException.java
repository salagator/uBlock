package gr.alpha.cbs.fuse.common.exceptions;

import io.quarkus.runtime.annotations.RegisterForReflection;

@RegisterForReflection
public class CBSException extends Exception {

	/** Serial version ID */
	private static final long serialVersionUID = 1L;
	
	private ErrorTypeModel errorModel = new ErrorTypeModel();

	public CBSException() {
		super();
	}

	public CBSException(ErrorTypeModel model) {
		super(model.getDescription());
		this.errorModel = model;
	}

	public CBSException(Throwable t, ErrorTypeModel model) {
		super(model.getDescription(),t);
		this.errorModel = model;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @return the errorModel
	 */
	public ErrorTypeModel getErrorModel() {
		return errorModel;
	}
}
