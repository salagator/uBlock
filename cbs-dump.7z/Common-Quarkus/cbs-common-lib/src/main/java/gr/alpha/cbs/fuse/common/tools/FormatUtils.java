package gr.alpha.cbs.fuse.common.tools;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.ifaces.RefDataTranslator;
import jakarta.xml.bind.DatatypeConverter;
import io.quarkus.runtime.annotations.RegisterForReflection;
import net.sf.saxon.dom.DocumentBuilderImpl;
import net.sf.saxon.s9api.Processor;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.Serializer;
import net.sf.saxon.s9api.XdmNode;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.validator.routines.checkdigit.ISINCheckDigit;
import org.eclipse.microprofile.config.ConfigProvider;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import javax.xml.XMLConstants;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.*;
import java.io.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Pattern;

@Named("formatUtils")
@ApplicationScoped
@RegisterForReflection
public class FormatUtils {
	private static final Logger LOGGER = Logger.getLogger(FormatUtils.class);
	public static final String OMIT_XML_DECLARATION_YES = "yes";
	public static final String OMIT_XML_DECLARATION_NO = "no";
	public static final String INDENT_YES = "yes";
	public static final String INDENT_NO = "no";
	public static final String METHOD_XML = "xml";

	/**
	 * <b>Method to add any number of a specified character at the end of a string.</b><br>
	 * e.g. <i>input string = "abc"</i><br>
	 * 		<i>size of final string = 5</i><br>
	 * 		<i>character to add = X</i><br>
	 *
	 * 		the resulting string is -> <b>"abcXX'</b>
	 * @param str Initial string
	 * @param size Size of resulting string
	 * @param padChar Character to append to initial string
	 * @return String with characters added at the end of the initial string
	 */
	public static String padRight(String str, int size, char padChar) {
		if (str == null)
			str = "";

		if (str.length() > size)
			return str.substring(0, size);

		StringBuilder strBuild = new StringBuilder(str);

		while (strBuild.length() < size) {
			strBuild.append(padChar);
		}

		return strBuild.toString();
	}

	/**
	 * <b>Method to add any number of a specified character at the beginning of a string.</b><br>
	 * e.g. <i>input string = "abc"</i><br>
	 * 		<i>size of final string = 5</i><br>
	 * 		<i>character to add = X</i><br>
	 *
	 * 		the resulting string is -> <b>"XXabc"</b>
	 * @param str Initial string
	 * @param size Size of resulting string
	 * @param padChar Character to put in front of the initial string
	 * @return String with characters added at the beginning of the initial string
	 */
	public static String padLeft(String str, int size, char padChar) {
		if (str == null)
			str = "";

		if (str.length() > size)
			return str.substring(0, size);

		StringBuilder strBuild = new StringBuilder(str);

		while (strBuild.length() < size) {
			strBuild.insert(0, padChar);
		}

		return strBuild.toString();
	}

	/**
	 * Transforms English characters to Greek
	 * @param in The string to convert
	 * @return Converted sring in Greek characters
	 */
	public static String EnglishToGreek(String in){
		String retValue="";
		String EnglishCharacters="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ";
		String GreekCharacters=  "ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟ/ΠΡΣ&ΤΥΦΧΨΩ0123456789 ";

		if(EnglishCharacters.length()==GreekCharacters.length()){
			for (int i = 0; i <= in.length()-1; i++) {
				int j=EnglishCharacters.indexOf(in.charAt(i));
				if(j<0){
					retValue += EnglishCharacters.charAt(i);
				}else{
					retValue += GreekCharacters.charAt(j);
				}
			}
		}
		return retValue;
	}

	/**
	 * <strong>Generates TUN code.</strong><br>
	 * Code is created based on the following formula.<br>
	 * <i>YYYY=Current year</i><br>
	 * <i>MM=Current month</i><br>
	 * <i>DD=Current day</i><br>
	 * <p>
	 * <i>((YYYY - 1900)*12+MM) concat with DD</i><br>
	 * <p>
	 * E.g <code>((2016 - 1900)*12+9) concat(28)</code> = 140128
	 * @param dt Current date
	 * @return TUN
	 */
	public static String getTUNDate(String dt){
		int yy=Integer.parseInt(dt.substring(0,4));
		int mm=Integer.parseInt(dt.substring(4,6));
		String dd=dt.substring(6,8);
		return String.valueOf((yy-1900)*12+mm)+dd;
	}

	/**
	 * <strong>Generates TUN code.</strong><br>
	 * Code is created based on the following formula.<br>
	 * <i>YYYY=Current year</i><br>
	 * <i>MM=Current month</i><br>
	 * <i>DD=Current day</i><br>
	 * <p>
	 * <i>((YYYY - 1900)*12+MM) concat with DD</i><br>
	 * <p>
	 * E.g <code>((2016 - 1900)*12+9) concat(28)</code> = 140128
	 * @param tun18 the TUN code as 18 characters
	 * @return TUN
	 */
	public static String getTUN16(String tun18){
		return getTUNDate(tun18)+tun18.substring(8);
	}

	/**
	 * Creates a string of (size) spaces
	 * @param size The total size of the string in spaces
	 * @return A string of spaces of length (size)
	 */
	public static String spaces(int size){
		return padLeft("", size, ' ');
	}

	/**
	 * This method is used to log a debug message.
	 */
	public static void logMsg(String clsName, String message) {
		String prefix = clsName;
		int lastPeriodIndex = prefix.lastIndexOf('.');
		if (lastPeriodIndex > 0) {
			prefix = prefix.substring(lastPeriodIndex + 1);
		}

	}

	/**
	 * The method replaces the module name of the dtpra message.
	 * @param payload The message to be send to the Host
	 * @param moduleName The module name that will be called.
	 * @return
	 */
	public static String changeModule(String payload, String moduleName) {
		String restMessage = payload.substring(20);
		String changedMessage = padRight(EnglishToGreek(moduleName), 20, ' ') + restMessage;

		return changedMessage;
	}

	/**
	 * Removes any special character from the host buffer.
	 * @param msg The response message of the Host.
	 * @return
	 */
	public static String cleanOutBuffer(String msg){
		//return msg.replaceAll("[\\000]*", " ");
		return msg;
	}

	private static Map<Character, Character>charMapFromHost = new HashMap<>();
	private static Map<Character, Character>charMapToHostOld = new HashMap<>();
	private static Map<Character, Character>greekToEnglishMap = new HashMap<>();
	private static Map<Character, Character>englishToGreekMap = new HashMap<>();
	private static Map<Character, Character>specialGreekCharacterMap = new HashMap<>();
	private static Map<Character, Character>charMapToHost = new HashMap<>();
	private static Set<Character> charSetToHostSpecialChar= new HashSet<Character>();

	private static void initMapFromHost(){
		charMapFromHost.put('?', 'R');
		charMapFromHost.put('A', 'Α');
		charMapFromHost.put('B', 'Β');
		charMapFromHost.put('C', 'Γ');
		charMapFromHost.put('D', 'Δ');
		charMapFromHost.put('E', 'Ε');
		charMapFromHost.put('F', 'Ζ');
		charMapFromHost.put('G', 'Η');
		charMapFromHost.put('H', 'Θ');
		charMapFromHost.put('I', 'Ι');
		charMapFromHost.put('J', 'Κ');
		charMapFromHost.put('K', 'Λ');
		charMapFromHost.put('L', 'Μ');
		charMapFromHost.put('M', 'Ν');
		charMapFromHost.put('N', 'Ξ');
		charMapFromHost.put('O', 'Ο');
		charMapFromHost.put('Q', 'Π');
		charMapFromHost.put('R', 'Ρ');
		charMapFromHost.put('S', 'Σ');
		charMapFromHost.put('U', 'Τ');
		charMapFromHost.put('V', 'Υ');
		charMapFromHost.put('W', 'Φ');
		charMapFromHost.put('X', 'Χ');
		charMapFromHost.put('Y', 'Ψ');
		charMapFromHost.put('Z', 'Ω');
		charMapFromHost.put('[', 'C');
		charMapFromHost.put('&', 'D');
		charMapFromHost.put(']', 'F');
		charMapFromHost.put(';', 'G');
		charMapFromHost.put('^', 'J');
		charMapFromHost.put('/', 'L');
		charMapFromHost.put('\\', 'Q');
		charMapFromHost.put(':', 'S');
		charMapFromHost.put('#', 'U');
		charMapFromHost.put('@', 'V');
		charMapFromHost.put('\"', 'W');
		charMapFromHost.put('P', '/');
		charMapFromHost.put('T', '&');
		charMapFromHost.put('!', '|');

		char byteArray1 = 130;
		charMapFromHost.put(byteArray1,'\"');

		char byteArray128 = 128;
		charMapFromHost.put(byteArray128,'^');

		char byteArray129 = 129;
		charMapFromHost.put(byteArray129,'!');

		char byteArray131 = 131;
		charMapFromHost.put(byteArray131,'#');

		char byteArray132 = 132;
		charMapFromHost.put(byteArray132,'@');

		char byteArray133 = 133;
		charMapFromHost.put(byteArray133,'[');

		char byteArray134 = 134;
		charMapFromHost.put(byteArray134,'\\');

		char byteArray135 = 135;
		charMapFromHost.put(byteArray135,'?');

		char byteArray136 = 136;
		charMapFromHost.put(byteArray136,':');

		char byteArray137 = 137;
		charMapFromHost.put(byteArray137,']');

		char byteArray138 = 138;
		charMapFromHost.put(byteArray138,';');

	}

	private static void initMapToHostOld(){
		charMapToHostOld.put('R', '?');
		charMapToHostOld.put('Α', 'A');
		charMapToHostOld.put('Β', 'B');
		charMapToHostOld.put('Γ', 'C');
		charMapToHostOld.put('Δ', 'D');
		charMapToHostOld.put('Ε', 'E');
		charMapToHostOld.put('Ζ', 'F');
		charMapToHostOld.put('Η', 'G');
		charMapToHostOld.put('Θ', 'H');
		charMapToHostOld.put('Ι', 'I');
		charMapToHostOld.put('Κ', 'J');
		charMapToHostOld.put('Λ', 'K');
		charMapToHostOld.put('Μ', 'L');
		charMapToHostOld.put('Ν', 'M');
		charMapToHostOld.put('Ξ', 'N');
		charMapToHostOld.put('Ο', 'O');
		charMapToHostOld.put('Π', 'Q');
		charMapToHostOld.put('Ρ', 'R');
		charMapToHostOld.put('Σ', 'S');
		charMapToHostOld.put('Τ', 'U');
		charMapToHostOld.put('Υ', 'V');
		charMapToHostOld.put('Φ', 'W');
		charMapToHostOld.put('Χ', 'X');
		charMapToHostOld.put('Ψ', 'Y');
		charMapToHostOld.put('Ω', 'Z');
		charMapToHostOld.put('C', '[');
		charMapToHostOld.put('D', '&');
		charMapToHostOld.put('F', ']');
		charMapToHostOld.put('G', ';');
		charMapToHostOld.put('J', '^');
		charMapToHostOld.put('L', '/');
		charMapToHostOld.put('Q', '\\');
		charMapToHostOld.put('S', ':');
		charMapToHostOld.put('U', '#');
		charMapToHostOld.put('V', '@');
		charMapToHostOld.put('W', '\"');
		charMapToHostOld.put('/', 'P');
		charMapToHostOld.put('&', 'T');
		charMapToHostOld.put('|', '!');

		char byteArray1 = 130;
		charMapToHostOld.put('\"',byteArray1);

		char byteArray128 = 128;
		charMapToHostOld.put('^',byteArray128);

		char byteArray129 = 129;
		charMapToHostOld.put('!',byteArray129);

		char byteArray131 = 131;
		charMapToHostOld.put('#',byteArray131);

		char byteArray132 = 132;
		charMapToHostOld.put('@',byteArray132);

		char byteArray133 = 133;
		charMapToHostOld.put('[',byteArray133);

		char byteArray134 = 134;
		charMapToHostOld.put('\\',byteArray134);

		char byteArray135 = 135;
		charMapToHostOld.put('?',byteArray135);

		char byteArray136 = 136;
		charMapToHostOld.put(':',byteArray136);

		char byteArray137 = 137;
		charMapToHostOld.put(']',byteArray137);

		char byteArray138 = 138;
		charMapToHostOld.put(';',byteArray138);
	}

	private static void initMapGreekToEnglish(){
		greekToEnglishMap.put('Α','A');
		greekToEnglishMap.put('Β','B');
		greekToEnglishMap.put('Ε','E');
		greekToEnglishMap.put('Η','H');
		greekToEnglishMap.put('Ι','I');
		greekToEnglishMap.put('Κ','K');
		greekToEnglishMap.put('Μ','M');
		greekToEnglishMap.put('Ν','N');
		greekToEnglishMap.put('Ο','O');
		greekToEnglishMap.put('Τ','T');
		greekToEnglishMap.put('Χ','X');
		greekToEnglishMap.put('Υ','Y');
		greekToEnglishMap.put('Ζ','Z');
		greekToEnglishMap.put('Ρ','P');
	}

	private static void initMapEnglishToGreek(){
		englishToGreekMap.put('A','Α');
		englishToGreekMap.put('B','Β');
		englishToGreekMap.put('E','Ε');
		englishToGreekMap.put('H','Η');
		englishToGreekMap.put('I','Ι');
		englishToGreekMap.put('K','Κ');
		englishToGreekMap.put('M','Μ');
		englishToGreekMap.put('N','Ν');
		englishToGreekMap.put('O','Ο');
		englishToGreekMap.put('T','Τ');
		englishToGreekMap.put('X','Χ');
		englishToGreekMap.put('Y','Υ');
		englishToGreekMap.put('Z','Ζ');
		englishToGreekMap.put('P','Ρ');
		englishToGreekMap.put('a','Α');
		englishToGreekMap.put('b','Β');
		englishToGreekMap.put('e','Ε');
		englishToGreekMap.put('h','Η');
		englishToGreekMap.put('i','Ι');
		englishToGreekMap.put('k','Κ');
		englishToGreekMap.put('m','Μ');
		englishToGreekMap.put('n','Ν');
		englishToGreekMap.put('o','Ο');
		englishToGreekMap.put('t','Τ');
		englishToGreekMap.put('x','Χ');
		englishToGreekMap.put('y','Υ');
		englishToGreekMap.put('z','Ζ');
		englishToGreekMap.put('p','Ρ');
	}

	private static void initMapSpecialGreekCharacters(){
		specialGreekCharacterMap.put('ΐ','Ι');
		specialGreekCharacterMap.put('ί','Ι');
		specialGreekCharacterMap.put('ϊ','Ι');
		specialGreekCharacterMap.put('Ί','Ι');
		specialGreekCharacterMap.put('Ϊ','Ι');
		specialGreekCharacterMap.put('ά','Α');
		specialGreekCharacterMap.put('Ά','Α');
		specialGreekCharacterMap.put('έ','Ε');
		specialGreekCharacterMap.put('Έ','Ε');
		specialGreekCharacterMap.put('ή','Η');
		specialGreekCharacterMap.put('Ή','Η');
		specialGreekCharacterMap.put('ΰ','Υ');
		specialGreekCharacterMap.put('ϋ','Υ');
		specialGreekCharacterMap.put('ύ','Υ');
		specialGreekCharacterMap.put('Ϋ','Υ');
		specialGreekCharacterMap.put('Ύ','Υ');
		specialGreekCharacterMap.put('ό','Ο');
		specialGreekCharacterMap.put('Ό','Ο');
		specialGreekCharacterMap.put('ώ','Ω');
		specialGreekCharacterMap.put('Ώ','Ω');
	}

	private static void initMapToHost(){
		charMapToHost.put('Α', 'A');
		charMapToHost.put('α', 'A');
		charMapToHost.put('Β', 'B');
		charMapToHost.put('β', 'B');
		charMapToHost.put('Γ', 'C');
		charMapToHost.put('γ', 'C');
		charMapToHost.put('Δ', 'D');
		charMapToHost.put('δ', 'D');
		charMapToHost.put('Ε', 'E');
		charMapToHost.put('ε', 'E');
		charMapToHost.put('Ζ', 'F');
		charMapToHost.put('ζ', 'F');
		charMapToHost.put('Η', 'G');
		charMapToHost.put('η', 'G');
		charMapToHost.put('Θ', 'H');
		charMapToHost.put('θ', 'H');
		charMapToHost.put('Ι', 'I');
		charMapToHost.put('ι', 'I');
		charMapToHost.put('Κ', 'J');
		charMapToHost.put('κ', 'J');
		charMapToHost.put('Λ', 'K');
		charMapToHost.put('λ', 'K');
		charMapToHost.put('Μ', 'L');
		charMapToHost.put('μ', 'L');
		charMapToHost.put('Ν', 'M');
		charMapToHost.put('ν', 'M');
		charMapToHost.put('Ξ', 'N');
		charMapToHost.put('ξ', 'N');
		charMapToHost.put('Ο', 'O');
		charMapToHost.put('ο', 'O');
		charMapToHost.put('Π', 'Q');
		charMapToHost.put('π', 'Q');
		charMapToHost.put('Ρ', 'R');
		charMapToHost.put('ρ', 'R');
		charMapToHost.put('Σ', 'S');
		charMapToHost.put('σ', 'S');
		charMapToHost.put('ς', 'S');
		charMapToHost.put('Τ', 'U');
		charMapToHost.put('τ', 'U');
		charMapToHost.put('Υ', 'V');
		charMapToHost.put('υ', 'V');
		charMapToHost.put('Φ', 'W');
		charMapToHost.put('φ', 'W');
		charMapToHost.put('Χ', 'X');
		charMapToHost.put('χ', 'X');
		charMapToHost.put('Ψ', 'Y');
		charMapToHost.put('ψ', 'Y');
		charMapToHost.put('Ω', 'Z');
		charMapToHost.put('ω', 'Z');

		//Latin letters with special translation
		charMapToHost.put('R', '?');
		charMapToHost.put('r', '?');
		charMapToHost.put('C', '[');
		charMapToHost.put('c', '[');
		charMapToHost.put('D', '&');
		charMapToHost.put('d', '&');
		charMapToHost.put('F', ']');
		charMapToHost.put('f', ']');
		charMapToHost.put('G', ';');
		charMapToHost.put('g', ';');
		charMapToHost.put('J', '^');
		charMapToHost.put('j', '^');
		charMapToHost.put('L', '/');
		charMapToHost.put('l', '/');
		charMapToHost.put('Q', '\\');
		charMapToHost.put('q', '\\');
		charMapToHost.put('S', ':');
		charMapToHost.put('s', ':');
		charMapToHost.put('U', '#');
		charMapToHost.put('u', '#');
		charMapToHost.put('V', '@');
		charMapToHost.put('v', '@');
		charMapToHost.put('W', '\"');
		charMapToHost.put('w', '\"');
		charMapToHost.put('H', 'G');
		charMapToHost.put('h', 'G');
		charMapToHost.put('K', 'J');
		charMapToHost.put('k', 'J');
		charMapToHost.put('M', 'L');
		charMapToHost.put('m', 'L');
		charMapToHost.put('N', 'M');
		charMapToHost.put('n', 'M');
		charMapToHost.put('P', 'R');
		charMapToHost.put('p', 'R');
		charMapToHost.put('T', 'U');
		charMapToHost.put('t', 'U');
		charMapToHost.put('Z', 'F');
		charMapToHost.put('z', 'F');
		charMapToHost.put('Y', 'V');
		charMapToHost.put('y', 'V');

		//Symbols
		charMapToHost.put('/', 'P');
		charMapToHost.put('&', 'T');
		charMapToHost.put('|', '!');

		char byteArray1 = 130;
		charMapToHost.put('\"',byteArray1);

		char byteArray128 = 128;
		charMapToHost.put('^',byteArray128);

		char byteArray129 = 129;
		charMapToHost.put('!',byteArray129);

		char byteArray131 = 131;
		charMapToHost.put('#',byteArray131);

		char byteArray132 = 132;
		charMapToHost.put('@',byteArray132);

		char byteArray133 = 133;
		charMapToHost.put('[',byteArray133);

		char byteArray134 = 134;
		charMapToHost.put('\\',byteArray134);

		char byteArray135 = 135;
		charMapToHost.put('?',byteArray135);

		char byteArray136 = 136;
		charMapToHost.put(':',byteArray136);

		char byteArray137 = 137;
		charMapToHost.put(']',byteArray137);

		char byteArray138 = 138;
		charMapToHost.put(';',byteArray138);

		//Special Greek Characters
		charMapToHost.put('ΐ','I');
		charMapToHost.put('ί','I');
		charMapToHost.put('ϊ','I');
		charMapToHost.put('Ί','I');
		charMapToHost.put('Ϊ','I');
		charMapToHost.put('ά','A');
		charMapToHost.put('Ά','A');
		charMapToHost.put('έ','E');
		charMapToHost.put('Έ','E');
		charMapToHost.put('ή','G');
		charMapToHost.put('Ή','G');
		charMapToHost.put('ΰ','V');
		charMapToHost.put('ϋ','V');
		charMapToHost.put('ύ','V');
		charMapToHost.put('Ϋ','V');
		charMapToHost.put('Ύ','V');
		charMapToHost.put('ό','O');
		charMapToHost.put('Ό','O');
		charMapToHost.put('ώ','Z');
		charMapToHost.put('Ώ','Z');

	}

	private static void initSetToHostSpecialChar() {

		charSetToHostSpecialChar.add((char) 0);
		charSetToHostSpecialChar.add((char) 1);
		charSetToHostSpecialChar.add((char) 2);
		charSetToHostSpecialChar.add((char) 3);
		charSetToHostSpecialChar.add((char) 4);
		charSetToHostSpecialChar.add((char) 5);
		charSetToHostSpecialChar.add((char) 6);
		charSetToHostSpecialChar.add((char) 7);
		charSetToHostSpecialChar.add((char) 8);
		charSetToHostSpecialChar.add((char) 9);
		charSetToHostSpecialChar.add((char) 10);
		charSetToHostSpecialChar.add((char) 11);
		charSetToHostSpecialChar.add((char) 12);
		charSetToHostSpecialChar.add((char) 13);
		charSetToHostSpecialChar.add((char) 14);
		charSetToHostSpecialChar.add((char) 15);
		charSetToHostSpecialChar.add((char) 16);
		charSetToHostSpecialChar.add((char) 17);
		charSetToHostSpecialChar.add((char) 18);
		charSetToHostSpecialChar.add((char) 19);
		charSetToHostSpecialChar.add((char) 20);
		charSetToHostSpecialChar.add((char) 21);
		charSetToHostSpecialChar.add((char) 22);
		charSetToHostSpecialChar.add((char) 23);
		charSetToHostSpecialChar.add((char) 24);
		charSetToHostSpecialChar.add((char) 25);
		charSetToHostSpecialChar.add((char) 26);
		charSetToHostSpecialChar.add((char) 27);
		charSetToHostSpecialChar.add((char) 28);
		charSetToHostSpecialChar.add((char) 29);
		charSetToHostSpecialChar.add((char) 30);
		charSetToHostSpecialChar.add((char) 31);
		charSetToHostSpecialChar.add((char) 170);
		charSetToHostSpecialChar.add((char) 255);

	}

	static{
		initMapEnglishToGreek();
		initMapFromHost();
		initMapGreekToEnglish();
		initMapSpecialGreekCharacters();
		initMapToHostOld();
		initMapToHost();
		initSetToHostSpecialChar();
	}

	public static String fromHost(String inText){

		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("Inside fromHost, inText:" + inText);
		}


		StringBuilder sb=new StringBuilder("");
		if(!StringUtils.isEmpty(inText)){
			for (Character chr : inText.toCharArray()) {
				char fChr = charMapFromHost.containsKey(chr)?charMapFromHost.get(chr):chr;
				sb.append(fChr);
			}
			return sb.toString();
		}else{
			return "";
		}
	}

	public static String toHostOld(String inText){
		StringBuilder sb=new StringBuilder("");
		for (Character chr : inText.toCharArray()) {
			char fChr = charMapToHostOld.containsKey(chr)?charMapToHostOld.get(chr):chr;
			sb.append(fChr);
		}
		return sb.toString();
	}

	public static String translateGreek(String inText){
		StringBuilder sb=new StringBuilder("");
		for (Character chr : inText.toCharArray()) {
			char fChr = greekToEnglishMap.containsKey(chr)?greekToEnglishMap.get(chr):chr;
			sb.append(fChr);
		}
		return sb.toString();
	}

	public static String translateEnglish(String inText){
		StringBuilder sb=new StringBuilder("");
		for (Character chr : inText.toCharArray()) {
			char fChr = englishToGreekMap.containsKey(chr)?englishToGreekMap.get(chr):chr;
			sb.append(fChr);
		}
		return sb.toString();
	}

	/**
	 * Parses a string and searches for accented Greek characters (Upper and lower case) and maps them to their corresponding Upper case character
	 * with no accentuation.
	 *
	 * <table border=1>
	 * 	<tr><th>Mapping</th></tr>
	 *  <tr><td>"ΐ" -> "Ι"</td></tr>
	 *  <tr><td>"ί" -> "Ι"</td></tr>
	 *  <tr><td>"ϊ" -> "Ι"</td></tr>
	 *  <tr><td>"Ί" -> "Ι"</td></tr>
	 *  <tr><td>"Ϊ" -> "Ι"</td></tr>
	 *  <tr><td>"ά" -> "Α"</td></tr>
	 *  <tr><td>"Ά" -> "Α"</td></tr>
	 *  <tr><td>"έ" -> "Ε"</td></tr>
	 *  <tr><td>"Έ" -> "Ε"</td></tr>
	 *  <tr><td>"ή" -> "Η"</td></tr>
	 *  <tr><td>"Ή" -> "Η"</td></tr>
	 *  <tr><td>"ΰ" -> "Υ"</td></tr>
	 *  <tr><td>"ϋ" -> "Υ"</td></tr>
	 *  <tr><td>"ύ" -> "Υ"</td></tr>
	 *  <tr><td>"Ϋ" -> "Υ"</td></tr>
	 *  <tr><td>"Ύ" -> "Υ"</td></tr>
	 *  <tr><td>"ό" -> "Ο"</td></tr>
	 *  <tr><td>"Ό" -> "Ο"</td></tr>
	 *  <tr><td>"ώ" -> "Ω"</td></tr>
	 *  <tr><td>"Ώ" -> "Ω"</td></tr>
	 * </table>
	 * @param inText
	 * @return
	 */
	public static String handleSpecialGreekCharacters(String inText){
		StringBuilder sb=new StringBuilder("");
		for (Character chr : inText.toCharArray()) {
			char fChr = specialGreekCharacterMap.containsKey(chr)?specialGreekCharacterMap.get(chr):chr;
			sb.append(fChr);
		}
		return sb.toString();
	}

	public static String toHostTranslation(String inText){
		StringBuilder sb1=new StringBuilder("");

		char tmp;

		for (Character chr : inText.toCharArray()) {
			if(englishToGreekMap.containsKey(chr)){
				tmp = englishToGreekMap.get(chr);
			}else if(specialGreekCharacterMap.containsKey(chr)){
				tmp = specialGreekCharacterMap.get(chr);
			}else{
				tmp = chr;
			}
			tmp = Character.toUpperCase(tmp);

			char fChr = charMapToHostOld.containsKey(tmp)?charMapToHostOld.get(tmp):tmp;
			sb1.append(fChr);
		}

		return sb1.toString();
	}

	public static String toHost(String inText){
		StringBuilder sb=new StringBuilder("");

		for (Character chr : inText.toCharArray()) {
			char fChr;
			if (charMapToHost.containsKey(chr)) {
				fChr = charMapToHost.get(chr);
			}
			else if (charSetToHostSpecialChar.contains(chr)) {
				fChr = ' ';
			}
			else {
				fChr= Character.toUpperCase(chr);
			}

			//char fChr = charMapToHost.containsKey(chr)?charMapToHost.get(chr):Character.toUpperCase(chr);
			sb.append(fChr);
		}
		return sb.toString();
	}

	public static String getDateFormatted(){
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		sdf.setTimeZone(TimeZone.getTimeZone(ZoneId.of(System.getProperty("cbs.time.zone", "Europe/Athens"))));
		String formatted = sdf.format(cal.getTime());

		return formatted;
	}

	public static String getDateFromHostFormatted(String hostDate) throws Exception{
		String dateFormatted = null;
		try{
			dateFormatted = LocalDate.parse(hostDate, DateTimeFormatter.BASIC_ISO_DATE).toString();
		}
		catch (Exception e){
			LOGGER.debug("Error occured. Unparsable Date");
			throw e;
		}

		return dateFormatted;
	}

	public static String getDateFormattedToHost(String xsDate) throws Exception{
		Calendar c = DatatypeConverter.parseDateTime(xsDate);
		DateFormat df = new SimpleDateFormat("yyyyMMdd");

		String formatted = df.format(c.getTime());

		return formatted;
	}

	/**
	 * Converts Host date (yyyyMMdd) to UFE date (yyyy-MM-dd).<br>
	 * The function does not validate input!<br>
	 * If the input date cannot be parsed then {@link java.time.format.DateTimeParseException} will be thrown.
	 *
	 * @param hostDate a date as a String in yyyyMMdd format
	 * @return String date in yyyy-MM-dd format
	 * @throws java.time.format.DateTimeParseException if hostDate cannot be parsed
	 */
	public static String fromHostDateToUfeDate(String hostDate) {
		return LocalDate.parse(LocalDate.parse(hostDate, DateTimeFormatter.BASIC_ISO_DATE).toString(), DateTimeFormatter.ISO_DATE).toString();
	}

	public static XMLGregorianCalendar getXMLGregorianDateFrom_YYYYMMDD(String dt) throws Exception{
		XMLGregorianCalendar xmlDate = null;
		XMLGregorianCalendar xmlDateStart = null;
		XMLGregorianCalendar xmlDateEnd = null;

		if (!"".equals(dt.trim()) && NumberUtils.toInt(dt) != 0) {
			DateFormat df = new SimpleDateFormat("yyyyMMdd");
			Date date = df.parse(dt);
			Date start = df.parse("18000101");
			Date end = df.parse("99991231");

			GregorianCalendar cal = new GregorianCalendar();
			cal.setTime(date);
			xmlDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
			xmlDate.setTimezone(DatatypeConstants.FIELD_UNDEFINED);

			cal.setTime(start);
			xmlDateStart = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
			xmlDateStart.setTimezone(DatatypeConstants.FIELD_UNDEFINED);


			cal.setTime(end);
			xmlDateEnd = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
			xmlDateEnd.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
		}

		if (xmlDate != null) {
			try {
				int start = xmlDate.compare(xmlDateStart);
				int end = xmlDate.compare(xmlDateEnd);
				if(start < 0){
					xmlDate = xmlDateStart;
				}
				if(end > 0){
					xmlDate = xmlDateEnd;
				}

			} catch (Exception ex) {
				xmlDate = null;
			}
		}

		return xmlDate;
	}

	public static String getValueOrNull(Document doc, String value, String fromSystem, String referenceType, RefDataTranslator translator) throws Exception {


		String inputValue = getValue(doc,value);

		if(StringUtils.isBlank(inputValue))
			return null;

		if(referenceType!=null)
			return translator.translateDataOrReturnNull(fromSystem, CBSConstants.REF_DATA_SYSTEM_UI, referenceType, inputValue);
		else
			return inputValue;

	}


	public static String getValue(Document doc, String value) {
		return getValue(doc, value,null);
	}

	public static String getValue(Document doc, String value, Map<String,String> m) {
		Long timer = System.nanoTime();
		if (LOGGER.isTraceEnabled()){
			LOGGER.trace("getValue:" + value);
		}

		XPath xPath = getXpath(m);
		String s = getValueXpath (xPath,doc,value);


		timer = System.nanoTime() - timer;
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("getValue:" + value + " took:" + timer /1000 + " micro," + "retVal:" + s);
		}
		return s;

	}


	// See https://examples.javacodegeeks.com/core-java/xml/xpath/java-xpath-performance-dom-vs-sax-example/
	private static final ThreadLocal<XPathFactory> XPATH_FACTORY = new ThreadLocal<XPathFactory>()
	{
		@Override
		protected XPathFactory initialValue()
		{
			try {
				return XPathFactory.newInstance("http://saxon.sf.net/jaxp/xpath/om","net.sf.saxon.xpath.XPathFactoryImpl", null);
			} catch (XPathFactoryConfigurationException e) {

				LOGGER.warn("Unable to get SAX Parser",e);
			}
			return XPathFactory.newInstance();

		}
	};


	public static XPathFactory getXPathFactory(){
		return XPATH_FACTORY.get();
	}

	public static XPath getXpath(Map<String,String> m) {
		Long timer = System.nanoTime();
		if (LOGGER.isTraceEnabled()){
			LOGGER.trace("getXpath Started");
		}
		//XPath xPath = new net.sf.saxon.xpath.XPathFactoryImpl().newXPath();

		XPath xPath = XPATH_FACTORY.get().newXPath();
		if (m!=null){
			try {

				xPath.setNamespaceContext(new NamespaceContext() {

					@Override
					public Iterator<String> getPrefixes(String arg0) {
						throw new UnsupportedOperationException();
					}

					@Override
					public String getPrefix(String arg0) {
						throw new UnsupportedOperationException();
					}

					@Override
					public String getNamespaceURI(String prefix) {
						if (prefix == null )throw new NullPointerException();
						else if (m != null && m.get(prefix) != null){
							return m.get(prefix);
						} else {
							return XMLConstants.NULL_NS_URI;
						}
					}
				});

			} catch (Exception e) {
				LOGGER.warn(e);
			}
		}


		if (LOGGER.isTraceEnabled()){
			timer = System.nanoTime() - timer;
			LOGGER.trace("getXpath took " + timer/1000 + " microsec");
		}
		return xPath;

	}

	public static String getValueXpath(XPath xPath,Document doc, String value) {

		if (LOGGER.isTraceEnabled()){
			LOGGER.trace("getValueXpath:" + value);
		}

		String retVal = "";
		Long timer = System.nanoTime();
		try {


			XPathExpression expr;
			expr = xPath.compile(value + "/text()");
			retVal = (String) expr.evaluate(doc, XPathConstants.STRING);

            boolean useAlternativePaths = AlternativePathsFlagHolder.isAlternativePathsFlag();

			if (useAlternativePaths && (retVal == null || retVal.isEmpty())) {
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				dbf.setNamespaceAware(false);
				DocumentBuilder builder = dbf.newDocumentBuilder();
				String documentRepresentation = nodeToString(doc, "yes", "no");
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("Document is:\n" + documentRepresentation);
				}
				Document nonNamespaceAwareDoc = builder.parse(new ByteArrayInputStream(documentRepresentation.getBytes(StandardCharsets.UTF_8)));
				String alternativeXPath = addWildcardToElementNames(value);
				try {
					if (LOGGER.isDebugEnabled()) {
						LOGGER.debug("Using alternative XPath: " + alternativeXPath);
					}
					expr = xPath.compile(alternativeXPath + "/text()");
					retVal = (String) expr.evaluate(nonNamespaceAwareDoc, XPathConstants.STRING);
				} catch (Exception e) {
					LOGGER.error("Error: " + e.getMessage() + " when compiling/evaluating alternative XPath: " + alternativeXPath);
				}
			}

			timer = System.nanoTime() - timer;
		} catch (Exception e) {
			LOGGER.warn("Exception Occured ",e);
			//e.printStackTrace();
		}


		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("xPath:" + xPath + " getValueXpath:" + value + " took:" + timer /1000 + " micro," + "retVal:" + retVal);
		}

		return retVal;
	}

	static String clearNamespaceInfoFromXPath(String xpath) {
		if (xpath == null || xpath.isEmpty()) {
			return xpath;
		}
		// Use regex to remove namespace prefixes (e.g., "prefix:" or "*:")
		return xpath.replaceAll("(?:\\*|\\w+):(?=[^']*(?:'[^']*'[^']*)*$)", "");
	}

	/**
	 * Converts a org.w3c.dom.Node to human Readable String
	 * @param node The node to be converted
	 * @return A string of an xml Node
	 */
	public static String nodeToString(Node node, String omitXmlDeclr, String indent, String method, String encoding) throws TransformerException {
		try {
			Processor processor = new Processor(false);
			XdmNode source = processor.newDocumentBuilder().wrap(node);
			Serializer serializer = processor.newSerializer();
			serializer.setOutputProperty(Serializer.Property.OMIT_XML_DECLARATION, omitXmlDeclr);
			serializer.setOutputProperty(Serializer.Property.INDENT, indent);
			if (method != null) {
				serializer.setOutputProperty(Serializer.Property.METHOD, method);
				serializer.setOutputProperty(Serializer.Property.ENCODING, encoding);
			}
			return serializer.serializeNodeToString(source);
		} catch (SaxonApiException e) {
			throw new TransformerException(e);
		}
	}

	public static String nodeToString(Node node, String omitXmlDeclr, String indent) throws TransformerException {
		return nodeToString(node, omitXmlDeclr, indent, null, null);
	}

	/**
	 * Parses a XPath field and checks for empty string values and zero values and returns null.<br>
	 * <p>
	 * <pre>
	 * <code>
	 * FormatUtils.parseEmpty("")        = null
	 * FormatUtils.parseEmpty("  ")      = null
	 * FormatUtils.parseEmpty("0")       = null
	 * FormatUtils.parseEmpty("000")     = null
	 * FormatUtils.parseEmpty("123  ")   = 123
	 * FormatUtils.parseEmpty("  123  ") = 123
	 * FormatUtils.parseEmpty("abc")     = abc
	 * FormatUtils.parseEmpty("abc  ")   = abc
	 * FormatUtils.parseEmpty("  abc  ") = abc
	 * </code>
	 * </pre>
	 *
	 * @param field
	 * @return
	 */
	public static String parseEmpty(String field){
		if(StringUtils.isNumericSpace(field)){
			if(NumberUtils.toLong(field.trim())!=0){
				return StringUtils.trim(field);
			}
		}else{
			return StringUtils.trimToNull(field);
		}

		return null;
	}

	/**
	 * Helper method that is used to validate if the value of a field from host can be used
	 * as reference data.
	 *
	 * The criteria for a valid reference data field is that it should contain values (not empty string or spaces).
	 *
	 * @param field
	 * @return
	 */
	public static boolean isReferenceDataValid(String field){
		boolean isReferenceData=false;
		if(StringUtils.trimToNull(field) != null){
			isReferenceData=true;
		}

		return isReferenceData;
	}

	public static boolean isFalse(String val){
		boolean tmpVal=false;

		if(NumberUtils.isDigits(val)){
			if(NumberUtils.toInt(val) == 0){
				tmpVal = true;
			}
		} else {
			if(StringUtils.trimToEmpty(val).length()==0){
				tmpVal = true;
			}
		}

		return tmpVal;
	}

	/**
	 * Alpha bank IBAN Calculator.
	 * The calculation is based on the branch unit code that created the account and the account number.
	 * In case the account number is not 15 characters long, the String "XXXXXXXXXXXXXXXXXXXXXXXXXXX" is returned.
	 * @param branch
	 * @param accountNumber
	 * @return The IBAN calculated according to branch and account number
	 */
	@Deprecated
	public static String calculateIBAN(String branch, String accountNumber){
		String tmpIBAN="";
		String tmpBIBAN="";

		if(accountNumber.trim().length()!=15){
			tmpIBAN = StringUtils.repeat("X", 27);
		}else{
			branch = StringUtils.leftPad(branch, 4, '0');
			tmpBIBAN = "014" + StringUtils.mid(branch, 0, 4) + 0 + accountNumber;
			tmpIBAN = tmpBIBAN +  "162700";
			String checkDigit = IBANUtils.calculateIBANCheckDigit(tmpIBAN);
			tmpIBAN = "GR" + checkDigit + tmpBIBAN;
		}
		return tmpIBAN;
	}

	/**
	 * Alpha bank IBAN Calculator.
	 * The calculation is based on the account number. The branch is extracted from the account number.
	 * In case the account number is not 15 characters long, the String "XXXXXXXXXXXXXXXXXXXXXXXXXXX" is returned.
	 * @param accountNumber
	 * @return The IBAN calculated according to account number
	 */
	public static String calculateIBAN(String accountNumber) {
		String tmpIBAN = "";
		String tmpBIBAN = "";
		if (accountNumber.trim().length() != 15) {
			tmpIBAN = StringUtils.repeat("X", 27);
		} else {
			String branch = StringUtils.leftPad(StringUtils.substring(accountNumber, 0, 3), 4, '0');
			tmpBIBAN = "014" + branch + 0 + accountNumber;
			tmpIBAN = tmpBIBAN + "162700";
			String checkDigit = IBANUtils.calculateIBANCheckDigit(tmpIBAN);
			tmpIBAN = "GR" + checkDigit + tmpBIBAN;
		}
		return tmpIBAN;
	}

	public static String calculateIBAN(String accountNumber, String unitCode, String unitCountry, String unitIBANCalculationMethod) {
		return IBANUtils.calculateIBAN(accountNumber, unitCode, unitCountry, unitIBANCalculationMethod);
	}

	/**
	 * Helper method used to validate iban
	 * @param iban : the iban
	 * @return the errorCode of the validation message or 0 for success
	 */
	public static String validateIBAN(String iban) {

		if (iban == null || iban.isEmpty()) {
			return "300739"; //Empty IBAN
		}
		iban = iban.trim();
		if (iban.length() != 27) {
			return "300740"; // Invalid IBAN length
		}
		if (!iban.substring(0, 2).equalsIgnoreCase("GR")) {
			return "300741"; // IBAN is not greek
		}

		String bankCode = iban.substring(4, 7);
		if (!bankCode.equals("014") && !bankCode.equals("084") && !bankCode.equals("012") &&
				!bankCode.equals("036") && !bankCode.equals("079") && !bankCode.equals("093")) {
			return "300742";
		}

		if (bankCode.equals("014")) {
			String accountNumber = iban.substring(12);
			String branchCode = iban.substring(7, 11);
			if (!FormatUtils.calculateIBAN(branchCode, accountNumber).equalsIgnoreCase(iban)) {
				return "300743"; // Invalid IBAN
			}
		}

		return "0"; // valid IBAN

	}

	/**
	 * Helper method used to validate afm
	 * @param afm
	 * @return the errorCode of the validation message or 0 for success
	 */
	public static String validateAfm(String afm) {

		if (afm == null || afm.isEmpty()) {
			return "300744"; // afm is empty
		}
		afm = afm.trim();
		if (afm.length() != 9) {
			return "300745"; // Afm wrong length
		} else {
			int checkSum = 0;
			for (int i = 0; i < 8; i++) {
				checkSum += Character.getNumericValue(afm.charAt(i)) * Math.pow(2, 8d - i);
			}

			int ypol = checkSum % 11;

			if (ypol == 10) {
				ypol = 0;
			}

			if (ypol != (Character.getNumericValue(afm.charAt(8)))) {
				return "300746"; // Invalid Afm
			}
		}
		return "0"; // Valid Afm
	}

	/**
	 * Hex to Decimal Converter
	 * converts hexadecimal Integer to Decimal Integer
	 * @param hex
	 * @return the Decimal form of the Hexadecimal
	 */
	public static String hex2decimal(String hex){

		if(!StringUtils.isEmpty(hex)){
			return new BigInteger(hex, 16).toString();
		}
		return "";
	}

	/**
	 * Hex to Decimal Converter
	 * converts hexadecimal Integer to Decimal Integer
	 * @param hex
	 * @return the Decimal form of the Hexadecimal
	 */
	public static String bunHex2Decimal(String hex){
		if(!StringUtils.isEmpty(hex)){
			String prefix = hex.substring(0,9);
			String suffix = hex.substring(9);

			System.out.println("PREFIX:" + prefix);
			System.out.println("SUFFIX:" + suffix);
			String hex1 = padLeft(new BigInteger(suffix, 16).toString(), 12, '0');
			System.out.println("HEX1:" + hex1);
			String result =  "" + prefix + hex1;
			System.out.println("RESULT:" + result);
			return result;
		}
		return "";
	}



	/**
	 * Decimal Converter
	 * Calculates BigDecimal according to the backend contract
	 * @param num
	 * @param lengthOfIntegerPart
	 * @return the actual BigDecimal
	 */
	public static BigDecimal getDecimalFromHost(String num, int lengthOfIntegerPart ){

		if(num==null) {
			return new BigDecimal(0);
		}

		StringBuilder builder = new StringBuilder(num);
		builder.insert(lengthOfIntegerPart,".");
		return new BigDecimal(builder.toString());
	}


	/**
	 * Decimal Converter
	 * Calculates Host Decimal given the Input Decimal
	 * @param num
	 * @param lengthOfIntegerPart
	 * @param lengthOfFractionalPart
	 * @return String host specific decimal
	 */
	public static String getDecimalToHost(String num, int lengthOfIntegerPart, int lengthOfFractionalPart) {
		String[] parts = num.split("\\.");
		StringBuilder fractionalBuilder = new StringBuilder();
		StringBuilder integerBuilder    = new StringBuilder();

		if(parts.length > 1){
			fractionalBuilder.append(parts[1]);
		}
		integerBuilder.append(parts[0]);


		while(integerBuilder.length()<lengthOfIntegerPart){
			integerBuilder.insert(0,"0");
		}
		while(fractionalBuilder.length()<lengthOfFractionalPart){
			fractionalBuilder.append("0");
		}

		if(integerBuilder.length()>lengthOfIntegerPart || fractionalBuilder.length()>lengthOfFractionalPart){
			throw new IllegalArgumentException("Error While converting Decimal to Host Decimel number: "+num+" intLength: "+lengthOfIntegerPart+" fractionalLength: "+lengthOfFractionalPart);
		}

		return integerBuilder.append(fractionalBuilder).toString();
	}

	/**
	 * Reads booleans from Xsd
	 * valid boolean in xsd are either 1/true or 0/false
	 * @param str
	 * @return boolean value
	 */
	public static boolean getBooleanFromXsd(String str){
		return "1".equals(str) || "true".equals(str) ? true : false;
	}

	/**
	 * The method transforms a Space into 0 and returns the value in String representation.
	 * The underlying mechanism uses NumberUtils.toInt() to do the conversion and finally wrapped as a string.
	 * <p>
	 * <pre>
	 * <code>
	 * spaceToZeroAsString(" ") = "0"
	 * </code>
	 * </pre>
	 * @param value - Space or any number
	 * @return Zero if the initial value are Spaces else the incoming number
	 */
	public static final String spaceToZeroAsString(String value){
		return String.valueOf(spaceToZero(value));
	}

	/**
	 * The method transforms a Space into 0.
	 * The underlying mechanism uses NumberUtils.toInt() to do the conversion.
	 * <p>
	 * <pre>
	 * <code>
	 * spaceToZero(" ") = 0
	 * </code>
	 * </pre>
	 * @param value - Space or any number
	 * @return Zero if the initial value are Spaces else the incoming number
	 */
	public static final int spaceToZero(String value){
		return NumberUtils.toInt(value);
	}

	/**
	 * The method checks a string for XML Special Characters Entities and surrounds the string with CDATA.
	 * @param inputStr - The string that will be checked for the special characters.
	 * @return A string surrounded with <![CDATA[ ...]]> if string contains XML Special Characters Entities, else the initial string.
	 */
	public static final String handleSpecialXMLchars(String inputStr){
		String tmpStr = inputStr;
		String outStr = "";
		String FORBIDEN_CHARS = "<>&\'\"";

		if(StringUtils.containsAny(tmpStr, FORBIDEN_CHARS)){
			StringBuilder sb = new StringBuilder();
			sb.append("<![CDATA[");
			sb.append(tmpStr);
			sb.append("]]>");

			outStr = sb.toString();
		}else{
			outStr = tmpStr;
		}
		return outStr;
	}

	/**
	 * The method extracts the actual User ID from the windows domain notation.<br>
	 * E.g. bank\c00023 -> c00023 <br>
	 * 		banktest\x89999 -> x89999
	 *
	 * @param user
	 * @return
	 */
	public static final String getUserFromDomain(String user){
		String slash="\\";
		String[] tokens = user.split(Pattern.quote(slash));

		return tokens[tokens.length-1];
	}

	/**
	 * The method extracts the first part of the JBOSS server name.<br>
	 *
	 * @param server
	 * @return
	 */
	public static final String getServerName(String server){
		String dot=".";
		String[] tokens = server.split(Pattern.quote(dot));

		return tokens[0];
	}

	public static String getDateFromHostClassicFormat(String hostDate) throws Exception{
		String dateFormatted = null;
		try{
			dateFormatted = LocalDate.parse(hostDate, DateTimeFormatter.BASIC_ISO_DATE).toString();
		}
		catch (Exception e){
			LOGGER.debug("Error occured on parsing date: " + hostDate + " Unparsable date.");
			throw e;
		}
		return dateFormatted;
	}

	/**
	 * This function transforms a Host number from one Host format to another Host format.<br>
	 *
	 * e.g.<br>
	 * <code>transformHostNumbers("000000015699999999", 10, 8, 2, 5)</code> -> 5699999<br>
	 * <code>transformHostNumbers("5699999", 2, 5, 10, 8)</code> -> 000000005699999000<br>
	 * <code>transformHostNumbers("000000015699999999", 10, 8, 2, 10)</code> -> 569999999900<br>
	 * <code>transformHostNumbers("5699999", 2, 5, 10, 3)</code> -> 0000000056999<br>
	 *
	 * @param number - The Initial number to be transformed
	 * @param fromIntPart - The integer part of the number
	 * @param fromDecPart - The decimal part of the number
	 * @param toIntPart - The transformed integer part of the new number
	 * @param toDecPart - The transformed decimal part of the new number
	 * @return
	 */
	public static final String transformHostNumbers(String number,int fromIntPart,int fromDecPart,int toIntPart,int toDecPart){
		String numberIntPart = StringUtils.mid(number, 0, fromIntPart);
		String numberDecPart = StringUtils.substring(number, fromIntPart);
		String newNumberIntPart = "";
		String newNumberDecPart = "";

		if(fromIntPart > toIntPart){
			newNumberIntPart = StringUtils.mid(numberIntPart, fromIntPart - toIntPart, toIntPart);
		}else{
			newNumberIntPart = StringUtils.leftPad(numberIntPart, toIntPart, '0');
		}

		if(fromDecPart > toDecPart){
			newNumberDecPart = StringUtils.substring(numberDecPart, 0, toDecPart);
		}else{
			newNumberDecPart = StringUtils.rightPad(numberDecPart, toDecPart, '0');
		}

		return newNumberIntPart+newNumberDecPart;
	}

	/**
	 * Serializes an Object to String
	 * @param o Object to be serialized
	 * @return Object serialized as String
	 * @throws IOException
	 */
	public static String serialize(Serializable o) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try (ObjectOutputStream oos = new ObjectOutputStream(baos)) {
			oos.writeObject(o);
		}
		return Base64.getEncoder().encodeToString(baos.toByteArray());
	}

	/**
	 * Deserializes a String to Object
	 * @param s String to deserialize
	 * @return String deserialized as Object
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public static Object deserialize(String s) throws IOException, ClassNotFoundException {
		byte[] data = Base64.getDecoder().decode(s);
		try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(data))) {
			return ois.readObject();
		}
	}


	/**
	 * Given a 14-digit accountNumber it returns the last digit.
	 * For example: given 95000221000149 returns: 2
	 * @param accountNumber
	 * @return last digit of an account as string
	 */
	public static final String getDigitStandardForAccount(String accountNumber){
		int digit ;
		int dTotal = 0;
		String[] account = accountNumber.split(StringUtils.EMPTY);

		if (account.length != 14){
			return StringUtils.EMPTY;
		}

		for (int i = 13; i > -1; i--){
			dTotal += ((double) Integer.parseInt(account[i])) * (int)Math.pow(2, 14.0 - i);
		}

		digit = dTotal % 11;
		digit = 11 - digit;
		digit = digit > 9 ? 0 : digit;

		return String.valueOf(digit);
	}

	/**
	 * Decimal to Hex Converter
	 * @param input
	 * @return the Hexadecimal form of the Decimal input
	 */
	public static String bunDecimal2Hex(String input){
		if(!StringUtils.isEmpty(input)){
			String prefix = input.substring(0,9);
			String suffix = input.substring(9);

			if (LOGGER.isDebugEnabled()){
				LOGGER.debug("PREFIX:" + prefix);
				LOGGER.debug("SUFFIX:" + suffix);
			}
			String dec = StringUtils.leftPad(Long.toHexString(Long.parseLong(suffix)).toUpperCase(), 9, '0') ;

			String result =  "" + prefix + dec;

			if (LOGGER.isDebugEnabled()){
				LOGGER.debug("RESULT:" + result);
			}

			return result;
		}
		return "";
	}

	/**
	 * Given a n-digit serialNumber it returns the last digit, based on modulo11
	 * calculations For example: given 000001221 returns: 1
	 *
	 * @param serialNumber
	 * @return last digit of an number as string
	 */
	public static String calculateModulo11CD(String serialNumber) {
		int len = serialNumber.length();
		int sum = 0;
		int rem = 0;
		for (int i = len; i >= 1; i--) {
			// compute weighted sum
			sum += (len - i + 2) * Character.getNumericValue(serialNumber.charAt(i - 1));
		}
		rem = 11 - (sum % 11);
		//check digit should be one digit!
		switch (rem) {
			case 10:
				return "0";
			case 11:
				return "1";
			default:
				return String.valueOf(rem);
		}
	}

	/**
	 * This method splits Swift BIC Codes, and puts in a map each value.
	 * @param bicCode
	 * @return map
	 */
	public static Map<String, String> splitSwiftBICCode(String bicCode) {

		Map<String, String> map = new HashMap<>();

		if (bicCode.length() == 12){
			map.put("BankCode", bicCode.substring(0,4));
			map.put("CountryCode", bicCode.substring(4,6));
			map.put("LocationCode", bicCode.substring(6,8));
			map.put("LogicalTerminal", bicCode.substring(8,9));
			map.put("BranchCode", bicCode.substring(9,12));
		}
		if (bicCode.length() == 11){
			map.put("BankCode", bicCode.substring(0,4));
			map.put("CountryCode", bicCode.substring(4,6));
			map.put("LocationCode", bicCode.substring(6,8));
			map.put("BranchCode", bicCode.substring(8,11));
		}

		return map;
	}

	/**
	 * This method converts X(26) timestamp in format yyyy-MM-dd'T'HH:mm:ss.SSSSSS.
	 * For example: given 2019-07-15 10S20S15.123456 returns: 2019-07-15T10:20:15.123456
	 * @param timestampOS2200
	 * @return timestamp as String in format yyyy-MM-dd'T'HH:mm:ss.SSSSSS
	 */
	public static String getTimestampFromOS2200(String timestampOS2200){
		DateTimeFormatter dtfin = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS");
		DateTimeFormatter dtfout = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSS");

		String timestamp = LocalDateTime.parse(timestampOS2200.replace("S", ":"), dtfin).format(dtfout);

		return timestamp;
	}

	/**
	 * This method converts X(26) timestamp in format yyyy-MM-dd'T'HH:mm:ss.SSSSSS.
	 * @param timestampOS2200
	 * @return timestamp as XMLGregorianCalendar in format yyyy-MM-dd'T'HH:mm:ss.SSSSSS
	 */
	public static XMLGregorianCalendar getXMLGregorianCalendarTimestampFromOS2200(String timestampOS2200) throws DatatypeConfigurationException {
		String transformedTstmp = getTimestampFromOS2200(timestampOS2200);
		return DatatypeFactory.newInstance().newXMLGregorianCalendar(transformedTstmp);
	}

	/**
	 * Given a BigDecimal it returns the exact number of decimal place.
	 * In case of null input, method will return -1
	 *
	 *
	 * For example:
	 *     [1] - given 154.256 returns: 3
	 *     [2] - given 154     returns: 0
	 *
	 * @param number - BigDecimal
	 * @return int - Number of decimal place (or -1 when number is null)
	 */
	public static int countDecimalplace(BigDecimal number) {

		if (number == null){
			return -1;
		}
		else{
			int numOfDecimals;
			String numberStr = number.toString();

			if (numberStr.indexOf('.') == -1){
				numOfDecimals = 0;
			}else{
				numOfDecimals = numberStr.substring(numberStr.indexOf('.')+1, numberStr.length()).length();
			}
			return numOfDecimals;
		}
	}

	/**
	 * This method recieves BIC Code 11, and creates a SwiftBICCode12.
	 * @param bicCode
	 * @return string
	 */

	public static String createSwiftBICCode12(String bicCode) {

		Map<String, String> swiftBICCode = FormatUtils.splitSwiftBICCode(bicCode);
		String createSwiftBICCode12 = bicCode;

		if (bicCode != null){
			if (bicCode.length() == 11){
				createSwiftBICCode12 = swiftBICCode.get("BankCode") + swiftBICCode.get("CountryCode") +
						swiftBICCode.get("LocationCode") + "X" + swiftBICCode.get("BranchCode");
			}
		}

		return createSwiftBICCode12;
	}


	/**
	 * This method recieves BIC Code 08, and creates a SwiftBICCode11.
	 * @param bicCode
	 * @return string
	 */
	public static String createSwiftBICCode11(String bicCode) {

		Map<String, String> swiftBICCode = FormatUtils.splitSwiftBICCode(bicCode);
		String createSwiftBICCode11 = bicCode;

		if (bicCode != null) {

			createSwiftBICCode11 = swiftBICCode.get("BankCode") + swiftBICCode.get("CountryCode")
					+ swiftBICCode.get("LocationCode")
					+ (swiftBICCode.get("BranchCode").trim().equals(StringUtils.EMPTY) ? "XXX"
					: swiftBICCode.get("BranchCode"));

		}

		return createSwiftBICCode11;
	}

	/**
	 * This method splits IBAN, and puts in a map each value.
	 * @param iban
	 * @return map
	 */

	public static Map<String, String> splitIBAN(String iban) {
		Map<String, String> map = new HashMap<>();

		if (iban.length() == 34){
			map.put("CountryISO",iban.substring(0,2));
			map.put("CheckDigit",iban.substring(2,4));
			map.put("BankIdentifier", iban.substring(4,7));
			map.put("BBAN",iban.substring(4,34));
		}

		return map;
	}

	/**
	 * This method checks if an ISIN checkDigit (12th digit) is valid or not.
	 * @param isin (all 12 digits)
	 * @return true/false
	 */
	public static boolean ISINDcheckigit(String isin) {

		ISINCheckDigit checkDigit = new ISINCheckDigit();

		return checkDigit.isValid(isin);
	}

	public static String addWildcardToElementNames(String xpath) {
		// This regex matches element names not already prefixed and not functions or node tests
		if (xpath!=null) {
			return xpath.replaceAll(
					"(?<=/)(?!\\*)(?!text\\(\\))(?!comment\\(\\))(?!node\\(\\))(?!processing-instruction\\(\\))(?!(?:[a-zA-Z_][\\w\\-]*)\\s*\\()([a-zA-Z_][\\w\\-]*)",
					"*:$1"
			);
		}
		else{
			return null;
		}
	}
}