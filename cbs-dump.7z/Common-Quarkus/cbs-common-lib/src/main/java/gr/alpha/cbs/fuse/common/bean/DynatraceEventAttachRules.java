package gr.alpha.cbs.fuse.common.bean;

import java.util.List;

public class DynatraceEventAttachRules {
	private List<String> entityIds;

	public DynatraceEventAttachRules(List<String> entityIds) {
		this.entityIds = entityIds;
	}

	public List<String> getEntityIds() {
		return entityIds;
	}
}
