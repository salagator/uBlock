package gr.alpha.cbs.fuse.common.exceptions;

import io.quarkus.runtime.annotations.RegisterForReflection;

import java.util.HashMap;
import java.util.Map;

@RegisterForReflection
public class OdissyErrorException extends Exception {
	private static final long serialVersionUID = 6597171266497011206L;
	
	private static final int technicalOdissyErrorCode = 900001;
	private static final int functionalOdissyErrorCode = 900002;
	private static final int functionalOdissyErrorCode2 = 900003;
	private static final int odissyRC1FunctionalErrorCode = 222;
	
	private static final Map<Integer, String> technicalInputMessageMap = new HashMap<>();
	
	static {
		technicalInputMessageMap.put(5, "ΛΑΘOΣ ΤRΑΝSΑCΤΙOΝ ΚΙΝD");
		technicalInputMessageMap.put(6, "ΙΝVΑLΙD CΗΑΝΝΕL CODΕ");
		technicalInputMessageMap.put(7, "ΑΝΙΣΑ ΠOΣΑ XPΕΩΣΗΣ/ΠΙΣΤΩΣΗΣ");
		technicalInputMessageMap.put(8, "ΛΑΘOΣ ΙSO CODΕ ΠOΣOΥ OUΤCOΜΕ");
		technicalInputMessageMap.put(9, "ΛΑΘOΣ ΙSO CODΕ ΠOΣOΥ INCOΜΕ");
		technicalInputMessageMap.put(10, "ΛΑΘOΣ ΙSO CODΕ ΠOΣOΥ ΔΑΝΕΙΟΥ");
		technicalInputMessageMap.put(11, "ΜΗ ΕΠΙΤPΕΠΤO ΝOΜΙΣΜΑ ΛOΓ/ΣΜOΥ");
		technicalInputMessageMap.put(12, "ΑΣΥΜΦΩΝΙΑ ΝΟΜΙΣΜΑΤΩΝ");
		technicalInputMessageMap.put(14, "ΛΑΘOΣ ΤRΑΝS-ΙΝC-ΑΙΤ-CODΕ");
		technicalInputMessageMap.put(15, "ΛΑΘOΣ ΤRΑΝS-OUTC-ΑΙΤ-CODΕ");
		technicalInputMessageMap.put(16, "ΛΑΘOΣ ΚΩΔΙΚOΣ ΠPOΜΗΘΕΙΑΣ");
		technicalInputMessageMap.put(17, "ΛΑΘOΣ ΚΩΔΙΚOΣ RΕΑL BRΑΝCΗ");
		technicalInputMessageMap.put(18, "ΛΑΘOΣ ΕΝΕPΓΕΙΑ ΔΕΣΜΕΥΣΗΣ");
		technicalInputMessageMap.put(19, "BUΝ DΕC ΝOΤ ΝUΜΕRΙC");
	}
	
	private int rc1;
	private int rc2;
	private String odissyError;
	private String errorMessage;
	private String errorOriginator;
	
	public OdissyErrorException(int rc1, int rc2, String odissyError, String errorMessage, String errorOriginator) {
		super("Odissy error encountered (" + rc1 + ", " + rc2 + ", " + odissyError + ", " + errorMessage + ", " + errorOriginator + ").");
		this.rc1 = rc1;
		this.rc2 = rc2;
		this.odissyError = odissyError;
		this.errorMessage = errorMessage;
		this.errorOriginator = errorOriginator;
	}
	
	public int getRc1() {
		return rc1;
	}
	
	public int getRc2() {
		return rc2;
	}
	
	public String getOdissyError() {
		return odissyError;
	}
	
	public String getErrorMessage() {
		return errorMessage;
	}
	
	public String getErrorOriginator() {
		return errorOriginator;
	}
	
	public int  getErrorCode() {
		if (odissyError != null) {
			return technicalOdissyErrorCode;
		}
		if (rc1 == odissyRC1FunctionalErrorCode) {
			return functionalOdissyErrorCode;
		}
		if ((rc1 != odissyRC1FunctionalErrorCode) && (rc1 != 0)) {
			return functionalOdissyErrorCode2;
		}
		return technicalOdissyErrorCode;
	}
	
	public String getSeverityLevel() {
		// All errors from odissy considered serverity error level.
		return ErrorTypeModel.SEVERITY_ERROR;
	}
	
	public String getExceptionType() {
		if (odissyError != null) {
			return ErrorTypeModel.ERROR_TYPE_TECHNICAL;
		}
		if ((rc1 == odissyRC1FunctionalErrorCode) || (rc1 != 0)) {
			return ErrorTypeModel.ERROR_TYPE_FUNCTIONAL;
		}
		return ErrorTypeModel.ERROR_TYPE_TECHNICAL;
	}
	
	public String getErrorDescription() {
		String returnValue = null;
		if (rc1 == 98) {
			returnValue = lookupRc2();
		} else {
			returnValue = errorMessage; //  + ", originator: " + errorOriginator;
		}
		if (returnValue == null) {
			returnValue = odissyError;
		}
		return returnValue;
	}
	
	private boolean rc1BelongsToTechninalErrorRange() {
		// Technical error ranges: RC1 = 5000-5999, 994-998, 99, 55, 98
		return (5000 <= rc1 && rc1 <= 5999) ||
				(994 <= rc1 && rc1 <= 998) ||
				rc1 == 99 || rc1 == 98 || rc1 == 55;
	}
	
	private String lookupRc2() {
		String returnValue = technicalInputMessageMap.get(rc2);
		if (returnValue == null) {
			return errorMessage;
		}
		return returnValue;
	}

}
