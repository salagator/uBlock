package gr.alpha.cbs.fuse.common.logging;

import gr.alpha.cbs.fuse.common.CBSConstants;
import org.slf4j.MDC;
import org.wildfly.common.net.HostName;

import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Date;
import java.util.TimeZone;

public class LoadLoggingHelper {
	private static final org.jboss.logging.Logger customLogger = org.jboss.logging.Logger.getLogger("webServiceLoadLogger");
	private static final org.jboss.logging.Logger customSigloLogger = org.jboss.logging.Logger.getLogger("sigloLoadLogger");
	private static final org.jboss.logging.Logger customLoggerDTPRA = org.jboss.logging.Logger.getLogger("webServiceLoadLoggerDtpra");

	private static final ThreadLocal<SimpleDateFormat> sdf = new ThreadLocal<SimpleDateFormat>() {
		protected SimpleDateFormat initialValue() {
			SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS");
			sdf2.setTimeZone(TimeZone.getTimeZone(ZoneId.of(System.getProperty("cbs.time.zone", "Europe/Athens"))));
			return sdf2;
		};
	};
	private static final String hostname;

	static {
		hostname = HostName.getHostName();
//		nodename = System.getProperty("jboss.node.name", "NODE");
	}
	
	public static void createMessageSiglo(String layer, String operation, long duration) {
		if(customSigloLogger.isDebugEnabled()){
			StringBuilder sb = new StringBuilder();
			
			String timestamp = sdf.get().format(new Date());
			String userId = MDC.get(CBSConstants.MDC_KEY_USER_ID);
			String businessCaseId = MDC.get(CBSConstants.MDC_KEY_BUSINESS_CASE_ID);
			String requestId = MDC.get(CBSConstants.MDC_KEY_REQUEST_ID);
			String durationString = String.valueOf(duration);
			
			sb.append(timestamp);
			sb.append(",");
			sb.append(userId);
			sb.append(",");
			sb.append(businessCaseId);
			sb.append(",");
			sb.append(requestId);
			sb.append(",");
			sb.append(operation);
			sb.append(",");
			sb.append(layer);
			sb.append(",");
			sb.append(hostname);
			sb.append(",");
//			sb.append(nodename);
//			sb.append(",");
			sb.append(durationString);
			
			customSigloLogger.debug("LoadLogging: " + sb.toString());
		}
	}

	public static void createMessage(String layer, String operation, long duration) {
		if(customLogger.isDebugEnabled()){
			StringBuilder sb = new StringBuilder();
			
			String timestamp = sdf.get().format(new Date());
			String userId = MDC.get(CBSConstants.MDC_KEY_USER_ID);
			String businessCaseId = MDC.get(CBSConstants.MDC_KEY_BUSINESS_CASE_ID);
			String requestId = MDC.get(CBSConstants.MDC_KEY_REQUEST_ID);
			String durationString = String.valueOf(duration);
			
			sb.append(timestamp);
			sb.append(",");
			sb.append(userId);
			sb.append(",");
			sb.append(businessCaseId);
			sb.append(",");
			sb.append(requestId);
			sb.append(",");
			sb.append(operation);
			sb.append(",");
			sb.append(layer);
			sb.append(",");
			sb.append(hostname);
			sb.append(",");
//			sb.append(nodename);
//			sb.append(",");
			sb.append(durationString);
			
			customLogger.debug("LoadLogging: " + sb.toString());
		}
	}

	public static void createMessageOS2200(String layer, String operation, long duration, String component, String rc1, String rc2) {
		if(customLoggerDTPRA.isDebugEnabled()){
			StringBuilder sb = new StringBuilder();
			
			String timestamp = sdf.get().format(new Date());
			String userId = MDC.get(CBSConstants.MDC_KEY_USER_ID);
			String businessCaseId = MDC.get(CBSConstants.MDC_KEY_BUSINESS_CASE_ID);
			String requestId = MDC.get(CBSConstants.MDC_KEY_REQUEST_ID);
			String durationString = String.valueOf(duration);
			
			sb.append(timestamp);
			sb.append(",");
			sb.append(userId);
			sb.append(",");
			sb.append(businessCaseId);
			sb.append(",");
			sb.append(requestId);
			sb.append(",");
			sb.append(operation);
			sb.append(",");
			sb.append(layer);
			sb.append(",");
			sb.append(hostname);
			sb.append(",");
//			sb.append(nodename);
//			sb.append(",");
			sb.append(durationString);
			sb.append(",");
			sb.append(component);
			sb.append(",");
			sb.append(rc1);
			sb.append(",");
			sb.append(rc2);
			
			customLoggerDTPRA.debug("LoadLoggingDTPRA: " + sb.toString());
		}
	}
}

