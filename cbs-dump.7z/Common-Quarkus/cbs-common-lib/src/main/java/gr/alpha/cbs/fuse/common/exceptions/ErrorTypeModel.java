package gr.alpha.cbs.fuse.common.exceptions;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

@Named("errorTypeModel")
@ApplicationScoped
@RegisterForReflection
public class ErrorTypeModel {
	/** This is the default error code (300001). Message will be used directly by client application */
	public static final String DEFAULT_ERROR_CODE = "300001";
	
	/** Functional error (1) */
	public static final String ERROR_TYPE_FUNCTIONAL = "1";
	/** Technical error (2) */
	public static final String ERROR_TYPE_TECHNICAL = "2";

	// Code of Source System that generates the Error
	/** Error thrown in UI (1) */
	public static final String ERROR_SYSTEM_ID_UI = "1";
	/** Error thrown in Camel Fuse (2) */
	public static final String ERROR_SYSTEM_ID_FUSE = "2";
	/** Error thrown in BPM (3) */
	public static final String ERROR_SYSTEM_ID_BPM = "3";
	/** Error thrown in BRMS (4) */
	public static final String ERROR_SYSTEM_ID_BRMS = "4";
	/** Error thrown in OS2200 (5) */
	public static final String ERROR_SYSTEM_ID_OS2200 = "5";
	/** Error thrown in OS2200 Dispatcher ICP (6) */
	public static final String ERROR_SYSTEM_ID_ICP = "6";
	/** Error thrown in Odissy (7) */
	public static final String ERROR_SYSTEM_ID_ODISSY = "7";
	/** Error thrown in Efile (8) */
	public static final String ERROR_SYSTEM_ID_EFILE = "8";
	/** Error thrown in Pee WS (9) */
	public static final String ERROR_SYSTEM_ID_PEE = "9";

	// Error severity codes
	/** Fatal (1) */
	public static final String SEVERITY_FATAL = "1";
	/** Severe (2) */
	public static final String SEVERITY_SEVERE = "2";
	/** Error (3) */
	public static final String SEVERITY_ERROR = "3";
	/** Warning (4) */
	public static final String SEVERITY_WARNING = "4";

	private String errorType;
	private String sourceSystem;
	private String component;
	private String errorCode;
	private String severityLevel;
	private String suggestions;
	private String description;
	private String serverName;
	private String parameterValues;

	
	public String getErrorType() {
		return errorType;
	}

	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getSeverityLevel() {
		return severityLevel;
	}

	public void setSeverityLevel(String severityLevel) {
		this.severityLevel = severityLevel;
	}

	public String getSuggestions() {
		return suggestions;
	}

	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
	
	public String getParameterValues() {
		return parameterValues;
	}

	public void setParameterValues(String parameterValues) {
		this.parameterValues = parameterValues;
	}
	
	/**
	 * Static method to generate the Error Model which will be propagated through 
	 * the raised exception to the client.
	 * @param errorType
	 * @param errorInSystem
	 * @param errorCode
	 * @param errorLevel
	 * @param errorMessage
	 * @return ErrorTypeModel to be set in Exception
	 */
	public static ErrorTypeModel createErrorModel(String errorType, String errorInSystem, String errorInComponent,
			String errorCode, String errorLevel, String errorMessage) {
		
		ErrorTypeModel model = new ErrorTypeModel();
		model.setErrorType(errorType);
		model.setSourceSystem(errorInSystem);
		model.setComponent(errorInComponent);
		model.setErrorCode(errorCode);
		model.setSeverityLevel(errorLevel);
		model.setSuggestions("");
		model.setDescription(errorMessage);
		model.setServerName("");
		return model;
	}
	
	/**
	 * Static method to generate the Error Model which will be propagated through the raised exception to the client. 
	 * This "overload" constructor was added as part of MW functionality of "Parametric-Error Messages".
	 * @param errorType
	 * @param errorInSystem
	 * @param errorCode
	 * @param errorLevel
	 * @param errorMessage
	 * @param parameterValues
	 * **Multiple Parametric values can be added followed by a pipe
	 * **e.g {value1|value2|value3}
	 * @return ErrorTypeModel to be set in Exception
	 */
	public static ErrorTypeModel createErrorModel(String errorType, String errorInSystem, String errorInComponent,
			String errorCode, String errorLevel, String errorMessage, String parameterValues) {
		
		ErrorTypeModel model = new ErrorTypeModel();
		model.setErrorType(errorType);
		model.setSourceSystem(errorInSystem);
		model.setComponent(errorInComponent);
		model.setErrorCode(errorCode);
		model.setSeverityLevel(errorLevel);
		model.setSuggestions("");
		model.setDescription(errorMessage);
		model.setServerName("");
		model.setParameterValues(parameterValues);
		return model;
	}
	
}