package gr.alpha.cbs.fuse.common.exceptions;

import io.quarkus.runtime.annotations.RegisterForReflection;

@RegisterForReflection
public class SigloApprovalRequiredException extends Exception {
	private static final long serialVersionUID = 6448379666437108240L;
	
	private String approvalNeededCode;
	private String tun;
	private String sigloServiceName;

	public SigloApprovalRequiredException(String approvalNeededCode, String tun, String sigloServiceName) {
		super("Siglo approval needed (" + approvalNeededCode + ", " + tun + ", " + sigloServiceName + ").");
		this.approvalNeededCode = approvalNeededCode;
		this.tun = tun;
		this.sigloServiceName = sigloServiceName;
	}
	
	public String getApprovalNeededCode() {
		return approvalNeededCode;
	}
	
	public String getTun() {
		return tun;
	}
	
	public String getSigloServiceName() {
		return sigloServiceName;
	}
	
	public String getSeverityLevel() {
		return "Error";
	}
	
	public String getExceptionType() {
		return "TechnicalError";
	}
}
