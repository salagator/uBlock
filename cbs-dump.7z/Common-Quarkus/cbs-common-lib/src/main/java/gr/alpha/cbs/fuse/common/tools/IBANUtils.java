package gr.alpha.cbs.fuse.common.tools;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

import java.util.Arrays;
import java.util.List;

@Named("ibanUtils")
@ApplicationScoped
@RegisterForReflection
public class IBANUtils {
	
	private static final List<String> luxBranches = Arrays.asList("902");
	
	public static String calculateIBANCheckDigit(String tempIBAN) {
		String tmpIBAN = tempIBAN;
		while (tmpIBAN.length() > 9) {
			tmpIBAN = String.valueOf(NumberUtils.toLong(StringUtils.mid(tmpIBAN, 0, 9)) % 97) + StringUtils.mid(tmpIBAN, 9, tmpIBAN.length() - 9);
		}
		tmpIBAN = String.valueOf(NumberUtils.toLong(StringUtils.mid(tmpIBAN, 0, 9)) % 97);
		
		String checkDigit = String.valueOf(98 - NumberUtils.toLong(tmpIBAN));
		if (checkDigit.length() == 1)
			checkDigit = "0" + checkDigit;
		return checkDigit;
	}
	
	public static String calculateIBAN(String accountNumber, String unitCode, String unitCountry, String unitIBANCalculationMethod) {
		String iban = "";
		String unitC = StringUtils.leftPad(unitCode, 3, '0');
		switch (unitIBANCalculationMethod) {
		case "1":
			iban = calculateGreekIBAN(accountNumber, unitC, unitCountry);
			break;
		case "2":	
			iban = calculateLuxIBAN(accountNumber, unitC, unitCountry);
			break;
		default:
			break;
		}
		return iban;
	}
	
	public static String calculateGreekIBAN(String accountNumber, String unitCode, String unitCountry) {
		String iban = "";
		String tmpBIBAN = "";
		if (accountNumber.trim().length() != 15) {
			iban = StringUtils.repeat("X", 27);
		} else {
			String branch = StringUtils.leftPad(StringUtils.substring(accountNumber, 0, 3), 4, '0');
			tmpBIBAN = unitCode + branch + 0 + accountNumber;
			String ibanCheckDigit = calculateIBANCheckDigit(tmpBIBAN + unitCountryDigits(unitCountry) + "00"); //G -> 16 , R-> 27
			iban = unitCountry + ibanCheckDigit + tmpBIBAN;
		}
		return iban;
	}
	
	public static String calculateLuxIBAN(String accountNumber, String unitCode, String unitCountry) {
		String iban = "";
		String tmpBIBAN = "";
		if (accountNumber.trim().length() != 15) {
			iban = StringUtils.repeat("X", 20);
		} else {
			String branchAA = String.valueOf(luxBranches.size());
			tmpBIBAN = unitCode + branchAA + accountNumber.substring(3, 15);
			String ibanCheckDigit = calculateIBANCheckDigit(tmpBIBAN + unitCountryDigits(unitCountry) + "00");  //L->21 , U-> 30
			iban = unitCountry + ibanCheckDigit + tmpBIBAN;
		}
		return iban;
	}
	
	public static String unitCountryDigits(String unitCountry) {
		StringBuilder s = new StringBuilder();
		for(char c: unitCountry.toCharArray()){
		   s.append(String.valueOf(unitCountryDigit(c)));
		}
		return s.toString(); 
	}
	
	/**
	 * Convert character to digit (A -> 10, B-> 11 ...)
	 */
	public static int unitCountryDigit(char c) {
		return (int)c - 'A' + 10; 
	} 
	
	public static String getAccountFromIBAN(String iban, String unitIBANCalculationMethod){
		String accountNumber = "";
		switch (unitIBANCalculationMethod) {
		case "1":
			accountNumber = iban.substring(12);
			break;
		case "2":
			//TODO refactor - need proper mapping between lux and greek branches
			accountNumber = luxBranches.get(Integer.parseInt(iban.substring(7,8)) - 1) + iban.substring(8);
			break;
		default:
			break;
		}
		return accountNumber;
	}
}
