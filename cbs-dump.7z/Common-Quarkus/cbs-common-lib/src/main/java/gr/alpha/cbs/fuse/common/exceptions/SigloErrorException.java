package gr.alpha.cbs.fuse.common.exceptions;

import io.quarkus.runtime.annotations.RegisterForReflection;

@RegisterForReflection
public class SigloErrorException extends Exception {
	private static final long serialVersionUID = -6828307513359318284L;
	
	private int status;
	private int errorCode;
	private String tun;
	private String sigloServiceName;
	
	public SigloErrorException(int status, int errorCode, String tun, String sigloServiceName) {
		super("Siglo error encountered (" + status + ", " + errorCode + ", " + tun + ", " + sigloServiceName + ").");
		this.status = status;
		this.errorCode = errorCode;
		this.tun = tun;
		this.sigloServiceName = sigloServiceName;
	}
	
	public int getStatus() {
		return status;
	}
	
	public int getErrorCode() {
		return errorCode;
	}
	
	public String getTun() {
		return tun;
	}
	
	public String getSigloServiceName() {
		return sigloServiceName;
	}
	
	public String getSeverityLevel() {
		if (status == 4) {
			return ErrorTypeModel.SEVERITY_WARNING;
		} else if (status == 8) {
			return ErrorTypeModel.SEVERITY_ERROR;
		} else if (status == 12) {
			return ErrorTypeModel.SEVERITY_SEVERE;
		} else if (status == 16) {
			return ErrorTypeModel.SEVERITY_FATAL;
		} else {
			return ErrorTypeModel.SEVERITY_ERROR;
		}
	}
	
	public String getExceptionType() {
		if (errorCode >= 600000 && errorCode <= 689999) {
			return ErrorTypeModel.ERROR_TYPE_FUNCTIONAL;
		}
		return ErrorTypeModel.ERROR_TYPE_TECHNICAL;
	}
}
