package gr.alpha.cbs.fuse.common.bean;

import gr.alpha.cbs.fuse.common.exceptions.*;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.Map;

import com.ctc.wstx.exc.WstxUnexpectedCharException;

import javax.xml.transform.TransformerException;

@Named("errorUtils")
@Dependent
@RegisterForReflection
public class ErrorUtils {
	private static final Logger LOGGER = Logger.getLogger(ErrorUtils.class);

	private static final String TYPE_ERROR = "error";
	private static final String TYPE_WARNING = "warning";

	private static final String ODISSEY_ERRORS_FILE_PATH = "gr/alpha/cbs/fuse/odissey-errors.properties";


	public static void  throwCBSException(Exception exception,
												 String errorType,
												 String errorInSystem,
												 String errorInComponent,
												 String errorCode,
												 String errorLevel,
												 String errorMessage,
												 String suggestions,
												 String serverName
												) throws CBSException {
		
		ErrorTypeModel errorTypeModel = new ErrorTypeModel();
		
		// If there is Exception get the message
		if(exception != null){
			errorTypeModel.setDescription(exception.getMessage());
		}
		// If there is a custom message overrides the exception message
		if(!StringUtils.isEmpty(errorMessage)){
			errorTypeModel.setDescription(errorMessage);
		}
		errorTypeModel.setErrorType(errorType);
		errorTypeModel.setSourceSystem(errorInSystem);
		errorTypeModel.setComponent(errorInComponent);
		errorTypeModel.setErrorCode(errorCode);
		errorTypeModel.setSeverityLevel(errorLevel);
		errorTypeModel.setSuggestions(suggestions);
		errorTypeModel.setServerName(serverName);
		
		if(exception != null){
			throw new CBSException(exception,errorTypeModel);
		}else{
			throw new CBSException(errorTypeModel);
		}
	}

	public static void  throwCBSException(Exception exception,
					 String errorType,
					 String errorInSystem,
					 String errorInComponent,
					 String errorCode,
					 String errorLevel,
					 String errorMessage,
					 String suggestions,
					 String serverName,
					 String parameterValues
					) throws CBSException{
		
		ErrorTypeModel errorTypeModel = new ErrorTypeModel();
		
		// If there is Exception get the message
		if(exception != null){
		errorTypeModel.setDescription(exception.getMessage());
		}
		// If there is a custom message overrides the exception message
		if(!StringUtils.isEmpty(errorMessage)){
		errorTypeModel.setDescription(errorMessage);
		}
		errorTypeModel.setErrorType(errorType);
		errorTypeModel.setSourceSystem(errorInSystem);
		errorTypeModel.setComponent(errorInComponent);
		errorTypeModel.setErrorCode(errorCode);
		errorTypeModel.setSeverityLevel(errorLevel);
		errorTypeModel.setSuggestions(suggestions);
		errorTypeModel.setServerName(serverName);
		if (parameterValues != null) {
			// Added as part of "Parametric Messages" functionality
			errorTypeModel.setParameterValues(parameterValues);
		}
		
		if(exception != null){
		throw new CBSException(exception,errorTypeModel);
		}else{
		throw new CBSException(errorTypeModel);
		}
	}

	public static void reThrowException(Exchange exchange) throws Exception{
		Exception ex = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
		throw ex;
	}
	
	public static void  throwApplicationOS2200Exception(Exception exception, 
														String errorType, 
														String errorInSystem, 
														String errorInComponent, 
														String errorCode, 
														String errorLevel,
														String errorMessage, 
														String suggestions, 
														String serverName, 
														int rc1, 
														int rc2, 
														String stack) throws Application2200Exception {

		ErrorTypeModel errorTypeModel = new ErrorTypeModel();

		/** If there is Exception get the message */
		if (exception != null) {
			errorTypeModel.setDescription(exception.getMessage());
		}
		/** If there is a custom message overrides the exception message */
		if (!StringUtils.isEmpty(errorMessage)) {
			errorTypeModel.setDescription(errorMessage);
		}
		errorTypeModel.setErrorType(errorType);
		errorTypeModel.setSourceSystem(errorInSystem);
		errorTypeModel.setComponent(errorInComponent);
		errorTypeModel.setErrorCode(errorCode);
		errorTypeModel.setSeverityLevel(errorLevel);
		errorTypeModel.setSuggestions(suggestions);
		errorTypeModel.setServerName(serverName);

		if (exception != null) {
			throw new Application2200Exception(exception, rc1, rc2, stack, errorTypeModel);
		} else {
			throw new Application2200Exception(rc1, rc2, stack, errorTypeModel);
		}
	}

	public static ErrorTypeModel handleException(Exception ex){
		ErrorTypeModel model;
		
		//Create common parts of the error model
		model = ErrorTypeModel.createErrorModel(
				ErrorTypeModel.ERROR_TYPE_TECHNICAL,	//Error Type
				ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, 	//Error in System
				"", 									//Error in Component
				ErrorTypeModel.DEFAULT_ERROR_CODE,		//Error code
				ErrorTypeModel.SEVERITY_ERROR, 			//Error Level
				"",										//Error message
				"");									//Error Parameter Values
		
		if(ex instanceof CBSException){
			return ((CBSException) ex).getErrorModel();
		}else if(ex instanceof Application2200Exception){
			return ((Application2200Exception) ex).getErrorModel();
		}else{
			StringBuilder sbError = new StringBuilder();
			
			if(!ExceptionUtils.getRootCauseMessage(ex).isEmpty()){
				sbError.append("Root Cause:\n");
				sbError.append("-----------\n");
				sbError.append(ExceptionUtils.getRootCauseMessage(ex));
				sbError.append("\n");
			}
			if(ExceptionUtils.getRootCauseStackTrace(ex).length != 0){
				sbError.append("Stack Trace:\n");
				sbError.append("-----------\n");
				for (int i = 0; i < ExceptionUtils.getRootCauseStackTrace(ex).length; i++) {
					sbError.append(ExceptionUtils.getRootCauseStackTrace(ex)[i]);
					sbError.append("\n");
				}
			}
			if(!StringUtils.isEmpty(ex.getMessage())){
				sbError.append("Message:\n");
				sbError.append("-----------\n");
				sbError.append(ex.getMessage());
				sbError.append("\n");
			}
			model.setDescription(sbError.toString());
			return model;
		}
	}
	
	public static boolean isSigloError(Exchange exchange) {
		Throwable throwableToCheck = exchange.getProperty("CamelExceptionCaught", Throwable.class);
		if (throwableToCheck == null) {
			return false;
		}
		while (true) {
			if (throwableToCheck instanceof SigloErrorException) {
				exchange.setProperty("CamelExceptionCaught", throwableToCheck);
				return true;
			}
			if (throwableToCheck.getCause() == null) {
				return false;
			}
			throwableToCheck = throwableToCheck.getCause();
		}
	}
	
	public static boolean isCBSException(Exchange exchange) {
		Throwable throwableToCheck = exchange.getProperty("CamelExceptionCaught", Throwable.class);
		if (throwableToCheck == null) {
			return false;
		}
		while (true) {
			if (throwableToCheck instanceof CBSException) {
				exchange.setProperty("CamelExceptionCaught", throwableToCheck);
				return true;
			}
			if (throwableToCheck.getCause() == null) {
				return false;
			}
			throwableToCheck = throwableToCheck.getCause();
		}
	}
	
		public static boolean isApplication2200Exception(Exchange exchange) {
		Throwable throwableToCheck = exchange.getProperty("CamelExceptionCaught", Throwable.class);
		if (throwableToCheck == null) {
			return false;
		}
		while (true) {
			if (throwableToCheck instanceof Application2200Exception) {
				exchange.setProperty("CamelExceptionCaught", throwableToCheck);
				return true;
			}
			if (throwableToCheck.getCause() == null) {
				return false;
			}
			throwableToCheck = throwableToCheck.getCause();
		}
	}
	
	public static boolean isIllegalCharacterException(Exchange exchange) {
		Throwable throwableToCheck = exchange.getProperty("CamelExceptionCaught", Throwable.class);
		if (throwableToCheck == null) {
			return false;
		}
		while (true) {
			if (throwableToCheck instanceof WstxUnexpectedCharException) {
				exchange.setProperty("CamelExceptionCaught", throwableToCheck);
				return true;
			}
			if (throwableToCheck instanceof TransformerException) {
				throwableToCheck = ((TransformerException) throwableToCheck).getException();
				if (throwableToCheck == null) {
					return false;
				}
			} else {
				if (throwableToCheck.getCause() == null) {
					return false;
				}
				throwableToCheck = throwableToCheck.getCause();
			}
		}
	}

	public static String getCBSExceptionErrorCode(Exchange exchange) {
		Throwable throwableToCheck = exchange.getProperty("CamelExceptionCaught", Throwable.class);
		if (throwableToCheck == null) {
			LOGGER.warn("Unable to get CBSException from route, giving up.");
			return "300001";
		}
		while (true) {
			if (throwableToCheck instanceof CBSException) {
				return ((CBSException) throwableToCheck).getErrorModel().getErrorCode();
			}
			if (throwableToCheck.getCause() == null) {
				LOGGER.warn("Unable to get CBSException from route and hierarchy, giving up.");
				return "300001";
			}
			throwableToCheck = throwableToCheck.getCause();
		}
	}

	public static String getSigloExceptionErrorCode(Exchange exchange) {
		Throwable throwableToCheck = exchange.getProperty("CamelExceptionCaught", Throwable.class);
		if (throwableToCheck == null) {
			LOGGER.warn("Unable to get SigloException from route, giving up.");
			return "0";
		}
		while (true) {
			if (throwableToCheck instanceof SigloErrorException) {
				return String.valueOf(((SigloErrorException) throwableToCheck).getErrorCode());
			}
			if (throwableToCheck.getCause() == null) {
				LOGGER.warn("Unable to get SigloException from route and hierarchy, giving up.");
				return "0";
			}
			throwableToCheck = throwableToCheck.getCause();
		}
	}


	public static String getSigloExceptionType(Exchange exchange) {
		Throwable throwableToCheck = exchange.getProperty("CamelExceptionCaught", Throwable.class);
		if (throwableToCheck == null) {
			LOGGER.warn("Unable to get severity level, giving up.");
			return TYPE_ERROR;
		}
		while (true) {
			if (throwableToCheck instanceof SigloErrorException) {
				return (String.valueOf(((SigloErrorException) throwableToCheck).getSeverityLevel())  == "4") ? TYPE_WARNING : TYPE_ERROR;
			}
			if (throwableToCheck.getCause() == null) {
				LOGGER.warn("Unable to get severity level from route and hierarchy, giving up.");
				return TYPE_ERROR;
			}
			throwableToCheck = throwableToCheck.getCause();
		}
	}

	public static boolean isOdissyError(Exchange exchange) {
		Throwable throwableToCheck = exchange.getProperty("CamelExceptionCaught", Throwable.class);
		if (throwableToCheck == null) {
			return false;
		}
		while (true) {
			if (throwableToCheck instanceof OdissyErrorException) {
				exchange.setProperty("CamelExceptionCaught", throwableToCheck);
				return true;
			}
			if (throwableToCheck.getCause() == null) {
				return false;
			}
			throwableToCheck = throwableToCheck.getCause();
		}
	}
	
	public static String getFullErrorDescription(Exchange exchange) {
		Throwable throwableToCheck = exchange.getProperty("CamelExceptionCaught", Throwable.class);
		if (throwableToCheck == null) {
			return "Error handling called, but no camel exception caught.";
		}
		StringWriter stringWriter = new StringWriter();
		if (throwableToCheck instanceof OdissyErrorException) {
			OdissyErrorException odissyError = (OdissyErrorException) throwableToCheck;
			if (ErrorTypeModel.ERROR_TYPE_FUNCTIONAL.equals(odissyError.getExceptionType())) {
				stringWriter.write(odissyError.getErrorDescription());
				return stringWriter.toString();
			}
		}
		stringWriter.write(throwableToCheck.getMessage());
		stringWriter.write("\r\n");
		PrintWriter writer = new PrintWriter(stringWriter);
		throwableToCheck.printStackTrace(writer);
		return stringWriter.toString();
	}
	
	/** 
	 * in this function there is logic which checks if the error 
	 * is Business or technical according to the Code. 
	 * This information is used from the template to decide 
	 * if it writes in the no completed journal 
	 * 
	 * */
	public static boolean checkBusinessException(Exchange exchange){
		Document doc = exchange.getIn().getBody(Document.class);
		
		
		
		String errorCodeStr = FormatUtils.getValue(doc, "//*:ErrorMessage/*:ErrorCode");
		String systemTypeStr = FormatUtils.getValue(doc, "//*:ErrorMessage/*:SourceSystem");
		String descriptionStr = FormatUtils.getValue(doc, "//*:ErrorMessage/*:Description");
		String parameterValues = FormatUtils.getValue(doc, "//*:ErrorMessage/*:ParameterValues");
		
		
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("errorCodeStr:" + errorCodeStr);
			LOGGER.debug("systemTypeStr:" + systemTypeStr);
			LOGGER.debug("descriptionStr:" + descriptionStr);
			LOGGER.debug("parameterValues:" + parameterValues);
		}
		boolean retVal = false;
		if(!StringUtils.isEmpty(errorCodeStr) && !StringUtils.isEmpty(systemTypeStr)
			&&	NumberUtils.isCreatable(errorCodeStr) && NumberUtils.isCreatable(systemTypeStr)){
			
						
			int errorCode = Integer.parseInt(errorCodeStr);
			int systemType = Integer.parseInt(systemTypeStr);
			
			switch (systemType) {
			case 2:
			case 4:
				if(errorCode!= 300001)
					retVal = true;
				break;
			case 6:
				//TODO Check with Accenture for technical errors
				retVal = true;
				break;
			case 5:
				if (errorCode <= 100000) {
					if (errorCode != 30 && errorCode !=31){
						retVal =  true;	
					} 
				}		
			}
		}
		// Put info to Journal Map
		if (retVal){
			if (exchange != null && exchange.getProperty("journalMap") != null){
				@SuppressWarnings("unchecked")
				Map<String, Object> m = (Map<String, Object>)exchange.getProperty("journalMap");
				m.put("TLayer", systemTypeStr);
				m.put("TErrorCode", errorCodeStr);
				if (descriptionStr != null){
					m.put("TErrorTrace", descriptionStr.substring(0,Math.min(50, descriptionStr.length())));	
				}
				
				if (!parameterValues.isEmpty()){
					m.put("TParameterValues", parameterValues.substring(0,Math.min(150, parameterValues.length())));
				}
				
				if (LOGGER.isDebugEnabled()){
					LOGGER.debug("Map:" + Arrays.toString(m.entrySet().toArray()));
				}
			}
		}
		
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("retVal:" + retVal);
		}
		return retVal;
	}
	
	public static void  throwOdisseyException(String errorInComponent,
											  String odisseyErrorCode,
											  String translatedErrorCode,
											  String errorLevel,
											  String errorMessage
											) throws CBSException {

		String errorType = ErrorTypeModel.ERROR_TYPE_FUNCTIONAL;
		String errorInSystem = ErrorTypeModel.ERROR_SYSTEM_ID_FUSE;
		String errorCode = "";
		
		LOGGER.debug("Odissey Exception");
		LOGGER.debug("odisseyErrorCode :"+odisseyErrorCode);
		LOGGER.debug("translatedErrorCode :"+translatedErrorCode);
		LOGGER.debug("errorMessage :"+errorMessage);
		
		
		// in case that a translatedErrorCode different than the zero (0) value is returned, then this errorCode will be propagated with empty errorMessage as functional (business) error
		// otherwise, the 300656 odissey generic MW error code will be propagated with the errorMessage received from Odissey as technical error
		if(translatedErrorCode.equalsIgnoreCase("0")){
			errorCode = "300656";
			errorMessage = odisseyErrorCode+" "+errorMessage;
			errorType = ErrorTypeModel.ERROR_TYPE_TECHNICAL;
		}
		else{
			errorCode = translatedErrorCode;
		}
		
		LOGGER.debug("errorCode :"+errorCode);

		
		throwCBSException(null, errorType, errorInSystem, errorInComponent, errorCode, errorLevel, errorMessage, " ", " ", null);
		
	}
	
	public static void  throwOdisseyException(String errorInComponent,
				  String odisseyErrorCode,
				  String translatedErrorCode,
				  String errorLevel,
				  String errorMessage,
				  String parameterValues
				) throws CBSException {
	
		String errorType = ErrorTypeModel.ERROR_TYPE_FUNCTIONAL;
		String errorInSystem = ErrorTypeModel.ERROR_SYSTEM_ID_FUSE;
		String errorCode = "";
		
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Odissey Exception");
			LOGGER.debug("odisseyErrorCode :"+odisseyErrorCode);
			LOGGER.debug("translatedErrorCode :"+translatedErrorCode);
			LOGGER.debug("errorMessage :"+errorMessage);
			LOGGER.debug("parameterValues :"+parameterValues);
		}
		
		// in case that a translatedErrorCode different than the zero (0) value is returned, then this errorCode will be propagated with empty errorMessage as functional (business) error
		// otherwise, the 300656 odissey generic MW error code will be propagated with the errorMessage received from Odissey as technical error
		if(translatedErrorCode.equalsIgnoreCase("0")){
		errorCode = "300656";
		errorMessage = odisseyErrorCode+" "+errorMessage;
		errorType = ErrorTypeModel.ERROR_TYPE_TECHNICAL;
		}
		else{
		errorCode = translatedErrorCode;
		}
		
		LOGGER.debug("errorCode :"+errorCode);


		throwCBSException(null, errorType, errorInSystem, errorInComponent, errorCode, errorLevel, errorMessage, " ", " ",parameterValues);
	
	}

}
