package gr.alpha.cbs.fuse.support;

import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import jakarta.xml.ws.BindingProvider;
import jakarta.xml.ws.Dispatch;
import jakarta.xml.ws.Service;
import jakarta.xml.ws.soap.SOAPBinding;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import java.io.InputStream;

public abstract class WsCallingProcessor implements Processor {
    private static final Logger logger = LoggerFactory.getLogger(WsCallingProcessor.class);

    private Service service = null;

    public abstract QName getServiceQName(); // This should set the service QName, e.g. new QName("http://fuse.ml.cbs.alpha.gr/timedeposits/", "timedeposits-transactional-at")
    public abstract QName getPortQName(); // This should set the port QName, e.g. new QName("http://fuse.ml.cbs.alpha.gr/timedeposits/", "TimedepositsATSOAP")
    public abstract String getURLString(); // This should set the URL, e.g. "https://cbsmtjfudev.centraltest.roottest.alphatest.ab/ops-time-deposits/timedeposits-transactional-at"

    public void modifyHandlerChain(BindingProvider bindingProvider) {
        // Intentionally empty. Override to modify the handler chain.
    }

    private synchronized void setUp() {
        if (service != null) {
            return;
        }
        QName serviceQName = getServiceQName();
        QName portQName = getPortQName();
        String urlString = getURLString() + "?wsdl";
        service = Service.create(serviceQName);
        service.addPort(portQName, SOAPBinding.SOAP11HTTP_BINDING, urlString);
    }

    @Override
    public void process(Exchange exchange) throws Exception {
        setUp();

        Dispatch<Source> sourceDispatch = service.createDispatch(getPortQName(), Source.class, Service.Mode.PAYLOAD);
        logger.info("Invoking xml request: " + exchange.getIn().getBody(String.class));

        sourceDispatch.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, getURLString());
        modifyHandlerChain(sourceDispatch);

        Source result = sourceDispatch.invoke(new StreamSource(exchange.getIn().getBody(InputStream.class)));
        exchange.getIn().setBody(result, Document.class);
        NodeList errorNodeList = exchange.getIn().getBody(Document.class).getElementsByTagName("ErrorMessage");
        if (errorNodeList.getLength() != 0) {
            Element errorElement = (Element) errorNodeList.item(0);
            ErrorTypeModel model = new ErrorTypeModel();
            model.setErrorType(safeGetFirstElementTextContent(errorElement.getElementsByTagName("ErrorType")));
            model.setSourceSystem(safeGetFirstElementTextContent(errorElement.getElementsByTagName("SourceSystem")));
            model.setComponent(safeGetFirstElementTextContent(errorElement.getElementsByTagName("Component")));
            model.setErrorCode(safeGetFirstElementTextContent(errorElement.getElementsByTagName("ErrorCode")));
            model.setSeverityLevel(safeGetFirstElementTextContent(errorElement.getElementsByTagName("SeverityLevel")));
            model.setSuggestions(safeGetFirstElementTextContent(errorElement.getElementsByTagName("Suggestions")));
            model.setDescription(safeGetFirstElementTextContent(errorElement.getElementsByTagName("Description")));
            model.setServerName(safeGetFirstElementTextContent(errorElement.getElementsByTagName("ServerName")));
            throw new CBSException(model);
        }
        logger.info("Received xml response: " + exchange.getIn().getBody(String.class));
    }

    private String safeGetFirstElementTextContent(NodeList nodeList) {
        if (nodeList == null || nodeList.getLength() == 0) {
            return "";
        }
        return nodeList.item(0).getTextContent();
    }

}
