package gr.alpha.cbs.fuse.common.support;

import io.quarkus.runtime.annotations.RegisterForReflection;
import org.jboss.logging.Logger;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@RegisterForReflection
public class TransactionConfig implements Serializable {

	private static final Logger logger = Logger.getLogger(TransactionConfig.class);

	private String eventCode;
	private String descriptionNative;
	private String descriptionForeign;
	private String aliasName;
	private String sourceApplication;
	private String serviceOperation;
	private String transactionNature;
	private String businessTaxonomy;
	private String reversalEvent;
	private String referenceNative;
	private String startDate;
	private String endDate;
	private String routeName;
	private String electronicSlipType;
	private List<String> electronicSlipTypeList;
	private List<String> templateIDList;
	private String eventType;
	private String unTransNumberType;
	private String commissionsTemplates;
	private String tagGroup;
	private String eventExMode;

	private boolean debit;
	private boolean credit;
	private boolean managerial;
	private boolean inquiry;
	private boolean restrictionGrouping;
	private boolean allowTransactionChannel;
	private boolean journal;
	private boolean vlm;
	private boolean bmr;
	private boolean genAlert;
	private boolean genEctronicSlip;
	private boolean genBUN;
	private boolean journalOnException;
	private boolean requiresApproval;
	private String accountingTemplate;
	private boolean checkDateValidation;
	private boolean hasTotals;
	private boolean reversal;
	private boolean sensitive;
	private boolean visible;

	private String operation;
	private String service;

	private String jtaTransactionTimeout;
	private String transactionElementTimeout;

	private boolean canReverse;

	private String reversalServiceOperation;
	private boolean generatesExtrait;
	private boolean persistsRequestPayload;
	private String acobFunctionCode;

	private boolean inPrintoutGroup;

	private boolean generatesDocumentRequirements;

	private boolean createBUN;

	public boolean isVisible() {
		return visible;
	}

	public void setVisible(boolean visible) {
		this.visible = visible;
	}

	public static Logger getLogger() {
		return logger;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}


	public boolean isReversal() {
		return reversal;
	}

	public void setReversal(boolean reversal) {
		this.reversal = reversal;
	}

	public boolean isAllowTransactionChannel() {
		return allowTransactionChannel;
	}

	public void setAllowTransactionChannel(boolean allowTransactionChannel) {
		this.allowTransactionChannel = allowTransactionChannel;
	}

	public boolean isHasTotals() {
		return hasTotals;
	}

	public void setHasTotals(boolean hasTotals) {
		this.hasTotals = hasTotals;
	}

	public boolean isCheckDateValidation() {
		return checkDateValidation;
	}

	public void setCheckDateValidation(boolean checkDateValidation) {
		this.checkDateValidation = checkDateValidation;
	}

	public String getRouteName() {
		return routeName;
	}

	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}

	public boolean getRequiresApproval() {
		return requiresApproval;
	}

	public void setRequiresApproval(boolean requiresApproval) {
		this.requiresApproval = requiresApproval;
	}

	public String getEventCode() {
		return eventCode;
	}

	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}

	public String getDescriptionNative() {
		return descriptionNative;
	}

	public void setDescriptionNative(String descriptionNative) {
		this.descriptionNative = descriptionNative;
	}

	public String getDescriptionForeign() {
		return descriptionForeign;
	}

	public void setDescriptionForeign(String descriptionForeign) {
		this.descriptionForeign = descriptionForeign;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public String getSourceApplication() {
		return sourceApplication;
	}

	public void setSourceApplication(String sourceApplication) {
		this.sourceApplication = sourceApplication;
	}

	public String getTransactionNature() {
		return transactionNature;
	}

	public void setTransactionNature(String transactionNature) {
		this.transactionNature = transactionNature;
	}

	public String getBusinessTaxonomy() {
		return businessTaxonomy;
	}

	public void setBusinessTaxonomy(String businessTaxonomy) {
		this.businessTaxonomy = businessTaxonomy;
	}

	public String getReversalEvent() {
		return reversalEvent;
	}

	public void setReversalEvent(String reversalEvent) {
		this.reversalEvent = reversalEvent;
	}

	public String getReferenceNative() {
		return referenceNative;
	}

	public void setReferenceNative(String referenceNative) {
		this.referenceNative = referenceNative;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public boolean getDebit() {
		return debit;
	}

	public void setDebit(boolean debit) {
		this.debit = debit;
	}

	public boolean getCredit() {
		return credit;
	}

	public void setCredit(boolean credit) {
		this.credit = credit;
	}

	public boolean getManagerial() {
		return managerial;
	}

	public void setManagerial(boolean managerial) {
		this.managerial = managerial;
	}

	public boolean getInquiry() {
		return inquiry;
	}

	public void setInquiry(boolean inquiry) {
		this.inquiry = inquiry;
	}

	public boolean getRestrictionGrouping() {
		return restrictionGrouping;
	}

	public void setRestrictionGrouping(boolean restrictionGrouping) {
		this.restrictionGrouping = restrictionGrouping;
	}

	public boolean getJournal() {
		return journal;
	}

	public void setJournal(boolean journal) {
		this.journal = journal;
	}

	public boolean getVlm() {
		return vlm;
	}

	public void setVlm(boolean vlm) {
		this.vlm = vlm;
	}

	public boolean getBmr() {
		return bmr;
	}

	public void setBmr(boolean bmr) {
		this.bmr = bmr;
	}

	public boolean getGenAlert() {
		return genAlert;
	}

	public void setGenAlert(boolean genAlert) {
		this.genAlert = genAlert;
	}

	public boolean getGenEctronicSlip() {
		return genEctronicSlip;
	}

	public void setGenEctronicSlip(boolean genEctronicSlip) {
		this.genEctronicSlip = genEctronicSlip;
	}

	public boolean getGenBUN() {
		return genBUN;
	}

	public void setGenBUN(boolean genBUN) {
		this.genBUN = genBUN;
	}

	public boolean getJournalOnException() {
		return journalOnException;
	}

	public void setJournalOnException(boolean journalOnException) {
		this.journalOnException = journalOnException;
	}

	public String getElectronicSlipType() {
		return electronicSlipType;
	}

	public void setElectronicSlipType(String electronicSlipType) {
		this.electronicSlipType = electronicSlipType;
	}

	public List<String> getElectronicSlipTypeList() {
		if (electronicSlipTypeList == null) {
			electronicSlipTypeList = new ArrayList<>();
		}
		return electronicSlipTypeList;
	}

	public void setElectronicSlipTypeList(List<String> electronicSlipTypeList) {
		this.electronicSlipTypeList = electronicSlipTypeList;
	}

	public List<String> getTemplateIDList() {
		if (templateIDList == null) {
			templateIDList = new ArrayList<>();
		}
		return templateIDList;
	}

	public void setTemplateIDList(List<String> templateIDList) {
		this.templateIDList = templateIDList;
	}

	public void addElectronicSlipTypeAndTemplateID(String electronicSlipType, String templateID) {
		getElectronicSlipTypeList().add(electronicSlipType);
		getTemplateIDList().add(templateID);
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getUnTransNumberType() {
		return unTransNumberType;
	}

	public void setUnTransNumberType(String unTransNumberType) {
		this.unTransNumberType = unTransNumberType;
	}

	public String getServiceOperation() {
		return serviceOperation;
	}

	public void setServiceOperation(String serviceOperation) {
		this.serviceOperation = serviceOperation;
	}

	public String getCommissionsTemplates() {
		return commissionsTemplates;
	}

	public void setCommissionsTemplates(String commissionsTemplates) {
		this.commissionsTemplates = commissionsTemplates;
	}

	public String getTagGroup() {
		return tagGroup;
	}

	public void setTagGroup(String tagGroup) {
		this.tagGroup = tagGroup;
	}

	public String getAccountingTemplate() {
		return accountingTemplate;
	}

	public void setAccountingTemplate(String accountingTemplate) {
		this.accountingTemplate = accountingTemplate;
	}

	public String getEventExMode() {
		return eventExMode;
	}

	public void setEventExMode(String eventExMode) {
		this.eventExMode = eventExMode;
	}

	public boolean isSensitive() {
		return sensitive;
	}

	public void setSensitive(boolean sensitive) {
		this.sensitive = sensitive;
	}

	public String getJtaTransactionTimeout() {
		return jtaTransactionTimeout;
	}

	public void setJtaTransactionTimeout(String jtaTransactionTimeout) {
		this.jtaTransactionTimeout = jtaTransactionTimeout;
	}

	public String getTransactionElementTimeout() {
		return transactionElementTimeout;
	}

	public void setTransactionElementTimeout(String transactionElementTimeout) {
		this.transactionElementTimeout = transactionElementTimeout;
	}

	public boolean isCanReverse() {
		return canReverse;
	}

	public void setCanReverse(boolean canReverse) {
		this.canReverse = canReverse;
	}

	public String getReversalServiceOperation() {
		return reversalServiceOperation;
	}

	public void setReversalServiceOperation(String reversalServiceOperation) {
		this.reversalServiceOperation = reversalServiceOperation;
	}

	public boolean getGeneratesExtrait() {
		return generatesExtrait;
	}

	public void setGeneratesExtrait(boolean generatesExtrait) {
		this.generatesExtrait = generatesExtrait;
	}

	public boolean getPersistsRequestPayload() {
		return persistsRequestPayload;
	}

	public void setPersistsRequestPayload(boolean persistsRequestPayload) {
		this.persistsRequestPayload = persistsRequestPayload;
	}

	public String getAcobFunctionCode() {
		return acobFunctionCode;
	}

	public void setAcobFunctionCode(String acobFunctionCode) {
		this.acobFunctionCode = acobFunctionCode;
	}

	public boolean isInPrintoutGroup() {
		return inPrintoutGroup;
	}

	public void setInPrintoutGroup(boolean inPrintoutGroup) {
		this.inPrintoutGroup = inPrintoutGroup;
	}

	public boolean getGeneratesDocumentRequirements() {
		return generatesDocumentRequirements;
	}

	public void setGeneratesDocumentRequirements(boolean generatesDocumentRequirements) {
		this.generatesDocumentRequirements = generatesDocumentRequirements;
	}

	public boolean getCreateBUN() {
		return createBUN;
	}

	public void setCreateBUN(boolean createBUN) {
		this.createBUN = createBUN;
	}

	@Override
	public String toString() {
		return "TransactionConfig [eventCode=" + eventCode + ", descriptionNative=" + descriptionNative
				+ ", descriptionForeign=" + descriptionForeign + ", aliasName=" + aliasName + ", sourceApplication="
				+ sourceApplication + ", transactionNature=" + transactionNature + ", businessTaxonomy="
				+ businessTaxonomy + ", reversalEvent=" + reversalEvent + ", referenceNative=" + referenceNative
				+ ", startDate=" + startDate + ", endDate=" + endDate + ", debit=" + debit + ", credit=" + credit
				+ ", managerial=" + managerial + ", inquiry=" + inquiry + ", restrictionGrouping=" + restrictionGrouping
				+ ", journal=" + journal + ", vlm=" + vlm + ", bmr=" + bmr + ", genAlert=" + genAlert
				+ ", genEctronicSlip=" + genEctronicSlip + getSlipTypeAndTemplateInfo() + ", genBUN=" + genBUN + ", JournalOnException="
				+ journalOnException + ", electronicSlipType=" + electronicSlipType + ", eventMode=" + eventExMode
				+ ", EventType=" + eventType + ", unTransNumberType=" + unTransNumberType + ", accountingTemplate="
				+ accountingTemplate + ", serviceOperation=" + serviceOperation + ", commissionsTemplates="
				+ commissionsTemplates + ", tagGroup=" + tagGroup + ", generatesExtrait=" + generatesExtrait
				+ ", persistsRequestPayload=" + persistsRequestPayload + ", acobFunctionCode=" + acobFunctionCode
				+ ", generatesDocumentRequirements=" + generatesDocumentRequirements
				+ ", createBUN=" + createBUN
				+ ", inPrintoutGroup=" + inPrintoutGroup + "]";
	}

	private String getSlipTypeAndTemplateInfo() {
		if (getElectronicSlipTypeList().size() != getTemplateIDList().size()) {
			logger.warn("Electronic slip type list has different size from template "
					+ "ID list (" + electronicSlipTypeList.size() + "," + templateIDList.size() + ").");
		}
		StringBuilder sb = new StringBuilder();
		sb.append(" [");
		for (int i = 0; i < Math.min(electronicSlipTypeList.size(), templateIDList.size()); i++) {
			String electronicSlipType = electronicSlipTypeList.get(i);
			String templateID = templateIDList.get(i);
			if (sb.length() != 2) {
				sb.append(",");
			}
			sb.append("(electronic slip type: ");
			sb.append(electronicSlipType);
			sb.append(", template ID: ");
			sb.append(templateID);
			sb.append(")");
		}
		sb.append("]");
		return sb.toString();
	}

	public static TransactionConfig getDefaultTransactionConfig() {

		TransactionConfig tc = new TransactionConfig();
		tc.setEventCode("111");
		tc.setDescriptionNative("defaultTransaction");
		tc.setDescriptionForeign("defaultTransaction");
		tc.setAliasName("A01");
		tc.setSourceApplication("TEST");
		tc.setOperation("operation");
		tc.setTransactionNature("transactionNature");
		tc.setBusinessTaxonomy("taxonomy");
		tc.setReversalEvent("revEvent");
		tc.setRouteName("routeName");
		tc.setElectronicSlipType("0");
		tc.setEventType("9");
		tc.setVisible(true);
		tc.setUnTransNumberType("0");
		tc.setEventExMode("1");
		tc.setCreateBUN(true);

		return tc;

	}

}
