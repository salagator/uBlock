package gr.alpha.cbs.fuse.common.ifaces;

import java.util.List;

public interface RefDataTranslator {
	public String translateData(String fromSystem, String toSystem, String parentName, String value) throws Exception;
	public String translateDataOrReturnNull(String fromSystem, String toSystem, String parentName, String value) throws Exception;
	public String reverseTranslateData(String fromSystem, String toSystem, String parentName, String description) throws Exception;
	public List<String> reverseTranslateAll(String fromSystem, String toSystem, String parentName, String description) throws Exception;
}
