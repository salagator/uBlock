package gr.alpha.cbs.fuse.common.tools;

public class AlternativePathsFlagHolder {
    private static final ThreadLocal<Boolean> alternativePathsFlag =
            ThreadLocal.withInitial(() -> Boolean.FALSE);

    public static void setAlternativePathsFlag(boolean flag) {
        alternativePathsFlag.set(flag);
    }

    public static boolean isAlternativePathsFlag() {
        return alternativePathsFlag.get();
    }

}
