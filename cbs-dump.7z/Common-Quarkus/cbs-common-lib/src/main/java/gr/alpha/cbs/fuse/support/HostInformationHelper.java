package gr.alpha.cbs.fuse.support;

import java.net.UnknownHostException;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Named;

import io.quarkus.runtime.annotations.RegisterForReflection;
import org.apache.camel.util.HostUtils;

/**
 * Used in order to adorn error reporting messages with the proper host name
 * and IP address of the machine where the error was generated.
 */
@Named("hostInformationHelper")
@Dependent
@RegisterForReflection
public class HostInformationHelper {
	HostInformationHelper(){
		//Utility class should not have public constructor
	}
	
	public static String getHostname() throws UnknownHostException {
		return HostUtils.getLocalHostName();
	}
	
	public static String getHostIP() throws UnknownHostException {
		return HostUtils.getLocalIp();
	}
	
	/**
	 * Wildfly specific implementation - not applicable to Quarkus: reverting to localhost
	 */
	public static String getHostWSUrl(boolean secure) throws Exception  {
		
		return  "http://localhost:8080";
	}
	

}
