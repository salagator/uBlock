package gr.alpha.cbs.fuse.common;

public interface CBSConstants {
	int DEFAULT_HOST_TIMEOUT = 60000;

	/*
	 * The following are the names that are used to store the "logging" information on the
	 * MDC log4j infrastructure.
	 */
	String MDC_KEY_REQUEST_ID = "cbs.RequestId";
	String MDC_KEY_SESSION_ID = "cbs.SessionId";
	String MDC_KEY_BUSINESS_CASE_ID = "cbs.BusinessCaseId";
	String MDC_KEY_SEQUENCE_ID = "cbs.SequenceId";
	String MDC_KEY_USER_ID = "cbs.UserId";
	String MDC_KEY_CBS_UN_ID = "cbs.CBSUnId";

	/**
	 * Camel property that tells the runtime whether calls to the backend systems should take part in the 2PC.
	 */
	String PROPERTY_TAKE_PART_IN_2PC = "cbs.op.takes.part.in.2pc";

	/**
	 * Camel header name used to hold the BUN on routes.
	 */
	String HEADER_BUN = "cbs.common.bun";

	/**
	 * Camel header name used to hold the BUN in decimal format on routes.
	 */
	String HEADER_BUN_DECIMAL = "cbs.common.bunDecimal";

	/**
	 * Camel header name used to hold the unique ID generated when the BUN was created. The route needs to keep
	 * this header until the end so that the code in the BUNHandlerBean can perform the logic
	 * that links TUNs with the BUN.
	 */
	String HEADER_BUN_REFERENCE = "cbs.common.bunReference";

	/**
	 * Camel header name that is used to hold the system ID, so that the BUNHandlerBean can look it up
	 * when recording the list of TUN/SystemID pairs associated with the BUN.
	 */
	String HEADER_SYSTEM_ID = "cbs.common.systemId";

	/**
	 * Camel header name that is used to hold the TUN, so that the BUNHandlerBean can look it up
	 * when recording the list of TUN/SystemID pairs associated with the BUN.
	 */
	String HEADER_TUN = "cbs.transaction.un";

	/**
	 * Camel header name that is used by the SIGLO component to hold the transaction name so that
	 * the appropriate operation (service) can be invoked in the SIGLO back end.
	 */
	String HEADER_SIGLO_TRANSACTION = "cbs.siglo.transaction";

	/**
	 * Camel header name that is used by the SIGLO component to hold the last warning issued by
	 * the back end during the orchestration of SIGLO calls. It is the responsibility of the
	 * camel route to pass this information up to the channel caller.
	 */
	String HEADER_SIGLO_WARNING = "cbs.siglo.warning";

	/**
	 * Camel header name that is used by the SIGLO component to hold the service name that issued the
	 * last warning by the back end during the orchestration of SIGLO calls. It is the responsibility
	 * of the camel route to pass this information up to the channel caller.
	 */
	String HEADER_SIGLO_WARNING_SERVICE_NAME = "cbs.siglo.warning.service.name";

	/**
	 * Camel header name that is used by the SIGLO component to hold the terminal id so that
	 * passed to the SIGLO back end for reporting purposes.
	 */
	String HEADER_SIGLO_TERMINAL_ID = "cbs.siglo.terminal.id";

	/**
	 * Camel header name that is used by the SIGLO routes that also need to interact
	 * with the Finesse system. For reporting purposes the BBBMMK information needs to be
	 * passed to the Finesse system (potentially through the Odissy ESB). 
	 */
	String HEADER_SIGLO_BBBMMK = "cbs.siglo.bbbmmk";

	/**
	 * Camel header name that is used to "override" the normal helper lookup logic, in the case
	 * when the normal operation does not apply (e.g. when AIS00002 -> AI00002 is not valid).
	 */
	String HEADER_SIGLO_HELPER_LOOKUP = "cbs.siglo.helper.lookup";

	/**
	 * Camel header name that is used to hold the channel type. 
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_CHANNEL_TYPE = "cbs.common.channelTypeCode";

	/**
	 * Camel header name that is used to hold the bank code. 
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_BANK_CODE = "cbs.common.bank";

	/**
	 * Camel header name that is used to hold the resource id. 
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_RESOURCE_ID = "cbs.common.resourceId";

	/**
	 * Camel header name that is used to hold the resource type. 
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_RESOURCE_TYPE = "cbs.common.resourceType";

	/**
	 * Camel header name that is used to hold the branch code. 
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_BRANCH_CODE = "cbs.common.branch";

	/**
	 * Camel header name that is used to hold the unit type code. 
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_UNIT_TYPE_CODE = "cbs.common.unitTypeCode";

	/**
	 * Camel header name that is used to hold the first alias in the list of aliases. 
	 * It is passed to the SIGLO back end upon existence in preference to the unit code above.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_ALIAS_CODE = "cbs.common.aliasCode";

	/**
	 * Camel header name that is used to hold the request id.
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_REQUEST_ID = "cbs.common.requestId";

	/**
	 * Camel header name that is used to hold the front end session id. 
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_FRONT_END_SESSION_ID = "cbs.common.frontEndSessionId";

	/**
	 * Camel header name that is used to hold the business case id.
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_BUSINESS_CASE_ID = "cbs.common.businessCaseId";

	/**
	 * Camel header name that is used to hold the sequence id. 
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_SEQUENCE_ID = "cbs.common.sequenceId";

	/**
	 * Camel header name that is used to hold the user id. 
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_USER_ID = "cbs.common.userId";


	String HEADER_CBS_UID ="cbs.common.cbsuid";

	/**
	 * Camel header name that is used to hold the working date of the system. 
	 * It is used in the header part of the OLTP Buffer as logging information and in the
	 * data part of the OLTP Buffer in the different contracts of the host components.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_WORK_DATE = "cbs.common.workDate";

	/**
	 * Camel header name that is used to hold the previous date of the system according to the working Date. 
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_PREVIOUS_DATE = "cbs.common.previousDate";

	/**
	 * Camel header name that is used to hold the next date of the system according to the working Date. 
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_NEXT_DATE = "cbs.common.nextDate";

	/**
	 * Camel header name that is used to hold the valeur date for SIGLO. 
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_VALEUR_DATE = "cbs.common.valeurDate";

	/**
	 * Camel header name that is used to hold the valeur date for SIGLO. 
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_MACHINE_DATE = "cbs.common.machineDate";

	/**
	 * Camel header name that is used to hold the local branch working date of the system. 
	 * It is used in the header part of the OLTP Buffer as logging information and in the
	 * data part of the OLTP Buffer in the different contracts of the host components.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_LOCAL_WORK_DATE = "cbs.common.localWorkDate";

	/**
	 * Camel header name that is used to hold the local branch previous date of the system according to the local branch working Date. 
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_LOCAL_PREVIOUS_DATE = "cbs.common.localPreviousDate";

	/**
	 * Camel header name that is used to hold the local branch next date of the system according to the local branch working Date. 
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_LOCAL_NEXT_DATE = "cbs.common.localNextDate";

	/**
	 * Camel header name that is used to hold the language of the UI.
	 */
	String HEADER_LANGUAGE = "cbs.common.language";

	/**
	 * Camel header name that is used to hold whether the card reader is present or not.
	 */
	String HEADER_CARD_READER_PRESENT = "cbs.common.card.reader.present";

	/**
	 * Camel header name that is used to hold the release type.
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_RELEASE_TYPE = "cbs.common.releaseType";

	/**
	 * Camel header name that is used to hold the Team Code.
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_TEAM_CODE = "cbs.common.teamCode";

	/**
	 * Camel header name that is used to hold the Group Code
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_GROUP_CODE = "cbs.common.groupCode";

	/**
	 * Camel header name that is used to hold the Flow Type
	 * It is used in the header part of the OLTP Buffer as logging information.
	 * It is passed by the payload into the camel route.
	 */
	String HEADER_FLOW_TYPE = "cbs.common.flowType";

	/**
	 * Camel property name that is used to hold the Odissy DUN
	 * Property's value is set in the transactionTemplate, using the 
	 * createDUN method of the BUNHandlerEjb 
	 */
	String HEADER_ODISSY_DUN = "cbs.odissy.dun";

	/** ESB System ID (1).<br>Used by the addTUN method as the TUN/System mapping */
	String SYSTEM_ID_ESB = "2";

	/** Odissy System ID (4).<br>Used by the createDUN  method as the mapping to the REF_SystemTypes */
	String SYSTEM_ID_ODISSY = "4";

	/**
	 * Camel header name that is used to hold the name of the transaction. It is used in the BunHandler to create 
	 * bun for the transaction.
	 */
	String HEADER_TRANSACTION_NAME = "cbs.common.transactionTypeId";
	String HEADER_TRANSACTION_FLOW = "cbs.common.transactionFlow";
	String HEADER_TRANSACTION_SERVICE = "cbs.common.service";
	String HEADER_INNER_CONTEXT ="cbs.common.innerCamelContextId";
	String HEADER_INNER_START ="cbs.common.inner-start";
	String HEADER_CALL_ADD_UN = "cbs.common.add-unique-number";

	String HEADER_ERROR_OCCURED = "cbs.common.errorOccured";

	/**
	 * Camel headers used to control whether "global" context wide hooks for sub-routes that specify the behavior
	 * of certain points during the request processing are used, or if (the default) transactionTypeId specific
	 * sub-routes will be used.
	 * This can be achieved per hook point by using the appropriate <code>HEADER_USE_GLOBAL_*hookPointName*</code>.
	 */
	String HEADER_USE_GLOBAL_PREPARE_BUN_HANDLER = "cbs.common.use.global.prepare.bun.handler";
	String HEADER_USE_GLOBAL_FAILURE_HANDLER = "cbs.common.use.global.failure.handler";
	String HEADER_USE_GLOBAL_CALL_SUCESS = "cbs.common.use.global.call.success";

	/**
	 * Camel headers used to control the printing horizontal.
	 */
	String HEADER_PRINTING_SLIP_TYPE = "cbs.common.printing.slip.type";
	String HEADER_PRINTING_STATUS = "cbs.common.printing.status";
	String HEADER_PRINTING_MODE = "cbs.common.printing.mode";
	String HEADER_PRINTING_TEMPLATE_CODE = "cbs.common.printing.reference.template.code";

	/** System Name of UI (UFE) */
	String REF_DATA_SYSTEM_UI = "UFE";
	/** System name of SIGLO (Siglo) */
	String REF_DATA_SYSTEM_SIGLO = "Siglo";
	/** System name of OS2200 (OS2200) */
	String REF_DATA_SYSTEM_OS2200 = "OS2200";

	//TODO Currently not exist in event registry
	/** System Name of Fuse (ESB) */
	String REF_DATA_SYSTEM_ESB = "ESB";
	/** System Name of BPM (BPM) */
	String REF_DATA_SYSTEM_BPM = "BPM";
	/** System Name of BRMS (BRMS) */
	String REF_DATA_SYSTEM_BRMS = "BRMS";
	//TODO Currently not exist in event registry

	//Removed 12-09-2017
	//	String REF_NAME_ALERT_KINDS = "AlertKinds";
	//	String REF_NAME_ALERT_SOURCE = "AlertSource";
	//	String REF_NAME_COOPERATION_STATUSES = "CooperationStatuses";
	//	String REF_NAME_TIME_DEPOSIT_EVENT_ON_MATURITY = "TimeDepositEventOnMaturity";

	//Reference data Group Names
	String REF_NAME_ADDRESS_TYPES = "AddressTypes";
	String REF_NAME_CERTIFICATE_TYPES = "CertificateTypes";
	String REF_NAME_DOYS = "DOYs";
	String REF_NAME_GENDERS = "Genders";
	String REF_NAME_NATIONALITIES = "Nationalities";
	String REF_NAME_LANGUAGES = "Languages";
	String REF_NAME_COUNTRIES = "Countries";
	String REF_NAME_WORK_POS_INDIVIDUALS = "WorkPosIndividuals";
	String REF_NAME_JOBS = "Jobs";
	String REF_NAME_COMPANY_STATUSES = "CompanyStatuses";
	String REF_NAME_LAP_CATEGORIES = "LAPCategories";
	String REF_NAME_CUSTOMER_CATEGORIES = "CustomerCategories";
	String REF_NAME_BRANCHES = "Branches";
	String REF_NAME_CURRENCIES = "Currencies";
	String REF_NAME_MEMBER_RELATIONS = "MemberRelations";
	String REF_NAME_YOUTH_TYPES = "YouthTypes";
	String REF_NAME_ACCOUNT_CATEGORIES = "AccountCategories";
	String REF_NAME_ACCOUNT_OPEN_CATEGORIES = "AccountOpenCategories";
	String REF_NAME_PROFESSION_TYPES = "ProfessionTypes";
	String REF_NAME_ACCOUNT_OPEN_REASON_CODES = "AccountOpenReasonCodes";
	String REF_NAME_MENU_FUNCTION_CODES = "MenuFunctionCodes";
	String REF_NAME_MISSING_DATA = "MissingData";
	String REF_NAME_FREQUENCY_CODES = "FrequencyCodes";
	String REF_NAME_AMKA_REASON_CODES = "AMKAReasonCodes";
	String REF_NAME_EXTRAIT_DELIVERY_METHOD_TYPES = "ExtraitDeliveryMethodTypes";
	String REF_NAME_SWIFT_TYPES = "SWIFTTypes";
	String REF_NAME_MEMBER_RELATION_TYPES = "MemberRelationTypes";
	String REF_NAME_ORDERING_DESCRIPTIONS = "OrderingDescriptions";
	String REF_NAME_ORDERING_NUMBERS = "OrderingNumbers";
	String REF_NAME_CUSTOMER_CATEGORY_TYPES = "CustomerCategoryTypes";
	String REF_NAME_FINANCE_AREAS = "FinanceAreas";
	String REF_NAME_MANAGEMENT_UNITS = "ManagementUnits";
	String REF_NAME_FINANCIAL_SECTORS = "FinancialSectors";
	String REF_NAME_RELEASE_TYPES = "ReleaseTypes";
	String REF_NAME_VERSION_DIRECTIVES = "VersionDirectives";
	String REF_NAME_ZIPCODES = "ZipCodes";
	String REF_NAME_CDI_FAX_MAIL_LANG = "CdiFaxMailLang";
	String REF_NAME_DOCUMENT_CATEGORIES = "DocumentCategories";
	String REF_NAME_AFM_CERTIFICATION_DOCS = "AFMCertificationDocs";
	String REF_NAME_AML_LISTS = "AMLLists";
	String REF_NAME_CUSTOMER_CATEGORIES_PEL = "CustomerCategoriesPEL";
	String REF_NAME_DOCUMENT_CERTIFICATION_STATUSES = "DocumentCertificationStatuses";
	String REF_NAME_DOCUMENT_CERTIFICATION_STATUSES_AFM = "DocumentCertificationStatusesAfm";
	String REF_NAME_DOCUMENT_CERTIFICATION_STATUSES_HOME_ADDRESS = "DocumentCertificationStatusesHomeAddress";
	String REF_NAME_DOCUMENT_CERTIFICATION_STATUSES_JOB = "DocumentCertificationStatusesJob";
	String REF_NAME_DOCUMENT_CERTIFICATION_STATUSES_PHONE = "PhoneCertificationStatuses";
	String REF_NAME_DOCUMENT_CERTIFICATION_STATUSES_W8W9 = "W8W9DocumentStatuses";
	String REF_NAME_DOCUMENT_CERTIFICATION_STATUSES_WORK_ADDRESS = "DocumentCertificationStatusesWorkAddress";
	String REF_NAME_FATCA_W8W9 = "FatcaW8W9";
	String REF_NAME_HOME_ADDRESS_CERTIFICATION_DOCS = "HomeAddressCertificationDocs";
	String REF_NAME_INCORPORATION_TYPES = "IncorporationTypes";
	String REF_NAME_JOB_CERTIFICATION_DOCS = "JobCertificationDocs";
	String REF_NAME_LAST_TRANSACTION_TYPES = "LastTransactionTypes";
	String REF_NAME_PHONE_CERTIFICATION_DOCS = "PhoneCertificationDocs";
	String REF_NAME_RISK_CATEGORIES = "RiskCategories";
	String REF_NAME_RISK_CATEGORY_REASON_CODES = "RiskCategoryReasonCodes";
	String REF_NAME_STAKOD = "STAKOD";
	String REF_NAME_W8W9_CERTIFICATION_DOCS = "W8W9CertificationDocs";
	String REF_NAME_WORK_ADDRESS_CERTIFICATION_DOCS = "WorkAddressCertificationDocs";


	String REF_NAME_YES_NO_OPTION = "YesNoOption";

	//Added 14-07-2017
	String REF_NAME_ACCOUNT_BALANCE_FLAG = "AccountBalanceFlag";
	String REF_NAME_ACCOUNT_CLOSING_REASON_CODES = "AccountClosingReasonCodes";
	String REF_NAME_ACCOUNT_EMPLOYEE_TYPE = "AccountEmployeeType";
	String REF_NAME_ACCOUNT_ESTATEMENT_INDICATOR = "AccountEstatementIndicator";
	String REF_NAME_ACCOUNT_F_C_BENEFICIARY_CATEGORY = "AccountFCBeneficiaryCategory";
	String REF_NAME_ACCOUNT_OVERDRAFT_REQUEST = "AccountOverdraftRequest";
	String REF_NAME_ACCOUNT_POLITICAL_INDICATOR = "AccountPoliticalIndicator";
	String REF_NAME_ACCOUNT_SALARY_FLAG = "AccountSalaryFlag";
	String REF_NAME_ACCOUNT_SALARY_KINDS = "AccountSalaryKinds";
	String REF_NAME_ACCOUNT_STATUS_ACTIVE_FLAG = "AccountStatusActiveFlag";
	String REF_NAME_ACCOUNT_STATUSES = "AccountStatuses";
	String REF_NAME_BLOCK_ACCOUNT_INDICATORS = "BlockAccountIndicators";
	String REF_NAME_BLOCK_LIMIT_FLAG = "BlockLimitFlag";
	String REF_NAME_CHANGE_TYPES = "ChangeTypes";
	String REF_NAME_CHANNEL_TYPES = "ChannelTypes";
	String REF_NAME_CHECK_GUN_FLAG = "CheckGUNFlag";
	String REF_NAME_CLASSIFICATION_DECLASSIFICATION = "ClassificationDeclassification";
	String REF_NAME_COUNTRIES_ISO = "CountriesISO";
	String REF_NAME_CREDIT_SPREAD_TYPES = "CreditSpreadTypes";
	String REF_NAME_CURRENCIES_ISO = "CurrenciesISO";
	String REF_NAME_CUSTOMER_ALTERNATIVE_CHANNEL_INDICATOR = "CustomerAlternativeChannelIndicator";
	String REF_NAME_CUSTOMER_DELAY_REASONS = "CustomerDelayReasons";
	String REF_NAME_CUSTOMER_RELATION_ACTIONS = "CustomerRelationActions";
	String REF_NAME_DEBIT_CREDIT_INDICATOR = "DebitCreditIndicator";
	String REF_NAME_DEBIT_SPREAD_TYPES = "DebitSpreadTypes";
	String REF_NAME_DOCUMENT_ACTION_TYPES = "DocumentActionTypes";
	String REF_NAME_EMPLOYEE_FLAG = "EmployeeFlag";
	String REF_NAME_ERROR_LEVELS = "Error_Levels";
	String REF_NAME_ERROR_SYSTEM_I_DS = "Error_System_IDs";
	String REF_NAME_ERROR_TYPES = "Error_Types";
	String REF_NAME_EXTRAIT_DELIVERY_ADDRESS_TYPES = "ExtraitDeliveryAddressTypes";
	String REF_NAME_EXTRAIT_DELIVERY_FREQUENCIES = "ExtraitDeliveryFrequencies";
	String REF_NAME_EXTRAIT_LANGUAGES = "ExtraitLanguages";
	String REF_NAME_INTEREST_CATEGORIES = "InterestCategories";
	String REF_NAME_INTEREST_TYPES = "InterestTypes";
	String REF_NAME_PASS_BOOK_ACCOUNT_KIND_CHECKS = "PassBookAccountKindChecks";
	String REF_NAME_PASSBOOK_STATUS_INDICATORS = "PassbookStatusIndicators";
	String REF_NAME_RESOURCE_IDENTIFIER_TYPES = "ResourceIdentifierTypes";
	String REF_NAME_RISK_CLASSIFICATION = "RiskClassification";
	String REF_NAME_TD_ACCOUNT_KIND_CHECKS = "TDAccountKindChecks";
	String REF_NAME_UNIT_TYPE = "UnitType";

	//Added 21-07-2017
	String REF_NAME_ABRS_MODELS = "ABRSModels";
	String REF_NAME_ABRS_RATINGS = "ABRSRatings";
	String REF_NAME_ACCOUNTING_BOOK_CLASS = "AccountingBookClass";
	String REF_NAME_ACCOUNT_OPENING_REASONS = "AccountOpeningReasons";
	String REF_NAME_ACCOUNT_PARTICIPANT_TYPES = "AccountParticipantTypes";
	String REF_NAME_ACCOUNT_PARTICIPANT_TYPES_ABBREVIATIONS = "AccountParticipantTypesAbbreviations";
	String REF_NAME_ACCOUNT_TYPES = "AccountTypes";
	String REF_NAME_ACTIVITY_SECTOR = "ActivitySector";
	String REF_NAME_ADDRESS_STREET_TYPES = "AddressStreetTypes";
	String REF_NAME_ADDRESS_TYPE = "AddressType";
	String REF_NAME_AGE_GROUPS = "AgeGroups";
	String REF_NAME_AICHANEL = "AICHANEL";
	String REF_NAME_AIDVLPGM = "AIDVLPGM";
	String REF_NAME_ALPHA_GROUP_EMPLOYEE = "AlphaGroupEmployee";
	String REF_NAME_APPLICATIONS = "Applications";
	String REF_NAME_APPROVED_LIMIT_STATUS = "ApprovedLimitStatus";
	String REF_NAME_ARRANGED_ACCOUNTS_TYPE_GROUPS = "ArrangedAccountsTypeGroups";
	String REF_NAME_ARRANGEMENT_APPLICATION_STATUS = "ArrangementApplicationStatus";
	String REF_NAME_ARRANGEMENT_FACILITATION_CHANNELS = "ArrangementFacilitationChannels";
	String REF_NAME_ARRANGEMENT_FACILITATION_ECHELONS = "ArrangementFacilitationEchelons";
	String REF_NAME_ARRANGEMENT_FAST_TRACK_STATUS = "ArrangementFastTrackStatus";
	String REF_NAME_ARREARS_MANAGEMENT_UNIT = "ArrearsManagementUnit";
	String REF_NAME_ARREARS_UNIT_ELIGIBLE_REASON = "ArrearsUnitEligibleReason";
	String REF_NAME_BOND_TYPES = "BondTypes";
	String REF_NAME_BUSINESS_ACTIVITY_COUNTRY = "BusinessActivityCountry";
	String REF_NAME_BUSINESS_CENTERS = "BusinessCenters";
	String REF_NAME_CONSTRUCTION_COMPANIES_CLASSES = "ConstructionCompaniesClasses";
	String REF_NAME_CONTRACT_SIGNATURE_STATUSES = "ContractSignatureStatuses";
	String REF_NAME_CONTRIBUTION_PAYMENT_STATUS = "ContributionPaymentStatus";
	String REF_NAME_CORPORATE_CUSTOMER_LEGAL_CAPACITY = "CorporateCustomerLegalCapacity";
	String REF_NAME_CREDICOM_COMPANIES = "CredicomCompanies";
	String REF_NAME_CURRENCY_CODES = "CurrencyCodes";
	String REF_NAME_CURRENCY_FOR_CHECK_DIGIT = "CurrencyForCheckDigit";
	String REF_NAME_CUSTOMER_CREATION_REASON = "CustomerCreationReason";
	String REF_NAME_CUSTOMER_DATA_SOURCE = "CustomerDataSource";
	String REF_NAME_CUSTOMER_DELETION_REASONS = "CustomerDeletionReasons";
	String REF_NAME_CUSTOMER_ECONOMIC_STATEMENT_ITEMS = "CustomerEconomicStatementItems";
	String REF_NAME_CUSTOMER_INCOME_STATEMENT = "CustomerIncomeStatement";
	String REF_NAME_CUSTOMER_MESSAGES = "CustomerMessages";
	String REF_NAME_CUSTOMER_RELATIONSHIP_CONNECTIONS = "CustomerRelationshipConnections";
	String REF_NAME_CUSTOMER_RELATIONSHIP_DESCRIPTION = "CustomerRelationshipDescription";
	String REF_NAME_CUSTOMER_RELATIONSHIPS = "CustomerRelationships";
	String REF_NAME_CUSTOMER_RELATIONSHIPS_TYPES = "CustomerRelationshipsTypes";
	String REF_NAME_CUSTOMER_STATUS = "CustomerStatus";
	String REF_NAME_DELIQUENCY_CLASSES = "DeliquencyClasses";
	String REF_NAME_DEVELOPMENT_PROGRAMS = "DevelopmentPrograms";
	String REF_NAME_DISCOUNTING_PENALTY_TYPES = "DiscountingPenaltyTypes";
	String REF_NAME_DOUBLE_TAXATION_EVATION_COUNTRIES = "DoubleTaxationEvationCountries";
	String REF_NAME_ECHELON_ASSIGNEES = "EchelonAssignees";
	String REF_NAME_ECHELONS = "Echelons";
	String REF_NAME_ECHELON_TYPES = "EchelonTypes";
	String REF_NAME_ECONOMIC_SECTOR = "EconomicSector";
	String REF_NAME_EDUCATIONAL_INSTITUTIONS = "EducationalInstitutions";
	String REF_NAME_EDUCATION_LEVEL = "EducationLevel";
	String REF_NAME_EMAIL_TYPE = "EmailType";
	String REF_NAME_ENTRY_CHANNELS = "EntryChannels";
	String REF_NAME_ERROR_MESSAGES = "ErrorMessages";
	String REF_NAME_ETEAN_REGIONS = "ETEANRegions";
	String REF_NAME_EXPENSES_TYPES = "ExpensesTypes";
	String REF_NAME_EXTERNAL_RATINGS = "ExternalRatings";
	String REF_NAME_EXTERNAL_RATINGS_AGENCIES = "ExternalRatingsAgencies";
	String REF_NAME_EXTERNAL_RATINGS_TYPES = "ExternalRatingsTypes";
	String REF_NAME_EXTRAIT_PREFERRED_LANGUAGES = "ExtraitPreferredLanguages";
	String REF_NAME_FAMILY_RELATIONSHIPS = "FamilyRelationships";
	String REF_NAME_FINANCIAL_RECOMMENDATION_CLASSIFICATION_STATUS = "FinancialRecommendationClassificationStatus";
	String REF_NAME_FINESSE_LEGAL_FRAMEWORKS = "FinesseLegalFrameworks";
	String REF_NAME_FUNDING_PURPOSES = "FundingPurposes";
	String REF_NAME_GENERAL_MESSAGES = "GeneralMessages";
	String REF_NAME_GENERIC_MESSAGES = "GenericMessages";
	String REF_NAME_GROUP_RELATIONS_FROM = "GroupRelationsFrom";
	String REF_NAME_GROUP_RELATIONS_HAS_MEMBER = "GroupRelationsHasMember";
	String REF_NAME_GROUP_RELATIONS_IS_MEMBER = "GroupRelationsIsMember";
	String REF_NAME_GROUP_RELATIONS_MAPPING = "GroupRelationsMapping";
	String REF_NAME_GROUP_RELATIONS_TO = "GroupRelationsTo";
	String REF_NAME_HOST_CONTRACT_STATUS = "HostContractStatus";
	String REF_NAME_HOST_CONTRACT_TYPES = "HostContractTypes";
	String REF_NAME_HOST_INCORPORATION_TYPES = "HostIncorporationTypes";
	String REF_NAME_ICAP_RATINGS = "ICAPRatings";
	String REF_NAME_ICAP_SCORES = "ICAPScores";
	String REF_NAME_IDENTIFICATION_DOCUMENT_TYPE = "IdentificationDocumentType";
	String REF_NAME_IDENTIFICATION_DOCUMENT_TYPE_2 = "IdentificationDocumentType2";
	String REF_NAME_IMPLEMENTED_LIMIT_DESCRIPTION = "ImplementedLimitDescription";
	String REF_NAME_IMPLEMENTED_LIMIT_STATUS = "ImplementedLimitStatus";
	String REF_NAME_INCORPORATION_TYPE = "IncorporationType";
	String REF_NAME_INDIVIDUAL_CUSTOMER_LEGAL_CAPACITY = "IndividualCustomerLegalCapacity";
	String REF_NAME_INITIAL_A_B_R_S_RATINGS = "InitialABRSRatings";
	String REF_NAME_INSURANCE_FUNDS = "InsuranceFunds";
	String REF_NAME_INVESTMENT_LOAN_TYPES = "InvestmentLoanTypes";
	String REF_NAME_INVESTMENT_SAVINGS_PROGRAMS = "InvestmentSavingsPrograms";
	String REF_NAME_ISO_CURRENCIES = "ISOCurrencies";
	String REF_NAME_JEREMIE_PROGRAMS = "JEREMIEPrograms";
	String REF_NAME_KL220A10 = "KL220A10";
	String REF_NAME_KL22A001 = "KL22A001";
	String REF_NAME_KL22A002 = "KL22A002";
	String REF_NAME_KL22A003 = "KL22A003";
	String REF_NAME_KL22A004 = "KL22A004";
	String REF_NAME_KL22A005 = "KL22A005";
	String REF_NAME_KL22A006 = "KL22A006";
	String REF_NAME_KL22A007 = "KL22A007";
	String REF_NAME_KL22A008 = "KL22A008";
	String REF_NAME_KL22A009 = "KL22A009";
	String REF_NAME_KL22A103 = "KL22A103";
	String REF_NAME_KL22A106 = "KL22A106";
	String REF_NAME_KL22A108 = "KL22A108";
	String REF_NAME_KL22A110 = "KL22A110";
	String REF_NAME_KL22C001 = "KL22C001";
	String REF_NAME_KL22C002 = "KL22C002";
	String REF_NAME_KL22C003 = "KL22C003";
	String REF_NAME_KL22C004 = "KL22C004";
	String REF_NAME_KL22C005 = "KL22C005";
	String REF_NAME_KL22C006 = "KL22C006";
	String REF_NAME_KL22C007 = "KL22C007";
	String REF_NAME_KL22C008 = "KL22C008";
	String REF_NAME_KL22L001 = "KL22L001";
	String REF_NAME_KL22L002 = "KL22L002";
	String REF_NAME_KL22L003 = "KL22L003";
	String REF_NAME_KL22L004 = "KL22L004";
	String REF_NAME_KL22L005 = "KL22L005";
	String REF_NAME_KL22S001 = "KL22S001";
	String REF_NAME_KL22S002 = "KL22S002";
	String REF_NAME_KL22S003 = "KL22S003";
	String REF_NAME_KL22S004 = "KL22S004";
	String REF_NAME_KL22S005 = "KL22S005";
	String REF_NAME_KL23FAST = "KL23FAST";
	String REF_NAME_LEGAL_CAPACITY = "LegalCapacity";
	String REF_NAME_LEGAL_ENTITY_TYPE_CORPORATE = "LegalEntityTypeCorporate";
	String REF_NAME_LEGAL_ENTITY_TYPE_OTHERS = "LegalEntityTypeOthers";
	String REF_NAME_LEGAL_ENTITY_TYPES = "LegalEntityTypes";
	String REF_NAME_LEGAL_FRAMEWORK_FOR_INSTALMENT_SUSPENSION = "LegalFrameworkForInstalmentSuspension";
	String REF_NAME_LEGAL_PROTECTIONS = "LegalProtections";
	String REF_NAME_LEGAL_STATUS = "LegalStatus";
	String REF_NAME_LENDING_APPLICATION_CODE = "LendingApplicationCode";
	String REF_NAME_LENDING_APPLICATION_PRODUCT_TYPES = "LendingApplicationProductTypes";
	String REF_NAME_LENDING_LAYOUTS = "LendingLayouts";
	String REF_NAME_LENDING_PRODUCT_TYPES = "LendingProductTypes";
	String REF_NAME_LENDING_RISK_CATEGORIES = "LendingRiskCategories";
	String REF_NAME_LIMIT_MANAGEMENT_BRANCH_TYPES = "LimitManagementBranchTypes";
	String REF_NAME_LIMIT_TYPES = "LimitTypes";
	String REF_NAME_LOAN_ACCOUNT_STATUSES = "LoanAccountStatuses";
	String REF_NAME_LOAN_AMORTIZATION_TYPES = "LoanAmortizationTypes";
	String REF_NAME_LOAN_ARRANGEMENT_TYPES = "LoanArrangementTypes";
	String REF_NAME_LOAN_CASH_CURRENCIES = "LoanCashCurrencies";
	String REF_NAME_LOAN_CONTRACT_TYPES = "LoanContractTypes";
	String REF_NAME_LOAN_INTEREST_ITEMS = "LoanInterestItems";
	String REF_NAME_LOAN_INTEREST_RATES = "LoanInterestRates";
	String REF_NAME_LOAN_PAYMENTS_FACILITATION_TYPES = "LoanPaymentsFacilitationTypes";
	String REF_NAME_LOAN_SETTLEMENT_ITEMS = "LoanSettlementItems";
	String REF_NAME_LOAN_TYPES = "LoanTypes";
	String REF_NAME_MAIL_CORRESPONDENCE_LANGUAGE = "MailCorrespondenceLanguage";
	String REF_NAME_MAIL_CORRESPONDENCE_OPTION = "MailCorrespondenceOption";
	String REF_NAME_MARITAL_STATUS = "MaritalStatus";
	String REF_NAME_MARKETING_PROMOTIONS = "MarketingPromotions";
	String REF_NAME_MIFID_CATEGORY = "MifidCategory";
	String REF_NAME_NATIONS = "Nations";
	String REF_NAME_OCCUPATION = "Occupation";
	String REF_NAME_OCCUPATIONS = "Occupations";
	String REF_NAME_OCCUPATIONS_CLASSIFICATION_STEP_9_2 = "OccupationsClassificationStep92";
	String REF_NAME_OPERATION_CODES = "OperationCodes";
	String REF_NAME_OTHER_CUSTOMER_CATEGORY = "OtherCustomerCategory";
	String REF_NAME_PE64REA1 = "PE64REA1";
	String REF_NAME_PERSONAL_DATA_PROCESS_RIGHTS = "PersonalDataProcessRights";
	String REF_NAME_PHONE_TYPE = "PhoneType";
	String REF_NAME_PMNTABRD = "PMNTABRD";
	String REF_NAME_PRINTABLE_ADDRESS_TYPE = "PrintableAddressType";
	String REF_NAME_PRINT_TARGET = "PrintTarget";
	String REF_NAME_PROVINCE = "Province";
	String REF_NAME_RELATIONSHIP_MANAGEMENT_UNIT = "RelationshipManagementUnit";
	String REF_NAME_RETAIL_CREDIT_CENTER_RATINGS = "RetailCreditCenterRatings";
	String REF_NAME_RISK_EVALUATION_TYPES = "RiskEvaluationTypes";
	String REF_NAME_SECURITIZATION_TYPES = "SecuritizationTypes";
	String REF_NAME_SETTLEMENT_COMPONENTS = "SettlementComponents";
	String REF_NAME_SEX = "Sex";
	String REF_NAME_SLIP_TYPE = "SlipType";
	String REF_NAME_STAKOD_0_8 = "Stakod08";
	String REF_NAME_SUBSIDISED_ECONOMIC_ACTIVITIES = "SubsidisedEconomicActivities";
	String REF_NAME_TAX_OFFICE = "TaxOffice";
	String REF_NAME_TC53PROV = "TC53PROV";
	String REF_NAME_TRANSACTION_RESTRICTION_TYPES = "TransactionRestrictionTypes";
	String REF_NAME_WINDOW_TITLES = "WindowTitles";
	String REF_NAME_YES_NO_OPTION_2 = "YesNoOption2";

	//Added 28-07-2017
	String REF_NAME_CONTRIBUTION_TYPES = "ContributionTypes";

	//Added 12-09-2017
	String REF_NAME_CUSTOMER_IDENTIFICATION_TYPES_PEL71 = "CustomerIdentificationTypesPEL71";
	String REF_NAME_DURATION_TYPE = "DurationType";
	String REF_NAME_ENOTIFICATION_COMMUNICATION_TYPES = "ENotificationCommunicationTypes";
	String REF_NAME_ENOTIFICATION_USER_TYPES = "ENotificationUserTypes";
	String REF_NAME_TIME_DEPOSIT_EARLY_WITHDRAWAL_TYPE = "TimeDepositEarlyWithdrawalType";

	//Added 26-09-2017
	String REF_NAME_ACCOUNT_ADDRESS_ACTION = "AccountAddressAction";
	String REF_NAME_ACCOUNT_ALERT_CHANGE_TYPE = "AccountAlertChangeType";
	String REF_NAME_ACCOUNT_CAPITALIZATION_METHOD = "AccountCapitalizationMethod";
	String REF_NAME_ACCOUNT_MODIFY_ACTION_CODE = "AccountModifyActionCode";
	String REF_NAME_ACCOUNT_OPEN_ACTIVE_TYPE = "AccountOpenActiveType";
	String REF_NAME_ACCOUNT_PURPOSE_TYPES = "AccountPurposeTypes";
	String REF_NAME_ACCOUNT_STATUS = "AccountStatus";
	String REF_NAME_ACCOUNT_TAX_INDICATOR = "AccountTaxIndicator";
	String REF_NAME_ACTION_TDEP_MATURITY = "ActionTDEPMaturity";
	String REF_NAME_ACTION_TYPES = "ActionTypes";
	String REF_NAME_ACTIVE_PRODUCT_INDICATOR = "ActiveProductIndicator";
	String REF_NAME_ADD_BENEFICIARY_FLAG = "AddBeneficiaryFlag";
	String REF_NAME_ADVICE_NOTIFICATIONS_TYPE = "AdviceNotificationsType";
	String REF_NAME_ADVICE_ORDER_TYPE = "AdviceOrderType";
	String REF_NAME_ADVICE_TYPE = "AdviceType";
	String REF_NAME_APPLICATION_CHANNELS = "ApplicationChannels";
	String REF_NAME_APPLICATION_CONTROL_ACCOUNT = "ApplicationControlAccount";
	String REF_NAME_APPLICATION_POINTS_CODE = "ApplicationPointsCode";
	String REF_NAME_AUTO_FLAGS = "AUTOFlags";
	String REF_NAME_BLOCK_ACTIVE_STATUSES = "BlockActiveStatuses";
	String REF_NAME_BONUS_FLAG = "BonusFlag";
	String REF_NAME_BRANCH_CATEGORIES = "BranchCategories";
	String REF_NAME_BRANCH_TYPE = "BranchType";
	String REF_NAME_B_RATE_DETAIL_STATUS = "BRATEDetailStatus";
	String REF_NAME_CAPITALIZATION_CODE = "CapitalizationCode";
	String REF_NAME_CARD_ACCOUNT_LINK_STATUS = "CardAccountLinkStatus";
	String REF_NAME_CHECKING_ACCOUNT_INTEREST_TYPES = "CheckingAccountInterestTypes";
	String REF_NAME_CREDIT_MARGIN_ZERO = "CreditMarginZero";
	String REF_NAME_CREDIT_RATE_TYPES = "CreditRateTypes";
	String REF_NAME_CUSTOMER_EVALUATION_REASONING = "CustomerEvaluationReasoning";
	String REF_NAME_CUSTOMER_KINDS = "CustomerKinds";
	String REF_NAME_CUSTOMER_PRODUCT_ASSOCIATION = "CustomerProductAssociation";
	String REF_NAME_DEAL_DEFINITION_KINDS = "DealDefinitionKinds";
	String REF_NAME_DEBIT_LIMIT_ZERO = "DebitLimitZero";
	String REF_NAME_DEBIT_MARGIN_ZERO = "DebitMarginZero";
	String REF_NAME_DEO_MAIN_ACTIONS = "DEOMainActions";
	String REF_NAME_DURATION_TYPES = "DurationTypes";
	String REF_NAME_E_NOTIFICATION_KEY_TYPES = "ENotificationKeyTypes";
	String REF_NAME_EURO_FLAG_INDICATOR = "EUROFlagIndicator";
	String REF_NAME_EVENT_ON_MATURITY = "EventOnMaturity";
	String REF_NAME_EXCHANGE_KIND = "ExchangeKind";
	String REF_NAME_EXTRAIT_DELIVERY_ADDRESS = "ExtraitDeliveryAddress";
	String REF_NAME_EXTRA_PROFIT_STATUS = "ExtraProfitStatus";
	String REF_NAME_EXTRA_PROFIT_SUBSCRIPTION_REQUEST_STATUS = "ExtraProfitSubscriptionRequestStatus";
	String REF_NAME_EXTRA_PROFIT_TARGET_GROUP_TYPE = "ExtraProfitTargetGroupType";
	String REF_NAME_FUNCTION_TYPES = "FunctionTypes";
	String REF_NAME_GET_EXTRA_PROFIT_PRODUCT_NAMES_LIST_ACTION_TYPES = "GetExtraProfitProductNamesListActionTypes";
	String REF_NAME_INTEREST_RATE_TYPES = "InterestRateTypes";
	String REF_NAME_INTEREST_RATE_USAGE_INDICATOR = "InterestRateUsageIndicator";
	String REF_NAME_INTEREST_TAXABLE_INDICATOR = "InterestTaxableIndicator";
	String REF_NAME_INVESTMENT_STATUS = "InvestmentStatus";
	String REF_NAME_ISSUING_AMOUNT_KINDS = "IssuingAmountKinds";
	String REF_NAME_LINK_ACCOUNT_CARD_STATUS = "LinkAccountCardStatus";
	String REF_NAME_MANAGEMENT_UNITS_MDK = "ManagementUnitsMDK";
	String REF_NAME_MATCHING_DEPOSIT_AND_CAPITALIZATION_DATE = "MatchingDepositAndCapitalizationDate";
	String REF_NAME_MORE_ACC_NO_DATA_EXISTS = "MoreAccNoDataExists";
	String REF_NAME_MORE_INTEREST_RATE_DATA_EXISTS = "MoreInterestRateDataExists";
	String REF_NAME_OM_SRVC_ODIMTR_MODE = "OmSrvcOdimtrMode";
	String REF_NAME_OWNER_CATEGORIES = "OwnerCategories";
	String REF_NAME_POINTS_REWARDING_RESULT = "PointsRewardingResult";
	String REF_NAME_PREMATURE_INDICATOR = "PrematureIndicator";
	String REF_NAME_PRINT_TIME_DEPOSIT = "PrintTimeDeposit";
	String REF_NAME_PRINT_TIME_DEPOSIT_CERTIFICATE_ACTION = "PrintTimeDepositCertificateAction";
	String REF_NAME_PSD_STATUS = "PSDStatus";
	String REF_NAME_RATE_SPREAD_ACTIONS_CTHIRECTYPE1 = "RateSpreadActionsCTHIRECTYPE1";
	String REF_NAME_RATE_SPREAD_ACTIONS_CTHIRECTYPENOT1 = "RateSpreadActionsCTHIRECTYPENOT1";
	String REF_NAME_SEARCH_TYPE_FLAGS = "SearchTypeFlags";
	String REF_NAME_SECOND_LEVEL_GL_ACCOUNT_INDICATORS = "SecondLevelGLAccountIndicators";
	String REF_NAME_SEIZUREEXEPTIONFLAG = "Seizureexeptionflag";
	String REF_NAME_SORTING_TYPE_FLAGS = "SortingTypeFlags";
	String REF_NAME_SPECIAL_BLOCK_ACCOUNT_INDICATOR = "SpecialBlockAccountIndicator";
	String REF_NAME_STPIMAX_AMOUNT_INDICATOR_FLAG = "STPIMAXAmountIndicatorFlag";
	String REF_NAME_TD_ALERT_INDICATOR_FLAG = "TDAlertIndicatorFlag";
	String REF_NAME_TD_APPLICATION_STATUS = "TDApplicationStatus";
	String REF_NAME_TD_CONTRACT_APPLICATION_CODE = "TDContractApplicationCode";
	String REF_NAME_TD_INTEREST_CAPITALIZATION_METHODS = "TDInterestCapitalizationMethods";
	String REF_NAME_TD_REVERSAL_TYPES = "TDReversalTypes";
	String REF_NAME_TD_SPECIAL_BLOCK_INDICATOR = "TDSpecialBlockIndicator";
	String REF_NAME_TERMS_CONDITIONS_SIGN_INDICATOR = "TermsConditionsSignIndicator";
	String REF_NAME_TIME_DEPO_CATEGORY_TYPE = "TimeDepoCategoryType";
	String REF_NAME_TIME_DEPO_PRINT_TYPES = "TimeDepoPrintTypes";
	String REF_NAME_TIME_DEPOSIT_ACTION_MODE = "TimeDepositActionMode";
	String REF_NAME_TIME_DEPOSIT_APPROVAL_PURPOSE_TYPES = "TimeDepositApprovalPurposeTypes";
	String REF_NAME_TIME_DEPOSIT_BULLETIN_DURATION_STATUS = "TimeDepositBulletinDurationStatus";
	String REF_NAME_TIME_DEPOSIT_EARLY_WITHDRAWAL_INTEREST_RATE_TYPE = "TimeDepositEarlyWithdrawalInterestRateType";
	String REF_NAME_TIME_DEPOSIT_GIFT_STATUS = "TimeDepositGiftStatus";
	String REF_NAME_TIME_DEPOSIT_INQUIRY_TYPE = "TimeDepositInquiryType";
	String REF_NAME_TIME_DEPOSIT_MODIFICATION_ACTION_TYPE = "TimeDepositModificationActionType";
	String REF_NAME_TIME_DEPOSIT_PRINT_STATUS = "TimeDepositPrintStatus";
	String REF_NAME_TIME_DEPOSIT_REVERSAL_FLAG = "TimeDepositReversalFlag";
	String REF_NAME_TIME_DEPOSIT_TRANSACTION_TYPE = "TimeDepositTransactionType";
	String REF_NAME_TRANSACTION_SCOPE = "TransactionScope";
	String REF_NAME_TRANSACTION_STATES_BUCK = "TransactionStatesBUCK";
	String REF_NAME_TRANSACTION_TYPE = "TransactionType";
	String REF_NAME_W8_W9_TYPE = "W8W9Type";
	String REF_NAME_WORKING_DAY_FLAG = "WorkingDayFlag";

	//Added 05/10/2017
	String REF_NAME_ACCOUNT_PROFILES = "AccountProfiles";
	String REF_NAME_APPLICATION_ROLE = "ApplicationRole";
	String REF_NAME_JEREMIE_PRODUCTS = "JeremieProducts";
	String REF_NAME_OTHER_CUSTOMER_PRODUCTS = "OtherCustomerProducts";
	String REF_NAME_TAXES = "Taxes";
	String REF_NAME_TEMPE_PRODUCTS = "TEMPEProducts";
	String REF_NAME_TIME_DEPOSIT_ACTION_TYPE = "TimeDepositActionType";
	String REF_NAME_TIME_DEPOSIT_STATUS = "TimeDepositStatus";
	String REF_NAME_BANK_ACCOUNT_OWNER_TYPES = "BankAccountOwnerTypes";
	String REF_NAME_BANK_ACCOUNT_PERMITTED_TR_TYPES = "BankAccountPermittedTrTypes";
	String REF_NAME_BANK_ACCOUNT_TYPES = "BankAccountTypes";
	String REF_NAME_CARD_VERIFICATION_ACTIONS = "CardVerificationActions";
	String REF_NAME_STANDING_ORDER_CODES = "StandingOrderCodes";
	String REF_NAME_TIME_DEPOSIT_GIFT_ACTION = "TimeDepositGiftAction";
	String REF_NAME_TRANSACTION_CODES = "TransactionCodes";
	String REF_NAME_WARNING_MESSAGES = "WarningMessages";

	//Added 02/11/2017
	String BIC = "CRBAGRAA";

	//Added 05/12/2017
	String REF_NAME_AUTHORIZATION_CODES_DESCRIPTION = "AuthorizationCodesDescription";
	String REF_NAME_CHEQUE_STATUSES = "ChequeStatuses";
	String REF_NAME_COUPON_FREQUENCY_TYPES = "CouponFrequencyTypes";
	String REF_NAME_CURRENCY_DECIMALS = "CurrencyDecimals";
	String REF_NAME_DEBIT_INSTRUMENT_TYPES = "DebitInstrumentTypes";
	String REF_NAME_DURATION_CATEGORIES = "DurationCategories";
	String REF_NAME_GROUP_RELATIONS_MAPPING_UFE = "GroupRelationsMappingUFE";
	String REF_NAME_HARD_CODED_VALUES_OB15 = "HardCodedValuesOB15";
	String REF_NAME_LOAN_ACCOUNT_INDICATOR = "LoanAccountIndicator";
	String REF_NAME_TIME_DEPOSIT_GIFT_REASON = "TimeDepositGiftReason";
	String REF_NAME_TIME_DEPOSIT_PRINT_TRANSACTION_TYPE = "TimeDepositPrintTransactionType";
	String REF_NAME_TRANSACTION_DESCRIPTION_EUR = "TransactionDescriptionEUR";
	String REF_NAME_TRANSACTION_DESCRIPTION_FX = "TransactionDescriptionFX";

	//Added 14/02/2018
	String REF_NAME_CARD_BIN_VALIDATION_CONTEXT = "CardBinValidationContext";
	String REF_NAME_CARD_CONTRACT_TYPE = "CardContractType";
	String REF_NAME_CARD_READER_ACTION_TYPE = "CardReaderActionType";
	String REF_NAME_CARD_READER_TRANSACTION_STATUS = "CardReaderTransactionStatus";
	String REF_NAME_DEFAULT_CURRENCY = "DefaultCurrency";
	String REF_NAME_FLOW_NAME = "FlowName";

	//Added 22/02/2018
	String REF_NAME_HOST_PROFESSIONS_BANKS = "HostProfessionsBanks";
	String REF_NAME_HOST_PROFESSIONS_CLUBS = "HostProfessionsClubs";
	String REF_NAME_HOST_PROFESSIONS_INDIV = "HostProfessionsIndiv";
	String REF_NAME_HOST_PROFESSIONS_LEGAL = "HostProfessionsLegal";

	//Added 21/03/2018
	String REF_NAME_ACCOUNT_OVERDRAFT_ACTION = "AccountOverdraftAction";
	String REF_NAME_BANK_NAMES = "BankNames";
	String REF_NAME_BASIC_RATE_STATUS = "BasicRateStatus";
	String REF_NAME_BONUS_CARD_USAGE_INDICATOR = "BonusCardUsageIndicator";
	String REF_NAME_BUN_ADDITIONAL_INFO_TYPE = "BUNAdditionalInfoType";
	String REF_NAME_HOST_ADDRESS_TYPES = "HostAddressTypes";
	String REF_NAME_LENDING_PRODUCT_CODES = "LendingProductCodes";
	String REF_NAME_SCALING_PRICE_TYPE = "ScalingPriceType";
	String REF_NAME_SETTLEMENT_SEARCH_STATUS = "SettlementSearchStatus";
	String REF_NAME_TDACCEPT_REJECT_GIFT_STATUS = "TDAcceptRejectGiftStatus";

	//Added 13/9/2018
	String REF_NAME_ACCOUNT_BALANCE_INQUIRY_EXTRAIT_MODE = "AccountBalanceInquiryExtraitMode";
	String REF_NAME_ACCOUNTING_INSTRUMENTAL_TYPE = "AccountingInstrumentalType";
	String REF_NAME_ACCOUNTING_TRANSACTION_TYPE = "AccountingTransactionType";
	String REF_NAME_ACCOUNT_MEDIA_INFO = "AccountMediaInfo";
	String REF_NAME_ACTION_TYPE = "ActionType";
	String REF_NAME_AFVL_MESSAGE_TYPE = "AFVLMessageType";
	String REF_NAME_AFVL_USAGE_FLAG = "AFVLUsageFlag";
	String REF_NAME_AMOUNT_TYPE = "AmountType";
	String REF_NAME_ANE_KAE_CHEQUE_REVERSAL = "AneKaeChequeReversal";
	String REF_NAME_APPROVAL_FLAG = "ApprovalFlag";
	String REF_NAME_APPROVALS = "Approvals";
	String REF_NAME_ATM_ACTION = "ATMAction";
	String REF_NAME_ATM_INDICATOR_TWENTY_FOUR = "ATMIndicatorTwentyFour";
	String REF_NAME_ATM_NETWORK_CODE = "ATMNetworkCode";
	String REF_NAME_ATM_RECONCILIATION_INDICATOR = "AtmReconciliationIndicator";
	String REF_NAME_BASE_TWENTY_FOUR_INDICATOR = "BaseTwentyFourIndicator";
	String REF_NAME_BLOCK_INDICATOR = "BlockIndicator";
	String REF_NAME_BLOCKING_TYPES = "BlockingTypes";
	String REF_NAME_CARD_TRANSACTION_ACTION_TYPE = "CardTransactionActionType";
	String REF_NAME_CARD_TYPE = "CardType";
	String REF_NAME_CASH_KIND = "CashKind";
	String REF_NAME_CASH_KIND_CARDS = "CashKindCards";
	String REF_NAME_CENTRAL_CASHIER_SYSTEM_INDICATOR = "CentralCashierSystemIndicator";
	String REF_NAME_CERTIFICATE_PRINT_STATUS = "CertificatePrintStatus";
	String REF_NAME_CERTIFICATE_VALIDITY_STATUS = "CertificateValidityStatus";
	String REF_NAME_CHECK_ACCOUNT_EXCEPTION_LIST_MESSAGE_LEVELS = "CheckAccountExceptionListMessageLevels";
	String REF_NAME_CHECK_EURO = "CheckEuro";
	String REF_NAME_CHECK_PAGIA = "CheckPagia";
	String REF_NAME_CHECK_TEIRESIA = "CheckTeiresia";
	String REF_NAME_CHEQUE_STATUS = "ChequeStatus";
	String REF_NAME_CHEQUE_TYPE = "ChequeType";
	String REF_NAME_CLAIM_TYPE = "ClaimType";
	String REF_NAME_CLHT_STATUS = "CLHTStatus";
	String REF_NAME_COMIS = "Comis";
	String REF_NAME_COMISSION_INDICATOR = "ComissionIndicator";
	String REF_NAME_CURRENCY_TYPE = "CurrencyType";
	String REF_NAME_DELTA_MOVEMENT_INDICATOR = "DeltaMovementIndicator";
	String REF_NAME_DEPOSIT_COMMISSION_TYPE = "DepositCommissionType";
	String REF_NAME_DEPOSIT_INCOMING_TYPE = "DepositIncomingType";
	String REF_NAME_DEPOSIT_JUSTIFICATION = "DepositJustification";
	String REF_NAME_DEPOSIT_TO = "DepositTo";
	String REF_NAME_DEPOSIT_TRANSACTION_TYPE = "DepositTransactionType";
	String REF_NAME_DEPOSIT_TRANSFER_TYPE = "DepositTransferType";
	String REF_NAME_DEPOSIT_TYPE = "DepositType";
	String REF_NAME_DEPOSIT_VALUE_DATE_TYPE = "DepositValueDateType";
	String REF_NAME_DIAS_PAYMENT_STATUS = "DIASPaymentStatus";
	String REF_NAME_ETESEP_INDICATORS = "ETESEPIndicators";
	String REF_NAME_EXCHANGE_TABLE_ISSUE_STATUS = "ExchangeTableIssueStatus";
	String REF_NAME_EXCHANGE_TABLE_TYPE = "ExchangeTableType";
	String REF_NAME_EXPENSES_STATUS = "ExpensesStatus";
	String REF_NAME_EXPENSES_TAXES = "ExpensesTaxes";
	String REF_NAME_FUNDS_BLOCKING_SOURCE = "FundsBlockingSource";
	String REF_NAME_HARD_CODED_VALUES_R_I = "HardCodedValuesRI";
	String REF_NAME_HOLD_PREDICTION_INDICATOR = "HoldPredictionIndicator";
	String REF_NAME_HSPT_TRANSACTION_TYPE = "HSPTTransactionType";
	String REF_NAME_INSTRUMENTAL_ACCOUNT_MOVEMENT_KIND = "InstrumentalAccountMovementKind";
	String REF_NAME_INSTRUMENTAL_ACCOUNT_TYPE = "InstrumentalAccountType";
	String REF_NAME_INT_BANK_FILE_MANAGEMENT_ACTION_TYPE = "IntBankFileManagementActionType";
	String REF_NAME_KARTOLINIO_PRINTING_JUSTIFICATION = "KartolinioPrintingJustification";
	String REF_NAME_LENDING_ORGANIZATIONS = "LendingOrganizations";
	String REF_NAME_LENDING_PERCENTAGE_DESCRIPTIONS = "LendingPercentageDescriptions";
	String REF_NAME_LENDING_PERIOD_TYPES = "LendingPeriodTypes";
	String REF_NAME_LIMITS_TRANSFER_MODE = "LimitsTransferMode";
	String REF_NAME_LISTOF_KARNE_SHEETS = "ListofKarneSheets";
	String REF_NAME_LOAN_ACCOUNT_PERIODICITY = "LoanAccountPeriodicity";
	String REF_NAME_LOAN_ACCOUNTS_RELATIONS = "LoanAccountsRelations";
	String REF_NAME_LOAN_CAPITALIZATION_TYPE = "LoanCapitalizationType";
	String REF_NAME_LOAN_CERTIFICATION_ENGINEERS = "LoanCertificationEngineers";
	String REF_NAME_LOAN_FINANCING_OBJECT = "LoanFinancingObject";
	String REF_NAME_LOAN_FINANCING_TYPE = "LoanFinancingType";
	String REF_NAME_LOAN_GUARANTEES = "LoanGuarantees";
	String REF_NAME_LOAN_INFO_DATES = "LoanInfoDates";
	String REF_NAME_LOAN_INSURANCES = "LoanInsurances";
	String REF_NAME_LOAN_INTEREST_REVISION_TABLE = "LoanInterestRevisionTable";
	String REF_NAME_LOAN_PROPOSAL_PERIODICITY = "LoanProposalPeriodicity";
	String REF_NAME_LOAN_PROPOSAL_TYPES = "LoanProposalTypes";
	String REF_NAME_LOAN_SECURITIZATION_TYPES = "LoanSecuritizationTypes";
	String REF_NAME_LOAN_SETTLEMENT_PERIODICITY = "LoanSettlementPeriodicity";
	String REF_NAME_MAIL_DELIVERY_TYPE = "MailDeliveryType";
	String REF_NAME_MOVEMENT_TYPE = "MovementType";
	String REF_NAME_MOVEMENT_TYPE_INDICATOR = "MovementTypeIndicator";
	String REF_NAME_MUST_POST_DEBIT_MOVEMENT_INDICATOR = "MustPostDebitMovementIndicator";
	String REF_NAME_NETWORK_CODE = "NetworkCode";
	String REF_NAME_NPRS_USAGE_FLAG = "NPRSUsageFlag";
	String REF_NAME_NUMBER_OF_DETAILS = "NumberOfDetails";
	String REF_NAME_PACKET_INDICATOR = "PacketIndicator";
	String REF_NAME_PAGH_STATUS = "PaghStatus";
	String REF_NAME_PASSBOOK_WARNING_MESSAGE = "PassbookWarningMessage";
	String REF_NAME_PAYMENT_FLAG = "PaymentFlag";
	String REF_NAME_PAYROLL_TYPE = "PayrollType";
	String REF_NAME_PDIV_ACTION = "PDIVAction";
	String REF_NAME_PIN_VERIFICATION_STATUS = "PinVerificationStatus";
	String REF_NAME_POST_DEBIT_INDICATOR = "PostDebitIndicator";
	String REF_NAME_POST_DEBIT_INDICATORFROM_BATCH_FLOW = "PostDebitIndicatorfromBatchFlow";
	String REF_NAME_PROCESS_INDICATOR = "ProcessIndicator";
	String REF_NAME_PRODUCT_TYPE = "ProductType";
	String REF_NAME_QUERY_TYPE = "QueryType";
	String REF_NAME_RECALL_INDICATOR = "RecallIndicator";
	String REF_NAME_REVERSAL_FULL_OR_PARTIAL_RECEIVED = "ReversalFullOrPartialReceived";
	String REF_NAME_SAFE_BOXES_COMM = "SafeBoxesComm";
	String REF_NAME_SAFE_BOXES_INSTALLMENT_TYPE = "SafeBoxesInstallmentType";
	String REF_NAME_SAFE_BOXES_LOCK_REASONS = "SafeBoxesLockReasons";
	String REF_NAME_SAFE_BOXES_SETTLEMENT_TYPE = "SafeBoxesSettlementType";
	String REF_NAME_SAFE_BOXES_SIZE = "SafeBoxesSize";
	String REF_NAME_SAFE_BOXES_STATUS = "SafeBoxesStatus";
	String REF_NAME_SAFE_BOXES_TYPE = "SafeBoxesType";
	String REF_NAME_SEIZED_CHEQUE_STATUS = "SeizedChequeStatus";
	String REF_NAME_SEIZURE_ISSUED_BY = "SeizureIssuedBy";
	String REF_NAME_SEIZURE_STATUS = "SeizureStatus";
	String REF_NAME_SEIZURE_TYPE = "SeizureType";
	String REF_NAME_SERVICE_CODE = "ServiceCode";
	String REF_NAME_SETTLEMENT_STATUS = "SettlementStatus";
	String REF_NAME_SPECIAL_BLOCK_INDICATOR = "SpecialBlockIndicator";
	String REF_NAME_SPTR_FLAG = "SPTRFlag";
	String REF_NAME_SYMB_FLAG = "SymbFlag";
	String REF_NAME_TIME_DEPOSIT_APPROVAL_PURPOSE_TYPES_FC = "TimeDepositApprovalPurposeTypesFC";
	String REF_NAME_TIME_DEPOSIT_RATE_APPROVAL_PURPOSE_TYPES_FC = "TimeDepositRateApprovalPurposeTypesFC";
	String REF_NAME_TRANSACTION_ACTION = "TransactionAction";
	String REF_NAME_TRANSACTION_DATA_TYPE = "TransactionDataType";
	String REF_NAME_TRANSACTION_KIND_CHEQUE = "TransactionKindCheque";
	String REF_NAME_TRANSACTION_LANGUAGE = "TransactionLanguage";
	String REF_NAME_TRANSACTION_MESSAGE_TYPE = "TransactionMessageType";
	String REF_NAME_TRANSACTION_TYPE_ALPHA_NET_DELTA_NET = "TransactionTypeAlphaNetDeltaNet";
	String REF_NAME_TRANSACTION_TYPE_CHARGING_TYPE = "TransactionTypeChargingType";
	String REF_NAME_TRANSACTION_TYPE_CHEQUE = "TransactionTypeCheque";
	String REF_NAME_TRANSACTION_TYPE_CREDIT_TYPE = "TransactionTypeCreditType";
	String REF_NAME_TRANSACTION_TYPES = "TransactionTypes";
	String REF_NAME_TRANSACTION_WORK_TYPE = "TransactionWorkType";
	String REF_NAME_TRANSCATION_MODE = "TranscationMode";
	String REF_NAME_UDFS_CATEGORIES_LOAN = "UdfsCategoriesLoan";
	String REF_NAME_UNIT_TYPES = "UnitTypes";
	String REF_NAME_VALEUR_INDICATOR = "ValeurIndicator";
	String REF_NAME_WITHDRAWAL_COMMISSION_TYPE = "WithdrawalCommissionType";
	String REF_NAME_WITHDRAWAL_JUSTIFICATION = "WithdrawalJustification";
	String REF_NAME_WITHDRAWAL_OUTGOING_TYPE = "WithdrawalOutgoingType";
	String REF_NAME_WITHDRAWAL_TRANSACTION_TYPE = "WithdrawalTransactionType";
	String REF_NAME_WITHDRAWAL_VALUE_DATE_TYPE = "WithdrawalValueDateType";
	String REF_NAME_WORK_STATION_BRANCH_CODE = "WorkStationBranchCode";
	String REF_NAME_WRITEOFF_TYPE = "WRITEOFFTYPE";

	//16/10/2018
	String REF_NAME_ACCOUNT_BLOCK_TYPE = "AccountBlockType";
	String REF_NAME_ACCOUNTING_ACCOUNT_IDENTIFICATION_FLAG = "AccountingAccountIdentificationFlag";
	String REF_NAME_ACCOUNTING_EXCEPTION_TYPE = "AccountingExceptionType";
	String REF_NAME_AMOUNT_ANALYSIS_INDICATOR = "AmountAnalysisIndicator";
	String REF_NAME_APPROVAL_REQUIREMENT_INDICATOR = "ApprovalRequirementIndicator";
	String REF_NAME_AVAILABLE_CHANNELS = "AvailableChannels";
	String REF_NAME_BALANCE_OF_PAYMENT = "BalanceOfPayment";
	String REF_NAME_BEFORE_AFTER = "Before_After";
	String REF_NAME_BLOCKING_JUSTIFICATION = "BlockingJustification";
	String REF_NAME_BLOCK_KIND = "BlockKind";
	String REF_NAME_BNK_GROUPS = "BNK_Groups";
	String REF_NAME_CACH_DEPOSIT = "CachDeposit";
	String REF_NAME_CASH_CENTER_REQUIREMENT_INDICATOR = "CashCenterRequirementIndicator";
	String REF_NAME_CASH_EQUIVALENT = "CashEquivalent";
	String REF_NAME_CHARGE_INDICATION_TYPE = "ChargeIndicationType";
	String REF_NAME_CHARGE_METHOD = "ChargeMethod";
	String REF_NAME_CHEQDAYS = "CHEQDAYS";
	String REF_NAME_CHEQUE_KIND = "ChequeKind";
	String REF_NAME_CHEQUE_PRINTING = "ChequePrinting";
	String REF_NAME_CLEAR_BY_SAME_BRANCH_INDICATOR = "ClearBySameBranchIndicator";
	String REF_NAME_CREDIT_INTEREST_INFO_REQUEST_TYPE = "CreditInterestInfoRequestType";
	String REF_NAME_CUSTOMER_BOP_FLAG = "CustomerBOPFlag";
	String REF_NAME_DAILY_CHEQUE_INQUIRY = "DailyChequeInquiry";
	String REF_NAME_DATE_RANGE = "DateRange";
	String REF_NAME_DB1_SCREEN_AREA = "DB1_ScreenArea";
	String REF_NAME_DDLG_ROW_TYPE = "DDLG__RowType";
	String REF_NAME_DDLG_RETRIEVAL_TYPE = "DDLG_RetrievalType";
	String REF_NAME_DEPOSIT_ACCOUNT_BALANCE_DETAILS_INQUIRY = "DepositAccountBalanceDetailsInquiry";
	String REF_NAME_DEPOSIT_ACCOUNT_INQUIRY_TYPE = "DepositAccountInquiryType";
	String REF_NAME_DEPOSIT_ACCOUNT_INTEREST_DETAILS_INQUIRY = "DepositAccountInterestDetailsInquiry";
	String REF_NAME_DEPOSIT_INDICATOR = "DepositIndicator";
	String REF_NAME_DERIVATIVE_PRODUCT_TYPE = "DerivativeProductType";
	String REF_NAME_DOCUMENT_ATTACHMENT_INDICATOR = "DocumentAttachmentIndicator";
	String REF_NAME_DORMANT_ACCOUNT_ACTION = "DormantAccountAction";
	String REF_NAME_DORMANT_ACCOUNT_HISTORY_SIGN_FLAG = "DormantAccountHistorySignFlag";
	String REF_NAME_EXPENSE_CHANNEL = "ExpenseChannel";
	String REF_NAME_EXTRAIT_DELIVERY_FREQUENCIES_OTHER = "ExtraitDeliveryFrequenciesOther";
	String REF_NAME_GENERAL_PARAMS = "GeneralParams";
	String REF_NAME_GRACE_PERIOD_CAPITALIZATION = "GracePeriodCapitalization";
	String REF_NAME_INQUIRY_FOR_INCOMING_SETTLEMENT = "InquiryForIncomingSettlement";
	String REF_NAME_INTEREST_RATE_TYPE = "InterestRateType";
	String REF_NAME_ISSUE_PASS_BOOK = "IssuePassBook";
	String REF_NAME_LENDING_CURRENCY_GENDERS = "LendingCurrencyGenders";
	String REF_NAME_LIQUIDATOR_REQUIREMENT_INDICATOR = "LiquidatorRequirementIndicator";
	String REF_NAME_LOAN_PRODUCT_TYPE = "LoanProductType";
	String REF_NAME_LOAN_REFERENCES = "LoanReferences";
	String REF_NAME_LOAN_REPAYMENT_PERIODICITY = "LoanRepaymentPeriodicity";
	String REF_NAME_MDF_ALLOWED_REASON = "MDF_AllowedReason";
	String REF_NAME_MULTIPLE_LIQUIDATION_INDICATOR = "MultipleLiquidationIndicator";
	String REF_NAME_OPERATION_CURRENCY_TYPE = "OperationCurrencyType";
	String REF_NAME_PASSBOOK_AMOUNT_TYPE = "PassbookAmountType";
	String REF_NAME_PENDING_RECORD_ACCOUNTING_TYPE = "PendingRecordAccountingType";
	String REF_NAME_PLEDGE_COLLECTION = "PledgeCollection";
	String REF_NAME_POSTDATE_MORE = "PostdateMore";
	String REF_NAME_PREMIUM_TYPE = "PremiumType";
	String REF_NAME_PSD_DEBIT_CREDIT_INDICATOR = "PSD_DebitCreditIndicator";
	String REF_NAME_RECORD_MOVEMENT_PENDING_INDICATOR = "RecordMovementPendingIndicator";
	String REF_NAME_RECORD_MOVEMENT_TYPE = "RecordMovementType";
	String REF_NAME_ROLES_AVAILABLE = "RolesAvailable";
	String REF_NAME_SAEP_FUNCTIONS = "SAEPFunctions";
	String REF_NAME_SAFE_BOX_DEFECT_INDICATOR = "SafeBoxDefectIndicator";
	String REF_NAME_SAME_OTHER_LITERAL = "SameOtherLiteral";
	String REF_NAME_SCANNER_TYPES = "ScannerTypes";
	String REF_NAME_SOURCE_TYPE_REGULATION = "SourceTypeRegulation";
	String REF_NAME_SPECIAL_BLOCK_TYPE = "SpecialBlockType";
	String REF_NAME_STAMP_INDICATION = "StampIndication";
	String REF_NAME_STAMP_STATEMENT = "StampStatement";
	String REF_NAME_TEMPORAL_DEFINITY = "TemporalDefinity";
	String REF_NAME_TRANSACTION_RECORD_MOVEMENT_TYPE = "TransactionRecordMovementType";
	String REF_NAME_VALUE_OF_INTEREST = "ValueOfInterest";

	//Added 08/02/2019
	String REF_NAME_ATTORNEY_EXPIRY_INDICATOR = "AttorneyExpiryIndicator";

	//Added 23/03/2019
	String LANGUAGE_GREEK = "Greek";
	String REF_NAME_CHANNEL_TYPE_CODE = "ChannelTypeCode";
	String REF_NAME_STANDING_ORDER_FREQUENCY = "StandingOrderFrequency";
	String REF_NAME_STANDING_ORDER_ACTION = "FixAmntStandingOrderAction";
	String REF_NAME_STANDING_ORDER_STATUS = "PagsStatus";

	//Added 04/04/2019
	String REF_NAME_KTEL_CATEGORY = "KtelCategory";
	String REF_NAME_KTEL_SUBCATEGORY = "KtelSubCategory";
	String REF_NAME_KTEL_CHANNEL = "KTELChannelID";
	String REF_NAME_KTEL_PERIOD = "KTELPeriod";

	//Addd 10/04/2019
	String REF_NAME_ESIG_ORIGINATING_SYSTEM = "EsignatureOriginatingSystem";
	String REF_NAME_ESIG_PROCESS = "EsignatureProcess";
	String ESIG_PROCESS_PHASE_COMPLETION = "PhaseCompletion";
	String ESIG_PROCESS_PROCESS_COMPLETION = "ProcessCompletion";

	//Added 18/12/2019
	String HEADER_APP_CONTEXT_UNIT_CODE = "cbs.applicationContext.unitCode";
	String HEADER_APP_CONTEXT_UNIT_COUNTRY = "cbs.applicationContext.unitCountry";
	String HEADER_APP_CONTEXT_UNIT_INSTITUTION_CODE = "cbs.applicationContext.unitInstitutionCode";
	String HEADER_APP_CONTEXT_UNIT_LANG = "cbs.applicationContext.unitLanguage";
	String HEADER_APP_CONTEXT_UNIT_FTS_ID = "cbs.applicationContext.unitFTSId";
	String HEADER_APP_CONTEXT_UNIT_IBAN_CALC_METHOD = "cbs.applicationContext.unitIBANCalculationMethod";

	//Added 07/01/2020
	String REF_NAME_SIMPLE_IMPORT_STATUS = "SimpleImportStatus";
	String REF_NAME_SIMPLE_IMPORTS_PAYMENT_TYPE = "SimpleImportsPaymentType";
	String REF_NAME_MONEY_ORDER_EXPENSES_FLAG = "MoneyOrderExpensesFlag";
	String REF_NAME_IMPORT_KIND = "ImportKind";

	//Added 29/01/2020
	String HEADER_TUN_FROM_BUN = "cbs.commons.tun.from.bun";

	//Added 06/02/2020
	String REF_NAME_PARTIAL_PROMISSORY_NOTE_PAYMENT_INDICATOR = "PartialPromissoryNotePaymentIndicator";
	String REF_NAME_PROMISSORY_NOTE_RECORD_TYPE = "PromissoryNoteRecordType";
	String REF_NAME_PROMISSORY_NOTE_STATUS = "PromissoryNoteStatus";
	String REF_NAME_PROMISSORY_NOTE_PAYMENT_CODE = "PromissoryNotePaymentCode";
	String REF_NAME_PROMISSORY_NOTE_EXPENSES_INDICATOR = "PromissoryNoteExpensesIndicator";
	String REF_NAME_PROMISSORY_NOTE_PACKAGE_CODE = "PromissoryNotePackageCode";
	String REF_NAME_PROMISSORY_NOTE_PACKAGE_REVERSAL_CODE = "PromissoryNotePackageReversalCode";
	String REF_NAME_PROMISSORY_NOTE_PACKAGE_STATUS_CODE = "PromissoryNotePackageStatusCode";
	String REF_NAME_PROMISSORY_NOTE_PACKAGE_TYPE = "PromissoryNotePackageType";
	String REF_NAME_PROMISSORY_NOTE_PARTIAL_PAYMENT_INDICATOR = "PromissoryNotePartialPaymentIndicator";
	String REF_NAME_PROMISSORY_NOTE_NO_PAYMENT_CODE = "PromissoryNoteNoPaymentCode";
	String REF_NAME_PROMISSORY_NOTE_OPERATIONS = "PromissoryNoteOperations";
	String REF_NAME_PROMISSORY_NOTE_PACKAGE_ACTIONS = "PromissoryNotePackageActions";
	String REF_NAME_PROMISSORY_NOTE_SEND_OPTIONS = "PromissoryNoteSendOptions";
	String REF_NAME_PROMISSORY_NOTE_ACTIONS = "PromissoryNoteActions";
	String REF_NAME_PROMISSORY_NOTE_FLAG_INTEREST = "PromissoryNoteFlagInterest";
	String REF_NAME_PROMISSORY_NOTE_PAY_OPERATION = "PromissoryNotePayOperation";

	//Added 10/04/2020
	String HEADER_WSAT = "cbs.commons.wsat";

	String HEADER_XSD_PATHS = "cbs.header.xsd.paths";

	String PROPERTY_KAFKA_ASYNC_CALL = "cbs.commons.kafka.async.call";

	String PROPERTY_KAFKA_KEY = "cbs.commons.kafka.key";

	String PROPERTY_KAFKA_OPERATION_NAME = "cbs.commons.kafka.operation.name";

	String PROPERTY_KAFKA_USE_OPERATION_NAME_AS_IDEMPOTENCY_CHECK = "cbs.commons.kafka.use.operation.name.as.idempotency.check";

	String PROPERTY_KAFKA_OUTBOX_TABLE_NAME = "cbs.commons.kafka.outbox.table.name";

	String PROPERTY_KAFKA_OUTGOING_TOPIC = "cbs.commons.kafka.outgoing.topic";

	String PROPERTY_KAFKA_TIMESTAMP = "cbs.commons.kafka.timestamp";
}