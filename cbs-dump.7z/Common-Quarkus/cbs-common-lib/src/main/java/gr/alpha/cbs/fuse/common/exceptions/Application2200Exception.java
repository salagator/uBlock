package gr.alpha.cbs.fuse.common.exceptions;

import io.quarkus.runtime.annotations.RegisterForReflection;

@RegisterForReflection
public class Application2200Exception extends Exception {

	/** Serial version ID */
	private static final long serialVersionUID = 1L;

	private int rc1;
	private int rc2;
	private ErrorTypeModel errorModel = new ErrorTypeModel();
	
	public Application2200Exception() {
		super();
	}

	public Application2200Exception(int rc1, int rc2, String stack, ErrorTypeModel model) {
		super(rc1+"/"+rc2+" "+model.getDescription()+" with Stack="+stack);
		this.rc1 = rc1;
		this.rc2 = rc2;
		this.errorModel = model;
	}

	public Application2200Exception(Throwable t, int rc1, int rc2, String stack, ErrorTypeModel model) {
		super(rc1+"/"+rc2+" "+model.getDescription()+" with Stack="+stack,t);
		this.rc1 = rc1;
		this.rc2 = rc2;
		this.errorModel = model;
	}

	public int getRc1() {
		return rc1;
	}

	public void setRc1(int rc1) {
		this.rc1 = rc1;
	}

	public int getRc2() {
		return rc2;
	}

	public void setRc2(int rc2) {
		this.rc2 = rc2;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @return the errorModel
	 */
	public ErrorTypeModel getErrorModel() {
		return errorModel;
	}
}
