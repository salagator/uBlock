package gr.alpha.cbs.fuse.cardsedge.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import gr.alpha.cbs.fuse.cardsedge.generated.*;
import gr.alpha.cbs.fuse.cardsedge.helper.model.CardEntriesResponse;
import gr.alpha.cbs.fuse.cardsedge.helper.model.PwcDbCardTransactionType;
import gr.alpha.cbs.fuse.cardsedge.helper.model.PwcDbCardTransactions;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.transaction.Transactional;
import org.apache.camel.Exchange;
import org.eclipse.microprofile.config.ConfigProvider;
import org.infinispan.protostream.SerializationContextInitializer;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;
import javax.naming.NamingException;
import javax.sql.DataSource;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;


@Named("getCardAuthorizationsAndTransactionsHelper")
@ApplicationScoped
@RegisterForReflection
public class GetCardAuthorizationsAndTransactionsHelper {
    @Inject
    CardsEdgeCommonFunctions cardsEdgeCommonFunctions;

    private static final Logger LOGGER = Logger.getLogger(GetCardAuthorizationsAndTransactionsHelper.class);

    private static final String SELECT_FROM_ENTRY_CARDS_PWC_PAGING = "SELECT [CardNumber]\n" +
            "      ,[TransactionDate]\n" +
            "      ,[PostingDate]\n" +
            "      ,[TransactionCode]\n" +
            "      ,[MerchantName]\n" +
            "      ,[MerchantCity]\n" +
            "      ,[MerchantCountry]\n" +
            "      ,[MerchantCategoryCode]\n" +
            "      ,[MerchantId]\n" +
            "      ,[CardHolderAmountSign]\n" +
            "      ,[CardHolderAmount]\n" +
            "      ,[CardHolderCurrency]\n" +
            "      ,[ForeignTransactionAmountSign]\n" +
            "      ,[ForeignTransactionAmount]\n" +
            "      ,[ForeignTransactionCurrency]\n" +
            "      ,[TransactionTime]\n" +
            "      ,[TransactionTimestamp]\n" +
            "      ,[TransactionRefNumber]\n" +
            "      ,[TransactionSeqNumber]\n" +
            "      ,[RecurringInd]\n" +
            "      ,[OriginatingChannel]\n" +
            "      ,[CPSTransactionID]\n" +
            "      ,[IssuerCorporateID]\n" +
            "      ,[ProcessingCode]\n" +
            "      ,[FastFundsIndicator]\n" +
            "      ,[PosData]\n" +
            "      ,[TokenRequestorID]\n" +
            "      ,[PaymentID]\n" +
            "      ,[CreditCardOpenLoadNumber]\n" +
            "      ,[TransactionStatusReasonCode]\n" +
            "      ,[TransactionRefSeqNumber]\n" +
            "      ,[AcquirerInstitutionCode]\n" +
            "      ,[ImportID]\n" +
            "  FROM [EntryCardsPWC] WITH (NOLOCK)\n" +
            "  WHERE CardNumber = ?\n" +
            "  AND TransactionDate BETWEEN ? AND ?\n" +
            "  AND (TransactionTimestamp < ? OR (TransactionTimestamp = ? AND TransactionRefSeqNumber > ?)) \n" +
            "  ORDER BY TransactionTimestamp DESC, TransactionRefSeqNumber ASC OFFSET 0 ROWS\n" +
            "  FETCH NEXT ? ROWS ONLY;";


    private static final String SELECT_FROM_ENTRY_CARDS_PWC = "SELECT [CardNumber]\n" +
            "      ,[TransactionDate]\n" +
            "      ,[PostingDate]\n" +
            "      ,[TransactionCode]\n" +
            "      ,[MerchantName]\n" +
            "      ,[MerchantCity]\n" +
            "      ,[MerchantCountry]\n" +
            "      ,[MerchantCategoryCode]\n" +
            "      ,[MerchantId]\n" +
            "      ,[CardHolderAmountSign]\n" +
            "      ,[CardHolderAmount]\n" +
            "      ,[CardHolderCurrency]\n" +
            "      ,[ForeignTransactionAmountSign]\n" +
            "      ,[ForeignTransactionAmount]\n" +
            "      ,[ForeignTransactionCurrency]\n" +
            "      ,[TransactionTime]\n" +
            "      ,[TransactionTimestamp]\n" +
            "      ,[TransactionRefNumber]\n" +
            "      ,[TransactionSeqNumber]\n" +
            "      ,[RecurringInd]\n" +
            "      ,[OriginatingChannel]\n" +
            "      ,[CPSTransactionID]\n" +
            "      ,[IssuerCorporateID]\n" +
            "      ,[ProcessingCode]\n" +
            "      ,[FastFundsIndicator]\n" +
            "      ,[PosData]\n" +
            "      ,[TokenRequestorID]\n" +
            "      ,[PaymentID]\n" +
            "      ,[CreditCardOpenLoadNumber]\n" +
            "      ,[TransactionStatusReasonCode]\n" +
            "      ,[TransactionRefSeqNumber]\n" +
            "      ,[AcquirerInstitutionCode]\n" +
            "      ,[ImportID]\n" +
            "  FROM [HistoryDB].[dbo].[EntryCardsPWC] WITH (NOLOCK)\n" +
            "  WHERE CardNumber IN (%s)\n" +
            "  AND TransactionDate BETWEEN ? AND ?\n" +
            "  ORDER BY TransactionTimestamp DESC OFFSET 0 ROWS\n" +
            "  FETCH NEXT ? ROWS ONLY;";

    private static final String SELECT_FROM_ENTRY_CARDS_PWC_CORPORATE_PAGING = "SELECT [CardNumber]\n" +
            "      ,[TransactionDate]\n" +
            "      ,[PostingDate]\n" +
            "      ,[TransactionCode]\n" +
            "      ,[MerchantName]\n" +
            "      ,[MerchantCity]\n" +
            "      ,[MerchantCountry]\n" +
            "      ,[MerchantCategoryCode]\n" +
            "      ,[MerchantId]\n" +
            "      ,[CardHolderAmountSign]\n" +
            "      ,[CardHolderAmount]\n" +
            "      ,[CardHolderCurrency]\n" +
            "      ,[ForeignTransactionAmountSign]\n" +
            "      ,[ForeignTransactionAmount]\n" +
            "      ,[ForeignTransactionCurrency]\n" +
            "      ,[TransactionTime]\n" +
            "      ,[TransactionTimestamp]\n" +
            "      ,[TransactionRefNumber]\n" +
            "      ,[TransactionSeqNumber]\n" +
            "      ,[RecurringInd]\n" +
            "      ,[OriginatingChannel]\n" +
            "      ,[CPSTransactionID]\n" +
            "      ,[IssuerCorporateID]\n" +
            "      ,[ProcessingCode]\n" +
            "      ,[FastFundsIndicator]\n" +
            "      ,[PosData]\n" +
            "      ,[TokenRequestorID]\n" +
            "      ,[PaymentID]\n" +
            "      ,[CreditCardOpenLoadNumber]\n" +
            "      ,[TransactionStatusReasonCode]\n" +
            "      ,[TransactionRefSeqNumber]\n" +
            "      ,[AcquirerInstitutionCode]\n" +
            "      ,[ImportID]\n" +
            "  FROM [EntryCardsPWC] WITH (NOLOCK)\n" +
            "  WHERE IssuerCorporateID = ?\n" +
            "  AND TransactionDate BETWEEN ? AND ?\n" +
            "  AND (TransactionTimestamp < ? OR (TransactionTimestamp = ? AND TransactionRefSeqNumber > ?)) \n" +
            "  ORDER BY TransactionTimestamp DESC, TransactionRefSeqNumber ASC OFFSET 0 ROWS\n" +
            "  FETCH NEXT ? ROWS ONLY;";

    private static final String SELECT_FROM_ENTRY_CARDS_PWC_CORPORATE = "SELECT [CardNumber]\n" +
            "      ,[TransactionDate]\n" +
            "      ,[PostingDate]\n" +
            "      ,[TransactionCode]\n" +
            "      ,[MerchantName]\n" +
            "      ,[MerchantCity]\n" +
            "      ,[MerchantCountry]\n" +
            "      ,[MerchantCategoryCode]\n" +
            "      ,[MerchantId]\n" +
            "      ,[CardHolderAmountSign]\n" +
            "      ,[CardHolderAmount]\n" +
            "      ,[CardHolderCurrency]\n" +
            "      ,[ForeignTransactionAmountSign]\n" +
            "      ,[ForeignTransactionAmount]\n" +
            "      ,[ForeignTransactionCurrency]\n" +
            "      ,[TransactionTime]\n" +
            "      ,[TransactionTimestamp]\n" +
            "      ,[TransactionRefNumber]\n" +
            "      ,[TransactionSeqNumber]\n" +
            "      ,[RecurringInd]\n" +
            "      ,[OriginatingChannel]\n" +
            "      ,[CPSTransactionID]\n" +
            "      ,[IssuerCorporateID]\n" +
            "      ,[ProcessingCode]\n" +
            "      ,[FastFundsIndicator]\n" +
            "      ,[PosData]\n" +
            "      ,[TokenRequestorID]\n" +
            "      ,[PaymentID]\n" +
            "      ,[CreditCardOpenLoadNumber]\n" +
            "      ,[TransactionStatusReasonCode]\n" +
            "      ,[TransactionRefSeqNumber]\n" +
            "      ,[AcquirerInstitutionCode]\n" +
            "      ,[ImportID]\n" +
            "  FROM [HistoryDB].[dbo].[EntryCardsPWC] WITH (NOLOCK)\n" +
            "  WHERE IssuerCorporateID = ?\n" +
            "  AND TransactionDate BETWEEN ? AND ?\n" +
            "  ORDER BY TransactionTimestamp DESC OFFSET 0 ROWS\n" +
            "  FETCH NEXT ? ROWS ONLY;";

    private static final String SELECT_FROM_PWC_DB_LOAD_DATE = "SELECT ShowDateTo FROM [HistoryDB].[dbo].[ApplicationConfig] WITH (NOLOCK) WHERE ServiceName = 'HistoryServiceCardsPWC'";

    private static final String SELECT_FROM_CMS_MAIN_CARDS_MAPPING = "SELECT CMS_MainCardNumber FROM [HistoryDB].[dbo].[CMS_MainCardsMapping] WITH (NOLOCK) where PWC_CorporateId = ?";

    private final String SELECT_APPLICATION_NUMBER_FROM_CARD_LINKS = "SELECT TOP 1 [ApplicationRefrenceNumber], [CardProgram] FROM [HistoryDB].[dbo].[CardLinks] WITH (NOLOCK) WHERE [ApplicationRefrenceNumber] <> '' AND [ApplicationRefrenceNumber] IS NOT NULL AND [AccountNumber] = ?";

    private final String SELECT_CARDS_INT_FROM_CARDS_LINK = "SELECT [AccountNumberINT] FROM [HistoryDB].[dbo].[CardLinks] WITH (NOLOCK) WHERE ApplicationRefrenceNumber = ? AND CardProgram = ? GROUP BY [AccountNumberINT]";

    private RemoteDatagridClientHelper<String, String> datagridHelper;
    private static SerializationContextInitializer contextInitializer;

    @Inject
    @io.quarkus.agroal.DataSource("cbs-history-db")
    private DataSource historyDbDatasource;

    @PostConstruct
    private void postConstruct() {
        datagridHelper = new RemoteDatagridClientHelper<>();
        datagridHelper.initCacheManagerWithMarshaller(contextInitializer);
        datagridHelper.setCache("cardTransactionsHistory");
    }

    @PreDestroy
    private void preDestroy() {
        datagridHelper.stopCacheManager();
    }

    @Transactional(Transactional.TxType.REQUIRED)
    public String getPwcDbLoadDateDb() throws CBSException {
        String pwcDbLoadDate = "";
        try(Connection connection = historyDbDatasource.getConnection(); PreparedStatement statement = connection.prepareStatement(SELECT_FROM_PWC_DB_LOAD_DATE)){
            try(ResultSet resultSet = statement.executeQuery()) {
                while(resultSet.next()){
                    pwcDbLoadDate = resultSet.getString("ShowDateTo");
                }
            }
        }catch (SQLException e){
            ErrorUtils.throwCBSException(null,
                    ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
                    ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
                    GetCardAuthorizationsAndTransactionsHelper.class.getCanonicalName(),
                    ConstantErrorMessages._SQL_EXCEPTION,
                    ErrorTypeModel.SEVERITY_ERROR,
                    "SQL Error while retrieving Pwc Dates from DB: " + e.getMessage(), "", "");
        }
        return pwcDbLoadDate;
    }

    @Transactional(Transactional.TxType.REQUIRED)
    public PwcDbCardTransactions getPwcDbTransactionsDb(Exchange exchange, String cardNumber, int dateFrom, int dateTo, int pageSize) throws CBSException{
        LOGGER.info("Retrieving Transactions from DB with DateFrom: " + dateFrom + "DateTo: " + dateTo + "PageSize: " + pageSize);

        //Get replaced cards and format the query in order to select with all the cards
        List<String> cards = getReplacedCards(cardNumber);
        String placeholders = String.join(",", cards.stream().map(i -> "?").collect(Collectors.toList()));
        String finalTransactionsQuery = String.format(SELECT_FROM_ENTRY_CARDS_PWC, placeholders);

        PwcDbCardTransactions pwcDbCardTransactions = new PwcDbCardTransactions();
        try(Connection connection = historyDbDatasource.getConnection(); PreparedStatement statement = connection.prepareStatement(finalTransactionsQuery)){

            for(int i = 0; i < cards.size(); i++){
                statement.setString(i + 1, cards.get(i));
            }
            statement.setInt(cards.size() + 1, dateFrom);
            statement.setInt(cards.size() + 2, dateTo);
            statement.setInt(cards.size() + 3, pageSize);

            try(ResultSet resultSet = statement.executeQuery()) {
                while(resultSet.next()){
                    PwcDbCardTransactionType pwcDbCardTransaction = new PwcDbCardTransactionType();
                    pwcDbCardTransaction.setCardNumber(resultSet.getString("CardNumber"));
                    pwcDbCardTransaction.setTransactionDate(resultSet.getString("TransactionDate"));
                    pwcDbCardTransaction.setPostingDate(resultSet.getString("PostingDate"));
                    pwcDbCardTransaction.setTransactionCode(resultSet.getString("TransactionCode"));
                    pwcDbCardTransaction.setMerchantName(resultSet.getString("MerchantName"));
                    pwcDbCardTransaction.setMerchantCity(resultSet.getString("MerchantCity"));
                    pwcDbCardTransaction.setMerchantCountry(resultSet.getString("MerchantCountry"));
                    pwcDbCardTransaction.setMerchantCategoryCode(resultSet.getString("MerchantCategoryCode"));
                    pwcDbCardTransaction.setMerchantId(resultSet.getString("MerchantId"));
                    pwcDbCardTransaction.setCardHolderAmountSign(resultSet.getString("CardHolderAmountSign"));
                    pwcDbCardTransaction.setCardHolderAmount(resultSet.getString("CardHolderAmount"));
                    pwcDbCardTransaction.setCardHolderCurrency(resultSet.getString("CardHolderCurrency"));
                    pwcDbCardTransaction.setForeignTransactionAmountSign(resultSet.getString("ForeignTransactionAmountSign"));
                    pwcDbCardTransaction.setForeignTransactionAmount(resultSet.getString("ForeignTransactionAmount"));
                    pwcDbCardTransaction.setForeignTransactionCurrency(resultSet.getString("ForeignTransactionCurrency"));
                    pwcDbCardTransaction.setTransactionTime(resultSet.getString("TransactionTime"));
                    pwcDbCardTransaction.setTransactionTimestamp(resultSet.getString("TransactionTimestamp"));
                    pwcDbCardTransaction.setTransactionRefNumber(resultSet.getString("TransactionRefNumber"));
                    pwcDbCardTransaction.setTransactionSeqNumber(resultSet.getString("TransactionSeqNumber"));
                    pwcDbCardTransaction.setRecurringInd(resultSet.getString("RecurringInd"));
                    pwcDbCardTransaction.setOriginatingChannel(resultSet.getString("OriginatingChannel"));
                    pwcDbCardTransaction.setCPSTransactionID(resultSet.getString("CPSTransactionID"));
                    pwcDbCardTransaction.setIssuerCorporateID(resultSet.getString("IssuerCorporateID"));
                    pwcDbCardTransaction.setProcessingCode(resultSet.getString("ProcessingCode"));
                    pwcDbCardTransaction.setFastFundsIndicator(resultSet.getString("FastFundsIndicator"));
                    pwcDbCardTransaction.setPosData(resultSet.getString("PosData"));
                    pwcDbCardTransaction.setTokenRequestorID(resultSet.getString("TokenRequestorID"));
                    pwcDbCardTransaction.setPaymentID(resultSet.getString("PaymentID"));
                    pwcDbCardTransaction.setCreditCardOpenLoadNumber(resultSet.getString("CreditCardOpenLoadNumber"));
                    pwcDbCardTransaction.setTransactionStatusReasonCode(resultSet.getString("TransactionStatusReasonCode"));
                    pwcDbCardTransaction.setTransactionRefSeqNumber(resultSet.getString("TransactionRefSeqNumber"));
                    pwcDbCardTransaction.setAcquirerInstitutionCode(resultSet.getString("AcquirerInstitutionCode"));
                    pwcDbCardTransaction.setImportID(resultSet.getString("ImportID"));
                    pwcDbCardTransactions.getPwcDbCardTransaction().add(pwcDbCardTransaction);
                }
            }
        }catch (SQLException e){
            ErrorUtils.throwCBSException(null,
                    ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
                    ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
                    GetCardAuthorizationsAndTransactionsHelper.class.getCanonicalName(),
                    ConstantErrorMessages._SQL_EXCEPTION,
                    ErrorTypeModel.SEVERITY_ERROR,
                    "SQL Error while retrieving Pwc Transactions from DB: " + e.getMessage(), "", "");
        }
        exchange.setProperty("PwcDbTransactionsCount", pwcDbCardTransactions.getPwcDbCardTransaction().size());
        return pwcDbCardTransactions;
    }

    public PwcDbCardTransactions getPwcDbTransactionsPaging(Exchange exchange, String cardNumber, int dateFrom, int dateTo, String transactionTimestamp, String transactionRefNumber, int transactionSeqNumber, int pageSize) throws SQLException, CBSException{
        PwcDbCardTransactions pwcDbCardTransactions = new PwcDbCardTransactions();
        String transactionRefSeqNumber = transactionRefNumber+transactionSeqNumber;
        LOGGER.info("DB Transaction Date BETWEEN " + dateFrom + " AND " + dateTo + " AND (TransactionTimestamp < " + java.sql.Timestamp.valueOf(transactionTimestamp) + " OR(TransactionTimestamp = " + java.sql.Timestamp.valueOf(transactionTimestamp) + " AND TransactionRefSeqNumber > " + transactionRefSeqNumber + ") PageSize: " + pageSize);
        try(Connection connection = historyDbDatasource.getConnection(); PreparedStatement statement = connection.prepareStatement(SELECT_FROM_ENTRY_CARDS_PWC_PAGING)){

            statement.setString(1, cardNumber);
            statement.setInt(2, dateFrom);
            statement.setInt(3, dateTo);
            statement.setTimestamp(4, java.sql.Timestamp.valueOf(transactionTimestamp));
            statement.setTimestamp(5, java.sql.Timestamp.valueOf(transactionTimestamp));
            statement.setString(6, transactionRefSeqNumber);
            statement.setInt(7, pageSize);

            try(ResultSet resultSet = statement.executeQuery()) {
                while(resultSet.next()){
                    PwcDbCardTransactionType pwcDbCardTransaction = new PwcDbCardTransactionType();
                    pwcDbCardTransaction.setCardNumber(resultSet.getString("CardNumber"));
                    pwcDbCardTransaction.setTransactionDate(resultSet.getString("TransactionDate"));
                    pwcDbCardTransaction.setPostingDate(resultSet.getString("PostingDate"));
                    pwcDbCardTransaction.setTransactionCode(resultSet.getString("TransactionCode"));
                    pwcDbCardTransaction.setMerchantName(resultSet.getString("MerchantName"));
                    pwcDbCardTransaction.setMerchantCity(resultSet.getString("MerchantCity"));
                    pwcDbCardTransaction.setMerchantCountry(resultSet.getString("MerchantCountry"));
                    pwcDbCardTransaction.setMerchantCategoryCode(resultSet.getString("MerchantCategoryCode"));
                    pwcDbCardTransaction.setMerchantId(resultSet.getString("MerchantId"));
                    pwcDbCardTransaction.setCardHolderAmountSign(resultSet.getString("CardHolderAmountSign"));
                    pwcDbCardTransaction.setCardHolderAmount(resultSet.getString("CardHolderAmount"));
                    pwcDbCardTransaction.setCardHolderCurrency(resultSet.getString("CardHolderCurrency"));
                    pwcDbCardTransaction.setForeignTransactionAmountSign(resultSet.getString("ForeignTransactionAmountSign"));
                    pwcDbCardTransaction.setForeignTransactionAmount(resultSet.getString("ForeignTransactionAmount"));
                    pwcDbCardTransaction.setForeignTransactionCurrency(resultSet.getString("ForeignTransactionCurrency"));
                    pwcDbCardTransaction.setTransactionTime(resultSet.getString("TransactionTime"));
                    pwcDbCardTransaction.setTransactionTimestamp(resultSet.getString("TransactionTimestamp"));
                    pwcDbCardTransaction.setTransactionRefNumber(resultSet.getString("TransactionRefNumber"));
                    pwcDbCardTransaction.setTransactionSeqNumber(resultSet.getString("TransactionSeqNumber"));
                    pwcDbCardTransaction.setRecurringInd(resultSet.getString("RecurringInd"));
                    pwcDbCardTransaction.setOriginatingChannel(resultSet.getString("OriginatingChannel"));
                    pwcDbCardTransaction.setCPSTransactionID(resultSet.getString("CPSTransactionID"));
                    pwcDbCardTransaction.setIssuerCorporateID(resultSet.getString("IssuerCorporateID"));
                    pwcDbCardTransaction.setProcessingCode(resultSet.getString("ProcessingCode"));
                    pwcDbCardTransaction.setFastFundsIndicator(resultSet.getString("FastFundsIndicator"));
                    pwcDbCardTransaction.setPosData(resultSet.getString("PosData"));
                    pwcDbCardTransaction.setTokenRequestorID(resultSet.getString("TokenRequestorID"));
                    pwcDbCardTransaction.setPaymentID(resultSet.getString("PaymentID"));
                    pwcDbCardTransaction.setCreditCardOpenLoadNumber(resultSet.getString("CreditCardOpenLoadNumber"));
                    pwcDbCardTransaction.setTransactionStatusReasonCode(resultSet.getString("TransactionStatusReasonCode"));
                    pwcDbCardTransaction.setTransactionRefSeqNumber(resultSet.getString("TransactionRefSeqNumber"));
                    pwcDbCardTransaction.setAcquirerInstitutionCode(resultSet.getString("AcquirerInstitutionCode"));
                    pwcDbCardTransaction.setImportID(resultSet.getString("ImportID"));
                    pwcDbCardTransactions.getPwcDbCardTransaction().add(pwcDbCardTransaction);
                }
            }
        }catch (SQLException e){
            ErrorUtils.throwCBSException(null,
                    ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
                    ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
                    GetCardAuthorizationsAndTransactionsHelper.class.getCanonicalName(),
                    ConstantErrorMessages._SQL_EXCEPTION,
                    ErrorTypeModel.SEVERITY_ERROR,
                    "SQL Error while retrieving Pwc Transactions from DB " + e.getMessage(), "", "");
        }
        exchange.setProperty("PwcDbTransactionsCount", pwcDbCardTransactions.getPwcDbCardTransaction().size());
        return pwcDbCardTransactions;
    }

    @Transactional(Transactional.TxType.REQUIRED)
    public PwcDbCardTransactions getPwcDbTransactionsCorporateDb(Exchange exchange, String corporateId, int dateFrom, int dateTo, int pageSize) throws CBSException{
        LOGGER.info("Retrieving Transactions from DB with DateFrom: " + dateFrom + "DateTo: " + dateTo + "PageSize: " + pageSize);
        PwcDbCardTransactions pwcDbCardTransactions = new PwcDbCardTransactions();
        try(Connection connection = historyDbDatasource.getConnection(); PreparedStatement statement = connection.prepareStatement(SELECT_FROM_ENTRY_CARDS_PWC_CORPORATE)){

            statement.setString(1, corporateId);
            statement.setInt(2, dateFrom);
            statement.setInt(3, dateTo);
            statement.setInt(4, pageSize);

            try(ResultSet resultSet = statement.executeQuery()) {
                while(resultSet.next()){
                    PwcDbCardTransactionType pwcDbCardTransaction = new PwcDbCardTransactionType();
                    pwcDbCardTransaction.setCardNumber(resultSet.getString("CardNumber"));
                    pwcDbCardTransaction.setTransactionDate(resultSet.getString("TransactionDate"));
                    pwcDbCardTransaction.setPostingDate(resultSet.getString("PostingDate"));
                    pwcDbCardTransaction.setTransactionCode(resultSet.getString("TransactionCode"));
                    pwcDbCardTransaction.setMerchantName(resultSet.getString("MerchantName"));
                    pwcDbCardTransaction.setMerchantCity(resultSet.getString("MerchantCity"));
                    pwcDbCardTransaction.setMerchantCountry(resultSet.getString("MerchantCountry"));
                    pwcDbCardTransaction.setMerchantCategoryCode(resultSet.getString("MerchantCategoryCode"));
                    pwcDbCardTransaction.setMerchantId(resultSet.getString("MerchantId"));
                    pwcDbCardTransaction.setCardHolderAmountSign(resultSet.getString("CardHolderAmountSign"));
                    pwcDbCardTransaction.setCardHolderAmount(resultSet.getString("CardHolderAmount"));
                    pwcDbCardTransaction.setCardHolderCurrency(resultSet.getString("CardHolderCurrency"));
                    pwcDbCardTransaction.setForeignTransactionAmountSign(resultSet.getString("ForeignTransactionAmountSign"));
                    pwcDbCardTransaction.setForeignTransactionAmount(resultSet.getString("ForeignTransactionAmount"));
                    pwcDbCardTransaction.setForeignTransactionCurrency(resultSet.getString("ForeignTransactionCurrency"));
                    pwcDbCardTransaction.setTransactionTime(resultSet.getString("TransactionTime"));
                    pwcDbCardTransaction.setTransactionTimestamp(resultSet.getString("TransactionTimestamp"));
                    pwcDbCardTransaction.setTransactionRefNumber(resultSet.getString("TransactionRefNumber"));
                    pwcDbCardTransaction.setTransactionSeqNumber(resultSet.getString("TransactionSeqNumber"));
                    pwcDbCardTransaction.setRecurringInd(resultSet.getString("RecurringInd"));
                    pwcDbCardTransaction.setOriginatingChannel(resultSet.getString("OriginatingChannel"));
                    pwcDbCardTransaction.setCPSTransactionID(resultSet.getString("CPSTransactionID"));
                    pwcDbCardTransaction.setIssuerCorporateID(resultSet.getString("IssuerCorporateID"));
                    pwcDbCardTransaction.setProcessingCode(resultSet.getString("ProcessingCode"));
                    pwcDbCardTransaction.setFastFundsIndicator(resultSet.getString("FastFundsIndicator"));
                    pwcDbCardTransaction.setPosData(resultSet.getString("PosData"));
                    pwcDbCardTransaction.setTokenRequestorID(resultSet.getString("TokenRequestorID"));
                    pwcDbCardTransaction.setPaymentID(resultSet.getString("PaymentID"));
                    pwcDbCardTransaction.setCreditCardOpenLoadNumber(resultSet.getString("CreditCardOpenLoadNumber"));
                    pwcDbCardTransaction.setTransactionStatusReasonCode(resultSet.getString("TransactionStatusReasonCode"));
                    pwcDbCardTransaction.setTransactionRefSeqNumber(resultSet.getString("TransactionRefSeqNumber"));
                    pwcDbCardTransaction.setAcquirerInstitutionCode(resultSet.getString("AcquirerInstitutionCode"));
                    pwcDbCardTransaction.setImportID(resultSet.getString("ImportID"));
                    pwcDbCardTransactions.getPwcDbCardTransaction().add(pwcDbCardTransaction);
                }
            }
        }catch (SQLException e){
            ErrorUtils.throwCBSException(null,
                    ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
                    ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
                    GetCardAuthorizationsAndTransactionsHelper.class.getCanonicalName(),
                    ConstantErrorMessages._SQL_EXCEPTION,
                    ErrorTypeModel.SEVERITY_ERROR,
                    "SQL Error while retrieving Pwc Transactions from DB " + e.getMessage(), "", "");
        }
        exchange.setProperty("PwcDbTransactionsCount", pwcDbCardTransactions.getPwcDbCardTransaction().size());
        return pwcDbCardTransactions;
    }

    public PwcDbCardTransactions getPwcDbTransactionsCorporatePaging(Exchange exchange, String corporateId, int dateFrom, int dateTo, String transactionTimestamp, String transactionRefNumber, int transactionSeqNumber, int pageSize) throws SQLException, CBSException{
        PwcDbCardTransactions pwcDbCardTransactions = new PwcDbCardTransactions();
        String transactionRefSeqNumber = transactionRefNumber+transactionSeqNumber;
        LOGGER.info("DB Transaction Date BETWEEN " + dateFrom + " AND " + dateTo + " AND (TransactionTimestamp < " + java.sql.Timestamp.valueOf(transactionTimestamp) + " OR(TransactionTimestamp = " + java.sql.Timestamp.valueOf(transactionTimestamp) + " AND TransactionRefSeqNumber > " + transactionRefSeqNumber + ") PageSize: " + pageSize);
        try(Connection connection = historyDbDatasource.getConnection(); PreparedStatement statement = connection.prepareStatement(SELECT_FROM_ENTRY_CARDS_PWC_CORPORATE_PAGING)){

            statement.setString(1, corporateId);
            statement.setInt(2, dateFrom);
            statement.setInt(3, dateTo);
            statement.setTimestamp(4, java.sql.Timestamp.valueOf(transactionTimestamp));
            statement.setTimestamp(5, java.sql.Timestamp.valueOf(transactionTimestamp));
            statement.setString(6, transactionRefSeqNumber);
            statement.setInt(7, pageSize);

            try(ResultSet resultSet = statement.executeQuery()) {
                while(resultSet.next()){
                    PwcDbCardTransactionType pwcDbCardTransaction = new PwcDbCardTransactionType();
                    pwcDbCardTransaction.setCardNumber(resultSet.getString("CardNumber"));
                    pwcDbCardTransaction.setTransactionDate(resultSet.getString("TransactionDate"));
                    pwcDbCardTransaction.setPostingDate(resultSet.getString("PostingDate"));
                    pwcDbCardTransaction.setTransactionCode(resultSet.getString("TransactionCode"));
                    pwcDbCardTransaction.setMerchantName(resultSet.getString("MerchantName"));
                    pwcDbCardTransaction.setMerchantCity(resultSet.getString("MerchantCity"));
                    pwcDbCardTransaction.setMerchantCountry(resultSet.getString("MerchantCountry"));
                    pwcDbCardTransaction.setMerchantCategoryCode(resultSet.getString("MerchantCategoryCode"));
                    pwcDbCardTransaction.setMerchantId(resultSet.getString("MerchantId"));
                    pwcDbCardTransaction.setCardHolderAmountSign(resultSet.getString("CardHolderAmountSign"));
                    pwcDbCardTransaction.setCardHolderAmount(resultSet.getString("CardHolderAmount"));
                    pwcDbCardTransaction.setCardHolderCurrency(resultSet.getString("CardHolderCurrency"));
                    pwcDbCardTransaction.setForeignTransactionAmountSign(resultSet.getString("ForeignTransactionAmountSign"));
                    pwcDbCardTransaction.setForeignTransactionAmount(resultSet.getString("ForeignTransactionAmount"));
                    pwcDbCardTransaction.setForeignTransactionCurrency(resultSet.getString("ForeignTransactionCurrency"));
                    pwcDbCardTransaction.setTransactionTime(resultSet.getString("TransactionTime"));
                    pwcDbCardTransaction.setTransactionTimestamp(resultSet.getString("TransactionTimestamp"));
                    pwcDbCardTransaction.setTransactionRefNumber(resultSet.getString("TransactionRefNumber"));
                    pwcDbCardTransaction.setTransactionSeqNumber(resultSet.getString("TransactionSeqNumber"));
                    pwcDbCardTransaction.setRecurringInd(resultSet.getString("RecurringInd"));
                    pwcDbCardTransaction.setOriginatingChannel(resultSet.getString("OriginatingChannel"));
                    pwcDbCardTransaction.setCPSTransactionID(resultSet.getString("CPSTransactionID"));
                    pwcDbCardTransaction.setIssuerCorporateID(resultSet.getString("IssuerCorporateID"));
                    pwcDbCardTransaction.setProcessingCode(resultSet.getString("ProcessingCode"));
                    pwcDbCardTransaction.setFastFundsIndicator(resultSet.getString("FastFundsIndicator"));
                    pwcDbCardTransaction.setPosData(resultSet.getString("PosData"));
                    pwcDbCardTransaction.setTokenRequestorID(resultSet.getString("TokenRequestorID"));
                    pwcDbCardTransaction.setPaymentID(resultSet.getString("PaymentID"));
                    pwcDbCardTransaction.setCreditCardOpenLoadNumber(resultSet.getString("CreditCardOpenLoadNumber"));
                    pwcDbCardTransaction.setTransactionStatusReasonCode(resultSet.getString("TransactionStatusReasonCode"));
                    pwcDbCardTransaction.setTransactionRefSeqNumber(resultSet.getString("TransactionRefSeqNumber"));
                    pwcDbCardTransaction.setAcquirerInstitutionCode(resultSet.getString("AcquirerInstitutionCode"));
                    pwcDbCardTransaction.setImportID(resultSet.getString("ImportID"));
                    pwcDbCardTransactions.getPwcDbCardTransaction().add(pwcDbCardTransaction);
                }
            }
        }catch (SQLException e){
            ErrorUtils.throwCBSException(null,
                    ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
                    ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
                    GetCardAuthorizationsAndTransactionsHelper.class.getCanonicalName(),
                    ConstantErrorMessages._SQL_EXCEPTION,
                    ErrorTypeModel.SEVERITY_ERROR,
                    "SQL Error while retrieving Pwc Transactions from DB " + e.getMessage(), "", "");
        }
        exchange.setProperty("PwcDbTransactionsCount", pwcDbCardTransactions.getPwcDbCardTransaction().size());
        return pwcDbCardTransactions;
    }

    @Transactional(Transactional.TxType.REQUIRED)
    public String getCardNumberFromCorporateIdDb(String corporateId) throws CBSException {
        String cardNumber = "";
        try(Connection connection = historyDbDatasource.getConnection(); PreparedStatement statement = connection.prepareStatement(SELECT_FROM_CMS_MAIN_CARDS_MAPPING)){
            statement.setString(1, corporateId);
            try(ResultSet resultSet = statement.executeQuery()) {
                while(resultSet.next()){
                    cardNumber = resultSet.getString("CMS_MainCardNumber");
                }
            }
        }catch (SQLException e){
            ErrorUtils.throwCBSException(null,
                    ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
                    ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
                    GetCardAuthorizationsAndTransactionsHelper.class.getCanonicalName(),
                    ConstantErrorMessages._SQL_EXCEPTION,
                    ErrorTypeModel.SEVERITY_ERROR,
                    "SQL Error while retrieving CardNumber by CorporateId from DB: " + e.getMessage(), "", "");
        }
        return cardNumber;
    }

    public List<String> getReplacedCards(String cardNumber) throws CBSException{
        List<String> replacedCards = new ArrayList<>();
        String applicationReferenceNumber = "";
        String cardProgram = "";
        try(Connection connection = historyDbDatasource.getConnection()){

            try(PreparedStatement applicationReferencePreparedStatement = connection.prepareStatement(SELECT_APPLICATION_NUMBER_FROM_CARD_LINKS)){
                applicationReferencePreparedStatement.setString(1, cardNumber);
                try(ResultSet applicationReferenceResultSet = applicationReferencePreparedStatement.executeQuery()){
                    while(applicationReferenceResultSet.next()){
                        applicationReferenceNumber = applicationReferenceResultSet.getString("ApplicationRefrenceNumber");
                        cardProgram = applicationReferenceResultSet.getString("CardProgram");
                    }
                }
            }

            try(PreparedStatement replacedCardsPreparedStatement = connection.prepareStatement(SELECT_CARDS_INT_FROM_CARDS_LINK)){
                replacedCardsPreparedStatement.setString(1, applicationReferenceNumber);
                replacedCardsPreparedStatement.setString(2, cardProgram);
                try(ResultSet replacedCardsResultSet = replacedCardsPreparedStatement.executeQuery()){
                    while(replacedCardsResultSet.next()){
                        replacedCards.add(replacedCardsResultSet.getString("AccountNumberINT"));
                    }
                }
            }

        }catch (SQLException e){
            ErrorUtils.throwCBSException(null,
                    ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
                    ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
                    GetCardAuthorizationsAndTransactionsHelper.class.getCanonicalName(),
                    ConstantErrorMessages._SQL_EXCEPTION,
                    ErrorTypeModel.SEVERITY_ERROR,
                    "SQL Error while selecting ApplicationReferenceNumber and CardProgram " + e.getMessage(), "", "");
        }

        if(!replacedCards.stream().anyMatch(card -> card.equals(cardNumber))){
            replacedCards.add(cardNumber);
        }

        return replacedCards;
    }

    public void putTransactionsToCache(String cacheKey, GetCardAuthorizationsAndTransactionsCardTransactionsListType cardTransactionsList) throws IOException {
        if(getTransactionsFromCache(cacheKey) == null) {
            ObjectMapper objectMapper = ObjectMapperHelper.getObjectMapperInstance().setupResponseConfiguration();
            String payload = objectMapper.writeValueAsString(cardTransactionsList);
            datagridHelper.put(cacheKey, payload);
        }
    }

    public GetCardAuthorizationsAndTransactionsCardTransactionsListType getTransactionsFromCache(String cacheKey) throws IOException {
        String cacheEntry = null;
        GetCardAuthorizationsAndTransactionsCardTransactionsListType cardTransactionsList = null;
        if (datagridHelper.getCache() != null) {
            Object value = datagridHelper.get(cacheKey);
            if (value != null) {
                cacheEntry = (String)value;
                ObjectMapper objectMapper = ObjectMapperHelper.getObjectMapperInstance().setupResponseConfiguration();
                cardTransactionsList = objectMapper.readValue(cacheEntry, GetCardAuthorizationsAndTransactionsCardTransactionsListType.class);
            }
        }
        return cardTransactionsList;
    }

    public String getCardNumberFromCorporateId(Exchange exchange) throws CBSException{
        return getCardNumberFromCorporateIdDb(exchange.getProperty("CorporateId", String.class));
    }

    public void buildCardEntriesUrl(Exchange exchange) throws NamingException, SQLException, CBSException {
        Document doc = exchange.getIn().getBody(Document.class);
        StringJoiner historyQueryParams = new StringJoiner("&");
        // dates are mandatory fields in request
        String historyDateFrom = String.format("DateFrom=%s", FormatUtils.getValue(doc, "/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:DateFrom"));
        historyQueryParams.add(historyDateFrom);

        String historyDateTo;
        String targetSystem = exchange.getProperty("TargetSystem", String.class);
        if(targetSystem.equals("Legacy")){
            historyDateTo = String.format("DateTo=%s", exchange.getProperty("DateTo", String.class));
        }else{
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
            LocalDateTime dateTo = LocalDateTime.parse(exchange.getProperty("DateTo", String.class), dateTimeFormatter);
            LocalDateTime pwcMigrationDate = LocalDateTime.parse(exchange.getProperty("PwcMigrationDate", String.class), dateTimeFormatter);
            if(dateTo.isBefore(pwcMigrationDate)) {
                historyDateTo = String.format("DateTo=%s", exchange.getProperty("DateTo", String.class));
            }else if(dateTo.isAfter(pwcMigrationDate)){
                historyDateTo = String.format("DateTo=%s", exchange.getProperty("PwcMigrationDate", String.class));
            }else{
                // Equal
                historyDateTo = String.format("DateTo=%s", exchange.getProperty("DateTo", String.class));
            }
        }
        historyQueryParams.add(historyDateTo);

        if (null != exchange.getProperty("LegacyPageNumber", String.class)) {
            String historyPageNumber = String.format("PageNumber=%s", exchange.getProperty("LegacyPageNumber", String.class));
            historyQueryParams.add(historyPageNumber);
        }

        boolean isCorporate = Boolean.parseBoolean(exchange.getProperty("IsCorporate", String.class));
        String productCode = "";
        if(isCorporate){
            productCode = exchange.getProperty("CardNumberFromCorporateId", String.class);
        }else{
            productCode = exchange.getProperty("CardNumber", String.class);
        }
        String historyProductCodes = String.format("ProductCodes=%s", productCode);
        historyQueryParams.add(historyProductCodes);

        if (null != exchange.getProperty("CBSPageSize", String.class)) {
            String historyPageSize = String.format("PageSize=%s", exchange.getProperty("CBSPageSize", String.class));
            historyQueryParams.add(historyPageSize);
        }

        if (!FormatUtils.getValue(doc, "/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:SearchWords").isEmpty()) {
            String historySearchWords = String.format("SearchWords=%s", FormatUtils.getValue(doc, "/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:SearchWords"));
            historyQueryParams.add(historySearchWords);
        }

        if (!FormatUtils.getValue(doc, "/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:Language").isEmpty()) {
            String historyLanguage = String.format("Language=%s", FormatUtils.getValue(doc, "/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:Language"));
            historyQueryParams.add(historyLanguage);
        }

        historyQueryParams.add("RetrieveAddons=true");

        if (null != ConfigProvider.getConfig().getValue("cbs.mw.cardsintegration.accshistorydbapi.params", String.class)) {
            historyQueryParams.add(ConfigProvider.getConfig().getValue("cbs.mw.cardsintegration.accshistorydbapi.params", String.class));
        }

        String cardEntriesUrl = String.format("https://%s/historyCardstx/api/v1/CardEntries?%s", ConfigProvider.getConfig().getValue("cbs.mw.cardsintegration.accshistorydbapi", String.class), historyQueryParams);
        LOGGER.infof("Calling %s", cardEntriesUrl);
        exchange.setProperty("CardEntriesUrl", cardEntriesUrl);
    }

    public void prepareCardEntriesResponse(Exchange exchange) throws IOException {
        String responseJson = exchange.getIn().getBody(String.class);
        ObjectMapper mapper = gr.alpha.cbs.fuse.cardsedge.powercard.ObjectMapperHelper.getObjectMapperInstance().setupResponseConfiguration();
        CardEntriesResponse cardEntriesResponse = mapper.readValue(responseJson, CardEntriesResponse.class);
        exchange.getIn().setBody(cardEntriesResponse);
    }

    public void getPwcDbTransactions(Exchange exchange) throws SQLException, CBSException, ParseException, NamingException {
        Document doc = exchange.getIn().getBody(Document.class);
        String cardNumber = FormatUtils.getValue(doc, "/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:CardNumber");

        final String OLD_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
        final String NEW_DATE_FORMAT = "yyyyMMdd";

        SimpleDateFormat dateFromSdf = new SimpleDateFormat(OLD_DATE_FORMAT);
        Date dateFromDate = dateFromSdf.parse(exchange.getProperty("DateFrom", String.class));
        dateFromSdf.applyPattern(NEW_DATE_FORMAT);
        String dateFrom = dateFromSdf.format(dateFromDate);

        SimpleDateFormat dateToSdf = new SimpleDateFormat(OLD_DATE_FORMAT);
        Date dateToDate = dateToSdf.parse(exchange.getProperty("DateTo", String.class));
        dateToSdf.applyPattern(NEW_DATE_FORMAT);
        String dateTo = dateToSdf.format(dateToDate);

        Integer pageSize = Integer.parseInt(FormatUtils.getValue(doc, "/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:PagingInfo/*:PageSize"));

        Boolean isPaging = exchange.getProperty("IsPaging", Boolean.class);
        boolean isCorporate = Boolean.parseBoolean(exchange.getProperty("IsCorporate", String.class));
        String corporateId = exchange.getProperty("CorporateId", String.class);
        if(isPaging) {
            final String NEW_DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
            SimpleDateFormat dateTimeSdf = new SimpleDateFormat(OLD_DATE_FORMAT);
            Date dateTime = dateTimeSdf.parse(FormatUtils.getValue(doc, "/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:PagingInfo/*:LastTransactionOnlineTimeStampDB"));
            dateTimeSdf.applyPattern(NEW_DATETIME_FORMAT);
            String lastTransactionOnlineTimeStampDB = dateTimeSdf.format(dateTime);
            String transIdDb = FormatUtils.getValue(doc,"/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:PagingInfo/*:TransRetrieveFromKeysDB/*:TransId");
            Integer refSeqDb = Integer.parseInt(FormatUtils.getValue(doc, "/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:PagingInfo/*:TransRetrieveFromKeysDB/*:RefSeq"));
            if(!isCorporate){
                exchange.getIn().setBody(getPwcDbTransactionsPaging(exchange, cardNumber, Integer.parseInt(dateFrom), Integer.parseInt(dateTo), lastTransactionOnlineTimeStampDB, transIdDb, refSeqDb, pageSize + 1));
            }else{
                exchange.getIn().setBody(getPwcDbTransactionsCorporatePaging(exchange, corporateId, Integer.parseInt(dateFrom), Integer.parseInt(dateTo), lastTransactionOnlineTimeStampDB, transIdDb, refSeqDb, pageSize + 1));
            }
        }else{
            if(!isCorporate) {
                exchange.getIn().setBody(getPwcDbTransactionsDb(exchange, cardNumber, Integer.parseInt(dateFrom), Integer.parseInt(dateTo), pageSize + 1));
            }else{
                exchange.getIn().setBody(getPwcDbTransactionsCorporateDb(exchange, corporateId, Integer.parseInt(dateFrom), Integer.parseInt(dateTo), pageSize + 1));
            }
        }
        Integer pwcDbTransactionsCount = exchange.getProperty("PwcDbTransactionsCount", Integer.class);
        boolean pwcDbHasMore = false;
        if(pageSize < pwcDbTransactionsCount){
            pwcDbHasMore = true;
        }
        exchange.setProperty("PwcDbHasMore", pwcDbHasMore);
    }

    public String getPwcMigrationDate(Exchange exchange) throws Exception {
        boolean isCorporate = Boolean.parseBoolean(exchange.getProperty("IsCorporate", String.class));
        String cardNumber = null;
        if(!isCorporate){
            cardNumber = exchange.getProperty("CardNumber", String.class);
        }else{
            cardNumber = getCardNumberFromCorporateId(exchange);
        }
        if(cardNumber != null && !cardNumber.isEmpty()) {
            String pwcMigrationDateFromBin = cardsEdgeCommonFunctions.getPwcMigrationDateFromBin(cardNumber);
            if (pwcMigrationDateFromBin != null && !pwcMigrationDateFromBin.isEmpty()) {
                final String OLD_DATE_FORMAT = "yyyy-MM-dd";
                final String NEW_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
                SimpleDateFormat pwcMigrationDateSdf = new SimpleDateFormat(OLD_DATE_FORMAT);
                Date pwcMigrationDate = pwcMigrationDateSdf.parse(pwcMigrationDateFromBin);
                pwcMigrationDateSdf.applyPattern(NEW_DATE_FORMAT);
                return pwcMigrationDateSdf.format(pwcMigrationDate);
            } else {
                return "2024-03-05T00:00:00";
            }
        }else{
            return "1900-01-01T00:00:00";
        }
    }

    public String getPwcDbLoadDate(Exchange exchange) throws CBSException, ParseException{
        final String OLD_DATE_FORMAT = "yyyyMMdd";
        final String NEW_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
        SimpleDateFormat pwcDbLoadDateSdf = new SimpleDateFormat(OLD_DATE_FORMAT);
        Date pwcDbLoadDate = pwcDbLoadDateSdf.parse(getPwcDbLoadDateDb());
        pwcDbLoadDateSdf.applyPattern(NEW_DATE_FORMAT);
        return pwcDbLoadDateSdf.format(pwcDbLoadDate);
    }

    public void prepareResponse(Exchange exchange) throws DatatypeConfigurationException, ParseException {
        Document doc = exchange.getIn().getBody(Document.class);
        GetCardAuthorizationsAndTransactionsCardTransactionsListType cardTransactionsList = new GetCardAuthorizationsAndTransactionsCardTransactionsListType();
        DatatypeFactory datatypeFactory = DatatypeFactory.newInstance();

        int cardTransactionsCount = exchange.getProperty("CardsTransactionsCount", Integer.class);
        for(int i = 1; i <= cardTransactionsCount; i++){
            GetCardAuthorizationsAndTransactionsCardTransactionType cardTransaction = new GetCardAuthorizationsAndTransactionsCardTransactionType();
            cardTransaction.setCardNumber(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:CardNumber"));
            String transactionDate = FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:TransactionDate");
            if(!transactionDate.isEmpty()) {
                cardTransaction.setTransactionDate(datatypeFactory.newXMLGregorianCalendar(transactionDate));
            }
            String queryDate = FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:QueryDate");
            if(!queryDate.isEmpty()) {
                cardTransaction.setQueryDate(datatypeFactory.newXMLGregorianCalendar(queryDate));
            }
            String transactionTimestamp = FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:TransactionTimestamp");
            if(!transactionTimestamp.isEmpty()) {
                cardTransaction.setTransactionTimestamp(datatypeFactory.newXMLGregorianCalendar(transactionTimestamp));
            }
            String groupingTimestamp = FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:GroupingTimestamp");
            if(!groupingTimestamp.isEmpty()) {
                cardTransaction.setGroupingTimestamp(datatypeFactory.newXMLGregorianCalendar(groupingTimestamp));
            }
            cardTransaction.setEventCategoryCode(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:EventCategoryCode"));
            cardTransaction.setEventCategoryLiteral(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:EventCategoryLiteral"));
            String numberOfInstallments = FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:NumberOfInstallments");
            if(!numberOfInstallments.isEmpty()) {
                cardTransaction.setNumberOfInstallments(Integer.parseInt(numberOfInstallments));
            }
            String numberOfTotalInstallments = FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:NumberOfTotalInstallments");
            if(!numberOfTotalInstallments.isEmpty()) {
                cardTransaction.setNumberOfTotalInstallments(Integer.parseInt(numberOfTotalInstallments));
            }
            cardTransaction.setMerchantName(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:MerchantName"));
            cardTransaction.setMerchantCity(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:MerchantCity"));
            cardTransaction.setMerchantCountry(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:MerchantCountry"));
            cardTransaction.setMerchantCategoriesLocalized(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:MerchantCategoriesLocalized"));
            cardTransaction.setMerchantCategoryCode(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:MerchantCategoryCode"));
            cardTransaction.setMerchantID(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:MerchantID"));
            cardTransaction.setMerchantCategoryLiteral(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:MerchantCategoryLiteral"));
            cardTransaction.setCardHolderAmountSign(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:CardHolderAmountSign"));
            cardTransaction.setCardHolderAmount(formatDecimal(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:CardHolderAmount")));
            cardTransaction.setCardHolderCurrency(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:CardHolderCurrency"));
            cardTransaction.setCardHolderCurrencyLiteral(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:CardHolderCurrencyLiteral"));
            String isPending = FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:IsPending");
            if(!isPending.isEmpty()) {
                cardTransaction.setIsPending(Boolean.parseBoolean(isPending));
            }
            cardTransaction.setDeltaReference(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:DeltaReference"));
            cardTransaction.setCKey(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:CKey"));
            String postingDate = FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:PostingDate");
            if(!postingDate.isEmpty()) {
                cardTransaction.setPostingDate(datatypeFactory.newXMLGregorianCalendar(postingDate));
            }
            cardTransaction.setChannelMainDescription(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:ChannelMainDescription"));
            String billingDate = FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:BillingDate");
            if(!billingDate.isEmpty()) {
                cardTransaction.setBillingDate(datatypeFactory.newXMLGregorianCalendar(billingDate));
            }
            String foreignTransactionCurrencyLiteral = FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:ForeignTransactionCurrencyLiteral");
            if(!foreignTransactionCurrencyLiteral.isEmpty()) {
                cardTransaction.setForeignTransactionCurrencyLiteral(foreignTransactionCurrencyLiteral);
            }
            cardTransaction.setForeignTransactionCurrency(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:ForeignTransactionCurrency"));
            cardTransaction.setForeignTransactionAmount(formatDecimal(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:ForeignTransactionAmount")));
            cardTransaction.setForeignTransactionAmountSign(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:ForeignTransactionAmountSign"));
            cardTransaction.setChannelMainId(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:ChannelMainId"));
            cardTransaction.setMerchantCategoriesId(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:MerchantCategoriesId"));
            cardTransaction.setTransactionCode(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:TransactionCode"));
            cardTransaction.setMidOnUs(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:MidOnUs"));
            cardTransaction.setSourceType(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:SourceType"));
            String utilityPaymentID = FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:UtilityPaymentID");
            if(!utilityPaymentID.isEmpty()) {
                cardTransaction.setUtilityPaymentID(utilityPaymentID);
            }
            cardTransaction.setRecordType(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:RecordType"));
            if(cardTransaction.getRecordType().equals("A")) {
                AuthoRetrieveFromKeysType authoRetrieveFromKeys = new AuthoRetrieveFromKeysType();
                authoRetrieveFromKeys.setReferenceNumber(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:ReferenceNumber"));
                authoRetrieveFromKeys.setInternalStan(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:InternalStan"));
                authoRetrieveFromKeys.setExternalStan(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:ExternalStan"));
                authoRetrieveFromKeys.setCaptureCode(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:CaptureCode"));
                authoRetrieveFromKeys.setRoutingCode(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:RoutingCode"));
                cardTransaction.setAuthoRetrieveFromKeys(authoRetrieveFromKeys);
            }
            if(cardTransaction.getRecordType().equals("T") || cardTransaction.getRecordType().equals("DB")){
                TransRetrieveFromKeysType transRetrieveFromKeys = new TransRetrieveFromKeysType();
                transRetrieveFromKeys.setTransId(FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:TransId"));
                String refSeq = FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:RefSeq");
                if(!refSeq.isEmpty()){
                    transRetrieveFromKeys.setRefSeq(Integer.parseInt(refSeq));
                }
                String transDate = FormatUtils.getValue(doc, "/*:Mapping/*:CardTransactionsList/*:CardTransaction[" + i + "]/*:TransDate");
                if(!transDate.isEmpty()) {
                    transRetrieveFromKeys.setTransDate(datatypeFactory.newXMLGregorianCalendar(transDate));
                }
                cardTransaction.setTransRetrieveFromKeys(transRetrieveFromKeys);
            }
            cardTransactionsList.getCardTransaction().add(cardTransaction);
        }

        GetCardAuthorizationsAndTransactionsCardTransactionsListType filteredCardTransactionList = new GetCardAuthorizationsAndTransactionsCardTransactionsListType();
        for(int i = 0; i < cardTransactionsList.getCardTransaction().size(); i++){
            if(cardTransactionsList.getCardTransaction().get(i).getRecordType().equals("A") || cardTransactionsList.getCardTransaction().get(i).getRecordType().equals("DB") || cardTransactionsList.getCardTransaction().get(i).getRecordType().equals("CE")){
                filteredCardTransactionList.getCardTransaction().add(cardTransactionsList.getCardTransaction().get(i));
            }
            if(cardTransactionsList.getCardTransaction().get(i).getRecordType().equals("T")){
                boolean transactionExistsInDB = false;
                for(int j = 0; j < cardTransactionsList.getCardTransaction().size(); j++){
                    if(cardTransactionsList.getCardTransaction().get(j).getRecordType().equals("DB")){
                        if(cardTransactionsList.getCardTransaction().get(i).getTransRetrieveFromKeys().getTransId().equals(cardTransactionsList.getCardTransaction().get(j).getTransRetrieveFromKeys().getTransId())
                                && cardTransactionsList.getCardTransaction().get(i).getTransRetrieveFromKeys().getRefSeq() == cardTransactionsList.getCardTransaction().get(j).getTransRetrieveFromKeys().getRefSeq()){
                            transactionExistsInDB = true;
                        }
                    }
                }
                if(!transactionExistsInDB){
                    filteredCardTransactionList.getCardTransaction().add(cardTransactionsList.getCardTransaction().get(i));
                }
            }
        }

        GetCardAuthorizationsAndTransactionsCardTransactionsListType sortedCardTransactionsList = new GetCardAuthorizationsAndTransactionsCardTransactionsListType();
        sortedCardTransactionsList.getCardTransaction().addAll(
                filteredCardTransactionList.getCardTransaction().stream().sorted((o1, o2) -> {
                            //First, order by Query Date
                            int queryDateComparison = o2.getQueryDate().compare(o1.getQueryDate());
                            if(queryDateComparison != 0) {
                                return queryDateComparison;
                            }

                            //If QueryDate is the same, sort by TransactionTimestamp
                            int transactionTimestampComparison = o2.getTransactionTimestamp().compare(o1.getTransactionTimestamp());
                            if (transactionTimestampComparison != 0) {
                                return transactionTimestampComparison;
                            }

                            //If QueryDate and TransactionTimestamp are the same, use CKey
                            return o1.getCKey().compareTo(o2.getCKey());
                        })
                        .collect(Collectors.toList())
        );

        // Limit the sorted transactions according to the page size
        GetCardAuthorizationsAndTransactionsCardTransactionsListType limitedCardTransactionsList = new GetCardAuthorizationsAndTransactionsCardTransactionsListType();
        int pageSize = exchange.getProperty("CBSPageSize", Integer.class);
        limitedCardTransactionsList.getCardTransaction().addAll(sortedCardTransactionsList.getCardTransaction().stream().limit(pageSize).collect(Collectors.toList()));

        // if any ACCS transaction is involved, return the full sorted list
        boolean limitedListHasAnyAccsTransactions = limitedCardTransactionsList.getCardTransaction().stream().anyMatch(cardTransaction -> "CE".equals(cardTransaction.getRecordType()));
        if(limitedListHasAnyAccsTransactions){
            limitedCardTransactionsList = sortedCardTransactionsList;
        }

        GetCardAuthorizationsAndTransactionsPagingInfoType pagingInfo = new GetCardAuthorizationsAndTransactionsPagingInfoType();

        boolean searchAuthorizationsCalled = cardTransactionsList.getCardTransaction().stream().anyMatch(cardTransaction -> cardTransaction.getRecordType().equals("A"));
        if(searchAuthorizationsCalled) {
            String pwcAuthorizationsCurrentPage = FormatUtils.getValue(doc, "/*:Mapping/*:PwcAuthorizationsCurrentPage");
            String pwcAuthorizationsTotalPages = FormatUtils.getValue(doc, "/*:Mapping/*:PwcAuthorizationsTotalPages");
            String lastPwcAuthorizationReferenceNumber = FormatUtils.getValue(doc, "/*:Mapping/*:LastPwcAuthorizationReferenceNumber");
            XMLGregorianCalendar lastIncludedAuthorizationTimeStamp = null;
            AuthoRetrieveFromKeysType lastIncludedAuthorizationKeys = null;
            boolean authorizationIncluded = false;
            for (GetCardAuthorizationsAndTransactionsCardTransactionType cardTransaction : limitedCardTransactionsList.getCardTransaction()) {
                if (cardTransaction.getRecordType().equals("A")) {
                    authorizationIncluded = true;
                    lastIncludedAuthorizationTimeStamp = cardTransaction.getTransactionDate();
                    lastIncludedAuthorizationKeys = new AuthoRetrieveFromKeysType();
                    lastIncludedAuthorizationKeys.setReferenceNumber(cardTransaction.getAuthoRetrieveFromKeys().getReferenceNumber());
                    lastIncludedAuthorizationKeys.setInternalStan(cardTransaction.getAuthoRetrieveFromKeys().getInternalStan());
                    lastIncludedAuthorizationKeys.setExternalStan(cardTransaction.getAuthoRetrieveFromKeys().getExternalStan());
                    lastIncludedAuthorizationKeys.setCaptureCode(cardTransaction.getAuthoRetrieveFromKeys().getCaptureCode());
                    lastIncludedAuthorizationKeys.setRoutingCode(cardTransaction.getAuthoRetrieveFromKeys().getRoutingCode());
                }
            }
            if ((pwcAuthorizationsCurrentPage.equals(pwcAuthorizationsTotalPages)) && (lastIncludedAuthorizationKeys != null && lastPwcAuthorizationReferenceNumber.equals(lastIncludedAuthorizationKeys.getReferenceNumber()))) {
                pagingInfo.setRequestAuthorizations(false);
            } else {
                pagingInfo.setRequestAuthorizations(true);
                if (authorizationIncluded) {
                    pagingInfo.setLastAuthorizationTimeStamp(lastIncludedAuthorizationTimeStamp);
                    pagingInfo.setAuthoRetrieveFromKeys(lastIncludedAuthorizationKeys);
                } else {
                    boolean requestAuthorizations = Boolean.parseBoolean(exchange.getProperty("RequestAuthorizations", String.class));
                    if(requestAuthorizations) {
                        pagingInfo.setLastAuthorizationTimeStamp(datatypeFactory.newXMLGregorianCalendar(FormatUtils.getValue(doc, "/*:Mapping/*:RequestPagingInfo/*:LastAuthorizationTimeStamp")));
                        AuthoRetrieveFromKeysType reqAuthoRetrieveFromKeys = new AuthoRetrieveFromKeysType();
                        reqAuthoRetrieveFromKeys.setReferenceNumber(FormatUtils.getValue(doc, "/*:Mapping/*:RequestPagingInfo/*:AuthoRetrieveFromKeys/*:ReferenceNumber"));
                        reqAuthoRetrieveFromKeys.setInternalStan(FormatUtils.getValue(doc, "/*:Mapping/*:RequestPagingInfo/*:AuthoRetrieveFromKeys/*:InternalStan"));
                        reqAuthoRetrieveFromKeys.setExternalStan(FormatUtils.getValue(doc, "/*:Mapping/*:RequestPagingInfo/*:AuthoRetrieveFromKeys/*:ExternalStan"));
                        reqAuthoRetrieveFromKeys.setCaptureCode(FormatUtils.getValue(doc, "/*:Mapping/*:RequestPagingInfo/*:AuthoRetrieveFromKeys/*:CaptureCode"));
                        reqAuthoRetrieveFromKeys.setRoutingCode(FormatUtils.getValue(doc, "/*:Mapping/*:RequestPagingInfo/*:AuthoRetrieveFromKeys/*:RoutingCode"));
                        pagingInfo.setAuthoRetrieveFromKeys(reqAuthoRetrieveFromKeys);
                    }else{
                        pagingInfo.setRequestAuthorizations(false);
                    }
                }
            }
        }else{
            pagingInfo.setRequestAuthorizations(false);
        }

        boolean searchTransactionsCalled = cardTransactionsList.getCardTransaction().stream().anyMatch(cardTransaction -> cardTransaction.getRecordType().equals("T"));
        if(searchTransactionsCalled){
            String pwcTransactionsCurrentPage = FormatUtils.getValue(doc, "/*:Mapping/*:PwcTransactionsCurrentPage");
            String pwcTransactionsTotalPages = FormatUtils.getValue(doc, "/*:Mapping/*:PwcTransactionsTotalPages");
            String lastPwcTransactionTransId = FormatUtils.getValue(doc, "/*:Mapping/*:LastPwcTransactionTransId");
            boolean containsLastPwcTransaction = false;
            XMLGregorianCalendar lastIncludedTransactionOnlineTimeStamp = null;
            TransRetrieveFromKeysType lastIncludedTransactionKeys = null;
            boolean transactionIncluded = false;
            for (GetCardAuthorizationsAndTransactionsCardTransactionType cardTransaction : limitedCardTransactionsList.getCardTransaction()) {
                if (cardTransaction.getRecordType().equals("T")) {
                    transactionIncluded = true;
                    lastIncludedTransactionKeys = new TransRetrieveFromKeysType();
                    lastIncludedTransactionOnlineTimeStamp = cardTransaction.getTransactionDate();
                    lastIncludedTransactionKeys.setTransId(cardTransaction.getTransRetrieveFromKeys().getTransId());
                    lastIncludedTransactionKeys.setRefSeq(cardTransaction.getTransRetrieveFromKeys().getRefSeq());
                    lastIncludedTransactionKeys.setTransDate(cardTransaction.getTransRetrieveFromKeys().getTransDate());
                }
                if(cardTransaction.getRecordType().equals("T") || cardTransaction.getRecordType().equals("DB")){
                    if(lastPwcTransactionTransId.equals(cardTransaction.getTransRetrieveFromKeys().getTransId())){
                        containsLastPwcTransaction = true;
                    }
                }
            }

            if ((pwcTransactionsCurrentPage.equals(pwcTransactionsTotalPages)) && (lastIncludedTransactionKeys != null && containsLastPwcTransaction)) {
                pagingInfo.setRequestTransactionsOnline(false);
            } else {
                pagingInfo.setRequestTransactionsOnline(true);
                if (transactionIncluded) {
                    pagingInfo.setLastTransactionOnlineTimeStamp(lastIncludedTransactionOnlineTimeStamp);
                    pagingInfo.setTransRetrieveFromKeys(lastIncludedTransactionKeys);
                } else {
                    boolean requestTransactionsOnline = Boolean.parseBoolean(exchange.getProperty("RequestTransactionsOnline", String.class));
                    if(requestTransactionsOnline) {
                        pagingInfo.setLastTransactionOnlineTimeStamp(datatypeFactory.newXMLGregorianCalendar(FormatUtils.getValue(doc, "/*:Mapping/*:RequestPagingInfo/*:LastTransactionOnlineTimeStamp")));
                        TransRetrieveFromKeysType reqTransRetrieveFromKeys = new TransRetrieveFromKeysType();
                        reqTransRetrieveFromKeys.setTransId(FormatUtils.getValue(doc, "/*:Mapping/*:RequestPagingInfo/*:TransRetrieveFromKeys/*:TransId"));
                        reqTransRetrieveFromKeys.setRefSeq(Integer.parseInt(FormatUtils.getValue(doc, "/*:Mapping/*:RequestPagingInfo/*:TransRetrieveFromKeys/*:RefSeq")));
                        String transDate = FormatUtils.getValue(doc, "/*:Mapping/*:RequestPagingInfo/*:TransRetrieveFromKeys/*:TransDate");
                        if(!transDate.isEmpty()) {
                            reqTransRetrieveFromKeys.setTransDate(datatypeFactory.newXMLGregorianCalendar(transDate));
                        }
                        pagingInfo.setTransRetrieveFromKeys(reqTransRetrieveFromKeys);
                    }else{
                        pagingInfo.setRequestTransactionsOnline(false);
                    }
                }
            }
        }else{
            pagingInfo.setRequestTransactionsOnline(false);
        }

        boolean dbCalled = cardTransactionsList.getCardTransaction().stream().anyMatch(cardTransaction -> cardTransaction.getRecordType().equals("DB"));

        if(dbCalled){
            String lastPwcTransactionTransIdDB = FormatUtils.getValue(doc, "/*:Mapping/*:LastPwcTransactionTransIdDB");
            boolean pwcDbHasMore = exchange.getProperty("PwcDbHasMore", Boolean.class);
            XMLGregorianCalendar lastIncludedTransactionOnlineTimeStampDB = null;
            TransRetrieveFromKeysType lastIncludedTransactionKeysDB = null;
            boolean transactionDBIncluded = false;
            for (GetCardAuthorizationsAndTransactionsCardTransactionType cardTransaction : limitedCardTransactionsList.getCardTransaction()) {
                if (cardTransaction.getRecordType().equals("DB")) {
                    transactionDBIncluded = true;
                    lastIncludedTransactionKeysDB = new TransRetrieveFromKeysType();
                    lastIncludedTransactionOnlineTimeStampDB = cardTransaction.getTransactionTimestamp();
                    lastIncludedTransactionKeysDB.setTransId(cardTransaction.getTransRetrieveFromKeys().getTransId());
                    lastIncludedTransactionKeysDB.setRefSeq(cardTransaction.getTransRetrieveFromKeys().getRefSeq());
                }
            }
            if ((!pwcDbHasMore) && (lastIncludedTransactionKeysDB != null && lastPwcTransactionTransIdDB.equals(lastIncludedTransactionKeysDB.getTransId()))) {
                pagingInfo.setRequestTransactionsOnlineDB(false);
            } else {
                pagingInfo.setRequestTransactionsOnlineDB(true);
                if (transactionDBIncluded) {
                    pagingInfo.setLastTransactionOnlineTimeStampDB(lastIncludedTransactionOnlineTimeStampDB);
                    pagingInfo.setTransRetrieveFromKeysDB(lastIncludedTransactionKeysDB);
                } else {
                    boolean requestTransactionsOnlineDB = Boolean.parseBoolean(exchange.getProperty("RequestTransactionsOnlineDB", String.class));
                    if(requestTransactionsOnlineDB){
                        pagingInfo.setLastTransactionOnlineTimeStampDB(datatypeFactory.newXMLGregorianCalendar(FormatUtils.getValue(doc, "/*:Mapping/*:RequestPagingInfo/*:LastTransactionOnlineTimeStampDB")));
                        TransRetrieveFromKeysType reqTransRetrieveFromKeysDB = new TransRetrieveFromKeysType();
                        reqTransRetrieveFromKeysDB.setTransId(FormatUtils.getValue(doc, "/*:Mapping/*:RequestPagingInfo/*:TransRetrieveFromKeysDB/*:TransId"));
                        reqTransRetrieveFromKeysDB.setRefSeq(Integer.parseInt(FormatUtils.getValue(doc, "/*:Mapping/*:RequestPagingInfo/*:TransRetrieveFromKeysDB/*:RefSeq")));
                        pagingInfo.setTransRetrieveFromKeysDB(reqTransRetrieveFromKeysDB);
                    }else{
                        pagingInfo.setRequestTransactionsOnlineDB(false);
                    }
                }
            }
        }else{
            pagingInfo.setRequestTransactionsOnlineDB(false);
        }

        boolean accsCalled = cardTransactionsList.getCardTransaction().stream().anyMatch(cardTransaction -> cardTransaction.getRecordType().equals("CE"));
        if(accsCalled){
            boolean accsHasMore = Boolean.parseBoolean(FormatUtils.getValue(doc, "/*:Mapping/*:AccsHasMore"));
            if(accsHasMore){
                pagingInfo.setRequestLegacy(true);
                int legacyPageNumber = exchange.getProperty("LegacyPageNumber", Integer.class);
                if(limitedListHasAnyAccsTransactions) {
                    pagingInfo.setLegacyPageNumber(legacyPageNumber + 1);
                }
            }else {
                if(!limitedListHasAnyAccsTransactions) {
                    pagingInfo.setRequestLegacy(true);
                }else{
                    pagingInfo.setRequestLegacy(false);
                }
            }
        }
        pagingInfo.setPageSize(exchange.getProperty("CBSPageSize", Integer.class));

        GetCardAuthorizationsAndTransactionsResponse response = new GetCardAuthorizationsAndTransactionsResponse();
        GetCardAuthorizationsAndTransactionsResponsePayload responsePayload = new GetCardAuthorizationsAndTransactionsResponsePayload();
        GetCardAuthorizationsAndTransactionsResponseItem responseItem = new GetCardAuthorizationsAndTransactionsResponseItem();
        responseItem.setCardTransactionsList(limitedCardTransactionsList);
        responseItem.setPagingInfo(pagingInfo);
        responsePayload.setGetCardAuthorizationsAndTransactionsResponseItem(responseItem);
        LoggingInfoType loggingInfo = LoggingInfoHelper.getLoggingInfo(exchange);
        responsePayload.setLoggingInfo(loggingInfo);
        response.setGetCardAuthorizationsAndTransactionsResponsePayload(responsePayload);

        exchange.getIn().setBody(response);
    }

    public static BigDecimal formatDecimal(String inputNumber) throws ParseException{
        if(inputNumber.trim().isEmpty()){
            return null;
        }
        DecimalFormatSymbols otherSymbols = new DecimalFormatSymbols(Locale.ENGLISH);
        DecimalFormat df = new DecimalFormat("#######################0.00", otherSymbols);
        return new BigDecimal(df.parse(inputNumber).toString());
    }

    private String calculateCacheKey(Exchange exchange){
        boolean isCorporate = Boolean.parseBoolean(exchange.getProperty("IsCorporate", String.class));
        String cardNumber = exchange.getProperty("CardNumber", String.class);
        String corporateId = exchange.getProperty("CorporateId", String.class);
        String dateFrom = exchange.getProperty("RequestDateFrom", String.class);
        String dateTo = exchange.getProperty("DateTo", String.class);
        String pageSize = exchange.getProperty("PageSize", String.class);

        String cacheKey;
        if(!isCorporate){
            cacheKey = cardNumber + "|" + dateFrom + "|" + dateTo + "|" + pageSize;
        }else{
            cacheKey = corporateId + "|" + dateFrom + "|" + dateTo + "|" + pageSize;
        }
        return cacheKey;
    }
}