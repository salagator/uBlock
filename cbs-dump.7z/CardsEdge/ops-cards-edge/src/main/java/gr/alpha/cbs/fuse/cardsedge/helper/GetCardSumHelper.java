package gr.alpha.cbs.fuse.cardsedge.helper;

import gr.alpha.cbs.fuse.cardsedge.generated.*;
import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.common.ifaces.RefDataTranslator;
import gr.alpha.cbs.fuse.common.tools.FormatUtils;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.ifaces.MasterDataInterface;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.w3c.dom.Document;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Objects;

@Named("getCardSumHelper")
@ApplicationScoped
@RegisterForReflection
public class GetCardSumHelper {

	@Inject
	MasterDataInterface masterDataInterface;

	@Inject
	RefDataTranslator refDataTranslator;

	public static BigDecimal formatDecimal(String inputNumber) throws ParseException{
		if(inputNumber.trim().isEmpty()){
			return null;
		}
		DecimalFormatSymbols otherSymbols = new DecimalFormatSymbols(new Locale("el","GR"));
		DecimalFormat df = new DecimalFormat("#######################0.00", otherSymbols);
		return new BigDecimal(df.parse(inputNumber).toString());
	}
	
	public static Integer formatInteger(String inputNumber){
		if(inputNumber.trim().isEmpty()){
			return null;
		}
		return Integer.valueOf(inputNumber);
	}
	
	public static XMLGregorianCalendar formatDate(String inputDate) throws DatatypeConfigurationException, ParseException
	{
		if(inputDate.trim().isEmpty()){
			return null;
		}
		final String OLD_FORMAT = "dd/MM/yyyy";
		final String NEW_FORMAT = "yyyy-MM-dd";
		SimpleDateFormat sdf = new SimpleDateFormat(OLD_FORMAT);
		Date d = sdf.parse(inputDate);
		sdf.applyPattern(NEW_FORMAT);
		return  DatatypeFactory.newInstance().newXMLGregorianCalendar(sdf.format(d));
	}

	public static void createResponse(Exchange exchange) throws ParseException, DatatypeConfigurationException{
		Document doc = exchange.getIn().getBody(Document.class);
		GetCardSumResponse response = new GetCardSumResponse();
		GetCardSumResponsePayload payload = new GetCardSumResponsePayload();
		GetCardSumResponseItem responseItem = new GetCardSumResponseItem();
		GetCardSumCmsResponse getCardSumCmsResponse = new GetCardSumCmsResponse();
		boolean hasResult = Boolean.parseBoolean(exchange.getProperty("hasResult", String.class));
		if(hasResult){
			getCardSumCmsResponse.setLastStatementBalance(formatDecimal(FormatUtils.getValue(doc, "/*:result/*:LastStatementBalance")));
			getCardSumCmsResponse.setLastStatementDate(formatDate(FormatUtils.getValue(doc, "/*:result/*:LastStatementDate")));
			getCardSumCmsResponse.setCurrentBalance(formatDecimal(FormatUtils.getValue(doc, "/*:result/*:CurrentBalance")));
			getCardSumCmsResponse.setLastPaymentAmount(formatDecimal(FormatUtils.getValue(doc, "/*:result/*:LastPaymentAmount")));
			getCardSumCmsResponse.setLastPaymentDate(formatDate(FormatUtils.getValue(doc, "/*:result/*:LastPaymentDate")));
			getCardSumCmsResponse.setAvailableAmount(formatDecimal(FormatUtils.getValue(doc, "/*:result/*:AvailableAmount")));
			getCardSumCmsResponse.setCreditLimit(formatDecimal(FormatUtils.getValue(doc, "/*:result/*:CreditLimit")));
			getCardSumCmsResponse.setMinPaymentAmount(formatDecimal(FormatUtils.getValue(doc, "/*:result/*:MinPaymentAmount")));
			getCardSumCmsResponse.setMinPaymentDueDate(formatDate(FormatUtils.getValue(doc, "/*:result/*:MinPaymentDueDate")));
			getCardSumCmsResponse.setCurrencyCode(FormatUtils.getValue(doc, "/*:result/*:CurrencyCode"));
			getCardSumCmsResponse.setCurrencyLitteral(FormatUtils.getValue(doc, "/*:result/*:CurrencyLitteral"));
			getCardSumCmsResponse.setCurrencyDecimals(formatInteger(FormatUtils.getValue(doc, "/*:result/*:CurrencyDecimals")));
			getCardSumCmsResponse.setSpendingLimit(formatDecimal(FormatUtils.getValue(doc, "/*:result/*:SpendingLimit")));
			getCardSumCmsResponse.setBlackListCode(FormatUtils.getValue(doc, "/*:result/*:BlackListCode"));
			getCardSumCmsResponse.setLastName(FormatUtils.getValue(doc, "/*:result/*:LastName"));
			getCardSumCmsResponse.setFirstName(FormatUtils.getValue(doc, "/*:result/*:FirstName"));
			getCardSumCmsResponse.setMemberSince(FormatUtils.getValue(doc, "/*:result/*:MemberSince"));
			getCardSumCmsResponse.setExpirationDate(FormatUtils.getValue(doc, "/*:result/*:ExpirationDate"));
			getCardSumCmsResponse.setTotalAuths(formatDecimal(FormatUtils.getValue(doc, "/*:result/*:TotalAuths")));
			getCardSumCmsResponse.setAddOn1Account(FormatUtils.getValue(doc, "/*:result/*:AddOn1Account"));
			getCardSumCmsResponse.setAddOn1Name(FormatUtils.getValue(doc, "/*:result/*:AddOn1Name"));
			getCardSumCmsResponse.setAddOn2Account(FormatUtils.getValue(doc, "/*:result/*:AddOn2Account"));
			getCardSumCmsResponse.setAddOn2Name(FormatUtils.getValue(doc, "/*:result/*:AddOn2Name"));
			getCardSumCmsResponse.setStandingOrderType(FormatUtils.getValue(doc, "/*:result/*:StandingOrderType"));
			getCardSumCmsResponse.setBankAccount(FormatUtils.getValue(doc, "/*:result/*:BankAccount"));
			getCardSumCmsResponse.setIDNumber(FormatUtils.getValue(doc, "/*:result/*:IDNumber"));
			getCardSumCmsResponse.setPassportNumber(FormatUtils.getValue(doc, "/*:result/*:PassportNumber"));
			getCardSumCmsResponse.setDoB(FormatUtils.getValue(doc, "/*:result/*:DoB"));
			getCardSumCmsResponse.setCDI(FormatUtils.getValue(doc, "/*:result/*:CDI"));
			getCardSumCmsResponse.setApplicationReference(FormatUtils.getValue(doc, "/*:result/*:ApplicationReference"));
			getCardSumCmsResponse.setNoHardCopy(Boolean.valueOf(FormatUtils.getValue(doc, "/*:result/*:noHardCopy")));
			getCardSumCmsResponse.setSubscribedSms(Boolean.valueOf(FormatUtils.getValue(doc, "/*:result/*:subscribedSms")));
			getCardSumCmsResponse.setCurrentAccountNo(FormatUtils.getValue(doc, "/*:result/*:CurrentAccountNo"));
			getCardSumCmsResponse.setPartInstAmount(formatDecimal(FormatUtils.getValue(doc, "/*:result/*:PartInstAmount")));
			getCardSumCmsResponse.setTotalInstAmount(formatDecimal(FormatUtils.getValue(doc, "/*:result/*:TotalInstAmount")));
		}
		boolean hasErrors = Boolean.parseBoolean(exchange.getProperty("hasErrors", String.class));
		if(hasErrors){
			int errorsCount = exchange.getProperty("errorsCount", Integer.class);
			GetCardSumErrorsListType errors = new GetCardSumErrorsListType();
			for(int i = 1; i <= errorsCount; i++){
				GetCardSumErrorRecordType error = new GetCardSumErrorRecordType();
				error.setCode(FormatUtils.getValue(doc, "/*:errors/*:error[" + i + "]" + "/*:code"));
				error.setMessage(FormatUtils.getValue(doc, "/*:errors/*:error[" + i + "]" + "/*:message"));
				errors.getError().add(error);
			}
			getCardSumCmsResponse.setErrors(errors);
		}
		responseItem.setGetCardSumCmsResponse(getCardSumCmsResponse);
		payload.setGetCardSumResponseItem(responseItem);
		payload.setLoggingInfo(LoggingInfoHelper.getLoggingInfo(exchange));
		response.setGetCardSumResponsePayload(payload);
		exchange.getIn().setBody(response);
	}

    public void setCurrencyData(Exchange exchange) throws Exception {
        Document body = exchange.getIn().getBody(Document.class);
        String baseCurrency = FormatUtils.getValue(body, "//*:GetCardDetailsResponseItem/*:AdvancedCardInfo/*:CurrencyCode");
        String numOfDecimals = "";
        String currency;
        String masterCode = Objects.requireNonNull(masterDataInterface.getMasterDetailsLists(CBSConstants.REF_NAME_CURRENCIES_ISO).entrySet().stream()
                .filter(mapEntry -> mapEntry.getValue().get("Currency_ISO_Numeric_Code").equals(baseCurrency))
                .findFirst()
                .map(mapEntry -> mapEntry.getValue().get("Value"))
                .orElse(null));
        HashMap<String,String> map = masterDataInterface.getMasterDetailsByItemNameLists(CBSConstants.REF_NAME_CURRENCIES_ISO, masterCode);
        if (map != null && !map.isEmpty() && map.containsKey("CURRENCY_DEC_POINTS")){
            numOfDecimals = map.get("CURRENCY_DEC_POINTS");
        }
        currency = refDataTranslator.translateData(CBSConstants.REF_DATA_SYSTEM_UI, "Greek", CBSConstants.REF_NAME_CURRENCIES_ISO, masterCode);
        exchange.setProperty("cbs.cardsintegration.currencyName", currency);
        exchange.setProperty("cbs.cardsintegration.currencyDecPoints", numOfDecimals);
    }

	public void mapPowercardErrorCodesToLegacyErrorCodes(Exchange exchange) {
		CBSException exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, CBSException.class);
		ErrorTypeModel cbsExceptionErrorModel = exception.getErrorModel();

		exchange.setProperty("ErrorDescription", cbsExceptionErrorModel.getDescription());

		if (cbsExceptionErrorModel.getErrorCode().equals(ConstantErrorMessages._Invalid_Card_NumberToken_Id_303710)) {
			exchange.setProperty("ErrorCode", "2");
		}
		else if (cbsExceptionErrorModel.getErrorCode().equals("999401")) {
			exchange.setProperty("ErrorCode", "3");
		}
		else if (cbsExceptionErrorModel.getErrorCode().equals("999500")) {
			exchange.setProperty("ErrorCode", "800");
		}
		else if (cbsExceptionErrorModel.getErrorCode().equals("00000")) {
			exchange.setProperty("ErrorCode", "0");
		}
		else {
			exchange.setProperty("ErrorCode", "-1");
			exchange.setProperty("ErrorDescription", "SYSTEM ERROR");
		}
	}
}
