package gr.alpha.cbs.fuse.cardsedge.beans;

import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.camel.component.xslt.XsltAggregationStrategy;
import org.apache.camel.component.xslt.XsltOutput;

@Named("enrichEntireResponse.xsl")
@ApplicationScoped
@RegisterForReflection
public class EnrichEntireResponse extends XsltAggregationStrategy {
    public EnrichEntireResponse() {
        super("gr/alpha/cbs/fuse/xslt/enrichEntireResponse.xsl");
        setOutput(XsltOutput.DOM);
    }

    // Copy properties
    @Override
    public Exchange aggregate(Exchange original, Exchange resource) {
        Exchange result = super.aggregate(original, resource);
        if (resource != null && result != null) {
            for (String key : resource.getProperties().keySet()) {
                result.setProperty(key, resource.getProperty(key));
            }
        }
        return result;
    }
}
