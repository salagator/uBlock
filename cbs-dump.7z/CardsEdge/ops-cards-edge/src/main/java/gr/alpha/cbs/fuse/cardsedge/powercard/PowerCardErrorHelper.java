package gr.alpha.cbs.fuse.cardsedge.powercard;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.common.ifaces.RefDataTranslator;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;

@Named("powerCardErrorHelper")
@Dependent
@RegisterForReflection
public class PowerCardErrorHelper {

	private final static Logger LOGGER = Logger.getLogger(PowerCardErrorHelper.class);
	private final static String CARDS = "Cards";
	private final static String HEADER_LANGUAGE = "en";

    @Inject
    RefDataTranslator refDataTranslator;

	public void translateError(Exchange ex) throws CBSException {
        String powercardErrorCode = null;
        String powercardErrorUID = null;
        String powercardOperation = ex.getProperty("cbs.camel.powercard.operation", String.class);
        String translatePowerCardErrorCodeToCBSErrorCode = null;
        String translateCBSErrorCodeToErrorDescription = null;
        try {
            powercardErrorCode = ex.getProperty("powercard.errorCode", String.class);
            powercardErrorUID = ex.getProperty("powercard.errorUUID", String.class);
            String powerCardErrorDesc = ex.getProperty("powercard.errorDescription", String.class);
            translatePowerCardErrorCodeToCBSErrorCode = refDataTranslator.translateData(CARDS, CBSConstants.REF_DATA_SYSTEM_UI, CBSConstants.REF_NAME_ERROR_MESSAGES, powercardErrorCode);
            translateCBSErrorCodeToErrorDescription = refDataTranslator.translateData(CBSConstants.REF_DATA_SYSTEM_UI, HEADER_LANGUAGE, CBSConstants.REF_NAME_ERROR_MESSAGES, translatePowerCardErrorCodeToCBSErrorCode);
            if (StringUtils.isBlank(translateCBSErrorCodeToErrorDescription)) {
                translateCBSErrorCodeToErrorDescription = powerCardErrorDesc;
            }
        } catch (Exception e) {
            LOGGER.error("Error translating with RefDataTranslatorEjb: " + e.getMessage());
            ErrorUtils.throwCBSException(null, ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
                    PowerCardErrorHelper.class.getCanonicalName(), ConstantErrorMessages._GENERAL_ERROR_MW,
                    ErrorTypeModel.SEVERITY_ERROR, "Error translating with RefDataTranslatorEjb", "", "");
        }
        String errorDescription = String.format("PowerCard operation '%s' with ResponseUID '%s' failed with ErrorCode: '%s' - '%s'", powercardOperation, powercardErrorUID, powercardErrorCode, translateCBSErrorCodeToErrorDescription);
        ErrorUtils.throwCBSException(null, ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
                PowerCardErrorHelper.class.getCanonicalName(), translatePowerCardErrorCodeToCBSErrorCode,
                ErrorTypeModel.SEVERITY_ERROR, errorDescription, "", "");
    }
    
}
