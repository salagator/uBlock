package gr.alpha.cbs.fuse.cardsedge.powercard;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.transaction.Transactional;
import org.jboss.logging.Logger;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

@Named("powercardCurrencyLiteralMapping")
@Dependent
@RegisterForReflection
@Transactional(Transactional.TxType.NOT_SUPPORTED)
public class PowercardCurrencyLiteralMapping {
	private static final Logger LOGGER = Logger.getLogger(PowercardCurrencyLiteralMapping.class);

	@Inject
	@io.quarkus.agroal.DataSource("cbs-cards-pricing")
	private DataSource cardsPricingDatasource;

	private RemoteDatagridClientHelper<String, String> datagridHelper;

	@PostConstruct
	private void postConstruct() {
		datagridHelper = new RemoteDatagridClientHelper<>();
		datagridHelper.initCacheManager();
		datagridHelper.setCache("powercardCurrencyLiterals");
	}

	@PreDestroy
	private void preDestroy() {
		datagridHelper.stopCacheManager();
	}

	public String getCurrencyLiteral(String currencyCode) throws SQLException, CBSException {
		String currencyLiteral = null;
		String currencyLiteralKey = currencyCode;
		if (datagridHelper.getCache() != null) {
			currencyLiteral = datagridHelper.get(currencyLiteralKey);
			if (currencyLiteral == null) {
				updateCurrencyLiteralsCache();
				currencyLiteral = datagridHelper.get(currencyLiteralKey);
			}
		} else {
			ErrorUtils.throwCBSException(null,
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					PowercardCurrencyLiteralMapping.class.getCanonicalName(),
					ConstantErrorMessages._SQL_EXCEPTION,
					ErrorTypeModel.SEVERITY_ERROR,
					"Error while retrieving currency literals from cache", "", "");
		}
		return currencyLiteral;
	}

	private void updateCurrencyLiteralsCache() throws SQLException, CBSException {
		Map<String, String> currencyLiterals = selectFromDwhCurrencyDimension();
		datagridHelper.putAll(currencyLiterals);
	}

	public Map<String, String> selectFromDwhCurrencyDimension() throws SQLException, CBSException{
		Map<String, String> currencyLiterals = new HashMap<>();
		try(Connection connection = cardsPricingDatasource.getConnection();
				PreparedStatement statement = connection.prepareStatement("SELECT [Currency_Code], [Currency_Name] from [CBS_CardsPricing].[dbo].[DWH_CURRENCY_DIMENSION] WITH (NOLOCK)")){
			try(ResultSet resultSet = statement.executeQuery()) {
				while(resultSet.next()){
					currencyLiterals.put(resultSet.getString("Currency_Code"), resultSet.getString("Currency_Name"));
				}
			}
		}catch (SQLException e){
			ErrorUtils.throwCBSException(null,
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					PowercardCurrencyLiteralMapping.class.getCanonicalName(),
					ConstantErrorMessages._SQL_EXCEPTION,
					ErrorTypeModel.SEVERITY_ERROR,
					"Error while retrieving currency literals from DB", "", "");
		}
		return currencyLiterals;
	}

}
