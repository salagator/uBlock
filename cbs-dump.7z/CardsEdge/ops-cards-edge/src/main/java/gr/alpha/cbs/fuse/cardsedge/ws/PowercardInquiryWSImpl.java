package gr.alpha.cbs.fuse.cardsedge.ws;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.service.AbstractCamelRouteDrivingProvider;
import gr.alpha.cbs.fuse.service.ResponseLayout;
import jakarta.jws.HandlerChain;
import jakarta.xml.ws.Service;
import jakarta.xml.ws.ServiceMode;
import jakarta.xml.ws.WebServiceProvider;
import org.apache.cxf.annotations.SchemaValidation;
import org.w3c.dom.Element;

import javax.xml.transform.dom.DOMSource;
import java.util.HashMap;
import java.util.Map;

@WebServiceProvider(serviceName = "powercard-inquiry", wsdlLocation = "/wsdl/powercard-inquiry.wsdl", portName = "CardsEdgePowercardSOAP", targetNamespace = "http://cards-edge.fuse.cbs.alpha.gr/cards-edge/")
@HandlerChain(file = "/context.xml")
@ServiceMode(Service.Mode.PAYLOAD)
@SchemaValidation
public class PowercardInquiryWSImpl extends AbstractCamelRouteDrivingProvider {

    @Override
    protected Map<String, Object> getHeaders(String operation, Element requestRootElement) {
        Map<String, Object> returnValue = new HashMap<>();
        returnValue.put(CBSConstants.HEADER_USE_GLOBAL_PREPARE_BUN_HANDLER, true);
        returnValue.put(CBSConstants.HEADER_USE_GLOBAL_FAILURE_HANDLER, true);
        returnValue.put(CBSConstants.HEADER_USE_GLOBAL_CALL_SUCESS, false);
        Map<String, String> jtaTransactionTimeoutMap = new HashMap<>();
        jtaTransactionTimeoutMap.put("GetCardDetails", "3");
        jtaTransactionTimeoutMap.put("GetCorporateInfo", "3");
        jtaTransactionTimeoutMap.put("GetMulticardDetails", "3");
        jtaTransactionTimeoutMap.put("SearchAuthorization", "3");
        jtaTransactionTimeoutMap.put("SearchTransactions", "3");
        returnValue.put("jtaTransactionTimeout", jtaTransactionTimeoutMap);
        returnValue.put("responseRootTag", operation + "Response");
        return returnValue;
    }

    @Override
    public String getConsumer(String operation) {
        return "direct:leanStart";
    }

    @Override
    public void setServiceOperationInfo(String flowName, String operation, Map<String, Object> header) {
        header.put(CBSConstants.HEADER_TRANSACTION_NAME, operation);
        header.put(CBSConstants.HEADER_TRANSACTION_FLOW, flowName);
        header.put(CBSConstants.HEADER_TRANSACTION_SERVICE, "CardsEdge");
        header.put(CBSConstants.HEADER_SYSTEM_ID, CBSConstants.SYSTEM_ID_ESB);
    }

    @Override
    public DOMSource invoke(DOMSource request) {
        return super.invoke(request);
    }

    @Override
    protected ResponseLayout keepRootElement() {
        return ResponseLayout.WRAP_UNWRAP;
    }

}
