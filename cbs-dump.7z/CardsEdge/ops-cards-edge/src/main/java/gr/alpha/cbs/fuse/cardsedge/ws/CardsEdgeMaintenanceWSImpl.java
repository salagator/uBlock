package gr.alpha.cbs.fuse.cardsedge.ws;

import gr.alpha.cbs.fuse.service.AbstractCamelRouteDrivingProvider;
import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.service.ResponseLayout;
import jakarta.jws.HandlerChain;
import jakarta.xml.ws.Service;
import jakarta.xml.ws.ServiceMode;
import jakarta.xml.ws.WebServiceProvider;
import org.apache.cxf.annotations.SchemaValidation;
import org.w3c.dom.Element;
import java.util.HashMap;
import java.util.Map;

@SchemaValidation

@ServiceMode(value = Service.Mode.PAYLOAD)
@HandlerChain(file = "/context.xml")
@WebServiceProvider(portName = "CardsEdgeSOAP", serviceName = "cards-edge-maintenance", targetNamespace = "http://cards-edge.fuse.cbs.alpha.gr/cards-edge/", wsdlLocation = "/wsdl/cards-edge-maintenance.wsdl")
public class CardsEdgeMaintenanceWSImpl extends AbstractCamelRouteDrivingProvider {

	@Override
	protected Map<String, Object> getHeaders(String operation, Element requestRootElement) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put(CBSConstants.HEADER_USE_GLOBAL_FAILURE_HANDLER, true);
		map.put(CBSConstants.HEADER_USE_GLOBAL_PREPARE_BUN_HANDLER, true);
		map.put(CBSConstants.HEADER_USE_GLOBAL_CALL_SUCESS, false);
		map.put("responseRootTag", operation + "Response");
		return map;
	}

	@Override
	public String getConsumer(String operation) {
		return "direct:leanStart";
	}

	@Override
	protected void setServiceOperationInfo(String flowName, String operation, Map<String, Object> header) {
		header.put(CBSConstants.HEADER_TRANSACTION_NAME, operation);
		header.put(CBSConstants.HEADER_TRANSACTION_FLOW, flowName);
		header.put(CBSConstants.HEADER_TRANSACTION_SERVICE, "CardsEdge");
		header.put(CBSConstants.HEADER_SYSTEM_ID, CBSConstants.SYSTEM_ID_ESB);
	}

	@Override
	protected ResponseLayout keepRootElement() {
		return ResponseLayout.WRAP_UNWRAP;
	}
}
