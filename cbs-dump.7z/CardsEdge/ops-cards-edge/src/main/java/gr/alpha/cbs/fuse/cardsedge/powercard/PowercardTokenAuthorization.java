package gr.alpha.cbs.fuse.cardsedge.powercard;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.math.NumberUtils;
import org.eclipse.microprofile.config.ConfigProvider;
import org.infinispan.protostream.SerializationContextInitializer;
import org.jboss.logging.Logger;
import java.io.IOException;
import java.time.Instant;

@Named("powercardTokenAuthorization")
@Dependent
@RegisterForReflection
public class PowercardTokenAuthorization {
    private static final Logger LOGGER = Logger.getLogger(PowercardTokenAuthorization.class);
    private static final String CONTAINER_NAME = "AuthTokens";
    private static final String TOKEN_TIMESTAMP_MACHINE_EPOCH_KEY = "tokenTimestampMachineEpochKey";
    private static final String TOKEN_EXPIRATION_SECONDS = "tokenExpirationSeconds";
    private static final String POWERCARD_USER = "powerCardUser";
    private RemoteDatagridClientHelper<String, Object> datagridHelper;
    private static SerializationContextInitializer contextInitializer;

    @PostConstruct
    private void postConstruct() {
        datagridHelper = new RemoteDatagridClientHelper<>();
        datagridHelper.initCacheManagerWithMarshaller(contextInitializer);
        datagridHelper.setCache(CONTAINER_NAME);
    }

    @PreDestroy
    private void preDestroy() {
        datagridHelper.stopCacheManager();
    }
    /*
     * We use three time sources to find the expiration time of the token
     * cacheTimestampMachineEpochSecs is the machine timestamp from the datagrid when renewing token,
     * cacheTokenExpirationSeconds is the dt from the token content expiration minus the issuance time,
     * machineDiff is the machineDifference between the datagrid machine timestamp and the current time.
     * We used user based cached token and timestampMachineEpochSecs, in order to keep tracking of retrieved token
     * TokenExpirationSeconds is cached in a common value independent of powerCard user
     */
    public String getCachedTokenValue(Exchange exchange) throws CBSException {
        String tokenKey = ConfigProvider.getConfig().getValue("cbs.camel.powercard.endpoint", String.class) + exchange.getProperty(POWERCARD_USER, String.class);
        Object cachedValue = null;
        if (datagridHelper.getCache() != null) {
            cachedValue = datagridHelper.get(tokenKey);
            if (cachedValue != null) {
                Object cacheTimestampMachineEpochSecs = datagridHelper.get(tokenKey + "_" + TOKEN_TIMESTAMP_MACHINE_EPOCH_KEY);
                Object cacheTokenExpirationSeconds = NumberUtils.toLong((String) datagridHelper.get(TOKEN_EXPIRATION_SECONDS));
                if (cacheTimestampMachineEpochSecs != null) {
                    long machineDiff = (Instant.now().toEpochMilli() / 1000) -  Long.parseLong((String) cacheTimestampMachineEpochSecs) ;
                    if (machineDiff >= (long) cacheTokenExpirationSeconds) {
                        // specific token is expired remove from cache
                        LOGGER.info("Token is Expired. Invalidating token");
                        cachedValue = null;
                        datagridHelper.remove(tokenKey);
                    }
                    LOGGER.debug(tokenKey + " token retrieved from datagrid:" + cachedValue);
                }
            }
        } else {
            LOGGER.info(CONTAINER_NAME + " Cache not found");
            ErrorUtils.throwCBSException(null, ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
                    PowercardTokenAuthorization.class.getCanonicalName(), "",
                    ErrorTypeModel.SEVERITY_ERROR, "DataGrid cache " + CONTAINER_NAME + " not found. Cannot retrieve token.", "", "");
        }
        exchange.setProperty("bearerToken", cachedValue);
        return (String) cachedValue;
    }


    /*
     * Helping method for updating existing token value, timestamp and global token duration
     */
    public String updateCachedTokenValue(Exchange exchange) throws IOException {
        String tokenKey = ConfigProvider.getConfig().getValue("cbs.camel.powercard.endpoint", String.class) + exchange.getProperty(POWERCARD_USER, String.class);
        datagridHelper.put(tokenKey + "_" + TOKEN_TIMESTAMP_MACHINE_EPOCH_KEY, String.valueOf(Instant.now().toEpochMilli() / 1000));//local timestamp
        String tokenValue = exchange.getProperty("bearerToken", String.class);
        datagridHelper.put(tokenKey, tokenValue);
        datagridHelper.put(TOKEN_EXPIRATION_SECONDS, exchange.getProperty("expiresIn", String.class));
        return tokenValue;
    }

}
