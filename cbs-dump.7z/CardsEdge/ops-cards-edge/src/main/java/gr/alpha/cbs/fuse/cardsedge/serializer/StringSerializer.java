package gr.alpha.cbs.fuse.cardsedge.serializer;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

public class StringSerializer extends StdSerializer<String> {

	private static final long serialVersionUID = 5326517062886741790L;

	public StringSerializer() {
		this(null);
	}
	
	public StringSerializer(Class<String> t) {
		super(t);
	}

	@Override
	public void serialize(String value, JsonGenerator gen, SerializerProvider provider) throws IOException {
		if (value != null) gen.writeString(value);;
	}

}