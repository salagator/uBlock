package gr.alpha.cbs.fuse.cardsedge.routes.inquiry;

import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import io.netty.channel.ConnectTimeoutException;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.http.base.HttpOperationFailedException;
import java.net.SocketTimeoutException;
import static org.apache.camel.component.xquery.XQueryBuilder.xquery;

public class GetCardSum extends RouteBuilder {
    @Override
    public void configure() throws Exception{
        from("direct:do-transaction-GetCardSumPayload")
        .routeId("direct:do-transaction-GetCardSumPayload")
        .streamCaching()
            .setProperty("CardNumber", xquery("//*:CCNo").resultType(java.lang.String.class))
            .setProperty("IsCorporateCard", method("cardsEdgeCommonFunctions", "isCorporateCard(*)"))
            .choice()
                .when().simple("${exchangeProperty.IsCorporateCard} == true")
                    .to("direct:GetCardSumCorporatePowerCard")
                .endChoice()
                .otherwise()
                    .to("direct:choose-card-system")
                .endChoice()
            .end()
        .end();

        from("direct:GetCardSumLegacy")
        .routeId("direct:GetCardSumLegacy")
        .streamCaching()
            .setProperty("cbs.getCardSum.legacy.username", simple("{{cbs.camel.fuse.deltaCards.username}}"))
            .setProperty("cbs.getCardSum.legacy.password", simple("{{cbs.camel.fuse.deltaCards.password}}"))
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/GetCardSum/GetCardSumRequest.xsl")
            .log("GetCardSum Request XSL: ${body}")
            .setProperty("requestBody", simple("${body}"))
            .doTry()
                .removeHeaders("*")
                .setHeader("CamelHttpMethod", constant("POST"))
                .setHeader("Content-Type", constant("text/xml; charset=utf-8"))
                .setHeader("Accept-Encoding", constant("gzip,deflate"))
                .setHeader("SOAPAction", constant("http://www.oneworld.gr/webservice/GetCardSum"))
                .to("https://{{cbs.camel.delta.card.info.host}}/Deltacards/deltacards.asmx?{{cbs.mw.getcardsum.params}}")
                .log("GetCardSum Paralos response: ${body}")
            .doCatch(HttpOperationFailedException.class)
                .setBody(simple("${exchangeProperty.requestBody}"))
                .to("bean:errorUtils?method=throwCBSException(null, '1', '2', ${property.cbs.common.transactionTypeId}, '', '3', 'GetCardSum Paralos Error error http status ${exception.statusCode}','','')")
            .endDoTry()
            .doCatch(SocketTimeoutException.class)
                .setBody(simple("${exchangeProperty.requestBody}"))
                .to("bean:errorUtils?method=throwCBSException(null, '1', '2', ${property.cbs.common.transactionTypeId}, '', '3', 'GetCardSum Paralos Timeout Error','','')")
            .endDoTry()
            .doCatch(ConnectTimeoutException.class)
                .setBody(simple("${exchangeProperty.requestBody}"))
                .to("bean:errorUtils?method=throwCBSException(null, '1', '2', ${property.cbs.common.transactionTypeId}, '', '3', 'GetCardSum Paralos Timeout Error','','')")
            .endDoTry()
            .end()
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/GetCardSum/getCDATAValues.xsl")
            .setProperty("hasResult", xquery("exists(/*:result)").resultType(java.lang.String.class))
            .setProperty("hasErrors", xquery("exists(/*:errors)").resultType(java.lang.String.class))
            .setProperty("errorsCount", xquery("count(//error)").resultType(java.lang.String.class))
            .bean("getCardSumHelper", "createResponse(*)")
        .end();

        from("direct:GetCardSumPowercard")
        .routeId("direct:GetCardSumPowercard")
        .streamCaching()
            .doTry()
                .to("direct:GetCardSum-GetCardDetails")
                .setProperty("PwcStatusCode", xquery("//*:GetCardDetailsResponseItem/*:CardDemog/*:StatusCode").resultType(java.lang.String.class))
                .setProperty("PwcStatusReason", xquery("//*:GetCardDetailsResponseItem/*:CardDemog/*:StatusReason").resultType(java.lang.String.class))
                .bean("cardsEdgeCommonFunctions", "mapPwcStatusToCmsBlacklistCode(*)")
                .bean("getCardSumHelper", "setCurrencyData(*)")
            .doCatch(CBSException.class)
                .bean("getCardSumHelper", "mapPowercardErrorCodesToLegacyErrorCodes(*)")
            .endDoTry()
            .end()
            .setProperty("cbs.getCardSum.cmsTransactionReferencePowercard", simple("${exchangeProperty.cbs.powercard.last.requestUID}"))
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/GetCardSum/GetCardSumPowercardResponse.xsl?output=DOM")
        .end();

        from("direct:GetCardSumCorporatePowerCard")
        .routeId("direct:GetCardSumCorporatePowerCard")
        .streamCaching()
            .doTry()
                .setProperty("powercardBankCode", method("cardsEdgeCommonFunctions", "setBankCode"))
                .to("direct:GetCardSum-GetCorporateInfo")
                .setProperty("cbs.powercard.corporate.statusCode", xquery("//*:GetCorporateInfoResponseItem/*:CorpDetails/*:CorpDemog/*:StatusCode").resultType(java.lang.String.class))
                .bean("cardsEdgeCommonFunctions", "mapCorporatePwcStatusToCmsBlacklistCode(*)")
            .doCatch(CBSException.class)
                .bean("cardsEdgeCommonFunctions", "handlePowercardCbsException(*)")
            .endDoTry()
            .end()
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/GetCardSum/GetCardSumCorporatePowerCardResponse.xsl?output=DOM")
        .end();

        from("direct:GetCardSum-GetCardDetails")
        .routeId("direct:GetCardSum-GetCardDetails")
        .streamCaching()
            .setProperty("cbs.redirect.powerCard", constant("GetCardDetailsPayload"))
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/GetCardSum/prepGetCardDetailsRequest.xsl")
            .to("direct:PowerCardInquiry")
        .end();

        from("direct:GetCardSum-GetCorporateInfo")
        .routeId("direct:GetCardSum-GetCorporateInfo")
        .streamCaching()
            .setProperty("cbs.redirect.powerCard", constant("GetCorporateInfoPayload"))
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/GetCardSum/prepGetCardDetailsRequest.xsl")
            .to("direct:PowerCardInquiry")
        .end();
    }
}
