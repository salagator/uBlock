package gr.alpha.cbs.fuse.cardsedge.powercard;

public class ObjectMapperHelper {

	private static final ObjectMapperCustomConfiguration objectMapper = new ObjectMapperCustomConfiguration();

	private ObjectMapperHelper() {}
	
	public static ObjectMapperCustomConfiguration getObjectMapperInstance(){
		return objectMapper;
	}

}
