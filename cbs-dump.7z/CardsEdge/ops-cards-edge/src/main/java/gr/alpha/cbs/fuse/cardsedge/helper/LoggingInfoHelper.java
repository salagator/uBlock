package gr.alpha.cbs.fuse.cardsedge.helper;

import gr.alpha.cbs.fuse.cardsedge.generated.LoggingInfoType;
import gr.alpha.cbs.fuse.common.CBSConstants;
import org.apache.camel.Exchange;

public class LoggingInfoHelper {

	public static LoggingInfoType getLoggingInfo(Exchange exchange) {
		LoggingInfoType loggingInfoType = new LoggingInfoType();
		loggingInfoType.setRequestId(exchange.getProperty(CBSConstants.HEADER_REQUEST_ID,String.class));
		loggingInfoType.setSessionId(exchange.getProperty(CBSConstants.HEADER_FRONT_END_SESSION_ID,String.class));
		loggingInfoType.setBusinessCaseId(exchange.getProperty(CBSConstants.HEADER_BUSINESS_CASE_ID,String.class));
		loggingInfoType.setSequenceId(exchange.getProperty(CBSConstants.HEADER_SEQUENCE_ID, String.class));
		loggingInfoType.setUserId(exchange.getProperty(CBSConstants.HEADER_USER_ID,String.class));
		loggingInfoType.setCBSUnId(exchange.getProperty(CBSConstants.HEADER_BUN,String.class));

		return loggingInfoType;
	}
}
