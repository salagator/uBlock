package gr.alpha.cbs.fuse.cardsedge.powercard;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import org.jboss.logging.Logger;

import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.XMLGregorianCalendar;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class CustomXMLGregCalendarSerializer extends StdSerializer<XMLGregorianCalendar> {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3691924709889728990L;

	private static final Logger LOGGER = Logger.getLogger(CustomXMLGregCalendarSerializer.class);
	
	private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");
	private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
	private static final DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

	public CustomXMLGregCalendarSerializer() {
		this(null);
	}
	
	public CustomXMLGregCalendarSerializer(Class<XMLGregorianCalendar> t) {
		super(t);
	}

	@Override
	public void serialize(XMLGregorianCalendar value, JsonGenerator gen, SerializerProvider serializers)
			 {
		try{
			if (value.getXMLSchemaType().equals(DatatypeConstants.DATETIME)){
				gen.writeString(dateTimeFormatter.format(value.toGregorianCalendar().toZonedDateTime()));
			}
			if (value.getXMLSchemaType().equals(DatatypeConstants.DATE)){
				gen.writeString(toDate(value).format(dateFormatter));
			}
			if (value.getXMLSchemaType().equals(DatatypeConstants.TIME)){
				gen.writeString(toTime(value).format(timeFormatter));
			}
			
		}catch (IllegalStateException | IOException e){
			LOGGER.error("Not a parsable convertion from XMLGregorianCalendar:"+ e);
		}
	}
	
	private LocalDate toDate(XMLGregorianCalendar calendar){
		if (calendar==null){
			return null;
		}
		return LocalDate.of(calendar.getYear(),calendar.getMonth(),calendar.getDay());
		
	}
	private LocalTime toTime(XMLGregorianCalendar calendar){
		if (calendar==null){
			return null;
		}
		return LocalTime.of(calendar.getHour(),calendar.getMinute(),calendar.getSecond());
		
	}

}
