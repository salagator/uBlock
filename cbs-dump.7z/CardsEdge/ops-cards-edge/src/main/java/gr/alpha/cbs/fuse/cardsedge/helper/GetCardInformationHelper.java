package gr.alpha.cbs.fuse.cardsedge.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import gr.alpha.cbs.fuse.cardsedge.helper.model.GetCardInformationRequestItemType;
import gr.alpha.cbs.fuse.cardsedge.helper.model.GetCardInformationResponse;
import gr.alpha.cbs.fuse.cardsedge.helper.model.GetCardInformationResponseItem;
import gr.alpha.cbs.fuse.cardsedge.helper.model.GetCardInformationResponsePayload;
import gr.alpha.cbs.fuse.cardsedge.powercard.ObjectMapperHelper;
import gr.alpha.cbs.fuse.cardsedge.powercard.PowerCardHelper;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.jboss.logging.Logger;
import java.io.IOException;

@Named("getCardInformationHelper")
@ApplicationScoped
@RegisterForReflection
public class GetCardInformationHelper {
	private static final Logger LOGGER = Logger.getLogger(GetCardInformationHelper.class);


	public void prepareCallGetCardInformationRequestLegacy(Exchange exchange) throws Exception {
		String requestJson = PowerCardHelper.xmlToJson(exchange, new GetCardInformationRequestItemType());
		exchange.getIn().setBody(requestJson);
	}

	public void prepareGetCardInformationLegacyResponse(Exchange exchange) throws IOException {
		String responseJson = exchange.getIn().getBody(String.class);
		ObjectMapper mapper = ObjectMapperHelper.getObjectMapperInstance().setupResponseConfiguration();
		GetCardInformationResponseItem getCardInformationResponseItem = mapper.readValue(responseJson, GetCardInformationResponseItem.class);
		GetCardInformationResponse getCardInformationResponse = new GetCardInformationResponse();
		GetCardInformationResponsePayload getCardInformationResponsePayload = new GetCardInformationResponsePayload();
		getCardInformationResponsePayload.setGetCardInformationResponseItem(getCardInformationResponseItem);
		getCardInformationResponsePayload.setLoggingInfo(LoggingInfoHelper.getLoggingInfo(exchange));
		getCardInformationResponse.setGetCardInformationResponsePayload(getCardInformationResponsePayload);
		exchange.getIn().setBody(getCardInformationResponse);
	}

}