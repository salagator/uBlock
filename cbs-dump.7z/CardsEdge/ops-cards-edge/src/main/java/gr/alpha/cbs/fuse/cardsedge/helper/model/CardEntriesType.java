
package gr.alpha.cbs.fuse.cardsedge.helper.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigDecimal;


/**
 * <p>Java class for CardEntriesType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CardEntriesType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SourceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CardNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TransactionTimestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="OriginalCardNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TransactionDate" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="QueryDate" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="PostingDate" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="DeltaReference" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TransactionCode" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="MerchantName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MerchantCity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MerchantCountry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MerchantCategoryCode" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="MerchantId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MidOnUs" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="CardHolderAmountSign" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CardHolderAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CardHolderCurrency" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="ForeignTransactionAmountSign" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ForeignTransactionAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="ForeignTransactionCurrency" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="ForeignTransactionCurrencyLiteral" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NumberOfInstallments" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="NumberOfTotalInstallments" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="TransactionTime" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="ChannelMain" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChannelAddInfo1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChannelAddInfo2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CardInternalAccount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MerchantCategories" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DisticntiveTitle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ImportID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="CKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EventCategoryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EventCategoryLiteral" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EventSubCategoryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EventSubCategoryLiteral" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProductCategoryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProductCategoryLiteral" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MerchantCategoryLiteral" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BillingDate" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="UtilityPaymentID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TlfToAccount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExcCategory" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CardEntriesType", propOrder = {
    "sourceType",
    "cardNumber",
    "transactionTimestamp",
    "originalCardNumber",
    "transactionDate",
    "queryDate",
    "postingDate",
    "deltaReference",
    "transactionCode",
    "merchantName",
    "merchantCity",
    "merchantCountry",
    "merchantCategoryCode",
    "merchantId",
    "midOnUs",
    "cardHolderAmountSign",
    "cardHolderAmount",
    "cardHolderCurrency",
    "foreignTransactionAmountSign",
    "foreignTransactionAmount",
    "foreignTransactionCurrency",
    "foreignTransactionCurrencyLiteral",
    "numberOfInstallments",
    "numberOfTotalInstallments",
    "transactionTime",
    "channelMain",
    "channelAddInfo1",
    "channelAddInfo2",
    "cardInternalAccount",
    "merchantCategories",
    "disticntiveTitle",
    "importID",
    "cKey",
    "eventCategoryCode",
    "eventCategoryLiteral",
    "eventSubCategoryCode",
    "eventSubCategoryLiteral",
    "productCategoryCode",
    "productCategoryLiteral",
    "merchantCategoryLiteral",
    "billingDate",
    "utilityPaymentID",
    "tlfToAccount",
    "excCategory"
})
public class CardEntriesType {

    @XmlElement(name = "SourceType")
    protected String sourceType;
    @XmlElement(name = "CardNumber")
    protected String cardNumber;
    @XmlElement(name = "TransactionTimestamp")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar transactionTimestamp;
    @XmlElement(name = "OriginalCardNumber")
    protected String originalCardNumber;
    @XmlElement(name = "TransactionDate")
    protected Integer transactionDate;
    @XmlElement(name = "QueryDate")
    protected Integer queryDate;
    @XmlElement(name = "PostingDate")
    protected Integer postingDate;
    @XmlElement(name = "DeltaReference")
    protected String deltaReference;
    @XmlElement(name = "TransactionCode")
    protected Integer transactionCode;
    @XmlElement(name = "MerchantName")
    protected String merchantName;
    @XmlElement(name = "MerchantCity")
    protected String merchantCity;
    @XmlElement(name = "MerchantCountry")
    protected String merchantCountry;
    @XmlElement(name = "MerchantCategoryCode")
    protected Integer merchantCategoryCode;
    @XmlElement(name = "MerchantId")
    protected String merchantId;
    @XmlElement(name = "MidOnUs")
    protected Integer midOnUs;
    @XmlElement(name = "CardHolderAmountSign")
    protected String cardHolderAmountSign;
    @XmlElement(name = "CardHolderAmount")
    protected BigDecimal cardHolderAmount;
    @XmlElement(name = "CardHolderCurrency")
    protected Integer cardHolderCurrency;
    @XmlElement(name = "ForeignTransactionAmountSign")
    protected String foreignTransactionAmountSign;
    @XmlElement(name = "ForeignTransactionAmount")
    protected BigDecimal foreignTransactionAmount;
    @XmlElement(name = "ForeignTransactionCurrency")
    protected Integer foreignTransactionCurrency;
    @XmlElement(name = "ForeignTransactionCurrencyLiteral")
    protected String foreignTransactionCurrencyLiteral;
    @XmlElement(name = "NumberOfInstallments")
    protected Integer numberOfInstallments;
    @XmlElement(name = "NumberOfTotalInstallments")
    protected Integer numberOfTotalInstallments;
    @XmlElement(name = "TransactionTime")
    protected Integer transactionTime;
    @XmlElement(name = "ChannelMain")
    protected String channelMain;
    @XmlElement(name = "ChannelAddInfo1")
    protected String channelAddInfo1;
    @XmlElement(name = "ChannelAddInfo2")
    protected String channelAddInfo2;
    @XmlElement(name = "CardInternalAccount")
    protected String cardInternalAccount;
    @XmlElement(name = "MerchantCategories")
    protected String merchantCategories;
    @XmlElement(name = "DisticntiveTitle")
    protected String disticntiveTitle;
    @XmlElement(name = "ImportID")
    protected Integer importID;
    @XmlElement(name = "CKey")
    protected String cKey;
    @XmlElement(name = "EventCategoryCode")
    protected String eventCategoryCode;
    @XmlElement(name = "EventCategoryLiteral")
    protected String eventCategoryLiteral;
    @XmlElement(name = "EventSubCategoryCode")
    protected String eventSubCategoryCode;
    @XmlElement(name = "EventSubCategoryLiteral")
    protected String eventSubCategoryLiteral;
    @XmlElement(name = "ProductCategoryCode")
    protected String productCategoryCode;
    @XmlElement(name = "ProductCategoryLiteral")
    protected String productCategoryLiteral;
    @XmlElement(name = "MerchantCategoryLiteral")
    protected String merchantCategoryLiteral;
    @XmlElement(name = "BillingDate")
    protected Integer billingDate;
    @XmlElement(name = "UtilityPaymentID")
    protected String utilityPaymentID;
    @XmlElement(name = "TlfToAccount")
    protected String tlfToAccount;
    @XmlElement(name = "ExcCategory")
    protected Integer excCategory;

    /**
     * Gets the value of the sourceType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("sourceType")
    public String getSourceType() {
        return sourceType;
    }

    /**
     * Sets the value of the sourceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceType(String value) {
        this.sourceType = value;
    }

    /**
     * Gets the value of the cardNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("cardNumber")
    public String getCardNumber() {
        return cardNumber;
    }

    /**
     * Sets the value of the cardNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardNumber(String value) {
        this.cardNumber = value;
    }

    /**
     * Gets the value of the transactionTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    @JsonProperty("transactionTimestamp")
    public XMLGregorianCalendar getTransactionTimestamp() {
        return transactionTimestamp;
    }

    /**
     * Sets the value of the transactionTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTransactionTimestamp(XMLGregorianCalendar value) {
        this.transactionTimestamp = value;
    }

    /**
     * Gets the value of the originalCardNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("originalCardNumber")
    public String getOriginalCardNumber() {
        return originalCardNumber;
    }

    /**
     * Sets the value of the originalCardNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalCardNumber(String value) {
        this.originalCardNumber = value;
    }

    /**
     * Gets the value of the transactionDate property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    @JsonProperty("transactionDate")
    public Integer getTransactionDate() {
        return transactionDate;
    }

    /**
     * Sets the value of the transactionDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTransactionDate(Integer value) {
        this.transactionDate = value;
    }

    /**
     * Gets the value of the queryDate property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    @JsonProperty("queryDate")
    public Integer getQueryDate() {
        return queryDate;
    }

    /**
     * Sets the value of the queryDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setQueryDate(Integer value) {
        this.queryDate = value;
    }

    /**
     * Gets the value of the postingDate property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    @JsonProperty("postingDate")
    public Integer getPostingDate() {
        return postingDate;
    }

    /**
     * Sets the value of the postingDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPostingDate(Integer value) {
        this.postingDate = value;
    }

    /**
     * Gets the value of the deltaReference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("deltaReference")
    public String getDeltaReference() {
        return deltaReference;
    }

    /**
     * Sets the value of the deltaReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeltaReference(String value) {
        this.deltaReference = value;
    }

    /**
     * Gets the value of the transactionCode property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    @JsonProperty("transactionCode")
    public Integer getTransactionCode() {
        return transactionCode;
    }

    /**
     * Sets the value of the transactionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTransactionCode(Integer value) {
        this.transactionCode = value;
    }

    /**
     * Gets the value of the merchantName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("merchantName")
    public String getMerchantName() {
        return merchantName;
    }

    /**
     * Sets the value of the merchantName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMerchantName(String value) {
        this.merchantName = value;
    }

    /**
     * Gets the value of the merchantCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("merchantCity")
    public String getMerchantCity() {
        return merchantCity;
    }

    /**
     * Sets the value of the merchantCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMerchantCity(String value) {
        this.merchantCity = value;
    }

    /**
     * Gets the value of the merchantCountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("merchantCountry")
    public String getMerchantCountry() {
        return merchantCountry;
    }

    /**
     * Sets the value of the merchantCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMerchantCountry(String value) {
        this.merchantCountry = value;
    }

    /**
     * Gets the value of the merchantCategoryCode property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    @JsonProperty("merchantCategoryCode")
    public Integer getMerchantCategoryCode() {
        return merchantCategoryCode;
    }

    /**
     * Sets the value of the merchantCategoryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMerchantCategoryCode(Integer value) {
        this.merchantCategoryCode = value;
    }

    /**
     * Gets the value of the merchantId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("merchantId")
    public String getMerchantId() {
        return merchantId;
    }

    /**
     * Sets the value of the merchantId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMerchantId(String value) {
        this.merchantId = value;
    }

    /**
     * Gets the value of the midOnUs property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    @JsonProperty("midOnUs")
    public Integer getMidOnUs() {
        return midOnUs;
    }

    /**
     * Sets the value of the midOnUs property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMidOnUs(Integer value) {
        this.midOnUs = value;
    }

    /**
     * Gets the value of the cardHolderAmountSign property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("cardHolderAmountSign")
    public String getCardHolderAmountSign() {
        return cardHolderAmountSign;
    }

    /**
     * Sets the value of the cardHolderAmountSign property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardHolderAmountSign(String value) {
        this.cardHolderAmountSign = value;
    }

    /**
     * Gets the value of the cardHolderAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    @JsonProperty("cardHolderAmount")
    public BigDecimal getCardHolderAmount() {
        return cardHolderAmount;
    }

    /**
     * Sets the value of the cardHolderAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCardHolderAmount(BigDecimal value) {
        this.cardHolderAmount = value;
    }

    /**
     * Gets the value of the cardHolderCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    @JsonProperty("cardHolderCurrency")
    public Integer getCardHolderCurrency() {
        return cardHolderCurrency;
    }

    /**
     * Sets the value of the cardHolderCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCardHolderCurrency(Integer value) {
        this.cardHolderCurrency = value;
    }

    /**
     * Gets the value of the foreignTransactionAmountSign property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("foreignTransactionAmountSign")
    public String getForeignTransactionAmountSign() {
        return foreignTransactionAmountSign;
    }

    /**
     * Sets the value of the foreignTransactionAmountSign property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForeignTransactionAmountSign(String value) {
        this.foreignTransactionAmountSign = value;
    }

    /**
     * Gets the value of the foreignTransactionAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    @JsonProperty("foreignTransactionAmount")
    public BigDecimal getForeignTransactionAmount() {
        return foreignTransactionAmount;
    }

    /**
     * Sets the value of the foreignTransactionAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setForeignTransactionAmount(BigDecimal value) {
        this.foreignTransactionAmount = value;
    }

    /**
     * Gets the value of the foreignTransactionCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    @JsonProperty("foreignTransactionCurrency")
    public Integer getForeignTransactionCurrency() {
        return foreignTransactionCurrency;
    }

    /**
     * Sets the value of the foreignTransactionCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setForeignTransactionCurrency(Integer value) {
        this.foreignTransactionCurrency = value;
    }

    /**
     * Gets the value of the foreignTransactionCurrencyLiteral property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("foreignTransactionCurrencyLiteral")
    public String getForeignTransactionCurrencyLiteral() {
        return foreignTransactionCurrencyLiteral;
    }

    /**
     * Sets the value of the foreignTransactionCurrencyLiteral property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForeignTransactionCurrencyLiteral(String value) {
        this.foreignTransactionCurrencyLiteral = value;
    }

    /**
     * Gets the value of the numberOfInstallments property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    @JsonProperty("numberOfInstallments")
    public Integer getNumberOfInstallments() {
        return numberOfInstallments;
    }

    /**
     * Sets the value of the numberOfInstallments property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumberOfInstallments(Integer value) {
        this.numberOfInstallments = value;
    }

    /**
     * Gets the value of the numberOfTotalInstallments property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    @JsonProperty("numberOfTotalInstallments")
    public Integer getNumberOfTotalInstallments() {
        return numberOfTotalInstallments;
    }

    /**
     * Sets the value of the numberOfTotalInstallments property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumberOfTotalInstallments(Integer value) {
        this.numberOfTotalInstallments = value;
    }

    /**
     * Gets the value of the transactionTime property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    @JsonProperty("transactionTime")
    public Integer getTransactionTime() {
        return transactionTime;
    }

    /**
     * Sets the value of the transactionTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTransactionTime(Integer value) {
        this.transactionTime = value;
    }

    /**
     * Gets the value of the channelMain property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("channelMain")
    public String getChannelMain() {
        return channelMain;
    }

    /**
     * Sets the value of the channelMain property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannelMain(String value) {
        this.channelMain = value;
    }

    /**
     * Gets the value of the channelAddInfo1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("channelAddInfo1")
    public String getChannelAddInfo1() {
        return channelAddInfo1;
    }

    /**
     * Sets the value of the channelAddInfo1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannelAddInfo1(String value) {
        this.channelAddInfo1 = value;
    }

    /**
     * Gets the value of the channelAddInfo2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("channelAddInfo2")
    public String getChannelAddInfo2() {
        return channelAddInfo2;
    }

    /**
     * Sets the value of the channelAddInfo2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannelAddInfo2(String value) {
        this.channelAddInfo2 = value;
    }

    /**
     * Gets the value of the cardInternalAccount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("cardInternalAccount")
    public String getCardInternalAccount() {
        return cardInternalAccount;
    }

    /**
     * Sets the value of the cardInternalAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardInternalAccount(String value) {
        this.cardInternalAccount = value;
    }

    /**
     * Gets the value of the merchantCategories property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("merchantCategories")
    public String getMerchantCategories() {
        return merchantCategories;
    }

    /**
     * Sets the value of the merchantCategories property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMerchantCategories(String value) {
        this.merchantCategories = value;
    }

    /**
     * Gets the value of the disticntiveTitle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("disticntiveTitle")
    public String getDisticntiveTitle() {
        return disticntiveTitle;
    }

    /**
     * Sets the value of the disticntiveTitle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisticntiveTitle(String value) {
        this.disticntiveTitle = value;
    }

    /**
     * Gets the value of the importID property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    @JsonProperty("importID")
    public Integer getImportID() {
        return importID;
    }

    /**
     * Sets the value of the importID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setImportID(Integer value) {
        this.importID = value;
    }

    /**
     * Gets the value of the cKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("cKey")
    public String getCKey() {
        return cKey;
    }

    /**
     * Sets the value of the cKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCKey(String value) {
        this.cKey = value;
    }

    /**
     * Gets the value of the eventCategoryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("eventCategoryCode")
    public String getEventCategoryCode() {
        return eventCategoryCode;
    }

    /**
     * Sets the value of the eventCategoryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventCategoryCode(String value) {
        this.eventCategoryCode = value;
    }

    /**
     * Gets the value of the eventCategoryLiteral property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("eventCategoryLiteral")
    public String getEventCategoryLiteral() {
        return eventCategoryLiteral;
    }

    /**
     * Sets the value of the eventCategoryLiteral property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventCategoryLiteral(String value) {
        this.eventCategoryLiteral = value;
    }

    /**
     * Gets the value of the eventSubCategoryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("eventSubCategoryCode")
    public String getEventSubCategoryCode() {
        return eventSubCategoryCode;
    }

    /**
     * Sets the value of the eventSubCategoryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventSubCategoryCode(String value) {
        this.eventSubCategoryCode = value;
    }

    /**
     * Gets the value of the eventSubCategoryLiteral property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("eventSubCategoryLiteral")
    public String getEventSubCategoryLiteral() {
        return eventSubCategoryLiteral;
    }

    /**
     * Sets the value of the eventSubCategoryLiteral property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventSubCategoryLiteral(String value) {
        this.eventSubCategoryLiteral = value;
    }

    /**
     * Gets the value of the productCategoryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("productCategoryCode")
    public String getProductCategoryCode() {
        return productCategoryCode;
    }

    /**
     * Sets the value of the productCategoryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCategoryCode(String value) {
        this.productCategoryCode = value;
    }

    /**
     * Gets the value of the productCategoryLiteral property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("productCategoryLiteral")
    public String getProductCategoryLiteral() {
        return productCategoryLiteral;
    }

    /**
     * Sets the value of the productCategoryLiteral property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCategoryLiteral(String value) {
        this.productCategoryLiteral = value;
    }

    /**
     * Gets the value of the merchantCategoryLiteral property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("merchantCategoryLiteral")
    public String getMerchantCategoryLiteral() {
        return merchantCategoryLiteral;
    }

    /**
     * Sets the value of the merchantCategoryLiteral property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMerchantCategoryLiteral(String value) {
        this.merchantCategoryLiteral = value;
    }

    /**
     * Gets the value of the billingDate property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    @JsonProperty("billingDate")
    public Integer getBillingDate() {
        return billingDate;
    }

    /**
     * Sets the value of the billingDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setBillingDate(Integer value) {
        this.billingDate = value;
    }

    /**
     * Gets the value of the utilityPaymentID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("utilityPaymentID")
    public String getUtilityPaymentID() {
        return utilityPaymentID;
    }

    /**
     * Sets the value of the utilityPaymentID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilityPaymentID(String value) {
        this.utilityPaymentID = value;
    }

    /**
     * Gets the value of the tlfToAccount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("tlfToAccount")
    public String getTlfToAccount() {
        return tlfToAccount;
    }

    /**
     * Sets the value of the tlfToAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTlfToAccount(String value) {
        this.tlfToAccount = value;
    }

    /**
     * Gets the value of the excCategory property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    @JsonProperty("excCategory")
    public Integer getExcCategory() {
        return excCategory;
    }

    /**
     * Sets the value of the excCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setExcCategory(Integer value) {
        this.excCategory = value;
    }

}
