package gr.alpha.cbs.fuse.cardsedge.routes.inquiry;

import gr.alpha.cbs.fuse.cardsedge.beans.EnrichEntireResponse;
import org.apache.camel.builder.RouteBuilder;
import static org.apache.camel.component.xquery.XQueryBuilder.xquery;

public class GetCardAuthorizationsAndTransactions extends RouteBuilder {
    @Override
    public void configure() throws Exception{
        from("direct:do-transaction-GetCardAuthorizationsAndTransactionsPayload")
        .routeId("direct:do-transaction-GetCardAuthorizationsAndTransactionsPayload")
        .streamCaching()
            .setProperty("CardNumber", xquery("/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:CardNumber").resultType(java.lang.String.class))
            .setProperty("CorporateId", xquery("/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:CorporateId").resultType(java.lang.String.class))
            .setProperty("IsCorporate", xquery("/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:IsCorporate").resultType(java.lang.String.class))
            .choice()
                .when().simple("${exchangeProperty.IsCorporate} == 'false' && ${exchangeProperty.CardNumber} == ''")
                    .to("bean:errorUtils?method=throwCBSException(null, '1', '2', ${exchangeProperty.cbs.common.transactionTypeId}, '301366', '3', 'Card number is empty','','')")
                .endChoice()
                .when().simple("${exchangeProperty.IsCorporate} == 'true' && ${exchangeProperty.CorporateId} == ''")
                .to("bean:errorUtils?method=throwCBSException(null, '1', '2', ${exchangeProperty.cbs.common.transactionTypeId}, '301366', '3', 'Corporate number is empty','','')")
                .endChoice()
            .end()
            .setProperty("RequestDateFrom", xquery("/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:DateFrom").resultType(java.lang.String.class))
            .setProperty("DateFrom", xquery("/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:DateFrom").resultType(java.lang.String.class))
            .setProperty("DateTo", xquery("/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:DateTo").resultType(java.lang.String.class))
            .setProperty("Language", xquery("/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:Language").resultType(java.lang.String.class))
            .setProperty("RequestAuthorizations", xquery("/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:PagingInfo/*:RequestAuthorizations").resultType(java.lang.String.class))
            .setProperty("RequestTransactionsOnline", xquery("/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:PagingInfo/*:RequestTransactionsOnline").resultType(java.lang.String.class))
            .setProperty("RequestTransactionsOnlineDB", xquery("/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:PagingInfo/*:RequestTransactionsOnlineDB").resultType(java.lang.String.class))
            .setProperty("RequestLegacy", xquery("/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:PagingInfo/*:RequestLegacy").resultType(java.lang.String.class))
            .choice()
                .when().simple("${exchangeProperty.RequestAuthorizations} == 'true' || ${exchangeProperty.RequestTransactionsOnline} == 'true' || ${exchangeProperty.RequestTransactionsOnlineDB} == 'true' || ${exchangeProperty.RequestTransactionsOnlineDB} == 'RequestLegacy'")
                    .setProperty("IsPaging", constant("true"))
                .endChoice()
                .otherwise()
                    .setProperty("IsPaging", constant("false"))
                .endChoice()
            .end()
            //.setProperty("RequestPageSize", xquery("/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:PagingInfo/*:PageSize").resultType(java.lang.String.class))
            //.setProperty("PageSize", xquery("/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:PagingInfo/*:PageSize").resultType(java.lang.String.class))
            .setProperty("CBSPageSize", xquery("/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:PagingInfo/*:PageSize").resultType(java.lang.String.class))
            .setProperty("PageNumber", xquery("/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:PagingInfo/*:PageNumber").resultType(java.lang.String.class))
            /*.process(exchange -> {
                int pageSize = Integer.parseInt(exchange.getProperty("RequestPageSize", String.class));
                if(pageSize <= 100){
                    exchange.setProperty("PageSize", pageSize * 10);
                }else{
                    exchange.setProperty("PageSize", pageSize);
                }

                String pageNumber = exchange.getProperty("PageNumber", String.class);
                if(!pageNumber.isEmpty()){
                    exchange.setProperty("PageNumber", pageNumber);
                }else{
                    exchange.setProperty("PageNumber", 1);
                }
            })*/
            .setProperty("LegacyPageNumber", xquery("/*:GetCardAuthorizationsAndTransactionsPayload/*:GetCardAuthorizationsAndTransactionsRequestItem/*:PagingInfo/*:LegacyPageNumber").resultType(java.lang.String.class))
            .process(exchange -> {
                String legacyPageNumber = exchange.getProperty("LegacyPageNumber", String.class);
                if(legacyPageNumber == null || legacyPageNumber.isEmpty()){
                    exchange.setProperty("LegacyPageNumber", "1");
                }
            })
            .setProperty("PwcMigrationDate", method("getCardAuthorizationsAndTransactionsHelper", "getPwcMigrationDate(*)"))
            .choice()
                .when().simple("${exchangeProperty.IsCorporate} == 'true'")
                    .to("direct:GetCardAuthorizationsAndTransactionsPowercard")
                .endChoice()
                .otherwise()
                    .to("direct:choose-card-system")
                .endChoice()
            .end()
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/GetCardAuthorizationsAndTransactions/GetCardAuthorizationsAndTransactionsMapping.xsl")
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/GetCardAuthorizationsAndTransactions/GetCardAuthorizationsAndTransactionsValuesLookup.xsl?saxonExtensionFunctions=#functionGetEventCategoryLiteral,#functionGetMerchantCategoryLiteral,#functionGetMerchantCategoryGroup,#functionGetChannelMainLiteral,#functionGetCurrencyExponent,#functionGetCurrencyLiteral")
            .setProperty("CardsTransactionsCount", xquery("count(/*:Mapping/*:CardTransactionsList/*:CardTransaction)").resultType(java.lang.String.class))
            .bean("getCardAuthorizationsAndTransactionsHelper", "prepareResponse(*)")
        .end();

        from("direct:GetCardAuthorizationsAndTransactionsLegacy")
        .routeId("direct:GetCardAuthorizationsAndTransactionsLegacy")
        .streamCaching()
            .choice()
                .when().simple("${exchangeProperty.IsPaging} == 'false'")
                    .enrich("direct:GetCardAuthorizationsAndTransactions-ACCSHistory", new EnrichEntireResponse())
                .endChoice()
            .end()
        .end();

        from("direct:GetCardAuthorizationsAndTransactionsPowercard")
        .routeId("direct:GetCardAuthorizationsAndTransactionsPowercard")
        .streamCaching()
            .choice()
                .when().simple("${exchangeProperty.RequestAuthorizations} == 'false' && ${exchangeProperty.RequestTransactionsOnline} == 'false' && ${exchangeProperty.RequestTransactionsOnlineDB} == 'false' && ${exchangeProperty.RequestLegacy} == 'false'")
                    .setProperty("PwcDbLoadDate", method("getCardAuthorizationsAndTransactionsHelper", "getPwcDbLoadDate(*)"))
                    .choice()
                        .when().simple("${exchangeProperty.DateFrom} <= ${exchangeProperty.PwcMigrationDate}")
                            .choice()
                                .when().simple("${exchangeProperty.DateTo} <= ${exchangeProperty.PwcMigrationDate}")
                                    .enrich("direct:GetCardAuthorizationsAndTransactions-ACCSHistory", new EnrichEntireResponse())
                                .endChoice()
                                .when().simple("${exchangeProperty.DateTo} > ${exchangeProperty.PwcMigrationDate} && ${exchangeProperty.DateTo} < ${exchangeProperty.PwcDbLoadDate}")
                                    .enrich("direct:GetCardAuthorizationsAndTransactions-ACCSHistory", new EnrichEntireResponse())
                                    .enrich("direct:GetCardAuthorizationsAndTransactions-GetPwcDbTransactions", new EnrichEntireResponse())
                                .endChoice()
                                .when().simple("${exchangeProperty.DateTo} >= ${exchangeProperty.PwcDbLoadDate}")
                                    .enrich("direct:GetCardAuthorizationsAndTransactions-ACCSHistory", new EnrichEntireResponse())
                                    .enrich("direct:GetCardAuthorizationsAndTransactions-GetPwcDbTransactions", new EnrichEntireResponse())
                                    .enrich("direct:GetCardAuthorizationsAndTransactions-SearchAuthorization", new EnrichEntireResponse())
                                    .setProperty("DateFrom", simple("${exchangeProperty.PwcDbLoadDate}"))
                                    .enrich("direct:GetCardAuthorizationsAndTransactions-SearchTransactions", new EnrichEntireResponse())
                                .endChoice()
                            .end()
                        .endChoice()
                        .when().simple("${exchangeProperty.DateFrom} >= ${exchangeProperty.PwcMigrationDate} && ${exchangeProperty.DateFrom} < ${exchangeProperty.PwcDbLoadDate}")
                            .choice()
                                .when().simple("${exchangeProperty.DateTo} >= ${exchangeProperty.PwcMigrationDate} && ${exchangeProperty.DateTo} < ${exchangeProperty.PwcDbLoadDate}")
                                    .enrich("direct:GetCardAuthorizationsAndTransactions-GetPwcDbTransactions", new EnrichEntireResponse())
                                .endChoice()
                                .when().simple("${exchangeProperty.DateTo} >= ${exchangeProperty.PwcDbLoadDate}")
                                    .enrich("direct:GetCardAuthorizationsAndTransactions-GetPwcDbTransactions", new EnrichEntireResponse())
                                    .enrich("direct:GetCardAuthorizationsAndTransactions-SearchAuthorization", new EnrichEntireResponse())
                                    .setProperty("DateFrom", simple("${exchangeProperty.PwcDbLoadDate}"))
                                    .enrich("direct:GetCardAuthorizationsAndTransactions-SearchTransactions", new EnrichEntireResponse())
                                .endChoice()
                            .end()
                        .endChoice()
                        .when().simple("${exchangeProperty.DateFrom} >= ${exchangeProperty.PwcDbLoadDate}")
                            .choice()
                                .when().simple("${exchangeProperty.DateTo} >= ${exchangeProperty.PwcDbLoadDate}")
                                    .enrich("direct:GetCardAuthorizationsAndTransactions-SearchAuthorization", new EnrichEntireResponse())
                                    .enrich("direct:GetCardAuthorizationsAndTransactions-SearchTransactions", new EnrichEntireResponse())
                                .endChoice()
                            .end()
                        .endChoice()
                    .end()
                .endChoice()
                .otherwise()
                    .choice()
                        .when().simple("${exchangeProperty.RequestAuthorizations} == 'true'")
                            .enrich("direct:GetCardAuthorizationsAndTransactions-SearchAuthorization", new EnrichEntireResponse())
                        .endChoice()
                        .when().simple("${exchangeProperty.RequestTransactionsOnline} == 'true'")
                            .enrich("direct:GetCardAuthorizationsAndTransactions-SearchTransactions", new EnrichEntireResponse())
                        .endChoice()
                        .when().simple("${exchangeProperty.RequestTransactionsOnlineDB} == 'true'")
                            .enrich("direct:GetCardAuthorizationsAndTransactions-GetPwcDbTransactions", new EnrichEntireResponse())
                        .endChoice()
                        .when().simple("${exchangeProperty.RequestLegacy} == 'true'")
                            .enrich("direct:GetCardAuthorizationsAndTransactions-ACCSHistory", new EnrichEntireResponse())
                        .endChoice()
                    .end()
                .endChoice()
            .end()
        .end();

        from("direct:GetCardAuthorizationsAndTransactions-SearchAuthorization")
        .routeId("direct:GetCardAuthorizationsAndTransactions-SearchAuthorization")
        .streamCaching()
            .setProperty("cbs.redirect.powerCard", constant("SearchAuthorizationPayload"))
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/GetCardAuthorizationsAndTransactions/prepSearchAuthorization.xsl?output=DOM")
            .to("direct:PowerCardInquiry")
        .end();

        from("direct:GetCardAuthorizationsAndTransactions-SearchTransactions")
        .routeId("direct:GetCardAuthorizationsAndTransactions-SearchTransactions")
        .streamCaching()
            .setProperty("cbs.redirect.powerCard", constant("SearchTransactionsPayload"))
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/GetCardAuthorizationsAndTransactions/prepSearchTransactions.xsl?output=DOM")
            .to("direct:PowerCardInquiry")
        .end();

        from("direct:GetCardAuthorizationsAndTransactions-GetPwcDbTransactions")
        .routeId("direct:GetCardAuthorizationsAndTransactions-GetPwcDbTransactions")
        .streamCaching()
            .bean("getCardAuthorizationsAndTransactionsHelper", "getPwcDbTransactions(*)")
        .end();

        from("direct:GetCardAuthorizationsAndTransactions-ACCSHistory")
        .routeId("direct:GetCardAuthorizationsAndTransactions-ACCSHistory")
        .streamCaching()
            .removeHeaders("*")
            .setHeader("CamelHttpMethod", constant("GET"))
            .setHeader("Content-Type", constant("application/json;charset=UTF-8"))
            .setHeader("Accept", constant("application/json;charset=UTF-8"))
            .choice()
                .when().simple("${exchangeProperty.IsCorporate} == 'true'")
                    .setProperty("CardNumberFromCorporateId", method("getCardAuthorizationsAndTransactionsHelper", "getCardNumberFromCorporateId(*)"))
                    .choice()
                        .when().simple("${exchangeProperty.CardNumberFromCorporateId} != ''")
                            .bean("getCardAuthorizationsAndTransactionsHelper", "buildCardEntriesUrl(*)")
                            .toD("${exchangeProperty.CardEntriesUrl}")
                            .convertBodyTo(java.lang.String.class)
                            .bean("getCardAuthorizationsAndTransactionsHelper", "prepareCardEntriesResponse(*)")
                        .endChoice()
                    .end()
                .endChoice()
                .otherwise()
                    .bean("getCardAuthorizationsAndTransactionsHelper", "buildCardEntriesUrl(*)")
                    .toD("${exchangeProperty.CardEntriesUrl}")
                    .convertBodyTo(java.lang.String.class)
                    .bean("getCardAuthorizationsAndTransactionsHelper", "prepareCardEntriesResponse(*)")
                .endChoice()
            .end()
        .end();
    }
}
