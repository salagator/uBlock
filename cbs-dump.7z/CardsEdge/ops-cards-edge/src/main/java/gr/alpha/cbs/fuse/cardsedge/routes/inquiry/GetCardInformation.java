package gr.alpha.cbs.fuse.cardsedge.routes.inquiry;

import gr.alpha.cbs.fuse.cardsedge.beans.EnrichEntireResponse;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.http.base.HttpOperationFailedException;
import java.net.SocketTimeoutException;
import static org.apache.camel.component.xquery.XQueryBuilder.xquery;

public class GetCardInformation extends RouteBuilder {
    @Override
    public void configure() throws Exception{
        from("direct:do-transaction-GetCardInformationPayload")
        .routeId("direct:do-transaction-GetCardInformationPayload")
        .streamCaching()
            .setProperty("KillSwitch", method("killSwitchBean", "getStatusFromCache('CardsEdge','GetCardInformation')"))
            .choice()
                .when().simple("${exchangeProperty.KillSwitch} == 'true'")
                    .to("bean:errorUtils?method=throwCBSException(null, '1', '2', ${exchangeProperty.cbs.common.transactionTypeId}, '301036', '3', 'Operation Switched Off','','')")
                .endChoice()
                .otherwise()
                    .enrich("direct:GetCardInformationLegacy", new EnrichEntireResponse())
                    .enrich("direct:GetCardInformationPowercard", new EnrichEntireResponse())
                    .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/GetCardInformation/GetCardInformationResponse.xsl?saxonExtensionFunctions=#functionTranslator,functionMasterDataAttributeValueRetriever,functionMasterDataCodeFromAttributeValueRetriever,#functionBlacklistCodeXsltExtension,#functionDwhProductClassGroupMappingXsltExtension&output=DOM")
                .endChoice()
            .end()
        .end();

        from("direct:GetCardInformationLegacy")
        .routeId("direct:GetCardInformationLegacy")
        .streamCaching()
            .setProperty("TempRequestBody", simple("${body}"))
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/GetCardInformation/prepGetCardInformationLegacyRequest.xsl?saxonExtensionFunctions=#functionCardBinRangeSplitter&output=DOM")
            .choice()
                .when().xquery("exists(/*:GetCardInformationPayload/*:GetCardInformationRequestItem/*:AccountNumber)")
                    .doTry()
                        .removeHeaders("*")
                        .setHeader("CamelHttpMethod", constant("POST"))
                        .setHeader("Content-Type", constant("application/json;charset=UTF-8"))
                        .setHeader("Accept", constant("application/json;charset=UTF-8"))
                        .setHeader("Authorization", simple("{{cbs.camel.sia.esb.token}}"))
                        .bean("getCardInformationHelper", "prepareCallGetCardInformationRequestLegacy(*)")
                        .to("https://{{cbs.camel.sia.esb.host}}/api/issuing/cardinformation/GetCardInformation?{{cbs.mw.getcardinformation.params}}")
                        .log("GetCardInformation Paralos json response: ${body}")
                        .convertBodyTo(String.class)
                    .doCatch(HttpOperationFailedException.class)
                        .setBody(simple("${exchangeProperty.TempRequestBody}"))
                        .to("bean:errorUtils?method=throwCBSException(null, '1', '2', ${exchangeProperty.cbs.common.transactionTypeId}, '', '3', 'GetCardInformation Paralos Error error http status ${exception.statusCode}','','')")
                    .endDoTry()
                    .doCatch(SocketTimeoutException.class)
                        .setBody(simple("${exchangeProperty.TempRequestBody}"))
                        .to("bean:errorUtils?method=throwCBSException(null, '1', '2', ${exchangeProperty.cbs.common.transactionTypeId}, '', '3', 'GetCardInformation Paralos Timeout Error','','')")
                    .endDoTry()
                    .end()
                    .bean("getCardInformationHelper", "prepareGetCardInformationLegacyResponse(*)")
                .endChoice()
            .end()
        .end();

        from("direct:GetCardInformationPowercard")
        .routeId("direct:GetCardInformationPowercard")
        .streamCaching()
            .setProperty("cbs.redirect.powerCard", constant("GetMultiCardDetailsPayload"))
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/GetCardInformation/prepGetMultiCardDetailsRequest.xsl?saxonExtensionFunctions=#functionCardBinRangeSplitter&output=DOM")
            .choice()
                .when().xquery("exists(/*:GetMultiCardDetailsPayload/*:GetMultiCardDetailsRequestItem/*:CardNums)")
                    .doTry()
                        .log("GetCardInformation PowerCard GetMultiCardDetails request : ${body}")
                        .to("direct:PowerCardInquiry")
                        .log("GetCardInformation PowerCard GetMultiCardDetails response : ${body}")
                    .doCatch(CBSException.class)
                        .setProperty("cbs.getCardInformation.getMultiCardDetails.exception", constant("true"))
                        .setProperty("cbs.getCardInformation.getMultiCardDetails.exception.message", simple("${exception.errorModel.description}"))
                    .endDoTry()
                .endChoice()
            .end()
        .end();
    }
}
