package gr.alpha.cbs.fuse.cardsedge.xslt.extension;

import gr.alpha.cbs.fuse.cardsedge.helper.CardsEdgeConstants;
import gr.alpha.cbs.fuse.ifaces.MasterDataInterface;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;
import org.jboss.logging.Logger;
import java.util.HashMap;
import java.util.Map;

@Named("functionCardBinRangeSplitter")
@ApplicationScoped
@RegisterForReflection
public class CardBinRangeSplitterXsltExtension extends ExtensionFunctionDefinition {
    private static final long serialVersionUID = 2060328814415747864L;

    private static final Logger LOGGER = Logger.getLogger(CardBinRangeSplitterXsltExtension.class);

    @Inject
    MasterDataInterface masterDataInterface;

    @Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("cbrs", "http://fuse.cbs.alpha.gr/cardBinRangeSplitter/", "cardBinRangeSplitter");
    }

    @Override
    public SequenceType[] getArgumentTypes() {
        return new SequenceType[]{SequenceType.SINGLE_STRING};
    }

    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
        return SequenceType.SINGLE_STRING;
    }

    @Override
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {

            /**
             *
             */
            private static final long serialVersionUID = -2058456742203368019L;

            /**
             * Returns card system based on the given card
             */

            @Override
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
                try {
                    String cardNumber = null;
                    String targetSystem = "";
                    //Check masterName - Required field
                    if (arguments[0] instanceof LazySequence) {
                        cardNumber = ((LazySequence) arguments[0]).head().getStringValue();
                    } else if (arguments[0] instanceof StringValue) {
                        cardNumber = ((StringValue) arguments[0]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type for cardNumber parameter: " + arguments[0].getClass().getCanonicalName());
                    }
                    if (cardNumber.length() >= CardsEdgeConstants.CARD_NUMBER_MIN_DIGITS && cardNumber.length() <= CardsEdgeConstants.CARD_NUMBER_MAX_DIGITS) {
                        HashMap<String, HashMap<String, String>> map = masterDataInterface.getMasterDetailsLists("CardBinRanges");
                        long cardBIN = Long.parseLong(cardNumber.substring(0, 8));
                        for (Map.Entry<String, HashMap<String, String>> entry : map.entrySet()) {
                            long binFrom = -1;
                            long binTo = -1;
                            for (Map.Entry<String, String> entry1 : entry.getValue().entrySet()) {
                                if (entry1.getKey().equalsIgnoreCase("CardNumFrom")) {
                                    binFrom = Long.parseLong(entry1.getValue());
                                }
                                if (entry1.getKey().equalsIgnoreCase("CardNumTo")) {
                                    binTo = Long.parseLong(entry1.getValue());
                                }
                            }
                            if ((cardBIN >= binFrom) && (cardBIN <= binTo)) {
                                targetSystem = entry.getValue().get("TargetSystem");
                            }
                        }
                        if(targetSystem.equals("")) {
                            return StringValue.makeStringValue("Legacy");
                        }else{
                            return StringValue.makeStringValue(targetSystem);
                        }
                    } else {
                        throw new Exception("Invalid Card Number: " + cardNumber);
                    }
                } catch (Exception e) {
                    throw new XPathException("Unable to retrieve attribute Value", e);
                }
            }
        };
    }
}
