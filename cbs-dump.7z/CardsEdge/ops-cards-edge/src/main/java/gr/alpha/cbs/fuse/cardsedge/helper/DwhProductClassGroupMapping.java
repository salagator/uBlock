package gr.alpha.cbs.fuse.cardsedge.helper;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.transaction.Transactional;
import org.infinispan.protostream.SerializationContextInitializer;
import org.jboss.logging.Logger;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

@Named("dwhProductClassGroupMapping")
@ApplicationScoped
@RegisterForReflection
public class DwhProductClassGroupMapping{
	private static final Logger LOGGER = Logger.getLogger(DwhProductClassGroupMapping.class);

	RemoteDatagridClientHelper<String, String> datagridHelper;
	private static SerializationContextInitializer contextInitializer;

	@Inject
	@io.quarkus.agroal.DataSource("cbs-cards-pricing")
	private DataSource cardsPricingDatasource;

	@PostConstruct
	private void postConstruct() {
		datagridHelper = new RemoteDatagridClientHelper<>();
		datagridHelper.initCacheManagerWithMarshaller(contextInitializer);
		datagridHelper.setCache("dwhProductClassGroups");
	}

	@PreDestroy
	private void preDestroy() {
		datagridHelper.stopCacheManager();
	}

	public String getClassGroup(String productCode) throws SQLException, CBSException {
		String classGroup = null;
		String classGroupKey = productCode;
		if (datagridHelper.getCache() != null) {
			classGroup = datagridHelper.get(classGroupKey);
			if (classGroup == null) {
				updateDwhProductClassGroupsCache();
				classGroup = datagridHelper.get(classGroupKey);
			}
		} else {
			ErrorUtils.throwCBSException(null,
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					DwhProductClassGroupMapping.class.getCanonicalName(),
					ConstantErrorMessages._SQL_EXCEPTION,
					ErrorTypeModel.SEVERITY_ERROR,
					"Error while retrieving class groups from cache", "", "");
		}
		return classGroup;
	}

	private void updateDwhProductClassGroupsCache() throws SQLException, CBSException {
		Map<String, String> classGroups = selectFromDwhProdChar();
		datagridHelper.putAll(classGroups);
	}

	@Transactional
	public Map<String, String> selectFromDwhProdChar() throws SQLException, CBSException{
		Map<String, String> classGroups = new HashMap<>();
		try(Connection connection = cardsPricingDatasource.getConnection();
				PreparedStatement statement = connection.prepareStatement("SELECT [Product_Code],[Class_Group] from [CBS_CardsPricing].[dbo].[DWH_PROD_CHAR] WITH (NOLOCK)")){
			try(ResultSet resultSet = statement.executeQuery()) {
				while(resultSet.next()){
					classGroups.put(resultSet.getString("Product_Code"), resultSet.getString("Class_Group"));
				}
			}
		}catch (SQLException e){
			ErrorUtils.throwCBSException(null,
					ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
					ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					DwhProductClassGroupMapping.class.getCanonicalName(),
					ConstantErrorMessages._SQL_EXCEPTION,
					ErrorTypeModel.SEVERITY_ERROR,
					"Error while retrieving class groups from DB", "", "");
		}
		return classGroups;
	}

}
