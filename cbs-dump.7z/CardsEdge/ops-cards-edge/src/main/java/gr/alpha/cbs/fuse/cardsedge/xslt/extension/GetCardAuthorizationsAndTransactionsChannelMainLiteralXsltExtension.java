package gr.alpha.cbs.fuse.cardsedge.xslt.extension;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.ifaces.RefDataTranslator;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;

@Named("functionGetChannelMainLiteral")
@ApplicationScoped
@RegisterForReflection
public class GetCardAuthorizationsAndTransactionsChannelMainLiteralXsltExtension extends ExtensionFunctionDefinition {
    private static final long serialVersionUID = 2060328814415747456L;

    @Inject
    RefDataTranslator refDataTranslator;

    @Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("gcml", "http://fuse.cbs.alpha.gr/GetChannelMainLiteral/", "GetChannelMainLiteral");
    }

    @Override
    public SequenceType[] getArgumentTypes() {
        return new SequenceType[]{SequenceType.SINGLE_INTEGER};
    }

    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
        return SequenceType.SINGLE_STRING;
    }

    @Override
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {
            private static final long serialVersionUID = -2058456742203368019L;

            @Override
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
                try {
                    String channelMainId = null;
                    if (arguments[0] instanceof LazySequence) {
                        channelMainId = ((LazySequence) arguments[0]).head().getStringValue();
                    } else if (arguments[0] instanceof StringValue) {
                        channelMainId = ((StringValue) arguments[0]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type for channelMainId parameter: " + arguments[0].getClass().getCanonicalName());
                    }
                    String channelMainLiteral = refDataTranslator.translateData(CBSConstants.REF_DATA_SYSTEM_UI, "en", "CardTransactionChannelMainCodes", channelMainId);
                    return StringValue.makeStringValue(channelMainLiteral);

                } catch (Exception e) {
                    throw new XPathException("Unable to retrieve Channel Main Literal attribute Value", e);
                }
            }
        };
    }
}
