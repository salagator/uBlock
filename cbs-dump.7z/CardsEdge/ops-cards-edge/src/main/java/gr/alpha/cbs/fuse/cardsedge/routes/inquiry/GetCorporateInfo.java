package gr.alpha.cbs.fuse.cardsedge.routes.inquiry;

import org.apache.camel.builder.RouteBuilder;

public class GetCorporateInfo extends RouteBuilder {
    @Override
    public void configure() throws Exception{
        from("direct:do-transaction-GetCorporateInfoPayload")
        .routeId("direct:do-transaction-GetCorporateInfoPayload")
        .streamCaching()
            .setProperty("bankCode", method("cardsEdgeCommonFunctions", "setBankCode"))
            .bean("powercardCurrencyExponentMapping", "getCurrencyExponent(*)")
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/GetCorporateInfo/prepGetCorporateInfoNativePowercard.xsl")
            .log("Powercard XML Request body: ${body}")
            .setProperty("tempBody", simple("${body}"))
            .setProperty("cbs.camel.powercard.endpoint", simple("{{cbs.camel.powercard.endpoint}}"))
            .setProperty("cbs.camel.powercard.operation", constant("api/getCorporateInfo"))
            .setProperty("cbs.camel.powercard.version", constant(""))
            .setProperty("cbs.camel.powercard.timeout", simple("?{{cbs.powercard.GetCorporateInfo.timeout}}"))
            .setProperty("cbs.powercard.native.http.method", constant("POST"))
            .setProperty("cbs.powercard.request.class", simple("gr.alpha.cbs.fuse.cardsedge.generated.GetCorporateInfoRequestItemType"))
            .bean("powerCardHelper", "prepareNativeRequestBody(*)")
            .log("Powercard native JSON Request body: ${body}")
            .to("direct:powercard-http-call")
            .setProperty("cbs.powercard.response.class", simple("gr.alpha.cbs.fuse.cardsedge.generated.GetCorporateInfoResponse"))
            .setProperty("cbs.powercard.payload.class", simple("gr.alpha.cbs.fuse.cardsedge.generated.GetCorporateInfoResponsePayload"))
            .setProperty("cbs.powercard.item.class", simple("gr.alpha.cbs.fuse.cardsedge.generated.GetCorporateInfoResponseItem"))
            .bean("powerCardHelper", "prepareResponseBody(*, 'inquiry')")
            .log("CBS powerCard ${exchangeProperty.cbs.camel.powercard.operation} xml response: ${body}")
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/removeEmptyElements.xsl")
        .end();
    }
}
