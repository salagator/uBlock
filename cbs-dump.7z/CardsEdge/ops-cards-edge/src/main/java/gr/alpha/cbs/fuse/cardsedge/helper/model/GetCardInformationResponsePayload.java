
package gr.alpha.cbs.fuse.cardsedge.helper.model;

import gr.alpha.cbs.fuse.cardsedge.generated.ErrorMessageType;
import gr.alpha.cbs.fuse.cardsedge.generated.LoggingInfoType;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetCardInformationResponsePayload complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetCardInformationResponsePayload">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GetCardInformationResponseItem" type="{http://cards-edge.fuse.cbs.alpha.gr/cards-edge/}GetCardInformationResponseItem" minOccurs="0"/>
 *         &lt;element ref="{http://cards-edge.fuse.cbs.alpha.gr/cards-edge/}LoggingInfo"/>
 *         &lt;element ref="{http://cards-edge.fuse.cbs.alpha.gr/cards-edge/}ErrorMessage" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetCardInformationResponsePayload", propOrder = {
    "getCardInformationResponseItem",
    "loggingInfo",
    "errorMessage"
})
public class GetCardInformationResponsePayload {

    @XmlElement(name = "GetCardInformationResponseItem")
    protected GetCardInformationResponseItem getCardInformationResponseItem;
    @XmlElement(name = "LoggingInfo", required = true)
    protected LoggingInfoType loggingInfo;
    @XmlElement(name = "ErrorMessage")
    protected ErrorMessageType errorMessage;

    /**
     * Gets the value of the getCardInformationResponseItem property.
     * 
     * @return
     *     possible object is
     *     {@link GetCardInformationResponseItem }
     *     
     */
    public GetCardInformationResponseItem getGetCardInformationResponseItem() {
        return getCardInformationResponseItem;
    }

    /**
     * Sets the value of the getCardInformationResponseItem property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetCardInformationResponseItem }
     *     
     */
    public void setGetCardInformationResponseItem(GetCardInformationResponseItem value) {
        this.getCardInformationResponseItem = value;
    }

    /**
     * Gets the value of the loggingInfo property.
     * 
     * @return
     *     possible object is
     *     {@link LoggingInfoType }
     *     
     */
    public LoggingInfoType getLoggingInfo() {
        return loggingInfo;
    }

    /**
     * Sets the value of the loggingInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link LoggingInfoType }
     *     
     */
    public void setLoggingInfo(LoggingInfoType value) {
        this.loggingInfo = value;
    }

    /**
     * Gets the value of the errorMessage property.
     * 
     * @return
     *     possible object is
     *     {@link ErrorMessageType }
     *     
     */
    public ErrorMessageType getErrorMessage() {
        return errorMessage;
    }

    /**
     * Sets the value of the errorMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link ErrorMessageType }
     *     
     */
    public void setErrorMessage(ErrorMessageType value) {
        this.errorMessage = value;
    }

}
