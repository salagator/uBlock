package gr.alpha.cbs.fuse.cardsedge.powercard;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import gr.alpha.cbs.fuse.cardsedge.helper.LoggingInfoHelper;
import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.common.ifaces.RefDataTranslator;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import org.apache.camel.Exchange;
import org.jboss.logging.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.IOException;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Named("powerCardHelper")
@Dependent
@RegisterForReflection
public class PowerCardHelper {
    private static final Logger LOGGER = Logger.getLogger(PowerCardHelper.class);

	@Inject
	RefDataTranslator translator;

	public static <R> String xmlToJson(Exchange ex, R requestItem) throws JAXBException, JsonProcessingException, CBSException {
		Document doc = ex.getIn().getBody(Document.class);
		Node firstNode = doc.getFirstChild();
		LOGGER.debug("Converting xml to json: "+ nodeToString(firstNode));
		Node requestNode = null;
		NodeList nodeList = firstNode.getChildNodes();
		for(int i=0; i < nodeList.getLength(); i++){
			if (nodeList.item(i).getNodeType() == Node.ELEMENT_NODE){
				Element requestElement = (Element) nodeList.item(i);
				if(requestElement.getTagName().contains("RequestItem")){
					requestNode = nodeList.item(i);
					break;
				}
			}
		}
		JAXBContext jaxbContext = JAXBContext.newInstance(requestItem.getClass());
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		JAXBElement<R> jaxbElement = (JAXBElement<R>)jaxbUnmarshaller.unmarshal(requestNode, requestItem.getClass());
		ObjectMapper mapper = ObjectMapperHelper.getObjectMapperInstance().setPowerCardRequestConfiguration();
		String jsonString = mapper.writeValueAsString(jaxbElement.getValue());
		LOGGER.debug("Converted json: " + jsonString);
		return jsonString;
	}

	public <R> String powerCardXmlToJson(Exchange ex, R requestItem) throws JAXBException, JsonProcessingException, CBSException {
		Document doc = ex.getIn().getBody(Document.class);
		Node firstNode = doc.getFirstChild();
		LOGGER.debug("Converting powercard xml to json: "+ nodeToString(firstNode));
		Node requestNode = null;
		NodeList nodeList = firstNode.getChildNodes();
		String powerCardRequestUID = UUID.randomUUID().toString();
		ex.setProperty("cbs.powercard.last.requestUID", powerCardRequestUID);
		for(int i = 0; i < nodeList.getLength(); i++) {
			if (nodeList.item(i).getNodeType() == Node.ELEMENT_NODE) {
				Element requestElement = (Element) nodeList.item(i);
				if (requestElement.getTagName().contains("RequestItem")) {
					requestNode = nodeList.item(i);
					Element requestInfoNode = doc.createElementNS(requestElement.getNamespaceURI(), "car:RequestInfo");
					Element requestUIDNode = doc.createElementNS(requestElement.getNamespaceURI(), "car:RequestUID");
					Element requestDateNode = doc.createElementNS(requestElement.getNamespaceURI(), "car:RequestDate");
					Element requestUserIDNode = doc.createElementNS(requestElement.getNamespaceURI(), "car:UserID");
					requestUIDNode.setTextContent(powerCardRequestUID);
					requestDateNode.setTextContent(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss").format(LocalDateTime.now()));
					requestUserIDNode.setTextContent(mapCbsUserToPowerCardUser(ex));
					requestInfoNode.appendChild(requestUserIDNode);
					requestInfoNode.appendChild(requestDateNode);
					requestInfoNode.appendChild(requestUIDNode);
					requestNode.appendChild(requestInfoNode);
					break;
				} 
			}
		}
		JAXBContext jaxbContext = JAXBContext.newInstance(requestItem.getClass());
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		JAXBElement<R> jaxbElement = (JAXBElement<R>)jaxbUnmarshaller.unmarshal(requestNode, requestItem.getClass());
		ObjectMapper mapper = ObjectMapperHelper.getObjectMapperInstance().setPowerCardRequestConfiguration();
		String jsonString = mapper.writeValueAsString(jaxbElement.getValue());
		LOGGER.debug("Native PowerCard Json: " + jsonString);
		return jsonString;
	}
   
    private static String nodeToString(Node node) throws CBSException {
    	  StringWriter sw = new StringWriter();
    	  try {
			  TransformerFactory factory = TransformerFactory.newInstance();
			  Transformer t = factory.newTransformer();
			  t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			  t.transform(new DOMSource(node), new StreamResult(sw));
    	  } catch (TransformerException te) {
			  LOGGER.debug("NodeToString Transformer Exception: " + te.getMessage());
			  ErrorUtils.throwCBSException(null, ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, ErrorTypeModel.ERROR_SYSTEM_ID_FUSE, PowerCardHelper.class.getCanonicalName(), ConstantErrorMessages._GENERAL_EXCEPTION, ErrorTypeModel.SEVERITY_ERROR, "NodeToString Transformer Exception", "", "");
    	  }
		  return sw.toString();
	}

	public static <S> S jsonStringToClass(String jsonString, S responseObject) throws IOException {
		ObjectMapper mapper = ObjectMapperHelper.getObjectMapperInstance().setPowerCardResponseConfiguration();
		return (S) mapper.readValue(jsonString, responseObject.getClass());
	}

	public static <R> String classToJsonString(R requestObject) throws IOException {
		ObjectMapper mapper = ObjectMapperHelper.getObjectMapperInstance().setPowerCardResponseConfiguration();
		return mapper.writeValueAsString(requestObject);
	}

	private static final ObjectMapper TOKEN_MAPPER = new ObjectMapper().configure(DeserializationFeature.USE_LONG_FOR_INTS, true);
	public static Map<String, Object> getTokenContent(String token) throws IOException {
		Map<String, Object> mapping = new HashMap<>();
		if (token != null) {
			String tokenSubContent = token.split("\\.")[1];
			//retrieve EpochSeconds as Long value
			mapping = TOKEN_MAPPER.readValue(
					new String(Base64.getDecoder().decode(tokenSubContent)), HashMap.class);
		}
		return mapping;
	}

	public String mapCbsUserToPowerCardUser(Exchange ex) throws CBSException {
		String userId = ex.getProperty("cbs.common.userId", String.class);
		String powerCardUserId = null;
		try {
			userId = userId.replace("\\", "\\\\"); // In database value contains double reverse slash
			powerCardUserId = translator.translateData(CBSConstants.REF_DATA_SYSTEM_UI, "el", "PowercardUsersMapping", userId);
			LOGGER.debug("userId is: " + userId);
			LOGGER.debug("translated powercard user is: " + powerCardUserId);
			if (powerCardUserId.isEmpty()) {//TODO REMOVE THIS STATEMENT WHEN PWC USERS ARE ADDED SUCCESSFULLY
				powerCardUserId = "appuser";
			}
			ex.setProperty("powerCardUser", powerCardUserId);
		} catch (Exception e) {
			ErrorUtils.throwCBSException(null, ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					PowerCardHelper.class.getCanonicalName(), ConstantErrorMessages._GENERAL_EXCEPTION,
					ErrorTypeModel.SEVERITY_ERROR, "Failed to translate powercard user", "", "");
		}
		return powerCardUserId;
	}

	/**
	 * Common method that prepares native json request body
	 * Takes a specific class name from cbs.powercard.request.class camel property
	 * Calls powerCardXmlToJson to create a powerCard json String from exchange xml body
	 * */
	public void prepareNativeRequestBody(Exchange exchange) throws JAXBException, JsonProcessingException, CBSException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		Class<?> powerCardRequestClass = Class.forName(exchange.getProperty("cbs.powercard.request.class", String.class));
		String requestJson = powerCardXmlToJson(exchange, powerCardRequestClass.newInstance());
		exchange.getIn().setBody(requestJson);
	}

	/**
	 * Helping common method which replaces success response processor
	 * Takes two args, exchange and operationType (values inquiry, maintenance)
	 * Uses three camel properties for response, payload and item classes
	 * Sets loggingInfo in payload class based on operationType
	 * Sets response CBS class to exchange body
	 * */
	public void prepareResponseBody(Exchange exchange, String operationType) throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException, CBSException {
		String responseJson = exchange.getIn().getBody(String.class);
		Class<?> responseClass = Class.forName(exchange.getProperty("cbs.powercard.response.class", String.class));
		Class<?> payloadClass = Class.forName(exchange.getProperty("cbs.powercard.payload.class", String.class));
		Class<?> itemClass = Class.forName(exchange.getProperty("cbs.powercard.item.class", String.class));
		Object response = responseClass.newInstance();
		Object payload = payloadClass.newInstance();
		Object item = jsonStringToClass(responseJson, itemClass.newInstance());
		invokeGenericMethod(payload, "set" + itemClass.getSimpleName(), item);
		if (operationType.equals("inquiry")) {
			invokeGenericMethod(payload, "setLoggingInfo", LoggingInfoHelper.getLoggingInfo(exchange));
		} else if (operationType.equals("maintenance")){
			invokeGenericMethod(payload, "setLoggingInfo", LoggingInfoHelper.getLoggingInfo(exchange));
		}
		invokeGenericMethod(response, "set" + payloadClass.getSimpleName(), payload);
		exchange.getIn().setBody(response);
	}

	/**
	 * Helping common method which invokes a method of the provided
	 * Takes three args the target object, the method name (in our cases the setter methods) and value that will be set
	 * */
	private void invokeGenericMethod(Object obj, String methodName, Object value) throws CBSException {
		try {
			Method method = obj.getClass().getMethod(methodName, value.getClass());
			method.invoke(obj, value);
		} catch (InvocationTargetException e) {
			LOGGER.error("InvocationTargetException: " + e.getMessage());
			ErrorUtils.throwCBSException(null, ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					PowerCardHelper.class.getCanonicalName(), ConstantErrorMessages._GENERAL_EXCEPTION,
					ErrorTypeModel.SEVERITY_ERROR, "InvocationTargetException: failed to invoke method: " + methodName + " for class: " + obj.getClass().getSimpleName(), "", "");
		} catch (NoSuchMethodException e) {
			LOGGER.error("NoSuchMethodException: " + e.getMessage());
			ErrorUtils.throwCBSException(null, ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					PowerCardHelper.class.getCanonicalName(), ConstantErrorMessages._GENERAL_EXCEPTION,
					ErrorTypeModel.SEVERITY_ERROR, "NoSuchMethodException: failed to invoke method: " + methodName + " for class: " + obj.getClass().getSimpleName(), "", "");
		} catch (IllegalAccessException e) {
			LOGGER.error("IllegalAccessException: " + e.getMessage());
			ErrorUtils.throwCBSException(null, ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
					PowerCardHelper.class.getCanonicalName(), ConstantErrorMessages._GENERAL_EXCEPTION,
					ErrorTypeModel.SEVERITY_ERROR, "IllegalAccessException: failed to invoke method: " + methodName + " for class: " + obj.getClass().getSimpleName(), "", "");
		}
	}



}
