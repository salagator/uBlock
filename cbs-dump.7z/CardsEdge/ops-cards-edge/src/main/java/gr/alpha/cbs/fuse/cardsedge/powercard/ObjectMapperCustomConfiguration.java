package gr.alpha.cbs.fuse.cardsedge.powercard;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;

import javax.xml.datatype.XMLGregorianCalendar;

public class ObjectMapperCustomConfiguration extends ObjectMapper{
	
	private static final long serialVersionUID = 1L;


	public ObjectMapperCustomConfiguration setupResponseConfiguration(){
		this.setSerializationInclusion(Include.NON_NULL);
		this.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		//hack to fix ussue #1791 solved on jackson 2.13
		SimpleModule customModule = new SimpleModule();
		customModule.addSerializer(XMLGregorianCalendar.class, new CustomXMLGregCalendarSerializer());
		// need to include empty strings because they are valid inputs
		customModule.addSerializer(String.class, new StringSerializer());
		this.registerModule(customModule);
		this.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		return this;
	}
	
	public ObjectMapperCustomConfiguration setupRequestConfiguration(){
		// do not include null values, empty arrays
		this.setSerializationInclusion(Include.NON_EMPTY);
		
		this.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		//hack to fix ussue #1791 solved on jackson 2.13
		SimpleModule customModule = new SimpleModule();
		customModule.addSerializer(XMLGregorianCalendar.class, new CustomXMLGregCalendarSerializer());
		// need to include empty strings because they are valid inputs
		customModule.addSerializer(String.class, new StringSerializer());
		this.registerModule(customModule);
		this.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		return this;
	}

	public ObjectMapperCustomConfiguration setPowerCardResponseConfiguration(){
		this.setSerializationInclusion(Include.NON_NULL);
		this.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		SimpleModule customModule = new SimpleModule();
		customModule.addSerializer(XMLGregorianCalendar.class, new CustomXMLGregCalendarSerializer());
		customModule.addDeserializer(XMLGregorianCalendar.class, new CustomXMLGregCalendarDeserializer());
		customModule.addSerializer(String.class, new StringSerializer());
		this.registerModule(customModule);
		this.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		return this;
	}

	public ObjectMapperCustomConfiguration setPowerCardRequestConfiguration(){
		// do not include null values, empty arrays
		this.setSerializationInclusion(Include.NON_EMPTY);

		this.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		//hack to fix ussue #1791 solved on jackson 2.13
		SimpleModule customModule = new SimpleModule();
		customModule.addSerializer(XMLGregorianCalendar.class, new CustomXMLGregCalendarSerializer());
		// need to include empty strings because they are valid inputs
		customModule.addSerializer(String.class, new StringSerializer());
		this.registerModule(customModule);
		this.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		return this;
	}
	
}
