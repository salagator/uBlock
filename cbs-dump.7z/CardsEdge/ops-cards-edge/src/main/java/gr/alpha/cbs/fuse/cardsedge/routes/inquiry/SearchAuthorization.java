package gr.alpha.cbs.fuse.cardsedge.routes.inquiry;

import org.apache.camel.builder.RouteBuilder;

public class SearchAuthorization extends RouteBuilder {
    @Override
    public void configure() throws Exception{
        from("direct:do-transaction-SearchAuthorizationPayload")
        .routeId("direct:do-transaction-SearchAuthorizationPayload")
        .streamCaching()
            .log("Powercard XML Request body: ${body}")
            .setProperty("tempBody", simple("${body}"))
            .setProperty("cbs.camel.powercard.endpoint", simple("{{cbs.camel.powercard.endpoint}}"))
            .setProperty("cbs.camel.powercard.operation", constant("SearchAuthorization"))
            .setProperty("cbs.camel.powercard.version", constant("/V2"))
            .setProperty("cbs.camel.powercard.timeout", simple("?{{cbs.powercard.SearchAuthorization.timeout}}"))
            .setProperty("cbs.powercard.native.http.method", constant("POST"))
            .setProperty("cbs.powercard.request.class", simple("gr.alpha.cbs.fuse.cardsedge.generated.SearchAuthorizationRequestItemType"))
            .bean("powerCardHelper", "prepareNativeRequestBody(*)")
            .log("Powercard native JSON Request body: ${body}")
            .to("direct:powercard-http-call")
            .setProperty("cbs.powercard.response.class", simple("gr.alpha.cbs.fuse.cardsedge.generated.SearchAuthorizationResponse"))
            .setProperty("cbs.powercard.payload.class", simple("gr.alpha.cbs.fuse.cardsedge.generated.SearchAuthorizationResponsePayload"))
            .setProperty("cbs.powercard.item.class", simple("gr.alpha.cbs.fuse.cardsedge.generated.SearchAuthorizationResponseItem"))
            .bean("powerCardHelper", "prepareResponseBody(*, 'inquiry')")
            .log("CBS powerCard ${exchangeProperty.cbs.camel.powercard.operation} xml response: ${body}")
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/removeEmptyElements.xsl")
        .end();
    }
}
