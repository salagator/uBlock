package gr.alpha.cbs.fuse.cardsedge.xslt.extension;

import gr.alpha.cbs.fuse.cardsedge.powercard.PowercardCurrencyExponentMapping;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;

@Named("functionGetCurrencyExponent")
@ApplicationScoped
@RegisterForReflection
public class PowercardCurrencyExponentMappingXsltExtension extends ExtensionFunctionDefinition {
    private static final long serialVersionUID = 2060328814415747910L;

    @Inject
    PowercardCurrencyExponentMapping powercardCurrencyExponentMapping;

    @Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("gce", "http://fuse.cbs.alpha.gr/GetCurrencyExponent/", "GetCurrencyExponent");
    }

    @Override
    public SequenceType[] getArgumentTypes() {
        return new SequenceType[]{SequenceType.SINGLE_STRING};
    }

    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
        return SequenceType.SINGLE_STRING;
    }

    @Override
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {
            private static final long serialVersionUID = -2058456742203368019L;

            @Override
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
                try {
                    String currencyCode = null;
                    if (arguments[0] instanceof LazySequence) {
                        currencyCode = ((LazySequence) arguments[0]).head().getStringValue();
                    } else if (arguments[0] instanceof StringValue) {
                        currencyCode = ((StringValue) arguments[0]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type for currencyCode parameter: " + arguments[0].getClass().getCanonicalName());
                    }
                    return StringValue.makeStringValue(powercardCurrencyExponentMapping.calculateCurrencyExponent(currencyCode));

                } catch (Exception e) {
                    throw new XPathException("Unable to retrieve Currency Exponents", e);
                }
            }
        };
    }
}
