
package gr.alpha.cbs.fuse.cardsedge.helper.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for GetCardInformationAccountNumbersType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetCardInformationAccountNumbersType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="StatementBalance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="StatementDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="StdType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TotalAuths" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="TotalInstallmentsAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="EmbossingName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddonMainIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PersonalCompanyIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EstatementsFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="SubscribedSms" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="AlertsDomesticPurchaseFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="SpendingLimit" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="AlertsDomesticWithdrawalFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="AlertsInternationalWithdrawalFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="PinEnabled" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="BankAccounts" type="{http://cards-edge.fuse.cbs.alpha.gr/cards-edge/}GetCardInformationBankAccounts" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="BankAccountsCountOverLimitFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BankAccountsTotalCount" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="CardPrg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ConnectedAccounts" type="{http://cards-edge.fuse.cbs.alpha.gr/cards-edge/}GetCardInformationConnectedAccounts" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="TaxNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OccupationCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TotalCardBlock" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="SPVCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AlertsInternationalPurchaseFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="OnboardingFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="RemainingTopUpAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="PassportNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Account" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicationReferenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BankAccount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BlackListCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CDINumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditLimit" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CurrencyDecimals" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CurrencyLiteral" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CurrentBalance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="CardActivationFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PendingInstallmentsAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="DateOfBirth" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="ExpirationDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FirstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IdNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastPayAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="LastPayDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="MemberSince" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MinimumPayAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="MinimumPayDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="NewAccount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OpenToBuy" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="DeliquentDays" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SecuritizationFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetCardInformationAccountNumbersType", propOrder = {
    "StatementBalance",
    "StatementDate",
    "StdType",
    "TotalAuths",
    "TotalInstallmentsAmount",
    "EmbossingName",
    "AddonMainIndicator",
    "PersonalCompanyIndicator",
    "EstatementsFlag",
    "SubscribedSms",
    "AlertsDomesticPurchaseFlag",
    "SpendingLimit",
    "AlertsDomesticWithdrawalFlag",
    "AlertsInternationalWithdrawalFlag",
    "PinEnabled",
    "BankAccounts",
    "BankAccountsCountOverLimitFlag",
    "BankAccountsTotalCount",
    "CardPrg",
    "ConnectedAccounts",
    "TaxNumber",
    "OccupationCode",
    "TotalCardBlock",
    "SPVCode",
    "AlertsInternationalPurchaseFlag",
    "OnboardingFlag",
    "RemainingTopUpAmount",
    "PassportNumber",
    "Account",
    "ApplicationReferenceNumber",
    "BankAccount",
    "BlackListCode",
    "CDINumber",
    "CreditLimit",
    "CurrencyCode",
    "CurrencyDecimals",
    "CurrencyLiteral",
    "CurrentBalance",
    "CardActivationFlag",
    "PendingInstallmentsAmount",
    "DateOfBirth",
    "ExpirationDate",
    "FirstName",
    "IdNumber",
    "LastName",
    "LastPayAmount",
    "LastPayDate",
    "MemberSince",
    "MinimumPayAmount",
    "MinimumPayDate",
    "NewAccount",
    "OpenToBuy",
    "OpenToBuyCash",
    "DeliquentDays",
    "SecuritizationFlag",
    "CurrentMemberNumber",
    "ActiveMemberNumber",
    "LastActiveMemberExpDate",
})
public class GetCardInformationAccountNumbersType {

    @XmlElement(name = "StatementBalance")
    protected BigDecimal StatementBalance;
    @XmlElement(name = "StatementDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar StatementDate;
    @XmlElement(name = "StdType")
    protected String StdType;
    @XmlElement(name = "TotalAuths")
    protected BigDecimal TotalAuths;
    @XmlElement(name = "TotalInstallmentsAmount")
    protected BigDecimal TotalInstallmentsAmount;
    @XmlElement(name = "EmbossingName")
    protected String EmbossingName;
    @XmlElement(name = "AddonMainIndicator")
    protected String AddonMainIndicator;
    @XmlElement(name = "PersonalCompanyIndicator")
    protected String PersonalCompanyIndicator;
    @XmlElement(name = "EstatementsFlag")
    protected Boolean EstatementsFlag;
    @XmlElement(name = "SubscribedSms")
    protected Boolean SubscribedSms;
    @XmlElement(name = "AlertsDomesticPurchaseFlag")
    protected Boolean AlertsDomesticPurchaseFlag;
    @XmlElement(name = "SpendingLimit")
    protected BigDecimal SpendingLimit;
    @XmlElement(name = "AlertsDomesticWithdrawalFlag")
    protected Boolean AlertsDomesticWithdrawalFlag;
    @XmlElement(name = "AlertsInternationalWithdrawalFlag")
    protected Boolean AlertsInternationalWithdrawalFlag;
    @XmlElement(name = "PinEnabled")
    protected Boolean PinEnabled;
    @XmlElement(name = "BankAccounts")
    protected List<GetCardInformationBankAccounts> BankAccounts;
    @XmlElement(name = "BankAccountsCountOverLimitFlag")
    protected String BankAccountsCountOverLimitFlag;
    @XmlElement(name = "BankAccountsTotalCount")
    protected Integer BankAccountsTotalCount;
    @XmlElement(name = "CardPrg")
    protected String CardPrg;
    @XmlElement(name = "ConnectedAccounts")
    protected List<GetCardInformationConnectedAccounts> ConnectedAccounts;
    @XmlElement(name = "TaxNumber")
    protected String TaxNumber;
    @XmlElement(name = "OccupationCode")
    protected String OccupationCode;
    @XmlElement(name = "TotalCardBlock")
    protected Boolean TotalCardBlock;
    @XmlElement(name = "SPVCode")
    protected String SPVCode;
    @XmlElement(name = "AlertsInternationalPurchaseFlag")
    protected Boolean AlertsInternationalPurchaseFlag;
    @XmlElement(name = "OnboardingFlag")
    protected Boolean OnboardingFlag;
    @XmlElement(name = "RemainingTopUpAmount")
    protected BigDecimal RemainingTopUpAmount;
    @XmlElement(name = "PassportNumber")
    protected String PassportNumber;
    @XmlElement(name = "Account")
    protected String Account;
    @XmlElement(name = "ApplicationReferenceNumber")
    protected String ApplicationReferenceNumber;
    @XmlElement(name = "BankAccount")
    protected String BankAccount;
    @XmlElement(name = "BlackListCode")
    protected String BlackListCode;
    @XmlElement(name = "CDINumber")
    protected String CDINumber;
    @XmlElement(name = "CreditLimit")
    protected BigDecimal CreditLimit;
    @XmlElement(name = "CurrencyCode")
    protected String CurrencyCode;
    @XmlElement(name = "CurrencyDecimals")
    protected String CurrencyDecimals;
    @XmlElement(name = "CurrencyLiteral")
    protected String CurrencyLiteral;
    @XmlElement(name = "CurrentBalance")
    protected BigDecimal CurrentBalance;
    @XmlElement(name = "CardActivationFlag")
    protected String CardActivationFlag;
    @XmlElement(name = "PendingInstallmentsAmount")
    protected BigDecimal PendingInstallmentsAmount;
    @XmlElement(name = "DateOfBirth")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar DateOfBirth;
    @XmlElement(name = "ExpirationDate")
    protected String ExpirationDate;
    @XmlElement(name = "FirstName")
    protected String FirstName;
    @XmlElement(name = "IdNumber")
    protected String IdNumber;
    @XmlElement(name = "LastName")
    protected String LastName;
    @XmlElement(name = "LastPayAmount")
    protected BigDecimal LastPayAmount;
    @XmlElement(name = "LastPayDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar LastPayDate;
    @XmlElement(name = "MemberSince")
    protected String MemberSince;
    @XmlElement(name = "MinimumPayAmount")
    protected BigDecimal MinimumPayAmount;
    @XmlElement(name = "MinimumPayDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar MinimumPayDate;
    @XmlElement(name = "NewAccount")
    protected String NewAccount;
    @XmlElement(name = "OpenToBuy")
    protected BigDecimal OpenToBuy;
    @XmlElement(name = "OpenToBuyCash")
    protected BigDecimal OpenToBuyCash;
    @XmlElement(name = "DeliquentDays")
    protected String DeliquentDays;
    @XmlElement(name = "SecuritizationFlag")
    protected Boolean SecuritizationFlag;
    @XmlElement(name = "CurrentMemberNumber")
    protected String CurrentMemberNumber;
    @XmlElement(name = "ActiveMemberNumber")
    protected String ActiveMemberNumber;
    @XmlElement(name = "LastActiveMemberExpDate")
    protected String LastActiveMemberExpDate;

    /**
     * Gets the value of the statementBalance property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    @JsonProperty("StatementBalance")
    public BigDecimal getStatementBalance() {
        return StatementBalance;
    }

    /**
     * Sets the value of the statementBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setStatementBalance(BigDecimal value) {
        this.StatementBalance = value;
    }

    /**
     * Gets the value of the statementDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    @JsonProperty("StatementDate")
    public XMLGregorianCalendar getStatementDate() {
        return StatementDate;
    }

    /**
     * Sets the value of the statementDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setStatementDate(XMLGregorianCalendar value) {
        this.StatementDate = value;
    }

    /**
     * Gets the value of the stdType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("StdType")
    public String getStdType() {
        return StdType;
    }

    /**
     * Sets the value of the stdType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStdType(String value) {
        this.StdType = value;
    }

    /**
     * Gets the value of the totalAuths property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    @JsonProperty("TotalAuths")
    public BigDecimal getTotalAuths() {
        return TotalAuths;
    }

    /**
     * Sets the value of the totalAuths property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalAuths(BigDecimal value) {
        this.TotalAuths = value;
    }

    /**
     * Gets the value of the totalInstallmentsAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    @JsonProperty("TotalInstallmentsAmount")
    public BigDecimal getTotalInstallmentsAmount() {
        return TotalInstallmentsAmount;
    }

    /**
     * Sets the value of the totalInstallmentsAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalInstallmentsAmount(BigDecimal value) {
        this.TotalInstallmentsAmount = value;
    }

    /**
     * Gets the value of the embossingName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("EmbossingName")
    public String getEmbossingName() {
        return EmbossingName;
    }

    /**
     * Sets the value of the embossingName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmbossingName(String value) {
        this.EmbossingName = value;
    }

    /**
     * Gets the value of the addonMainIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("AddonMainIndicator")
    public String getAddonMainIndicator() {
        return AddonMainIndicator;
    }

    /**
     * Sets the value of the addonMainIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddonMainIndicator(String value) {
        this.AddonMainIndicator = value;
    }

    /**
     * Gets the value of the personalCompanyIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("PersonalCompanyIndicator")
    public String getPersonalCompanyIndicator() {
        return PersonalCompanyIndicator;
    }

    /**
     * Sets the value of the personalCompanyIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPersonalCompanyIndicator(String value) {
        this.PersonalCompanyIndicator = value;
    }

    /**
     * Gets the value of the estatementsFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    @JsonProperty("EstatementsFlag")
    public Boolean isEstatementsFlag() {
        return EstatementsFlag;
    }

    /**
     * Sets the value of the estatementsFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setEstatementsFlag(Boolean value) {
        this.EstatementsFlag = value;
    }

    /**
     * Gets the value of the subscribedSms property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    @JsonProperty("SubscribedSms")
    public Boolean isSubscribedSms() {
        return SubscribedSms;
    }

    /**
     * Sets the value of the subscribedSms property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSubscribedSms(Boolean value) {
        this.SubscribedSms = value;
    }

    /**
     * Gets the value of the alertsDomesticPurchaseFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    @JsonProperty("AlertsDomesticPurchaseFlag")
    public Boolean isAlertsDomesticPurchaseFlag() {
        return AlertsDomesticPurchaseFlag;
    }

    /**
     * Sets the value of the alertsDomesticPurchaseFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAlertsDomesticPurchaseFlag(Boolean value) {
        this.AlertsDomesticPurchaseFlag = value;
    }

    /**
     * Gets the value of the spendingLimit property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    @JsonProperty("SpendingLimit")
    public BigDecimal getSpendingLimit() {
        return SpendingLimit;
    }

    /**
     * Sets the value of the spendingLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSpendingLimit(BigDecimal value) {
        this.SpendingLimit = value;
    }

    /**
     * Gets the value of the alertsDomesticWithdrawalFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    @JsonProperty("AlertsDomesticWithdrawalFlag")
    public Boolean isAlertsDomesticWithdrawalFlag() {
        return AlertsDomesticWithdrawalFlag;
    }

    /**
     * Sets the value of the alertsDomesticWithdrawalFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAlertsDomesticWithdrawalFlag(Boolean value) {
        this.AlertsDomesticWithdrawalFlag = value;
    }

    /**
     * Gets the value of the alertsInternationalWithdrawalFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    @JsonProperty("AlertsInternationalWithdrawalFlag")
    public Boolean isAlertsInternationalWithdrawalFlag() {
        return AlertsInternationalWithdrawalFlag;
    }

    /**
     * Sets the value of the alertsInternationalWithdrawalFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAlertsInternationalWithdrawalFlag(Boolean value) {
        this.AlertsInternationalWithdrawalFlag = value;
    }

    /**
     * Gets the value of the pinEnabled property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    @JsonProperty("PinEnabled")
    public Boolean isPinEnabled() {
        return PinEnabled;
    }

    /**
     * Sets the value of the pinEnabled property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPinEnabled(Boolean value) {
        this.PinEnabled = value;
    }

    /**
     * Gets the value of the bankAccounts property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the bankAccounts property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBankAccounts().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GetCardInformationBankAccounts }
     * 
     * 
     */
    @JsonProperty("BankAccounts")
    public List<GetCardInformationBankAccounts> getBankAccounts() {
        if (BankAccounts == null) {
            BankAccounts = new ArrayList<GetCardInformationBankAccounts>();
        }
        return this.BankAccounts;
    }

    /**
     * Gets the value of the bankAccountsCountOverLimitFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("BankAccountsCountOverLimitFlag")
    public String getBankAccountsCountOverLimitFlag() {
        return BankAccountsCountOverLimitFlag;
    }

    /**
     * Sets the value of the bankAccountsCountOverLimitFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankAccountsCountOverLimitFlag(String value) {
        this.BankAccountsCountOverLimitFlag = value;
    }

    /**
     * Gets the value of the bankAccountsTotalCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    @JsonProperty("BankAccountsTotalCount")
    public Integer getBankAccountsTotalCount() {
        return BankAccountsTotalCount;
    }

    /**
     * Sets the value of the bankAccountsTotalCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setBankAccountsTotalCount(Integer value) {
        this.BankAccountsTotalCount = value;
    }

    /**
     * Gets the value of the cardPrg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("CardPrg")
    public String getCardPrg() {
        return CardPrg;
    }

    /**
     * Sets the value of the cardPrg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardPrg(String value) {
        this.CardPrg = value;
    }

    /**
     * Gets the value of the connectedAccounts property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the connectedAccounts property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConnectedAccounts().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GetCardInformationConnectedAccounts }
     * 
     * 
     */
    @JsonProperty("ConnectedAccounts")
    public List<GetCardInformationConnectedAccounts> getConnectedAccounts() {
        if (ConnectedAccounts == null) {
            ConnectedAccounts = new ArrayList<GetCardInformationConnectedAccounts>();
        }
        return this.ConnectedAccounts;
    }

    /**
     * Gets the value of the taxNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("TaxNumber")
    public String getTaxNumber() {
        return TaxNumber;
    }

    /**
     * Sets the value of the taxNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxNumber(String value) {
        this.TaxNumber = value;
    }

    /**
     * Gets the value of the occupationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("OccupationCode")
    public String getOccupationCode() {
        return OccupationCode;
    }

    /**
     * Sets the value of the occupationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOccupationCode(String value) {
        this.OccupationCode = value;
    }

    /**
     * Gets the value of the totalCardBlock property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    @JsonProperty("TotalCardBlock")
    public Boolean isTotalCardBlock() {
        return TotalCardBlock;
    }

    /**
     * Sets the value of the totalCardBlock property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setTotalCardBlock(Boolean value) {
        this.TotalCardBlock = value;
    }

    /**
     * Gets the value of the spvCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("SPVCode")
    public String getSPVCode() {
        return SPVCode;
    }

    /**
     * Sets the value of the spvCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSPVCode(String value) {
        this.SPVCode = value;
    }

    /**
     * Gets the value of the alertsInternationalPurchaseFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    @JsonProperty("AlertsInternationalPurchaseFlag")
    public Boolean isAlertsInternationalPurchaseFlag() {
        return AlertsInternationalPurchaseFlag;
    }

    /**
     * Sets the value of the alertsInternationalPurchaseFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAlertsInternationalPurchaseFlag(Boolean value) {
        this.AlertsInternationalPurchaseFlag = value;
    }

    /**
     * Gets the value of the onboardingFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    @JsonProperty("OnboardingFlag")
    public Boolean isOnboardingFlag() {
        return OnboardingFlag;
    }

    /**
     * Sets the value of the onboardingFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setOnboardingFlag(Boolean value) {
        this.OnboardingFlag = value;
    }

    /**
     * Gets the value of the remainingTopUpAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    @JsonProperty("RemainingTopUpAmount")
    public BigDecimal getRemainingTopUpAmount() {
        return RemainingTopUpAmount;
    }

    /**
     * Sets the value of the remainingTopUpAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setRemainingTopUpAmount(BigDecimal value) {
        this.RemainingTopUpAmount = value;
    }

    /**
     * Gets the value of the passportNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("PassportNumber")
    public String getPassportNumber() {
        return PassportNumber;
    }

    /**
     * Sets the value of the passportNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPassportNumber(String value) {
        this.PassportNumber = value;
    }

    /**
     * Gets the value of the account property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("Account")
    public String getAccount() {
        return Account;
    }

    /**
     * Sets the value of the account property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccount(String value) {
        this.Account = value;
    }

    /**
     * Gets the value of the applicationReferenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("ApplicationReferenceNumber")
    public String getApplicationReferenceNumber() {
        return ApplicationReferenceNumber;
    }

    /**
     * Sets the value of the applicationReferenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationReferenceNumber(String value) {
        this.ApplicationReferenceNumber = value;
    }

    /**
     * Gets the value of the bankAccount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("BankAccount")
    public String getBankAccount() {
        return BankAccount;
    }

    /**
     * Sets the value of the bankAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankAccount(String value) {
        this.BankAccount = value;
    }

    /**
     * Gets the value of the blackListCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("BlackListCode")
    public String getBlackListCode() {
        return BlackListCode;
    }

    /**
     * Sets the value of the blackListCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBlackListCode(String value) {
        this.BlackListCode = value;
    }

    /**
     * Gets the value of the cdiNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("CDINumber")
    public String getCDINumber() {
        return CDINumber;
    }

    /**
     * Sets the value of the cdiNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCDINumber(String value) {
        this.CDINumber = value;
    }

    /**
     * Gets the value of the creditLimit property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    @JsonProperty("CreditLimit")
    public BigDecimal getCreditLimit() {
        return CreditLimit;
    }

    /**
     * Sets the value of the creditLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCreditLimit(BigDecimal value) {
        this.CreditLimit = value;
    }

    /**
     * Gets the value of the currencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("CurrencyCode")
    public String getCurrencyCode() {
        return CurrencyCode;
    }

    /**
     * Sets the value of the currencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCode(String value) {
        this.CurrencyCode = value;
    }

    /**
     * Gets the value of the currencyDecimals property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("CurrencyDecimals")
    public String getCurrencyDecimals() {
        return CurrencyDecimals;
    }

    /**
     * Sets the value of the currencyDecimals property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyDecimals(String value) {
        this.CurrencyDecimals = value;
    }

    /**
     * Gets the value of the currencyLiteral property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("CurrencyLiteral")
    public String getCurrencyLiteral() {
        return CurrencyLiteral;
    }

    /**
     * Sets the value of the currencyLiteral property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyLiteral(String value) {
        this.CurrencyLiteral = value;
    }

    /**
     * Gets the value of the currentBalance property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    @JsonProperty("CurrentBalance")
    public BigDecimal getCurrentBalance() {
        return CurrentBalance;
    }

    /**
     * Sets the value of the currentBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCurrentBalance(BigDecimal value) {
        this.CurrentBalance = value;
    }

    /**
     * Gets the value of the cardActivationFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("CardActivationFlag")
    public String getCardActivationFlag() {
        return CardActivationFlag;
    }

    /**
     * Sets the value of the cardActivationFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardActivationFlag(String value) {
        this.CardActivationFlag = value;
    }

    /**
     * Gets the value of the pendingInstallmentsAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    @JsonProperty("PendingInstallmentsAmount")
    public BigDecimal getPendingInstallmentsAmount() {
        return PendingInstallmentsAmount;
    }

    /**
     * Sets the value of the pendingInstallmentsAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPendingInstallmentsAmount(BigDecimal value) {
        this.PendingInstallmentsAmount = value;
    }

    /**
     * Gets the value of the dateOfBirth property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    @JsonProperty("DateOfBirth")
    public XMLGregorianCalendar getDateOfBirth() {
        return DateOfBirth;
    }

    /**
     * Sets the value of the dateOfBirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateOfBirth(XMLGregorianCalendar value) {
        this.DateOfBirth = value;
    }

    /**
     * Gets the value of the expirationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("ExpirationDate")
    public String getExpirationDate() {
        return ExpirationDate;
    }

    /**
     * Sets the value of the expirationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpirationDate(String value) {
        this.ExpirationDate = value;
    }

    /**
     * Gets the value of the firstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("FirstName")
    public String getFirstName() {
        return FirstName;
    }

    /**
     * Sets the value of the firstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstName(String value) {
        this.FirstName = value;
    }

    /**
     * Gets the value of the idNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("IdNumber")
    public String getIdNumber() {
        return IdNumber;
    }

    /**
     * Sets the value of the idNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdNumber(String value) {
        this.IdNumber = value;
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("LastName")
    public String getLastName() {
        return LastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String value) {
        this.LastName = value;
    }

    /**
     * Gets the value of the lastPayAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    @JsonProperty("LastPayAmount")
    public BigDecimal getLastPayAmount() {
        return LastPayAmount;
    }

    /**
     * Sets the value of the lastPayAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setLastPayAmount(BigDecimal value) {
        this.LastPayAmount = value;
    }

    /**
     * Gets the value of the lastPayDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    @JsonProperty("LastPayDate")
    public XMLGregorianCalendar getLastPayDate() {
        return LastPayDate;
    }

    /**
     * Sets the value of the lastPayDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastPayDate(XMLGregorianCalendar value) {
        this.LastPayDate = value;
    }

    /**
     * Gets the value of the memberSince property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("MemberSince")
    public String getMemberSince() {
        return MemberSince;
    }

    /**
     * Sets the value of the memberSince property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberSince(String value) {
        this.MemberSince = value;
    }

    /**
     * Gets the value of the minimumPayAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    @JsonProperty("MinimumPayAmount")
    public BigDecimal getMinimumPayAmount() {
        return MinimumPayAmount;
    }

    /**
     * Sets the value of the minimumPayAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMinimumPayAmount(BigDecimal value) {
        this.MinimumPayAmount = value;
    }

    /**
     * Gets the value of the minimumPayDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    @JsonProperty("MinimumPayDate")
    public XMLGregorianCalendar getMinimumPayDate() {
        return MinimumPayDate;
    }

    /**
     * Sets the value of the minimumPayDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setMinimumPayDate(XMLGregorianCalendar value) {
        this.MinimumPayDate = value;
    }

    /**
     * Gets the value of the newAccount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("NewAccount")
    public String getNewAccount() {
        return NewAccount;
    }

    /**
     * Sets the value of the newAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewAccount(String value) {
        this.NewAccount = value;
    }

    /**
     * Gets the value of the openToBuy property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    @JsonProperty("OpenToBuy")
    public BigDecimal getOpenToBuy() {
        return OpenToBuy;
    }

    /**
     * Sets the value of the openToBuy property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOpenToBuy(BigDecimal value) {
        this.OpenToBuy = value;
    }

    /**
     * Gets the value of the openToBuyCash property.
     *
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *
     */
    @JsonProperty("OpenToBuyCash")
    public BigDecimal getOpenToBuyCash() {
        return OpenToBuyCash;
    }

    /**
     * Sets the value of the openToBuyCash property.
     *
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *
     */
    public void setOpenToBuyCash(BigDecimal value) {
        this.OpenToBuyCash = value;
    }

    /**
     * Gets the value of the deliquentDays property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("DeliquentDays")
    public String getDeliquentDays() {
        return DeliquentDays;
    }

    /**
     * Sets the value of the deliquentDays property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeliquentDays(String value) {
        this.DeliquentDays = value;
    }

    /**
     * Gets the value of the securitizationFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    @JsonProperty("SecuritizationFlag")
    public Boolean isSecuritizationFlag() {
        return SecuritizationFlag;
    }

    /**
     * Sets the value of the securitizationFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSecuritizationFlag(Boolean value) {
        this.SecuritizationFlag = value;
    }


    /**
     * Gets the value of the currentMemberNumber property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    @JsonProperty("CurrentMemberNumber")
    public String getCurrentMemberNumber() {
        return CurrentMemberNumber;
    }

    /**
     * Sets the value of the currentMemberNumber property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setCurrentMemberNumber(String value) {
        this.CurrentMemberNumber = value;
    }

    /**
     * Gets the value of the activeMemberNumber property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    @JsonProperty("ActiveMemberNumber")
    public String getActiveMemberNumber() {
        return ActiveMemberNumber;
    }

    /**
     * Sets the value of the activeMemberNumber property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setActiveMemberNumber(String value) {
        this.ActiveMemberNumber = value;
    }

    /**
     * Gets the value of the lastActiveMemberExpDate property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    @JsonProperty("LastActiveMemberExpDate")
    public String getLastActiveMemberExpDate() {
        return LastActiveMemberExpDate;
    }

    /**
     * Sets the value of the lastActiveMemberExpDate property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setLastActiveMemberExpDate(String value) {
        this.LastActiveMemberExpDate = value;
    }

}
