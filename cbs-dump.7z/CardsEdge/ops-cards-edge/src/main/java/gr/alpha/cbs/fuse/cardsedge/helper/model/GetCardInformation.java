package gr.alpha.cbs.fuse.cardsedge.helper.model;

import jakarta.xml.bind.annotation.*;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GetCardInformationPayload" type="{http://cards-edge.fuse.cbs.alpha.gr/cards-edge/}GetCardInformationPayload"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getCardInformationPayload"
})
@XmlRootElement(name = "GetCardInformation")
public class GetCardInformation {

    @XmlElement(name = "GetCardInformationPayload", required = true)
    protected GetCardInformationPayload getCardInformationPayload;

    /**
     * Gets the value of the getCardInformationPayload property.
     * 
     * @return
     *     possible object is
     *     {@link GetCardInformationPayload }
     *     
     */
    public GetCardInformationPayload getGetCardInformationPayload() {
        return getCardInformationPayload;
    }

    /**
     * Sets the value of the getCardInformationPayload property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetCardInformationPayload }
     *     
     */
    public void setGetCardInformationPayload(GetCardInformationPayload value) {
        this.getCardInformationPayload = value;
    }

}
