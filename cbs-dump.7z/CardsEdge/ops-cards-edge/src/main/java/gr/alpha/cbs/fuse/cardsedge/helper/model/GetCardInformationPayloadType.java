
package gr.alpha.cbs.fuse.cardsedge.helper.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for GetCardInformationPayloadType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetCardInformationPayloadType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AccountNumbers" type="{http://cards-edge.fuse.cbs.alpha.gr/cards-edge/}GetCardInformationAccountNumbersType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetCardInformationPayloadType", propOrder = {
    "AccountNumbers"
})
public class GetCardInformationPayloadType {

    @XmlElement(name = "AccountNumbers")
    protected List<GetCardInformationAccountNumbersType> AccountNumbers;

    /**
     * Gets the value of the accountNumbers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the accountNumbers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAccountNumbers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GetCardInformationAccountNumbersType }
     * 
     * 
     */
    @JsonProperty("AccountNumbers")
    public List<GetCardInformationAccountNumbersType> getAccountNumbers() {
        if (AccountNumbers == null) {
            AccountNumbers = new ArrayList<GetCardInformationAccountNumbersType>();
        }
        return this.AccountNumbers;
    }

}
