package gr.alpha.cbs.fuse.cardsedge;

import io.quarkus.runtime.StartupEvent;
import io.quarkus.security.Authenticated;
import io.vertx.core.http.HttpServerRequest;
import jakarta.enterprise.event.Observes;
import io.smallrye.faulttolerance.api.*;
import org.eclipse.microprofile.faulttolerance.*;
import org.jboss.resteasy.reactive.RestResponse;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.UriInfo;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import java.time.temporal.*;

import jakarta.annotation.PostConstruct;

import gr.alpha.cbs.fuse.cardsedge.generated.*;

@Path("/rest-cards-edge-inquiry")
public class CardsEdgeInquiryRestAPI extends gr.alpha.cbs.fuse.service.AbstractCamelRouteDrivingRESTAPI {

	public void init(@Observes StartupEvent event) {
		restapiHelper = new gr.alpha.cbs.fuse.cardsedge.ws.CardsEdgeInquiryRESTImpl();
		
		super.init();
	}

	@Path("GetCardInformation")
	@POST
	@RateLimit()
	public RestResponse<String> doGetCardInformation(
			@HeaderParam("requestId") String requestId,
			@HeaderParam("userId") String userId,
			@HeaderParam("language") String language,
			@HeaderParam("channelTypeCode") String channelTypeCode,
			@Context UriInfo uriInfo,
			@Context HttpServerRequest request,
			GetCardInformation input) {
		return performOperation(requestId, userId, language, channelTypeCode, uriInfo, request, input);
	}

	@Path("GetCardAuthorizationsAndTransactions")
	@POST
	@RateLimit()
	public RestResponse<String> doGetCardAuthorizationsAndTransactions(
			@HeaderParam("requestId") String requestId,
			@HeaderParam("userId") String userId,
			@HeaderParam("language") String language,
			@HeaderParam("channelTypeCode") String channelTypeCode,
			@Context UriInfo uriInfo,
			@Context HttpServerRequest request,
			GetCardAuthorizationsAndTransactions input) {
		return performOperation(requestId, userId, language, channelTypeCode, uriInfo, request, input);
	}

	@Path("GetCardSum")
	@POST
	@RateLimit()
	public RestResponse<String> doGetCardSum(
			@HeaderParam("requestId") String requestId,
			@HeaderParam("userId") String userId,
			@HeaderParam("language") String language,
			@HeaderParam("channelTypeCode") String channelTypeCode,
			@Context UriInfo uriInfo,
			@Context HttpServerRequest request,
			GetCardSum input) {
		return performOperation(requestId, userId, language, channelTypeCode, uriInfo, request, input);
	}

}
