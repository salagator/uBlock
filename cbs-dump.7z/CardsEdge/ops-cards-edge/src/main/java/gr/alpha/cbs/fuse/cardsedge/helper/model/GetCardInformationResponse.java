
package gr.alpha.cbs.fuse.cardsedge.helper.model;

import jakarta.xml.bind.annotation.*;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GetCardInformationResponsePayload" type="{http://cards-edge.fuse.cbs.alpha.gr/cards-edge/}GetCardInformationResponsePayload"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getCardInformationResponsePayload"
})
@XmlRootElement(name = "GetCardInformationResponse")
public class GetCardInformationResponse {

    @XmlElement(name = "GetCardInformationResponsePayload", required = true)
    protected GetCardInformationResponsePayload getCardInformationResponsePayload;

    /**
     * Gets the value of the getCardInformationResponsePayload property.
     * 
     * @return
     *     possible object is
     *     {@link GetCardInformationResponsePayload }
     *     
     */
    public GetCardInformationResponsePayload getGetCardInformationResponsePayload() {
        return getCardInformationResponsePayload;
    }

    /**
     * Sets the value of the getCardInformationResponsePayload property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetCardInformationResponsePayload }
     *     
     */
    public void setGetCardInformationResponsePayload(GetCardInformationResponsePayload value) {
        this.getCardInformationResponsePayload = value;
    }

}
