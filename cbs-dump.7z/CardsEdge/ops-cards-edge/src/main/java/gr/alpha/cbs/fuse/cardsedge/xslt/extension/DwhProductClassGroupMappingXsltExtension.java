package gr.alpha.cbs.fuse.cardsedge.xslt.extension;

import gr.alpha.cbs.fuse.cardsedge.helper.DwhProductClassGroupMapping;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;

@Named("functionDwhProductClassGroupMappingXsltExtension")
@ApplicationScoped
@RegisterForReflection
public class DwhProductClassGroupMappingXsltExtension extends ExtensionFunctionDefinition {
    private static final long serialVersionUID = 2060328814415747910L;

    @Inject
    DwhProductClassGroupMapping dwhProductClassGroupMapping;

    @Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("gpcg", "http://fuse.cbs.alpha.gr/GetProductClassGroup/", "GetProductClassGroup");
    }

    @Override
    public SequenceType[] getArgumentTypes() {
        return new SequenceType[]{SequenceType.SINGLE_STRING};
    }

    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
        return SequenceType.SINGLE_STRING;
    }

    @Override
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {
            private static final long serialVersionUID = -2058456742203368019L;

            @Override
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
                try {
                    String productCode = null;
                    if (arguments[0] instanceof LazySequence) {
                        productCode = ((LazySequence) arguments[0]).head().getStringValue();
                    } else if (arguments[0] instanceof StringValue) {
                        productCode = ((StringValue) arguments[0]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type for productCode parameter: " + arguments[0].getClass().getCanonicalName());
                    }
                    return StringValue.makeStringValue(dwhProductClassGroupMapping.getClassGroup(productCode));

                } catch (Exception e) {
                    throw new XPathException("Unable to retrieve Class Groups: " + e.getMessage(), e);
                }
            }
        };
    }
}
