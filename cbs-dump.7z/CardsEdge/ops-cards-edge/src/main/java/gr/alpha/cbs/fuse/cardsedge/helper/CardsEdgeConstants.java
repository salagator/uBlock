package gr.alpha.cbs.fuse.cardsedge.helper;

import org.apache.commons.lang3.tuple.Pair;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class CardsEdgeConstants {
    public static final int CARD_NUMBER_MIN_DIGITS = 14;
    public static final int CARD_NUMBER_MAX_DIGITS = 19;
    public static final String PWC_SYSTEM_ERROR_CODE = "9999";
    protected static final Map<String, String> SYSTEM_ERROR_OPERATION_ORIGINATOR_MAPPER;
    protected static final Map<String, Pair<String, Integer>> OPERATIONS_ERROR_CODES_MAPPER;

    static {
        Map<String, String> systemErrorOperationOriginatorMapper = new HashMap<>();
        systemErrorOperationOriginatorMapper.put("CardActivation", "CSR");
        systemErrorOperationOriginatorMapper.put("CardReIssueUpdate", "CSR");
        systemErrorOperationOriginatorMapper.put("CardDeactivation", "CSR");
        systemErrorOperationOriginatorMapper.put("CardCashLimit", "CSR");
        systemErrorOperationOriginatorMapper.put("CardSpendingLimitUpdate", "CSR");
        systemErrorOperationOriginatorMapper.put("CardDeliveryAddressUpdate", "CSR");
        systemErrorOperationOriginatorMapper.put("CardPinDelivery", "CSR");
        systemErrorOperationOriginatorMapper.put("GetCardData", "CSRGetCardData");
        systemErrorOperationOriginatorMapper.put("CardBankAccountUpdate", "CSR");
        systemErrorOperationOriginatorMapper.put("CardPinReissue", "CSR");
        SYSTEM_ERROR_OPERATION_ORIGINATOR_MAPPER = Collections.unmodifiableMap(systemErrorOperationOriginatorMapper);

        Map<String, Pair<String, Integer>> operationsErrorCodeMap = new HashMap<>();
        operationsErrorCodeMap.put("CardActivation", Pair.of("FDH(CSRCardActivation)", 115));
        operationsErrorCodeMap.put("CardReissue", Pair.of("FDH(CSRCardReissue)", 988));
        operationsErrorCodeMap.put("CardDeactivation", Pair.of("FDH(CSRCardDeactivation)", 380));
        operationsErrorCodeMap.put("CardCashLimit", Pair.of("FDH(CSRCardCashLimit)", 481));
        operationsErrorCodeMap.put("CardSpendingLimitUpdate", Pair.of("FDH(CSRCardSpendingLimitUpdate)", 1080));
        operationsErrorCodeMap.put("CardDeliveryAddressUpdate", Pair.of("FDH(CSRCardDeliveryAddressUpdate)", 680));
        operationsErrorCodeMap.put("CardPinDelivery", Pair.of("FDH(CSRCardPinDelivery)", 288));
        operationsErrorCodeMap.put("GetCardData", Pair.of("FDH(CSRGetAccountData)", 140));
        operationsErrorCodeMap.put("CardBankAccountUpdate", Pair.of("FDH(CSRCardBankAccountUpdate)", 1180));
        operationsErrorCodeMap.put("CardPinReissue", Pair.of("FDH(CSRCardPinReissue)", 280));
        OPERATIONS_ERROR_CODES_MAPPER = Collections.unmodifiableMap(operationsErrorCodeMap);
    }

}
