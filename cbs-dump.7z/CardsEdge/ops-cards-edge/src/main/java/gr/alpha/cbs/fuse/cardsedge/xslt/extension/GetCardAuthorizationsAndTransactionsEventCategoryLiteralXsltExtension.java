package gr.alpha.cbs.fuse.cardsedge.xslt.extension;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.common.ifaces.RefDataTranslator;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;

@Named("functionGetEventCategoryLiteral")
@ApplicationScoped
@RegisterForReflection
public class GetCardAuthorizationsAndTransactionsEventCategoryLiteralXsltExtension extends ExtensionFunctionDefinition {
    private static final long serialVersionUID = 2060328814415747123L;

    @Inject
    RefDataTranslator refDataTranslator;

    @Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("gecl", "http://fuse.cbs.alpha.gr/GetEventCategoryLiteral/", "GetEventCategoryLiteral");
    }

    @Override
    public SequenceType[] getArgumentTypes() {
        return new SequenceType[]{SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING};
    }

    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
        return SequenceType.SINGLE_STRING;
    }

    @Override
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {
            private static final long serialVersionUID = -2058456742203368019L;

            @Override
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
                try {
                    String eventCategoryCode = null;
                    if (arguments[0] instanceof LazySequence) {
                        eventCategoryCode = ((LazySequence) arguments[0]).head().getStringValue();
                    } else if (arguments[0] instanceof StringValue) {
                        eventCategoryCode = ((StringValue) arguments[0]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type for eventCategoryCode parameter: " + arguments[0].getClass().getCanonicalName());
                    }

                    String language = null;
                    if (arguments[1] instanceof LazySequence) {
                        language = ((LazySequence) arguments[1]).head().getStringValue();
                    } else if (arguments[1] instanceof StringValue) {
                        language = ((StringValue) arguments[1]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type for language parameter: " + arguments[1].getClass().getCanonicalName());
                    }
                    String eventCategoryLiteral = refDataTranslator.translateData(CBSConstants.REF_DATA_SYSTEM_UI, language, "CardTransactionEventCategoryCodes", eventCategoryCode);
                    return StringValue.makeStringValue(eventCategoryLiteral);

                } catch (Exception e) {
                    throw new XPathException("Unable to retrieve Event Category Literal attribute Value", e);
                }
            }
        };
    }
}
