package gr.alpha.cbs.fuse.cardsedge.powercard;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

public class CustomXMLGregCalendarDeserializer extends StdDeserializer<XMLGregorianCalendar> {
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
    private final SimpleDateFormat datetimeFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

    public CustomXMLGregCalendarDeserializer() {
        super(XMLGregorianCalendar.class);
    }

    @Override
    public XMLGregorianCalendar deserialize(JsonParser p, DeserializationContext deserializationContext) throws IOException {
        String dateString = p.getValueAsString();
        Date date;
        try {
            // powercard returns 2 formats
            // yyyyMMdd for date
            // yyyy-MM-dd'T'HH:mm:ss for datetime
            if (dateString.matches("\\d{8}")) {
                date = dateFormat.parse(dateString);
            } else {
                date = datetimeFormat.parse(dateString);
            }
            GregorianCalendar gregorianCalendar = new GregorianCalendar();
            gregorianCalendar.setTime(date);
            XMLGregorianCalendar xmlGregorianCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
            xmlGregorianCalendar.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
            return xmlGregorianCalendar;
        } catch (ParseException | DatatypeConfigurationException e) {
            throw new IOException("Failed to parse date or create XMLGregorianCalendar: " + dateString, e);
        }
    }
}
