
package gr.alpha.cbs.fuse.cardsedge.helper.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for CardEntriesResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CardEntriesResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CardEntries" type="{http://fuse.ml.cbs.alpha.gr/cards-integration/}CardEntriesType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="RecordCount" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="HasMore" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="ValidationMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="WarningMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CardEntriesResponse", propOrder = {
    "cardEntries",
    "recordCount",
    "hasMore",
    "validationMessage",
    "warningMessage"
})

@XmlRootElement(name = "CardEntriesResponse")
public class CardEntriesResponse {

    @XmlElement(name = "CardEntries")
    protected List<CardEntriesType> cardEntries;
    @XmlElement(name = "RecordCount")
    protected int recordCount;
    @XmlElement(name = "HasMore")
    protected boolean hasMore;
    @XmlElement(name = "ValidationMessage", required = true)
    protected String validationMessage;
    @XmlElement(name = "WarningMessage", required = true)
    protected String warningMessage;

    /**
     * Gets the value of the cardEntries property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cardEntries property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCardEntries().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CardEntriesType }
     * 
     * 
     */
    @JsonProperty("cardEntries")
    public List<CardEntriesType> getCardEntries() {
        if (cardEntries == null) {
            cardEntries = new ArrayList<CardEntriesType>();
        }
        return this.cardEntries;
    }

    /**
     * Gets the value of the recordCount property.
     * 
     */
    @JsonProperty("recordCount")
    public int getRecordCount() {
        return recordCount;
    }

    /**
     * Sets the value of the recordCount property.
     * 
     */
    public void setRecordCount(int value) {
        this.recordCount = value;
    }

    /**
     * Gets the value of the hasMore property.
     * 
     */
    @JsonProperty("hasMore")
    public boolean isHasMore() {
        return hasMore;
    }

    /**
     * Sets the value of the hasMore property.
     * 
     */
    public void setHasMore(boolean value) {
        this.hasMore = value;
    }

    /**
     * Gets the value of the validationMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("validationMessage")
    public String getValidationMessage() {
        return validationMessage;
    }

    /**
     * Sets the value of the validationMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidationMessage(String value) {
        this.validationMessage = value;
    }

    /**
     * Gets the value of the warningMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("warningMessage")
    public String getWarningMessage() {
        return warningMessage;
    }

    /**
     * Sets the value of the warningMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWarningMessage(String value) {
        this.warningMessage = value;
    }

}
