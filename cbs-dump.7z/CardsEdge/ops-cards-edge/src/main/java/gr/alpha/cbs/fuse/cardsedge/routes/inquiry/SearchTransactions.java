package gr.alpha.cbs.fuse.cardsedge.routes.inquiry;

import org.apache.camel.builder.RouteBuilder;

public class SearchTransactions extends RouteBuilder {
    @Override
    public void configure() throws Exception{
        from("direct:do-transaction-SearchTransactionsPayload")
        .routeId("direct:do-transaction-SearchTransactionsPayload")
        .streamCaching()
            .log("Powercard XML Request body: ${body}")
            .setProperty("tempBody", simple("${body}"))
            .setProperty("cbs.camel.powercard.endpoint", simple("{{cbs.camel.powercard.endpoint}}"))
            .setProperty("cbs.camel.powercard.operation", constant("SearchTransactions"))
            .setProperty("cbs.camel.powercard.version", constant("/V2"))
            .setProperty("cbs.camel.powercard.timeout", simple("?{{cbs.powercard.SearchTransactions.timeout}}"))
            .setProperty("cbs.powercard.native.http.method", constant("POST"))
            .setProperty("cbs.powercard.request.class", simple("gr.alpha.cbs.fuse.cardsedge.generated.SearchTransactionsRequestItemType"))
            .bean("powerCardHelper", "prepareNativeRequestBody(*)")
            .log("Powercard native JSON Request body: ${body}")
            .to("direct:powercard-http-call")
            .setProperty("cbs.powercard.response.class", simple("gr.alpha.cbs.fuse.cardsedge.generated.SearchTransactionsResponse"))
            .setProperty("cbs.powercard.payload.class", simple("gr.alpha.cbs.fuse.cardsedge.generated.SearchTransactionsResponsePayload"))
            .setProperty("cbs.powercard.item.class", simple("gr.alpha.cbs.fuse.cardsedge.generated.SearchTransactionsResponseItem"))
            .bean("powerCardHelper", "prepareResponseBody(*, 'inquiry')")
            .log("CBS powerCard ${exchangeProperty.cbs.camel.powercard.operation} xml response: ${body}")
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/removeEmptyElements.xsl")
        .end();
    }
}
