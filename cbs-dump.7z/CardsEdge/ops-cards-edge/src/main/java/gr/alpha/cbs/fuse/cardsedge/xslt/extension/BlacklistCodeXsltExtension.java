package gr.alpha.cbs.fuse.cardsedge.xslt.extension;

import gr.alpha.cbs.fuse.ifaces.MasterDataInterface;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.lib.ExtensionFunctionCall;
import net.sf.saxon.lib.ExtensionFunctionDefinition;
import net.sf.saxon.om.LazySequence;
import net.sf.saxon.om.Sequence;
import net.sf.saxon.om.StructuredQName;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.SequenceType;
import net.sf.saxon.value.StringValue;
import java.util.Map;

@Named("functionBlacklistCodeXsltExtension")
@ApplicationScoped
@RegisterForReflection
public class BlacklistCodeXsltExtension extends ExtensionFunctionDefinition {
    private static final long serialVersionUID = 2060328814415747911L;

    @Inject
    MasterDataInterface masterDataInterface;

    @Override
    public StructuredQName getFunctionQName() {
        return new StructuredQName("blc", "http://fuse.cbs.alpha.gr/GetBlackListCode/", "GetBlackListCode");
    }

    @Override
    public SequenceType[] getArgumentTypes() {
        return new SequenceType[]{SequenceType.SINGLE_STRING, SequenceType.SINGLE_STRING};
    }

    @Override
    public SequenceType getResultType(SequenceType[] suppliedArgumentTypes) {
        return SequenceType.SINGLE_STRING;
    }

    @Override
    public ExtensionFunctionCall makeCallExpression() {
        return new ExtensionFunctionCall() {
            private static final long serialVersionUID = -2058456742203368019L;

            @Override
            public Sequence call(XPathContext context, Sequence[] arguments) throws XPathException {
                try {
                    String statusCode = null;
                    String statusReason = null;
                    if (arguments[0] instanceof LazySequence) {
                        statusCode = arguments[0].head().getStringValue();
                    } else if (arguments[0] instanceof StringValue) {
                        statusCode = ((StringValue) arguments[0]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type for attributeName parameter: " + arguments[0].getClass().getCanonicalName());
                    }

                    if (arguments[1] instanceof LazySequence) {
                        statusReason = arguments[1].head().getStringValue();
                    } else if (arguments[1] instanceof StringValue) {
                        statusReason = ((StringValue) arguments[1]).getStringValue();
                    } else {
                        throw new Exception("Unrecognized argument type for attributeName parameter: " + arguments[1].getClass().getCanonicalName());
                    }
                    String pwcStatus = statusCode + "," + statusReason;
                    Map<String, String> pwcStatusToBlackListCodeMap = masterDataInterface.getMasterDetailsByItemNameLists("PWC_BLACKLISTCODE_MAPPING", pwcStatus);
                    return StringValue.makeStringValue(pwcStatusToBlackListCodeMap.get("PowercardBlacklistCodes"));

                } catch (Exception e) {
                    throw new XPathException("Unable to map BlackListCode", e);
                }
            }
        };
    }
}
