package gr.alpha.cbs.fuse.cardsedge.routes.inquiry;

import org.apache.camel.builder.RouteBuilder;

public class GetCardDetails extends RouteBuilder {
    @Override
    public void configure() throws Exception{
        from("direct:do-transaction-GetCardDetailsPayload")
        .routeId("direct:do-transaction-GetCardDetailsPayload")
        .streamCaching()
            .bean("powercardCurrencyExponentMapping", "getCurrencyExponent(*)")
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/GetCardDetails/prepGetCardDetailsNativePowercard.xsl")
            .log("Powercard XML Request body: ${body}")
            .setProperty("tempBody", simple("${body}"))
            .setProperty("cbs.camel.powercard.endpoint", simple("{{cbs.camel.powercard.endpoint}}"))
            .setProperty("cbs.camel.powercard.operation", constant("GetCardDetails"))
            .setProperty("cbs.camel.powercard.version", constant("/V2"))
            .setProperty("cbs.camel.powercard.timeout", simple("?{{cbs.powercard.GetCardDetails.timeout}}"))
            .setProperty("cbs.powercard.native.http.method", constant("POST"))
            .setProperty("cbs.powercard.request.class", simple("gr.alpha.cbs.fuse.cardsedge.generated.GetCardDetailsNativeRequestItemType"))
            .bean("powerCardHelper", "prepareNativeRequestBody(*)")
            .log("Powercard native JSON Request body: ${body}")
            .to("direct:powercard-http-call")
            .setProperty("cbs.powercard.response.class", simple("gr.alpha.cbs.fuse.cardsedge.generated.GetCardDetailsResponse"))
            .setProperty("cbs.powercard.payload.class", simple("gr.alpha.cbs.fuse.cardsedge.generated.GetCardDetailsResponsePayload"))
            .setProperty("cbs.powercard.item.class", simple("gr.alpha.cbs.fuse.cardsedge.generated.GetCardDetailsResponseItem"))
            .bean("powerCardHelper", "prepareResponseBody(*, 'inquiry')")
            .log("CBS powerCard ${exchangeProperty.cbs.camel.powercard.operation} xml response: ${body}")
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/GetCardDetails/prepGetCardDetailsResponse.xsl")
            .to("xslt-saxon:gr/alpha/cbs/fuse/xslt/removeEmptyElements.xsl")
        .end();
    }
}
