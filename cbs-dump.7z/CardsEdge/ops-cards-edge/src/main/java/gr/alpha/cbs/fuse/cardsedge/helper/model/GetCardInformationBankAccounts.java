package gr.alpha.cbs.fuse.cardsedge.helper.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetCardInformationBankAccounts complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetCardInformationBankAccounts">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BankAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BankAccountOwnerCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BankAccountPermittedTransactionsCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BankAccountTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetCardInformationBankAccounts", propOrder = {
    "BankAccountNumber",
    "BankAccountOwnerCode",
    "BankAccountPermittedTransactionsCode",
    "BankAccountTypeCode"
})
public class GetCardInformationBankAccounts {

    @XmlElement(name = "BankAccountNumber")
    protected String BankAccountNumber;
    @XmlElement(name = "BankAccountOwnerCode")
    protected String BankAccountOwnerCode;
    @XmlElement(name = "BankAccountPermittedTransactionsCode")
    protected String BankAccountPermittedTransactionsCode;
    @XmlElement(name = "BankAccountTypeCode")
    protected String BankAccountTypeCode;

    /**
     * Gets the value of the bankAccountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("BankAccountNumber")
    public String getBankAccountNumber() {
        return BankAccountNumber;
    }

    /**
     * Sets the value of the bankAccountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankAccountNumber(String value) {
        this.BankAccountNumber = value;
    }

    /**
     * Gets the value of the bankAccountOwnerCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("BankAccountOwnerCode")
    public String getBankAccountOwnerCode() {
        return BankAccountOwnerCode;
    }

    /**
     * Sets the value of the bankAccountOwnerCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankAccountOwnerCode(String value) {
        this.BankAccountOwnerCode = value;
    }

    /**
     * Gets the value of the bankAccountPermittedTransactionsCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("BankAccountPermittedTransactionsCode")
    public String getBankAccountPermittedTransactionsCode() {
        return BankAccountPermittedTransactionsCode;
    }

    /**
     * Sets the value of the bankAccountPermittedTransactionsCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankAccountPermittedTransactionsCode(String value) {
        this.BankAccountPermittedTransactionsCode = value;
    }

    /**
     * Gets the value of the bankAccountTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @JsonProperty("BankAccountTypeCode")
    public String getBankAccountTypeCode() {
        return BankAccountTypeCode;
    }

    /**
     * Sets the value of the bankAccountTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankAccountTypeCode(String value) {
        this.BankAccountTypeCode = value;
    }

}
