
package gr.alpha.cbs.fuse.cardsedge.helper.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for GetCardInformationResponseItem complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetCardInformationResponseItem">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Payload" type="{http://cards-edge.fuse.cbs.alpha.gr/cards-edge/}GetCardInformationPayloadType" minOccurs="0"/>
 *         &lt;element name="IsSuccess" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Errors" type="{http://cards-edge.fuse.cbs.alpha.gr/cards-edge/}GetCardInformationErrors" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ServiceBusHeader" type="{http://cards-edge.fuse.cbs.alpha.gr/cards-edge/}GetCardInformationServiceBusHeader" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetCardInformationResponseItem", propOrder = {
    "Payload",
    "IsSuccess",
    "Errors",
    "ServiceBusHeader"
})
public class GetCardInformationResponseItem {

    @XmlElement(name = "Payload")
    protected GetCardInformationPayloadType Payload;
    @XmlElement(name = "IsSuccess")
    protected Boolean IsSuccess;
    @XmlElement(name = "Errors")
    protected List<GetCardInformationErrors> Errors;
    @XmlElement(name = "ServiceBusHeader")
    protected GetCardInformationServiceBusHeader ServiceBusHeader;

    /**
     * Gets the value of the payload property.
     * 
     * @return
     *     possible object is
     *     {@link GetCardInformationPayloadType }
     *     
     */
    @JsonProperty("Payload")
    public GetCardInformationPayloadType getPayload() {
        return Payload;
    }

    /**
     * Sets the value of the payload property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetCardInformationPayloadType }
     *     
     */
    public void setPayload(GetCardInformationPayloadType value) {
        this.Payload = value;
    }

    /**
     * Gets the value of the isSuccess property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    @JsonProperty("IsSuccess")
    public Boolean isIsSuccess() {
        return IsSuccess;
    }

    /**
     * Sets the value of the isSuccess property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsSuccess(Boolean value) {
        this.IsSuccess = value;
    }

    /**
     * Gets the value of the errors property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the errors property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getErrors().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GetCardInformationErrors }
     * 
     * 
     */
    @JsonProperty("Errors")
    public List<GetCardInformationErrors> getErrors() {
        if (Errors == null) {
            Errors = new ArrayList<GetCardInformationErrors>();
        }
        return this.Errors;
    }

    /**
     * Gets the value of the serviceBusHeader property.
     * 
     * @return
     *     possible object is
     *     {@link GetCardInformationServiceBusHeader }
     *     
     */
    @JsonProperty("ServiceBusHeader")
    public GetCardInformationServiceBusHeader getServiceBusHeader() {
        return ServiceBusHeader;
    }

    /**
     * Sets the value of the serviceBusHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetCardInformationServiceBusHeader }
     *     
     */
    public void setServiceBusHeader(GetCardInformationServiceBusHeader value) {
        this.ServiceBusHeader = value;
    }

}
