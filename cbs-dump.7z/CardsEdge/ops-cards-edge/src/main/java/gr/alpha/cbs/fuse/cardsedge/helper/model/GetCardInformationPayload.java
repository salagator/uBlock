
package gr.alpha.cbs.fuse.cardsedge.helper.model;

import gr.alpha.cbs.fuse.cardsedge.generated.EnvParamsType;
import gr.alpha.cbs.fuse.cardsedge.generated.LoggingInfoType;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GetCardInformationPayload complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GetCardInformationPayload">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GetCardInformationRequestItem" type="{http://cards-edge.fuse.cbs.alpha.gr/cards-edge/}GetCardInformationRequestItemType"/>
 *         &lt;element ref="{http://cards-edge.fuse.cbs.alpha.gr/cards-edge/}LoggingInfo"/>
 *         &lt;element ref="{http://cards-edge.fuse.cbs.alpha.gr/cards-edge/}EnvParams"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetCardInformationPayload", propOrder = {
    "getCardInformationRequestItem",
    "loggingInfo",
    "envParams"
})
public class GetCardInformationPayload {

    @XmlElement(name = "GetCardInformationRequestItem", required = true)
    protected GetCardInformationRequestItemType getCardInformationRequestItem;
    @XmlElement(name = "LoggingInfo", required = true)
    protected LoggingInfoType loggingInfo;
    @XmlElement(name = "EnvParams", required = true)
    protected EnvParamsType envParams;

    /**
     * Gets the value of the getCardInformationRequestItem property.
     * 
     * @return
     *     possible object is
     *     {@link GetCardInformationRequestItemType }
     *     
     */
    public GetCardInformationRequestItemType getGetCardInformationRequestItem() {
        return getCardInformationRequestItem;
    }

    /**
     * Sets the value of the getCardInformationRequestItem property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetCardInformationRequestItemType }
     *     
     */
    public void setGetCardInformationRequestItem(GetCardInformationRequestItemType value) {
        this.getCardInformationRequestItem = value;
    }

    /**
     * Gets the value of the loggingInfo property.
     * 
     * @return
     *     possible object is
     *     {@link LoggingInfoType }
     *     
     */
    public LoggingInfoType getLoggingInfo() {
        return loggingInfo;
    }

    /**
     * Sets the value of the loggingInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link LoggingInfoType }
     *     
     */
    public void setLoggingInfo(LoggingInfoType value) {
        this.loggingInfo = value;
    }

    /**
     * Gets the value of the envParams property.
     * 
     * @return
     *     possible object is
     *     {@link EnvParamsType }
     *     
     */
    public EnvParamsType getEnvParams() {
        return envParams;
    }

    /**
     * Sets the value of the envParams property.
     * 
     * @param value
     *     allowed object is
     *     {@link EnvParamsType }
     *     
     */
    public void setEnvParams(EnvParamsType value) {
        this.envParams = value;
    }

}
