package gr.alpha.cbs.fuse.cardsedge.helper;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.ifaces.MasterDataInterface;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.tuple.Pair;
import org.jboss.logging.Logger;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Named("cardsEdgeCommonFunctions")
@ApplicationScoped
@RegisterForReflection
public class CardsEdgeCommonFunctions {
    private static final Logger LOGGER = Logger.getLogger(CardsEdgeCommonFunctions.class);

    @Inject
    MasterDataInterface masterStudio;

    public String getCardSystemFromBin(Exchange ex) throws Exception {
        String cardNumber = ex.getProperty("CardNumber", String.class);
        String targetSystem = "";

        if (cardNumber.length() >= CardsEdgeConstants.CARD_NUMBER_MIN_DIGITS && cardNumber.length() <= CardsEdgeConstants.CARD_NUMBER_MAX_DIGITS) {
            HashMap<String, HashMap<String, String>> map = masterStudio.getMasterDetailsLists("CardBinRanges");
            long cardBIN = Long.parseLong(cardNumber.substring(0, 8));

            for (Map.Entry<String, HashMap<String, String>> entry : map.entrySet()) {
                HashMap<String, String> innerMap = entry.getValue();
                long binFrom = Long.parseLong(innerMap.getOrDefault("CardNumFrom", "-1"));
                long binTo = Long.parseLong(innerMap.getOrDefault("CardNumTo", "-1"));
                if ((cardBIN >= binFrom) && (cardBIN <= binTo)) {
                    targetSystem = entry.getValue().get("TargetSystem");
                    break;
                }
            }
            if(targetSystem.equals("")) {
                LOGGER.info("BIN not found for card number: " + cardNumber);
                return "Legacy";
            }else{
                LOGGER.info("BIN for card number: " + cardNumber + " is " + targetSystem);
                return targetSystem;
            }
        } else {
            ErrorUtils.throwCBSException(null, ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
                    CardsEdgeCommonFunctions.class.getCanonicalName(), "600558",
                    ErrorTypeModel.SEVERITY_SEVERE, "Invalid Card Number: " + cardNumber, "", "");
        }
        return targetSystem;
    }

    public String getPwcMigrationDateFromBin(String cardNumber) throws Exception {
        String pwcMigrationDate = null;
        if (cardNumber.length() >= CardsEdgeConstants.CARD_NUMBER_MIN_DIGITS && cardNumber.length() <= CardsEdgeConstants.CARD_NUMBER_MAX_DIGITS) {
            HashMap<String, HashMap<String, String>> map = masterStudio.getMasterDetailsLists("CardBinRanges");
            long cardBIN = Long.parseLong(cardNumber.substring(0, 8));

            String targetSystem = "";
            for (Map.Entry<String, HashMap<String, String>> entry : map.entrySet()) {
                HashMap<String, String> innerMap = entry.getValue();
                long binFrom = Long.parseLong(innerMap.getOrDefault("CardNumFrom", "-1"));
                long binTo = Long.parseLong(innerMap.getOrDefault("CardNumTo", "-1"));
                if ((cardBIN >= binFrom) && (cardBIN <= binTo)) {
                    pwcMigrationDate = entry.getValue().get("PWC_MigrationDate");
                    break;
                }
            }
        }
        else {
            ErrorUtils.throwCBSException(null, ErrorTypeModel.ERROR_TYPE_FUNCTIONAL, ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
                    CardsEdgeCommonFunctions.class.getCanonicalName(), "600558",
                    ErrorTypeModel.SEVERITY_SEVERE, "Invalid Card Number: " + cardNumber, "", "");
        }
        return pwcMigrationDate;
    }

    public static boolean isCorporateCard(Exchange exchange){
        String cardNumber = exchange.getProperty("CardNumber", String.class);
        Pattern corporateCardPattern = Pattern.compile("^[DCP]\\d+$");
        Matcher corporateCardMatcher = corporateCardPattern.matcher(cardNumber);
        if (corporateCardMatcher.matches()) {
            return true;
        }else {
            return false;
        }
    }

    public String setBankCode() {
        return "A00001";
    }

    public void mapCorporatePwcStatusToCmsBlacklistCode(Exchange ex) throws Exception {
        String pwcCorporateStatusCode = ex.getProperty("cbs.powercard.corporate.statusCode", String.class);
        String mappedBlackListCodeFromCorporateStatusCode = Objects.requireNonNull(masterStudio.getMasterDetailsLists("CORPORATE_PWC_BLACKLISTCODE_MAPPING").entrySet().stream()
                .filter(mapEntry -> mapEntry.getValue().get("Key").equals(pwcCorporateStatusCode))
                .findFirst()
                .map(mapEntry -> mapEntry.getValue().get("PWC_BLACKLISTCODE_MAPPING"))
                .orElse("99")); // if status not found in master data table then return 99
        ex.setProperty("cbs.powercard.corporate.blacklistCode", mappedBlackListCodeFromCorporateStatusCode);
    }

    public static void handlePowercardCbsException(Exchange exchange) {
        CBSException exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, CBSException.class);
        ErrorTypeModel powercardErrorModel = exception.getErrorModel();

        // originator, <rc1, rc2>
        Pair<String, Pair<Integer, Integer>> cmsErrorCodes = mapCbsPowercardErrorToCmsError(exchange, powercardErrorModel.getErrorCode());

        exchange.setProperty("OH_OUT_USER_RC1", cmsErrorCodes.getValue().getKey());
        exchange.setProperty("OH_OUT_USER_RC2", cmsErrorCodes.getValue().getValue());
        exchange.setProperty("OH_OUT_ERROR_MESSAGE", powercardErrorModel.getDescription());
        exchange.setProperty("OH_OUT_ERROR_ORIGINATOR", cmsErrorCodes.getKey());
    }

    public static Pair<String, Pair<Integer, Integer>> mapCbsPowercardErrorToCmsError(Exchange exchange, String cbsPowercardError) {
        Pair<String, Pair<Integer, Integer>> cbsErrors;
        String operation = exchange.getProperty("cbs.common.transactionTypeId", String.class);

        if (cbsPowercardError.equals(CardsEdgeConstants.PWC_SYSTEM_ERROR_CODE)) {
            String originator = CardsEdgeConstants.SYSTEM_ERROR_OPERATION_ORIGINATOR_MAPPER.get(operation);
            cbsErrors = Pair.of(originator, Pair.of(995, 130));
        }
        else {
            // originator, rc2
            Pair<String, Integer> opsErrors = CardsEdgeConstants.OPERATIONS_ERROR_CODES_MAPPER.get(operation);
            cbsErrors = Pair.of(opsErrors.getLeft(), Pair.of(Integer.parseInt(cbsPowercardError), opsErrors.getRight()));
        }

        return cbsErrors;
    }

    public void mapPwcStatusToCmsBlacklistCode(Exchange ex) throws Exception {
        String pwcStatusCode = ex.getProperty("PwcStatusCode", String.class);
        String pwcStatusReason = ex.getProperty("PwcStatusReason", String.class);
        String pwcStatus = pwcStatusCode + "," + pwcStatusReason;
        Map<String, String> pwcStatusToBlackListCodeMap = masterStudio.getMasterDetailsByItemNameLists("PWC_BLACKLISTCODE_MAPPING", pwcStatus);
        ex.setProperty("MappedCmsBlacklistCode", pwcStatusToBlackListCodeMap.get("PowercardBlacklistCodes"));
    }

}
