package gr.alpha.cbs.fuse.cardsedge.ws;

import gr.alpha.cbs.fuse.common.CBSConstants;
import gr.alpha.cbs.fuse.service.RESTAPIHelper;
import gr.alpha.cbs.fuse.service.ResponseLayout;
import org.w3c.dom.Element;

import java.util.HashMap;
import java.util.Map;

public class PowercardInquiryRESTImpl implements RESTAPIHelper {

	@Override
	public Map<String, Object> getHeaders(String operation, Element requestRootElement) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put(CBSConstants.HEADER_USE_GLOBAL_FAILURE_HANDLER, true);
		map.put(CBSConstants.HEADER_USE_GLOBAL_PREPARE_BUN_HANDLER, true);
		map.put(CBSConstants.HEADER_USE_GLOBAL_CALL_SUCESS, false);
		map.put(CBSConstants.HEADER_XSD_PATHS, new String [] {"/wsdl/xsd/powercard-inquiry.xsd"});
		Map<String, String> jtaTransactionTimeoutMap = new HashMap<>();
		jtaTransactionTimeoutMap.put("GetCardDetails", "3");
		jtaTransactionTimeoutMap.put("GetCorporateInfo", "3");
		jtaTransactionTimeoutMap.put("GetMulticardDetails", "3");
		jtaTransactionTimeoutMap.put("SearchAuthorization", "3");
		jtaTransactionTimeoutMap.put("SearchTransactions", "3");
		map.put("jtaTransactionTimeout", jtaTransactionTimeoutMap);
		map.put("responseRootTag", operation + "Response");
		return map;
	}

	@Override
	public void setServiceOperationInfo(String flowName, String operation, Map<String, Object> header) {
		header.put(CBSConstants.HEADER_TRANSACTION_NAME, operation);
		header.put(CBSConstants.HEADER_TRANSACTION_FLOW, flowName);
		header.put(CBSConstants.HEADER_TRANSACTION_SERVICE, "CardsEdge");
		header.put(CBSConstants.HEADER_SYSTEM_ID, CBSConstants.SYSTEM_ID_ESB);
	}

	@Override
	public String getConsumer(String operation) {
		return "direct:leanStart";
	}

	@Override
	public ResponseLayout keepRootElement() {
		return ResponseLayout.WRAP_UNWRAP;
	}
}
