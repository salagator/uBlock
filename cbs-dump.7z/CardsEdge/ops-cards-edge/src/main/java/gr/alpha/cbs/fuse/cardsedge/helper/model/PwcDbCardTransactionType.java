
package gr.alpha.cbs.fuse.cardsedge.helper.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PwcDbCardTransactionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PwcDbCardTransactionType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CardNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TransactionDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PostingDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TransactionCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MerchantName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MerchantCity" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MerchantCountry" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MerchantCategoryCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MerchantId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CardHolderAmountSign" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CardHolderAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CardHolderCurrency" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ForeignTransactionAmountSign" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ForeignTransactionAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ForeignTransactionCurrency" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TransactionTime" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TransactionTimestamp" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TransactionRefNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TransactionSeqNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="RecurringInd" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="OriginatingChannel" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CPSTransactionID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="IssuerCorporateID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ProcessingCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="FastFundsIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PosData" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TokenRequestorID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PwcDbCardTransactionType", propOrder = {
    "cardNumber",
    "transactionDate",
    "postingDate",
    "transactionCode",
    "merchantName",
    "merchantCity",
    "merchantCountry",
    "merchantCategoryCode",
    "merchantId",
    "cardHolderAmountSign",
    "cardHolderAmount",
    "cardHolderCurrency",
    "foreignTransactionAmountSign",
    "foreignTransactionAmount",
    "foreignTransactionCurrency",
    "transactionTime",
    "transactionTimestamp",
    "transactionRefNumber",
    "transactionSeqNumber",
    "recurringInd",
    "originatingChannel",
    "cpsTransactionID",
    "issuerCorporateID",
    "processingCode",
    "fastFundsIndicator",
    "posData",
    "tokenRequestorID",
    "paymentID",
    "creditCardOpenLoadNumber",
    "transactionStatusReasonCode",
    "transactionRefSeqNumber",
    "acquirerInstitutionCode",
    "importID",
})
public class PwcDbCardTransactionType {

    @XmlElement(name = "CardNumber", required = true)
    protected String cardNumber;
    @XmlElement(name = "TransactionDate", required = true)
    protected String transactionDate;
    @XmlElement(name = "PostingDate", required = true)
    protected String postingDate;
    @XmlElement(name = "TransactionCode", required = true)
    protected String transactionCode;
    @XmlElement(name = "MerchantName", required = true)
    protected String merchantName;
    @XmlElement(name = "MerchantCity", required = true)
    protected String merchantCity;
    @XmlElement(name = "MerchantCountry", required = true)
    protected String merchantCountry;
    @XmlElement(name = "MerchantCategoryCode", required = true)
    protected String merchantCategoryCode;
    @XmlElement(name = "MerchantId", required = true)
    protected String merchantId;
    @XmlElement(name = "CardHolderAmountSign", required = true)
    protected String cardHolderAmountSign;
    @XmlElement(name = "CardHolderAmount", required = true)
    protected String cardHolderAmount;
    @XmlElement(name = "CardHolderCurrency", required = true)
    protected String cardHolderCurrency;
    @XmlElement(name = "ForeignTransactionAmountSign", required = true)
    protected String foreignTransactionAmountSign;
    @XmlElement(name = "ForeignTransactionAmount", required = true)
    protected String foreignTransactionAmount;
    @XmlElement(name = "ForeignTransactionCurrency", required = true)
    protected String foreignTransactionCurrency;
    @XmlElement(name = "TransactionTime", required = true)
    protected String transactionTime;
    @XmlElement(name = "TransactionTimestamp", required = true)
    protected String transactionTimestamp;
    @XmlElement(name = "TransactionRefNumber", required = true)
    protected String transactionRefNumber;
    @XmlElement(name = "TransactionSeqNumber", required = true)
    protected String transactionSeqNumber;
    @XmlElement(name = "RecurringInd", required = true)
    protected String recurringInd;
    @XmlElement(name = "OriginatingChannel", required = true)
    protected String originatingChannel;
    @XmlElement(name = "CPSTransactionID", required = true)
    protected String cpsTransactionID;
    @XmlElement(name = "IssuerCorporateID", required = true)
    protected String issuerCorporateID;
    @XmlElement(name = "ProcessingCode", required = true)
    protected String processingCode;
    @XmlElement(name = "FastFundsIndicator", required = true)
    protected String fastFundsIndicator;
    @XmlElement(name = "PosData", required = true)
    protected String posData;
    @XmlElement(name = "TokenRequestorID", required = true)
    protected String tokenRequestorID;
    @XmlElement(name = "PaymentID", required = true)
    protected String paymentID;
    @XmlElement(name = "CreditCardOpenLoadNumber", required = true)
    protected String creditCardOpenLoadNumber;
    @XmlElement(name = "TransactionStatusReasonCode", required = true)
    protected String transactionStatusReasonCode;
    @XmlElement(name = "TransactionRefSeqNumber", required = true)
    protected String transactionRefSeqNumber;
    @XmlElement(name = "AcquirerInstitutionCode", required = true)
    protected String acquirerInstitutionCode;
    @XmlElement(name = "ImportID", required = true)
    protected String importID;
    /**
     * Gets the value of the cardNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardNumber() {
        return cardNumber;
    }

    /**
     * Sets the value of the cardNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardNumber(String value) {
        this.cardNumber = value;
    }

    /**
     * Gets the value of the transactionDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionDate() {
        return transactionDate;
    }

    /**
     * Sets the value of the transactionDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionDate(String value) {
        this.transactionDate = value;
    }

    /**
     * Gets the value of the postingDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostingDate() {
        return postingDate;
    }

    /**
     * Sets the value of the postingDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostingDate(String value) {
        this.postingDate = value;
    }

    /**
     * Gets the value of the transactionCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionCode() {
        return transactionCode;
    }

    /**
     * Sets the value of the transactionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionCode(String value) {
        this.transactionCode = value;
    }

    /**
     * Gets the value of the merchantName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMerchantName() {
        return merchantName;
    }

    /**
     * Sets the value of the merchantName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMerchantName(String value) {
        this.merchantName = value;
    }

    /**
     * Gets the value of the merchantCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMerchantCity() {
        return merchantCity;
    }

    /**
     * Sets the value of the merchantCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMerchantCity(String value) {
        this.merchantCity = value;
    }

    /**
     * Gets the value of the merchantCountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMerchantCountry() {
        return merchantCountry;
    }

    /**
     * Sets the value of the merchantCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMerchantCountry(String value) {
        this.merchantCountry = value;
    }

    /**
     * Gets the value of the merchantCategoryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMerchantCategoryCode() {
        return merchantCategoryCode;
    }

    /**
     * Sets the value of the merchantCategoryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMerchantCategoryCode(String value) {
        this.merchantCategoryCode = value;
    }

    /**
     * Gets the value of the merchantId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMerchantId() {
        return merchantId;
    }

    /**
     * Sets the value of the merchantId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMerchantId(String value) {
        this.merchantId = value;
    }

    /**
     * Gets the value of the cardHolderAmountSign property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardHolderAmountSign() {
        return cardHolderAmountSign;
    }

    /**
     * Sets the value of the cardHolderAmountSign property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardHolderAmountSign(String value) {
        this.cardHolderAmountSign = value;
    }

    /**
     * Gets the value of the cardHolderAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardHolderAmount() {
        return cardHolderAmount;
    }

    /**
     * Sets the value of the cardHolderAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardHolderAmount(String value) {
        this.cardHolderAmount = value;
    }

    /**
     * Gets the value of the cardHolderCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardHolderCurrency() {
        return cardHolderCurrency;
    }

    /**
     * Sets the value of the cardHolderCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardHolderCurrency(String value) {
        this.cardHolderCurrency = value;
    }

    /**
     * Gets the value of the foreignTransactionAmountSign property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getForeignTransactionAmountSign() {
        return foreignTransactionAmountSign;
    }

    /**
     * Sets the value of the foreignTransactionAmountSign property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForeignTransactionAmountSign(String value) {
        this.foreignTransactionAmountSign = value;
    }

    /**
     * Gets the value of the foreignTransactionAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getForeignTransactionAmount() {
        return foreignTransactionAmount;
    }

    /**
     * Sets the value of the foreignTransactionAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForeignTransactionAmount(String value) {
        this.foreignTransactionAmount = value;
    }

    /**
     * Gets the value of the foreignTransactionCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getForeignTransactionCurrency() {
        return foreignTransactionCurrency;
    }

    /**
     * Sets the value of the foreignTransactionCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForeignTransactionCurrency(String value) {
        this.foreignTransactionCurrency = value;
    }

    /**
     * Gets the value of the transactionTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionTime() {
        return transactionTime;
    }

    /**
     * Sets the value of the transactionTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionTime(String value) {
        this.transactionTime = value;
    }

    /**
     * Gets the value of the transactionTimestamp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionTimestamp() {
        return transactionTimestamp;
    }

    /**
     * Sets the value of the transactionTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionTimestamp(String value) {
        this.transactionTimestamp = value;
    }

    /**
     * Gets the value of the transactionRefNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionRefNumber() {
        return transactionRefNumber;
    }

    /**
     * Sets the value of the transactionRefNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionRefNumber(String value) {
        this.transactionRefNumber = value;
    }

    /**
     * Gets the value of the transactionSeqNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionSeqNumber() {
        return transactionSeqNumber;
    }

    /**
     * Sets the value of the transactionSeqNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionSeqNumber(String value) {
        this.transactionSeqNumber = value;
    }

    /**
     * Gets the value of the recurringInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecurringInd() {
        return recurringInd;
    }

    /**
     * Sets the value of the recurringInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecurringInd(String value) {
        this.recurringInd = value;
    }

    /**
     * Gets the value of the originatingChannel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginatingChannel() {
        return originatingChannel;
    }

    /**
     * Sets the value of the originatingChannel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginatingChannel(String value) {
        this.originatingChannel = value;
    }

    /**
     * Gets the value of the cpsTransactionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPSTransactionID() {
        return cpsTransactionID;
    }

    /**
     * Sets the value of the cpsTransactionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPSTransactionID(String value) {
        this.cpsTransactionID = value;
    }

    /**
     * Gets the value of the issuerCorporateID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssuerCorporateID() {
        return issuerCorporateID;
    }

    /**
     * Sets the value of the issuerCorporateID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssuerCorporateID(String value) {
        this.issuerCorporateID = value;
    }

    /**
     * Gets the value of the processingCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessingCode() {
        return processingCode;
    }

    /**
     * Sets the value of the processingCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessingCode(String value) {
        this.processingCode = value;
    }

    /**
     * Gets the value of the fastFundsIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFastFundsIndicator() {
        return fastFundsIndicator;
    }

    /**
     * Sets the value of the fastFundsIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFastFundsIndicator(String value) {
        this.fastFundsIndicator = value;
    }

    /**
     * Gets the value of the posData property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPosData() {
        return posData;
    }

    /**
     * Sets the value of the posData property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPosData(String value) {
        this.posData = value;
    }

    /**
     * Gets the value of the tokenRequestorID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTokenRequestorID() {
        return tokenRequestorID;
    }

    /**
     * Sets the value of the tokenRequestorID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTokenRequestorID(String value) {
        this.tokenRequestorID = value;
    }

    /**
     * Gets the value of the paymentID property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getPaymentID() {
        return paymentID;
    }

    /**
     * Sets the value of the paymentID property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setPaymentID(String value) {
        this.paymentID = value;
    }

    /**
     * Gets the value of the creditCardOpenLoadNumber property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getCreditCardOpenLoadNumber() {
        return creditCardOpenLoadNumber;
    }

    /**
     * Sets the value of the creditCardOpenLoadNumber property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setCreditCardOpenLoadNumber(String value) {
        this.creditCardOpenLoadNumber = value;
    }

    /**
     * Gets the value of the transactionStatusReasonCode property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getTransactionStatusReasonCode() {
        return transactionStatusReasonCode;
    }

    /**
     * Sets the value of the transactionStatusReasonCode property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setTransactionStatusReasonCode(String value) {
        this.transactionStatusReasonCode = value;
    }

    /**
     * Gets the value of the transactionRefSeqNumber property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getTransactionRefSeqNumber() {
        return transactionRefSeqNumber;
    }

    /**
     * Sets the value of the transactionRefSeqNumber property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setTransactionRefSeqNumber(String value) {
        this.transactionRefSeqNumber = value;
    }

    /**
     * Gets the value of the acquirerInstitutionCode property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getAcquirerInstitutionCode() {
        return acquirerInstitutionCode;
    }

    /**
     * Sets the value of the acquirerInstitutionCode property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setAcquirerInstitutionCode(String value) {
        this.acquirerInstitutionCode = value;
    }

    /**
     * Gets the value of the importID property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getImportID() {
        return importID;
    }

    /**
     * Sets the value of the importID property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setImportID(String value) {
        this.importID = value;
    }

}
