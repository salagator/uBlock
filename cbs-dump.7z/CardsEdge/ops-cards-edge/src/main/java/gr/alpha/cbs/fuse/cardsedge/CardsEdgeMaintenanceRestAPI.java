package gr.alpha.cbs.fuse.cardsedge;

import io.quarkus.runtime.StartupEvent;
import io.quarkus.security.Authenticated;
import io.vertx.core.http.HttpServerRequest;
import jakarta.enterprise.event.Observes;
import io.smallrye.faulttolerance.api.*;
import org.eclipse.microprofile.faulttolerance.*;
import org.jboss.resteasy.reactive.RestResponse;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.UriInfo;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import java.time.temporal.*;

import jakarta.annotation.PostConstruct;

import gr.alpha.cbs.fuse.cardsedge.generated.*;

@Path("/rest-cards-edge-maintenance")
public class CardsEdgeMaintenanceRestAPI extends gr.alpha.cbs.fuse.service.AbstractCamelRouteDrivingRESTAPI {

	public void init(@Observes StartupEvent event) {
		restapiHelper = new gr.alpha.cbs.fuse.cardsedge.ws.CardsEdgeMaintenanceRESTImpl();
		
		super.init();
	}

}
