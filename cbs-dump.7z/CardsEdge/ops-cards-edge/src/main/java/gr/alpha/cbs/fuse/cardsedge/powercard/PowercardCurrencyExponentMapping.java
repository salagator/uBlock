package gr.alpha.cbs.fuse.cardsedge.powercard;

import gr.alpha.cbs.fuse.common.bean.ErrorUtils;
import gr.alpha.cbs.fuse.common.exceptions.CBSException;
import gr.alpha.cbs.fuse.common.exceptions.ErrorTypeModel;
import gr.alpha.cbs.fuse.enums.ConstantErrorMessages;
import gr.alpha.cbs.fuse.support.RemoteDatagridClientHelper;
import io.quarkus.runtime.annotations.RegisterForReflection;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.transaction.Transactional;
import org.apache.camel.Exchange;
import org.eclipse.microprofile.config.ConfigProvider;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

@Named("powercardCurrencyExponentMapping")
@Dependent
@RegisterForReflection
@Transactional(Transactional.TxType.NOT_SUPPORTED)
public class PowercardCurrencyExponentMapping {
    RemoteDatagridClientHelper<String, String> datagridHelper;

    @Inject
    @io.quarkus.agroal.DataSource("cbs-cards-pricing")
    private DataSource cardsPricingDatasource;

    @PostConstruct
    private void postConstruct() {
        this.datagridHelper = new RemoteDatagridClientHelper();
        this.datagridHelper.initCacheManager();
        this.datagridHelper.setCache("powercardCurrencyExponents");
    }

    @PreDestroy
    private void preDestroy() {
        this.datagridHelper.stopCacheManager();
    }

    public void getCurrencyExponent(Exchange exchange) throws SQLException, CBSException {
        String globalBankIssuingCurrency = ConfigProvider.getConfig().getValue("cbs.camel.powercard.globalBankIssuingCurrency", String.class);
        double powercardAmountMultiplier = Math.pow(10, Integer.parseInt(calculateCurrencyExponent(globalBankIssuingCurrency)));
        exchange.setProperty("powercardAmountMultiplier", powercardAmountMultiplier);
    }

    public String calculateCurrencyExponent(String currencyCode) throws SQLException, CBSException {
        String currencyExponent = null;
        String currencyExponentKey = currencyCode;
        if (datagridHelper.getCache() != null) {
            currencyExponent = datagridHelper.get(currencyExponentKey);
            if (currencyExponent == null) {
                updateCurrencyExponentsCache();
                currencyExponent = datagridHelper.get(currencyExponentKey);
            }
        } else {
            ErrorUtils.throwCBSException(null,
                    ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
                    ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
                    PowercardCurrencyExponentMapping.class.getCanonicalName(),
                    ConstantErrorMessages._SQL_EXCEPTION,
                    ErrorTypeModel.SEVERITY_ERROR,
                    "Error while retrieving currency exponents from cache", "", "");
        }
        return currencyExponent;
    }

    private void updateCurrencyExponentsCache() throws SQLException, CBSException {
        Map<String, String> currencyExponents = selectFromDwhCurrencyDimension();
        datagridHelper.putAll(currencyExponents);
    }

    public Map<String, String> selectFromDwhCurrencyDimension() throws SQLException, CBSException{
        Map<String, String> currencyExponents = new HashMap<>();
        try(Connection connection = cardsPricingDatasource.getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT [Currency_Code], [Currency_Exponent] from [CBS_CardsPricing].[dbo].[DWH_CURRENCY_DIMENSION] WITH (NOLOCK)")){
            try(ResultSet resultSet = statement.executeQuery()) {
                while(resultSet.next()){
                    currencyExponents.put(resultSet.getString("Currency_Code"), resultSet.getString("Currency_Exponent"));
                }
            }
        }catch (SQLException e){
            ErrorUtils.throwCBSException(null,
                    ErrorTypeModel.ERROR_TYPE_FUNCTIONAL,
                    ErrorTypeModel.ERROR_SYSTEM_ID_FUSE,
                    PowercardCurrencyExponentMapping.class.getCanonicalName(),
                    ConstantErrorMessages._SQL_EXCEPTION,
                    ErrorTypeModel.SEVERITY_ERROR,
                    "Error while retrieving currency exponents from DB", "", "");
        }
        return currencyExponents;
    }
}
