package gr.alpha.cbs.fuse;

import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.apache.camel.ProducerTemplate;

@Path("/hello")
public class ExampleResource {

    @Inject
    ProducerTemplate template;

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String hello() {
        // Send a message to the direct endpoint
        template.sendBody("direct:start", "Hello from Quarkus REST");
        return "Hello from Quarkus REST";
    }
}
